# Deliverable F — Residual-risk register (corrective round 4)

Every item below is **OPEN**. Nothing here is closed, accepted or certified by this round.

| # | Risk | Status | Why it is still open |
| --- | --- | --- | --- |
| **R1** | SQLite WAL-reset runtime incompatibility (3.7.0–3.51.2 affected; 3.51.3 fixed; backports 3.44.6 / 3.50.7) | **OPEN — blocks certification** | The environment runs SQLite **3.50.4**. The Amendment 1 gate refuses; readiness stays `ready_degraded_runtime_not_supported`. |
| **R2** | Plan R1 (runtime upgrade / backport / vendor provenance) | **OPEN** | A separate deployment gate; not authorized in this task. |
| **R3** | DEBT-045 — hidden-rowid persistence | **OPEN** | Rowid survival across `VACUUM` is not a documented guarantee for this table shape; no rewrite is authorized. |
| **R4** | Physical erasure with `secure_delete` OFF | **OPEN** | A DELETE frees the row but does not overwrite its bytes; the text survives in freed pages, backups and forensic copies. The setting was not changed. |
| **R5** | Advisory locking is not process fencing | **OPEN by disclosure** | Cooperating migrators only; the deployment contract (all processes stopped) remains the protection. |
| **R6** | Backup verification excludes application-owned user tables | **OPEN (W12/F08)** | The verified digest scope is the content table plus schema/trigger/index identity. |
| **R7** | Preservation capacity preflight and source-stability detection | **OPEN (W14/F36)** | R4-03 fixed the manifest lifecycle (F11) — a **different** requirement. The preflight and the change-during-copy detection are still not implemented. |
| **R8** | No dedicated initialization lock | **OPEN (W10/F23/F47/F56)** | Two simultaneous first starts are serialized only by SQLite's own locking. |
| **R9** | Database-path identity not unified across aliases | **OPEN (W19/F51/R51)** | The URI parsing is now correct (R4-01) and the lock identity is safe, but the database path itself is not canonicalised across relative/absolute, symlink, junction and hard-link aliases. |
| **R10** | Stale checkpoint-inventory sidecar measurements | **OPEN (F31)** | The inventory still reports pre-connection sizes for its own figures. |
| **R11** | The Python protection is defence in depth, not an OS sandbox | **OPEN by disclosure** | OS-level isolation is preferable where available. |
| **R12** | Historical production-vault test pollution | **OPEN** | `.data/memory/cognitive/vault_v4.json` still holds three duplicate test-entry pairs; not rewritten. |
| **R13** | The 21 pre-existing failures and 51 errors | **OPEN (pre-existing)** | Identical in the pristine-HEAD clone; not hidden, not fixed here. |
| **R14** | The configuration manager's TOML flush behaviour | **OPEN (pre-existing)** | Contained for tests (`CONFIG_DIR` redirected to a temporary copy); the manager's semantics were not changed. |

## Governance position (unchanged)

**G4 OPEN / NOT ACCEPTED · DEBT-045 OPEN · runtime certification NOT READY · deployment
certification NOT READY.** No freeze, no production deployment authorization, and **no acceptance
decision is issued by the implementation agent.**
