# Deliverable C — Regression and reproduction evidence (corrective round 4)

**Environment:** CPython **3.14.3** · bundled SQLite **3.50.4** (an **affected** engine) · Windows x64
**Source revision:** HEAD `739e58ce185a527d2d2f58c7622c5108f5b0e0db` on `independent/g4-fts-rev3-20261105`
+ the supplied change set (all modifications **uncommitted**).
**Command form:** `python -X utf8 -m pytest <targets> -p no:cacheprovider -q`

## C.1 The reproduction of R4-01 (before the fix)

The defect was demonstrated against the shipped code with the application's own URI form:

```
uri        : file:/C:/Users/.../.data/memory/unified.db?mode=rw
uri->path  : '/C:/Users/.../.data/memory/unified.db'
norm(uri)  : 'c:\\c:\\users\\...\\.data\\memory\\unified.db'
root       : 'c:\\users\\...\\.data\\memory'
protected? : False          <-- the boundary did NOT recognize it
BYPASS for the application's own URI form: True   (in ro, rw AND rwc)
```

After the fix the same URI normalizes to the native path and is recognized as protected; the
regression suite pins this.

## C.2 The new targeted suite (run FIRST)

```
python -X utf8 -m pytest tests\test_g4_r4_corrections.py -p no:cacheprovider -q
```

**Result: 24 passed** — 6 classes / 24 test functions (25 pytest cases after parametrization):

| Class | Cases | Finding |
| --- | ---: | --- |
| `TestR401UriProtection` | 11 | both Windows drive-URI slash forms, UNC authorities, percent-encoded `#`/`?`/`%`/space/Unicode, query-parameter separation, the production root recognized, `ro`/`rw`/`rwc` rejected, the **wrapped** `sqlite3.connect` raising while the underlying connector is **never reached**, the child inheriting the boundary, the child **failing closed** |
| `TestR402JournalModeRepairPreservation` | 3 | A: the snapshot exists and matches the pre-transition hash, the mode becomes WAL, no FTS rebuild / trigger replacement / index recreation / duplicate ledger row; B: an injected preservation failure **refuses** the transition (the mode stays DELETE, the bytes are unchanged, the report names the failed preservation and its location); C: an existing recovery snapshot is **reused** (no second set) |
| `TestR403IncompletePreservation` | 3 | a copy failure on the second artifact: the first is retained with a matching hash, the failed artifact is identified, the destination reaches the caller, the manifest says `incomplete` and lists the verified artifact, the run refuses; a manifest-write failure still discloses the destination and that there is no valid manifest |
| `TestR404JsonContract` | 5 | the missing database, an open failure, an inspection failure, a contract failure (the full 11-item payload) and a success — **every** one parses as JSON and agrees with the exit code |
| `TestR405DisposableCopy` | 2 | the forensic snapshot matches the originals, the original artifacts stay byte-identical, the verdict concerns the copy, the copy is **removed**, the forensic set remains; an injected copy failure still removes the temporary directory |

## C.3 The existing G4 suites (re-run)

```
python -X utf8 -m pytest tests/test_g4_rev3_sqlite_contract.py tests/test_g4_rev3_search_regression.py `
  tests/test_g4_rev3_runtime_gate.py tests/test_g4_rev3_policy_disposition.py `
  tests/test_g4_rev3_mutation_atomicity.py tests/test_g4_rev3_migration_lifecycle.py `
  tests/test_g4_rev3_failure_recovery.py tests/test_g4_indep_trigger_contract.py `
  tests/test_g4_indep_runtime_gate_lower_bound.py tests/test_g4_indep_readonly_diagnostics.py `
  tests/test_g4_indep_post_commit_reporting.py tests/test_g4_indep_conn_lifecycle.py -p no:cacheprovider -q
```
**Result: 138 passed.**

```
python -X utf8 -m pytest tests/test_g4_revg4_remediation.py tests/test_g4_f01_f38_remediation.py `
  tests/test_g4_interaction_scenarios.py tests/test_g4_r4_corrections.py tests/test_unified_memory.py `
  tests/test_cognitive_memory.py tests/test_memory_vault.py tests/test_orchestrator_memory_migration.py `
  tests/test_k2_2_runtime_migration.py tests/test_k2_2_retrieval_cutover.py `
  tests/test_session4b_memory_hardening.py tests/test_session4c_architecture.py -p no:cacheprovider -q
```
**Result: 357 passed.**

Two pre-existing preservation tests were updated to the **R4-03 manifest contract** (the per-artifact
record is now `{source, destination, bytes, sha256, verified, status}` instead of `{copy, …}`); the
assertions were kept and strengthened (`manifest["status"] == "complete"`).

## C.4 The interaction scenarios (A–L)

`tests/test_g4_interaction_scenarios.py` — **12 passed**, with **H** and **I** rewritten for R4-06:
scenario I now establishes the FTS `rank=1` PASS precondition independently and asserts it
**exactly**; scenario H compares the **bytes** of the main file, the WAL, the `-shm` and the journal
before and after, and states the `-shm` claim precisely.

## C.5 Full repository suite and the pristine-HEAD comparison

```
python -X utf8 -m pytest tests -p no:cacheprovider -q --deselect tests/test_live_citation_check.py
```

| Measurement | Pristine-HEAD clone (`739e58c`) | Corrected worktree | Delta |
| --- | ---: | ---: | ---: |
| passed | 2 186 | **2 349** | **+163** (the new tests) |
| failed | 21 | 21 | 0 |
| errors | 51 | 51 | 0 |
| skipped | 27 | 27 | 0 |
| deselected | 36 | 36 | 0 |
| xfailed | 1 | 1 | 0 |

Set-level comparison of the `FAILED`/`ERROR` lines:

```
=== FAILED: baseline=21 working-tree=21 common=21
--- only in WORKING TREE (0):
--- only in BASELINE (0):
=== ERROR: baseline=51 working-tree=51 common=51
--- only in WORKING TREE (0):
--- only in BASELINE (0):
```

**No failure or error was introduced, removed or masked by this round.** The 21 failures and 51
errors are the documented pre-existing ones (Linux seccomp/POSIX tests on Windows, the three
Windows path-separator assertions in `test_check_drift.py`, two `test_ci_test_gate.py` cases, the
Windows path/NUL-byte/symlink-privilege cases, one console-encoding case, and the
`test_module_name_containment.py` errors that need the repository's ignored data directories).

`tests/test_live_citation_check.py` (excluded from the comparison run as a slow in-process harness
suite) was measured separately: **36 passed**.

## C.6 Evidence classification used in this package

| Class | Where it is used |
| --- | --- |
| **REPRODUCED** | R4-01 (the bypass was executed against the shipped code before the fix), R4-02 … R4-06 (each has an executable test) |
| **SOURCE-CONFIRMED** | W10 (the initialization lock is absent — confirmed by source inspection), W12, W19 |
| **NOT VERIFIED** | **F36** — the capacity preflight and the copy-stability detection are NOT implemented and NOT demonstrated |

A test passing does not establish an unrelated invariant, and a test count does not establish the
correctness of the assertions; the register names the evidence for every row.
