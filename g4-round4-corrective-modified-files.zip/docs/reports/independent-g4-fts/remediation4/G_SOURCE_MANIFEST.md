# Deliverable G — Complete source and artifact manifest

**Branch:** `independent/g4-fts-rev3-20261105` · **HEAD:** `739e58ce185a527d2d2f58c7622c5108f5b0e0db` — unchanged; every modification below is **uncommitted**.

**Staged:** 0 · **Working-tree entries:** 30 (18 modified, 12 untracked).

## G.1 Modified tracked files

| Path | Bytes | SHA-256 |
| --- | ---: | --- |
| `KNOWN_ISSUES.md` | 249657 | `56af2c7e6f5efe024b857a4e85eb6add3479d18012b3a6a3b5257a761d91ba2c` |
| `core/memory/backends/sqlite_storage.py` | 30566 | `13bb47e809aee2f13d59f180626d1af794169e48da076a36aacf52000c46d534` |
| `core/memory/cognitive_vault.py` | 4264 | `5de7f0fca133d1552cef253793a8436518c2ae3e4c596bc2828a3ef30604ee4f` |
| `core/memory/graph/graph_engine.py` | 15783 | `d473da72d38d5c35412d29c5ba9029c0fa519e314b9e51ff51527f7ab861e540` |
| `core/memory/sqlite_contract.py` | 37024 | `9e3d08db8d363efc7f769b1c3d554114fdd913445f6460292e0bbd40373ae78d` |
| `core/memory/sqlite_integrity.py` | 51309 | `11562a6a91345f01afe08e91dd37fdaa7ee8b8b76496de3c480f238fa0444d3a` |
| `core/memory/sqlite_migration.py` | 116535 | `907eab07cebe3381e77d9dd3c00ddda5051d55c4eeaa910c83a943cc0d4e8172` |
| `core/memory/unified_memory.py` | 58892 | `96ae01c228eaa76b66f208aa3105ad632cd09d1ee258286d3b5fc066353fcff5` |
| `docs/reports/G4_FTS_REV3_REMEDIATION_REPORT.md` | 80772 | `278d5062a9211f059abe9c868a279648341b24c37e45f0f3390707e1d543bf04` |
| `docs/reports/independent-g4-fts/EVIDENCE_NOTE.md` | 17183 | `640762f4f39f8c4c3eb03dc2139bf6fd97c3f8e7a993ebb27f1d9bd029fcda3e` |
| `docs/reports/independent-g4-fts/HANDOFF.md` | 27283 | `c7190f3d38942ffe1dfc1563bc12a248372c8aacb7625ee3311a6f6f787d465b` |
| `interface/cli.py` | 49848 | `ead26dff6e0c91b8d820058ad5b97a7c03899571d9ae1d977a6cad5d868bd13a` |
| `tests/_crash_restart_child.py` | 4176 | `e381179bbe755d90998de6c3505de25326286c797db042e40e68b7eb1501b774` |
| `tests/conftest.py` | 8544 | `0f012c9e5d2def4bafd9506d18e09352bb3cf0afe172ed684a6789d2a163d8fd` |
| `tests/test_g4_indep_trigger_contract.py` | 13935 | `746a8a66707d695380a81c98b4e8e3c3897f0a4226b83c00a7fdafa8daab2492` |
| `tests/test_g4_rev3_mutation_atomicity.py` | 14588 | `a9b9fbbafb58ce71e7b4eb39cd9c776073ff30479d785c8cc71d3207727f29a6` |
| `tests/test_g4_rev3_search_regression.py` | 13945 | `3025fe5651737407a703a1049e3224f67c4ce4c89406c6b7776363cc8ed73570` |
| `tests/test_g4_rev3_sqlite_contract.py` | 30359 | `ffc7da62472f5ddeec4914db91591992db485c72003c4ddfc0f612303dc164df` |

## G.2 New files and directories

| Path | Bytes | Files | SHA-256 |
| --- | ---: | ---: | --- |
| `docs/reports/independent-g4-fts/remediation2//` | 88428 | 32 | (per-file hashes below) |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/A_FINDINGS_REGISTER.md` | 21003 | 1 | `835a902f8f9c08239f8dcc744e98b76290bc4968fe1199cddc0dacfad20c416f` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/B_REPRODUCTION_EVIDENCE.md` | 7125 | 1 | `9371f901d4e04dcc6b3fd6786e7ccee1c24b3833ce695db760c70121badf4d9d` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/C_CORRECTION_RECORD.md` | 11096 | 1 | `aaff1cce734d24a62f7f419e9d79380539da39a9949ece067e32f8633394e4f3` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/D_REGRESSION_TESTS.md` | 5892 | 1 | `0707943b955c230f761a106cb4b98f525182f6e47241abd860f0808f8fed41e3` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/E_TEST_EXECUTION_EVIDENCE.md` | 10345 | 1 | `c6cd1072c0a95178a89cfb2926d53343dcf2a9f2f6a868399f518ea91879a8ed` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/postfix/postfix_p01_doctor_leaves_wal_untouched.txt` | 674 | 1 | `e21479da401b44656eee98388e4a2b7085107e75fb79c905096e7e2294bd3eb8` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/postfix/postfix_p02_unsupported_db_not_converted.txt` | 496 | 1 | `f552ac786c2504df31171cefa76ab797bdb5f56583ca276369a644ea003f80a2` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/postfix/postfix_p03_index_drift_detected_and_repaired.txt` | 484 | 1 | `5d18c6ed6560e6ccd76b5ced66b5b0fa9b576cbfe97512cbf27aa9c6ca425a16` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/postfix/postfix_p03b_wrong_definition_rejected.txt` | 389 | 1 | `5fb15f164fbdc6fd62c3bd9f64721672ebe96345807845a7b1ccc95c0502f2cd` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/postfix/postfix_p04_missing_target_never_created.txt` | 463 | 1 | `8e5307d4d89551f1349921a05ce4232acfc323f6cb4ff6b5c08663ea5c620861` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/postfix/postfix_p05_backup_missing_source_not_created.txt` | 676 | 1 | `3ca76367dee5601471ea16596e314d315f2334fceebe23ac3d424473b4890933` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/postfix/postfix_p06_journal_is_preserved.txt` | 519 | 1 | `943f32aa61ce5c5c759fae78647cdb0af0bd1e6cfed7984aead2fc5aa4fbe37f` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/postfix/postfix_p07a_inspection_connection_closed.txt` | 532 | 1 | `8aef6682808d3d26d43c664913e15398ee6a1da0f83ec6499d65371391dc54c3` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/postfix/postfix_p07b_delete_mode_database_refused.txt` | 706 | 1 | `2b3b2c9a4a43b3ca217f06225f65530d33783a54d63cbcf525965dc386628cdb` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/postfix/postfix_p08_doctor_reports_unavailable_truthfully.txt` | 475 | 1 | `1f3f03a986e2cc590308655fa8de444cfbc71c636a581470a912da2e5af6afd2` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/stage1/repro_revg4_01a_checkpoint_inventory_wal_mutation.txt` | 1254 | 1 | `8ad682b2d2610c3b2011a47eac2e87c125765f64073e4e8273633a41fcf55467` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/stage1/repro_revg4_01b_doctor_cli_wal_mutation.txt` | 1982 | 1 | `42d975dbc19d292bd58d2994ac58f586c749a329e915433fb17de2c0a979f244` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/stage1/repro_revg4_01c_doctor_rw_fallback.txt` | 638 | 1 | `ce3457c2637d24b1e01e447209f624e5c363c43490719a78ab2f07d74afcbc49` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/stage1/repro_revg4_02_unsupported_delete_converted_to_wal.txt` | 1286 | 1 | `085c8cf0aca15767448c6204d47d41b4aba6bca8e82ec6e5cd5ec5dd1d910678` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/stage1/repro_revg4_03a_missing_index_already_applied.txt` | 1230 | 1 | `d229c11137c9bde6f9a047c6cea59335662911f2f5af3d0d1a0b623406dacd30` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/stage1/repro_revg4_03b_wrong_index_definition_passes_readiness.txt` | 737 | 1 | `8dacaa52eeb32bfba1cb003b48d1eedd695ba3dc271180c99722939fc421121c` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/stage1/repro_revg4_04a_estimate_creates_missing_db.txt` | 502 | 1 | `297e63b979bbc83ed6086e8ce63a8616aa8afed99b5716b2ac084c9fd77947fa` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/stage1/repro_revg4_04b_runner_missing_path_creates_then_fails.txt` | 1324 | 1 | `40810fc2191dc815dca7e3cee96ab78591b617e88fece51b7135e48cc94f2418` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/stage1/repro_revg4_04c_runner_zero_byte_target.txt` | 1017 | 1 | `49d8f62fda076e4ccf63e0096038ce696f0649e46442c7285b0faac606a7e471` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/stage1/repro_revg4_05_backup_missing_source.txt` | 619 | 1 | `cd8e212f705c61bf5fca8aaa1401f971e9a4edcf1dc100c8603cb28947f7b184` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/stage1/repro_revg4_06a_preservation_omits_journal.txt` | 581 | 1 | `72ce08fdf9339565ef6b122c81268024cd0c07b012379b5ed9d64abe7e594e55` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/stage1/repro_revg4_06b_preservation_after_recovery.txt` | 1083 | 1 | `5eb08ab6b24627ddcfd9e9dd06ffe565f5c59e24a914d47e277a66e8d4d0d10f` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/stage1/repro_revg4_07a_unclosed_inspection_connection.txt` | 1110 | 1 | `7de6a99f85bbf13aab0acaa0e22ba4b9ac67ad9e7541ac22558618a25b7ea3cc` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/stage1/repro_revg4_07b_silent_wal_reconversion.txt` | 757 | 1 | `22a9abefe53f03ae2c0cb67f32785dd0b2f74cdb1fdb2ca88f016659dc3e75b7` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/evidence/stage1/repro_revg4_07d_singleton_default_prefix.txt` | 753 | 1 | `f3102ba434b00e5836b48bd7d255e93d019103f3728adc7d248326efd97388b5` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/F_RUNTIME_CERTIFICATION_RECORD.md` | 4458 | 1 | `0c7810c7610f42dc0cba5c1ff5936b0410526d085740fd138353b2b93c5ddd96` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation2/G_FRESH_REVIEWER_HANDOFF.md` | 8222 | 1 | `a1f9a63b1633dfc9f7012171e331f4def7e990f99a57b94bcaffeda7d49902be` |
| `docs/reports/independent-g4-fts/remediation3//` | 90600 | 9 | (per-file hashes below) |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation3/A_FINDINGS_REGISTER.md` | 14188 | 1 | `0087745d067bff5b164595c1b6f1f956a9d811ef5b8c7d6c5017377271f2e8fe` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation3/B_IMPLEMENTATION_REPORT.md` | 5533 | 1 | `5b5f405815fac62221dcb0212edc69a48042eb39f30537a27b8e0cd8045c8779` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation3/C_REGRESSION_EVIDENCE.md` | 9832 | 1 | `95de0d5cef31a166d00fdc639e824ff734acb4647b4ac5fbd03eb13abb70eb37` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation3/CHANGES.md` | 26840 | 1 | `16ae308462911f583fd95037f3a256924188234921d1b959be4b7e65e5ae4c40` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation3/D_DATABASE_SAFETY_EVIDENCE.md` | 9040 | 1 | `d78adda39c1ac400a2689e1a4e67cf761df4e8426fbc0469d3cea45ff2d54717` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation3/E_DOCUMENTATION_RECONCILIATION.md` | 6078 | 1 | `1d8fb0cc09498443693813d60c935ba0c580cd4b3f1e1631e72f90e35fcf1f74` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation3/F_RESIDUAL_RISK_REGISTER.md` | 5431 | 1 | `25d5e6cc6b3edc999e95e77b98f246086be94d136d6dc4bbc9534dea9b053af6` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation3/G_SOURCE_MANIFEST.md` | 5262 | 1 | `adfdd31276d17d0738695f14ba6617d8674cd67d93a30ca865fc3bb6debea03a` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation3/H_FRESH_REVIEW_HANDOFF.md` | 8396 | 1 | `9f7b07e39bb5c982c14c0ccb05840ede412ad756a388ab7c4d44b392e70e8eb2` |
| `docs/reports/independent-g4-fts/remediation4//` | 120266 | 10 | (per-file hashes below) |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation4/A_FINDINGS_REGISTER.md` | 32330 | 1 | `7535825fd5edc81118ff0f228c021d6399092f0772407ce0b99b39e7fc867eae` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation4/B_IMPLEMENTATION_REPORT.md` | 6884 | 1 | `9907067293b35f2a8f40955f596dac37c41e987c3dd219b378acd231efdcaa44` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation4/C_REGRESSION_EVIDENCE.md` | 6981 | 1 | `ad95e978d34b39e370d93dc21b033d897a1ace13aff7a7055cc04b7b1f5c965d` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation4/crosswalk.json` | 37223 | 1 | `16c54a67e6184cd581285a0c1e267139963a4c8bf3a5c164e323e4d05e381f0a` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation4/D_DATABASE_SAFETY_EVIDENCE.md` | 3369 | 1 | `87120a9c068e9f848020831e14605295ec380f5e58c1face15c8d6750a1b7aa4` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation4/E_DOCUMENTATION_RECONCILIATION.md` | 2489 | 1 | `13e81ac59c14d4f6f9038ffe614d5fc85161d2ea73ebbcd7525a1450d4d9a7a5` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation4/F_RESIDUAL_RISK_REGISTER.md` | 3207 | 1 | `ad56040b0f782c4e8b0b29164f9b83713b56706930f6e68b1aa4cff2082eaccf` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation4/G_SOURCE_MANIFEST.md` | 20633 | 1 | `2923bb092a2f892368c25c6fbb20bb7febae9183bd6032a2ad31ed2eabd1e1ee` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation4/H_FRESH_REVIEW_HANDOFF.md` | 5749 | 1 | `0bb94e32f133eadb9a52b96a118e072c98affc0f326825182cb5f147e4c40f84` |
| &nbsp;&nbsp;`docs/reports/independent-g4-fts/remediation4/README.md` | 1401 | 1 | `2dfcc0165c4507b0eabb790f4275303f5361c45cae4a92368bcffaa58196b828` |
| `modules/test_rce001_name_tmp//` | 191944 | 3 | (per-file hashes below) |
| &nbsp;&nbsp;`modules/test_rce001_name_tmp/__init__.py` | 0 | 1 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| &nbsp;&nbsp;`modules/test_rce001_name_tmp/knowledge.db/chroma.sqlite3` | 188416 | 1 | `05c8d4cc3e23ce695c6dee4dbb60cd1597256911ca31739a59761d73af32bd80` |
| &nbsp;&nbsp;`modules/test_rce001_name_tmp/module.py` | 3528 | 1 | `a5bfd7c425374fd920de847d39781b68ced10e2382a22b67f229b9a271ff5543` |
| `modules/test_rce001_tmp//` | 192152 | 3 | (per-file hashes below) |
| &nbsp;&nbsp;`modules/test_rce001_tmp/__init__.py` | 0 | 1 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| &nbsp;&nbsp;`modules/test_rce001_tmp/knowledge.db/chroma.sqlite3` | 188416 | 1 | `2849c2384b519f94c83ec1188effba5d471eb31ea18fce14331a4972062201e0` |
| &nbsp;&nbsp;`modules/test_rce001_tmp/module.py` | 3736 | 1 | `b5fb8bee4ac8f6d231e69221621c116642898a7099e8dbdc11c971c318d68be8` |
| `scripts/g4_indep/probe_revg4_stage1_repro.py` | 26410 | 1 | `31e8d32619dcf5f31b0cc47e4ca8d1e880f0d7738c4831b3cee7447c6c3d81d5` |
| `scripts/g4_indep/probe_revg4_stage2_postfix.py` | 16189 | 1 | `8f5e6af18730512914b5136dcf1d53d834483e2dfd4612e1e90080cea8083709` |
| `tests/_g4_protection.py` | 14998 | 1 | `cb4952f01dd721dc861f41787c642ea9000db6485d8b748ac494084903190838` |
| `tests/test_g4_f01_f38_remediation.py` | 35019 | 1 | `92eaf8397e3286a5d4515e5b8c308e06d645749b1ef65a09fbb099d6b99eeeae` |
| `tests/test_g4_interaction_scenarios.py` | 20333 | 1 | `b3b3188416b2e71381e8a8c323a757882cb4f62ff0fca06b59181d234ce50c01` |
| `tests/test_g4_r4_corrections.py` | 24180 | 1 | `4f004b9110a108a8bb67b6cdaa5bb0c7635179a9efce3c238a55f0353a6f5718` |
| `tests/test_g4_revg4_remediation.py` | 46438 | 1 | `b9ce5f51721a3da310822499a182c028a02d7f6643bb86f83fda6ec17fd0196f` |

## G.3 Change statistics (tracked files)

```
 KNOWN_ISSUES.md                                  |  108 ++
 core/memory/backends/sqlite_storage.py           |  106 +-
 core/memory/cognitive_vault.py                   |   13 +-
 core/memory/graph/graph_engine.py                |   10 +-
 core/memory/sqlite_contract.py                   |  619 +++++++-
 core/memory/sqlite_integrity.py                  |  684 ++++++++-
 core/memory/sqlite_migration.py                  | 1746 +++++++++++++++++++---
 core/memory/unified_memory.py                    |   25 +-
 docs/reports/G4_FTS_REV3_REMEDIATION_REPORT.md   |  358 ++++-
 docs/reports/independent-g4-fts/EVIDENCE_NOTE.md |   29 +-
 docs/reports/independent-g4-fts/HANDOFF.md       |  169 +++
 interface/cli.py                                 |  673 +++++++--
 tests/_crash_restart_child.py                    |   22 +
 tests/conftest.py                                |  182 ++-
 tests/test_g4_indep_trigger_contract.py          |   27 +-
 tests/test_g4_rev3_mutation_atomicity.py         |   36 +-
 tests/test_g4_rev3_search_regression.py          |   74 +-
 tests/test_g4_rev3_sqlite_contract.py            |   67 +-
 18 files changed, 4469 insertions(+), 479 deletions(-)
```

## G.4 Removed files

**None.** No file was deleted or renamed in this round. The two untracked test by-product directories (`modules/test_rce001_name_tmp/`, `modules/test_rce001_tmp/`) pre-date this work and were left in place (deleting untracked files is out of bounds).


## G.5 Git and governance operations performed

**None.** No branch was created or switched, nothing was staged, committed, pushed, rebased or merged; no PR was opened, updated or closed; no issue or governance decision was touched. No `git clean`, `git reset --hard`, broad restore or `git add -A` was used — only narrow, path-specific `git checkout --` of test-run byproducts (chroma fixtures, tracked `.pyc`).


## G.6 Commands and results (round 4)

# targeted (new round-4 suite):
python -X utf8 -m pytest tests\test_g4_r4_corrections.py -p no:cacheprovider -q
#   -> 24 passed
# the G4 Rev 3 gate suites:
python -X utf8 -m pytest tests/test_g4_rev3_sqlite_contract.py tests/test_g4_rev3_search_regression.py \
  tests/test_g4_rev3_runtime_gate.py tests/test_g4_rev3_policy_disposition.py \
  tests/test_g4_rev3_mutation_atomicity.py tests/test_g4_rev3_migration_lifecycle.py \
  tests/test_g4_rev3_failure_recovery.py tests/test_g4_indep_trigger_contract.py \
  tests/test_g4_indep_runtime_gate_lower_bound.py tests/test_g4_indep_readonly_diagnostics.py \
  tests/test_g4_indep_post_commit_reporting.py tests/test_g4_indep_conn_lifecycle.py \
  -p no:cacheprovider -q
#   -> 138 passed
# the corrective suites + memory-adjacent:
python -X utf8 -m pytest tests/test_g4_revg4_remediation.py tests/test_g4_f01_f38_remediation.py \
  tests/test_g4_interaction_scenarios.py tests/test_g4_r4_corrections.py tests/test_unified_memory.py \
  tests/test_cognitive_memory.py tests/test_memory_vault.py tests/test_orchestrator_memory_migration.py \
  tests/test_k2_2_runtime_migration.py tests/test_k2_2_retrieval_cutover.py \
  tests/test_session4b_memory_hardening.py tests/test_session4c_architecture.py -p no:cacheprovider -q
#   -> 357 passed
# the full repository suite (the slow network-bound harness file is measured separately):
python -X utf8 -m pytest tests -p no:cacheprovider -q --deselect tests/test_live_citation_check.py
#   -> 21 failed, 2349 passed, 27 skipped, 36 deselected, 1 xfailed, 51 errors
python -X utf8 -m pytest tests/test_live_citation_check.py -p no:cacheprovider -q
#   -> 36 passed
# the pristine-HEAD baseline comparison (a git clone of 739e58c):
python -X utf8 -m pytest tests -p no:cacheprovider -q --deselect tests/test_live_citation_check.py
#   -> 21 failed, 2186 passed, 27 skipped, 36 deselected, 1 xfailed, 51 errors
# the crosswalk generator (validates that all 98 identifiers appear exactly once):
python -X utf8 build_crosswalk.py && python -X utf8 render_register.py