# Deliverable E — Documentation reconciliation (corrective round 4)

**Method:** dated, additive superseding sections. The third-round package (`remediation3/`) is kept
**immutable** as a historical review target; this round adds `remediation4/`.

| Document | Problem corrected | Correction | Evidence |
| --- | --- | --- | --- |
| `docs/reports/G4_FTS_REV3_REMEDIATION_REPORT.md` | no record of the fourth corrective round | new dated **§18** with the R4-01…R4-06 dispositions, the reconciled totals and the explicit non-claims | §18 |
| `docs/reports/independent-g4-fts/HANDOFF.md` | the third-round handoff (§9) references the **older** 50-entry archive (`g4-revg4-remediation-modified-files.zip`, `2D73E808…`) as if it were the current package | new dated **§10** naming the **current** archive (`g4-f01-f38-corrective-modified-files.zip`, `24af8d0e…`, 65 entries) and stating the relationship between the two; the older archive is identified as the **second-round** package | §10 |
| `docs/reports/independent-g4-fts/remediation3/A_FINDINGS_REGISTER.md` | the headline said 18 FIXED / 6 PARTIAL while its own table said 20 / 4 | **superseded** by `remediation4/A_FINDINGS_REGISTER.md` (generated, deterministic, 98 identifiers each exactly once) | remediation4 §A.1 |
| `docs/reports/independent-g4-fts/remediation3/F_RESIDUAL_RISK_REGISTER.md` | F31/F36/F10/F11/F23/F26/F28 carried conflicting aggregate statuses | **superseded** by `remediation4/F_RESIDUAL_RISK_REGISTER.md`; each conflicting finding is now split into its sub-claims with an explicit overall disposition | remediation4 §A.4 |
| `docs/reports/independent-g4-fts/remediation3/E_DOCUMENTATION_RECONCILIATION.md` | third-round reconciliation only | **superseded** by this document | this file |
| `KNOWN_ISSUES.md` | no pointer to the fourth round | dated pointer added (DEBT-045 OPEN, the erasure caveat unchanged, the production-data boundary now covers the URI bypass) | the addendum |
| `docs/reports/independent-g4-fts/remediation3/CHANGES.md` | third-round implementation detail | **superseded** by `remediation4/B_IMPLEMENTATION_REPORT.md`; the third-round file is retained unchanged | remediation4 §B |

**Corrections that were deliberately NOT applied:** no historical report was rewritten, the 246-test
and third-round evidence records stay as history, the 21 pre-existing failures and 51 errors stay
visible, and the historical production-vault pollution is not "cleaned".
