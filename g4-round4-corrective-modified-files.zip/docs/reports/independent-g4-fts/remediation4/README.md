# Corrective round 4 — review entry point

**Start here.** This directory is the self-contained package for the fourth corrective round of
the G4-FTS Rev 3 workstream.

| Deliverable | Content |
| --- | --- |
| `A_FINDINGS_REGISTER.md` | the authoritative consolidated crosswalk: 98 identifiers (F01–F38, F39–F56, R39–R56, W01–W24), each exactly once, with the current disposition, the evidence class, the regression test and the residual risk |
| `B_IMPLEMENTATION_REPORT.md` | what changed for R4-01 … R4-06, file by file |
| `C_REGRESSION_EVIDENCE.md` | the exact commands, the environment and the counts |
| `D_DATABASE_SAFETY_EVIDENCE.md` | production hashes before/after and the boundary's coverage |
| `E_DOCUMENTATION_RECONCILIATION.md` | every corrected inconsistency, with the superseding reference |
| `F_RESIDUAL_RISK_REGISTER.md` | the OPEN risks (unchanged or still open) |
| `G_SOURCE_MANIFEST.md` | every changed/created file with sizes and SHA-256 |
| `H_FRESH_REVIEW_HANDOFF.md` | the review order, the claims to distrust and the adversarial commands |
| `crosswalk.json` | the machine-readable crosswalk (the source of the register) |

**Governance:** G4 OPEN / NOT ACCEPTED · DEBT-045 OPEN · runtime certification NOT READY ·
deployment certification NOT READY. This package is an input to a fresh independent review, not an
acceptance decision.
