# Deliverable B — Implementation report (corrective round 4)

**Base:** HEAD `739e58c` on `independent/g4-fts-rev3-20261105` + the supplied change set
(`g4-f01-f38-corrective-modified-files.zip`, SHA-256 `24af8d0e…`, 65 entries).
**All changes are local and uncommitted.**

## 1. R4-01 — the Windows SQLite URI bypass (HIGH)

**Defect.** `sqlite_file_uri()` produces `file:/C:/Users/…/.data/memory/unified.db?mode=rw`.
The boundary's `_uri_to_path()` stripped the scheme and the query string but never normalized
the `/C:/…` drive form, so the URI-derived candidate normalized to `c:\c:\users\…` — which does
**not** match the protected root `c:\users\…\.data\memory`. The application's own URI form
therefore **passed the boundary in `ro`, `rw` AND `rwc`** (reproduced before the fix: see
`docs/reports/independent-g4-fts/remediation4/evidence/`).

**Correction** (`tests/_g4_protection.py`): `_uri_to_path()` is now a real, platform-aware URI
parser —

* the scheme is matched case-insensitively;
* the **query** is split at the FIRST `?` **before** percent-decoding (a literal `?` in a file
  name must be `%3F`);
* `file://authority/path` is the authority form (a non-empty authority is a UNC share, an empty
  authority is an absolute path: `file:///C:/…` → `C:\…`);
* the path component is percent-decoded, so encoded spaces, `#`, `?`, `%` and non-ASCII characters
  are restored exactly;
* on Windows the drive form is converted to a native drive path and the separators normalized.

POSIX absolute-path handling, symlink resolution and the hard-link identity fallback are
preserved.

## 2. R4-02 — the journal-mode-only repair bypassed the pre-mutation preservation (HIGH)

**Defect.** The runner returned through `_repair_journal_mode_only()` **before** the generic
pre-mutation preservation block, so a `PRAGMA journal_mode=WAL` — a persistent database
transition — could execute with no pre-mutation evidence.

**Correction** (`core/memory/sqlite_migration.py`): the order is now
pre-mutation preservation → **then** the journal-mode-only branch. The narrow repair contract is
unchanged (no FTS rebuild, no trigger replacement, no index recreation, no duplicate ledger row,
no migration transaction); the step trace now records `replace_triggers: skipped`,
`ensure_indexes: skipped` and `fts_rebuild: skipped` explicitly, so the operator can see what did
**not** happen. An already completed recovery-risk snapshot is **reused** (no duplicate copy), and
a preservation failure **refuses** the transition.

## 3. R4-03 — incomplete preservation sets are now self-describing (HIGH)

**Correction** (`core/memory/sqlite_migration.py`): `_preserve_recoverable_state()` now follows an
explicit lifecycle — unique destination → **initial manifest with `status="in_progress"`** → copy
and verify each artifact → per-artifact manifest records → `complete` on success, or
`incomplete` (with the failed artifact and the error) on failure. Failures raise the new
`PreservationError`, which carries the destination directory, the manifest path, the source path,
the copied and verified artifacts, the failed artifact, the stage, the underlying error and
whether the manifest could be written at all. The partial set is **retained**, never deleted and
never presented as complete. Every caller reports `preservation.disposition`
(`complete`/`incomplete`), the destination and the manifest path, and the remediation text names the
actual location.

## 4. R4-04 — `memory-verify --json` now emits one parseable JSON object on EVERY path (MEDIUM)

**Correction** (`interface/cli.py`): the command has a single documented JSON schema
(`database`, `ok`, `contract_passed`, `checks_ran`, `error{stage,type,message}`, `contract`,
`verification_target`, `verification_target_removed`, `verdict_scope`,
`recovery_evidence_preserved`, `logical_unchanged`, plus the full verification result). Every early
refusal (missing database), every failure (open, preservation, disposable copy, inspection) and
every success emits **exactly one** JSON object on stdout; Rich output is confined to the text
mode and diagnostics go to **stderr** in JSON mode. Unexecuted inspections are represented as
failed/unavailable, never as passing, and the payload and the exit code always agree.

## 5. R4-05 — the disposable verification copy is disposed (MEDIUM)

**Correction** (`interface/cli.py`): when a writable open could consume recovery evidence the raw
artifact set is preserved **forensically** (that snapshot is retained) and the writable
verification runs against a **managed** copy in a temporary directory that is removed when the
command finishes — on success, on failure, on an open failure, on an inspection exception and on a
copy failure. The copies are hash-verified against their sources **before** they are opened, and
the command never falls back to verifying the original. The JSON states that the verification
concerned a copy and that the copy was removed (`verification_target_removed: true`).

## 6. R4-06 — interaction scenarios H and I now prove their invariants (MEDIUM)

* **Scenario I** now establishes the precondition independently (the FTS index and the content table
  are consistent) and asserts **exactly** `fts_rank1 == "pass"`, `trigger_contract == "fail"`,
  `contract_passed is False` and a non-zero exit code. The previous form
  (`in ("pass", "fail")`) permitted the very result the scenario claims to distinguish.
* **Scenario H** now hashes the main database, the WAL, the `-shm` and the journal before and after
  the run, asserts byte identity for the main file and the WAL, asserts that no journal appeared,
  asserts that **no preservation copy** was created and that the outcome is `already_applied`. The
  `-shm` claim is made **precisely**: it is SQLite's coordination file, its bytes are not claimed to
  be preserved, and the assertion is that it was neither removed nor replaced.

## 7. Cross-artifact reconciliation

The authoritative crosswalk (Deliverable A) is **generated** from one table and validated
deterministically: 98 identifiers (F01–F38, F39–F56, R39–R56, W01–W24), each appearing **exactly
once**; **83 FIXED / 14 PARTIAL / 1 NOT FIXED**; work packages **20 FIXED / 4 PARTIAL** (the
third-round headline "18 FIXED / 6 PARTIAL" was inconsistent with its own table and is superseded).

## 8. Deliberately NOT changed

The runtime, `secure_delete`, `wal_autocheckpoint`, the space factor, the canonical DDL, DEBT-045,
the G4 governance state, every production file and every production database. The 14 OPEN risks
listed in `F_RESIDUAL_RISK_REGISTER.md` remain open — including the capacity preflight and the
copy-stability detection (F36), which this round did **not** implement.
