# Deliverable H — Fresh independent-review handoff (corrective round 4)

**You did not produce this work.** Everything needed is in this repository; do not rely on any
earlier chat message.

## 0. The one-paragraph version

A third corrective round (REV-G4) was reviewed adversarially and six further defects were found
(R4-01 … R4-06): a **Windows SQLite URI bypass** in the production protection boundary, a
journal-mode-only repair that **bypassed the pre-mutation preservation**, **non-self-describing
incomplete preservation sets**, **`memory-verify --json` paths that emitted no JSON**, **disposable
verification copies that were never disposed**, and two interaction scenarios that did **not prove**
their advertised invariants. All six are fixed and proven by executable tests, the historical
finding identifiers are reconciled into one generated crosswalk (98 identifiers, each exactly
once), and the previous package's contradictory totals are superseded. **G4 remains OPEN / NOT
ACCEPTED.**

## 1. Where everything is

| Item | Path |
| --- | --- |
| Working tree (authoritative) | `C:\Users\Produ\Downloads\ocbrain-g4-indep\wt` — branch `independent/g4-fts-rev3-20261105` @ `739e58c`, **all changes uncommitted** |
| This round's package | `docs/reports/independent-g4-fts/remediation4/` (Deliverables A–H + `README.md` + `crosswalk.json`) |
| The historical third-round target | `docs/reports/independent-g4-fts/remediation3/` (immutable; superseded by dated pointers) |
| New regression suite | `tests/test_g4_r4_corrections.py` (24 tests) |
| Strengthened scenarios | `tests/test_g4_interaction_scenarios.py` (12 tests, H and I rewritten) |
| The protection boundary | `tests/_g4_protection.py` |
| The current change-set archive | `g4-f01-f38-corrective-modified-files.zip` — SHA-256 `24af8d0e5bc968b160a437019e51b01c657c0810095eb44ec8c0751854072c6f`, 65 entries |
| The **earlier, different** archive | `g4-revg4-remediation-modified-files.zip` — SHA-256 `2D73E808F70C6C97808CEAD725C810C534EC8AC65F9BC25E47A91C703E3F9EFC`, 50 entries — this is the **second-round** package, **not** the current tree |

## 2. Review order

1. **`remediation4/A_FINDINGS_REGISTER.md`** — the generated crosswalk (98 identifiers). Check the
   evidence class of every row, then follow the test names it cites.
2. **`remediation4/B_IMPLEMENTATION_REPORT.md`** — what changed for R4-01 … R4-06.
3. **Run the new suite first** — it is the fastest way to see whether the corrections hold:
   ```powershell
   python -X utf8 -m pytest tests/test_g4_r4_corrections.py -p no:cacheprovider -q
   ```
4. **Re-derive the bypass yourself** (R4-01): build the application's own URI form for a
   protected path and check that `_is_protected()` recognizes it and that the wrapped
   `sqlite3.connect` raises **without reaching the underlying connector**:
   ```powershell
   python -X utf8 -c "import sys; sys.path.insert(0,'tests'); import importlib.util as u;      s=u.spec_from_file_location('p','tests/_g4_protection.py'); m=u.module_from_spec(s); s.loader.exec_module(m);      from core.memory.sqlite_contract import sqlite_file_uri;      t='.data/memory/unified.db'; u2=sqlite_file_uri(t,'rw'); print(u2, m._is_protected(u2, m.protected_paths_for('.')))"
   ```
5. **Re-derive the preservation ordering** (R4-02): delete an index, run the maintenance repair
   and confirm a preservation set exists **before** the journal-mode transition.
6. **Re-derive the JSON contract** (R4-04): run `memory-verify --json` against a missing database
   and parse stdout — it must be exactly one JSON object.
7. **Re-derive the disposable-copy lifecycle** (R4-05): create a hot rollback journal, verify
   against it, and confirm the temporary copy is gone while the forensic snapshot remains.

## 3. Claims to distrust first

| Claim | How to falsify it |
| --- | --- |
| "the boundary cannot be bypassed by a URI" | try `file:/C:/…`, `file:///C:/…`, a UNC URI, percent-encoded paths, and every connection mode |
| "no persistent change without pre-mutation evidence" | inject a preservation failure and confirm the journal mode does not change |
| "an incomplete preservation is discoverable" | inject a copy failure on the second artifact and read the manifest |
| "`--json` always emits JSON" | hit every early refusal and parse stdout |
| "no temporary copy is left behind" | run the verification with a hot journal and list the temp directory afterwards |
| "the scenarios prove their preconditions" | read scenarios H and I: the FTS rank=1 PASS is asserted exactly, and the sidecar claim is byte-wise |
| "nothing regressed" | run the full suite in a pristine clone of `739e58c` and compare the failure SETS |

## 4. What is explicitly NOT claimed

No G4 acceptance, closure, freeze or deployment certification · no runtime certification (SQLite
3.50.4 is affected) · DEBT-045 stays OPEN · F36 (capacity preflight / copy-stability detection)
stays **NOT FIXED** · W10, W12, W14 and W19 stay **PARTIAL** · the 21 pre-existing failures and 51
errors stay visible · the historical production-vault pollution is not cleaned.

## 5. The reconciliation the reviewer should check first

The third-round package contradicted itself (headline "18 FIXED / 6 PARTIAL" vs its own table
"20 / 4"; F31 both FIXED and PARTIAL; F36 both PARTIAL and NOT FIXED). The authoritative
crosswalk is **generated** from one table and validated deterministically
(`build_crosswalk.py` asserts that all 98 identifiers appear exactly once) — verify that the
counts in the report, the register, the residual-risk register, the change log, the manifest and
this handoff all agree.
