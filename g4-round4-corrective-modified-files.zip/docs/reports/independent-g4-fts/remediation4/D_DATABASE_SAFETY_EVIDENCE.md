# Deliverable D — Database-safety evidence (corrective round 4)

**Rule:** every number concerns a **disposable** database. No production database was opened,
read, written, migrated, verified, checkpointed, repaired or backed up.

## D.1 Production state before and after the campaign

| Path | Before | After |
| --- | --- | --- |
| `.data/memory/unified.db` | 86 016 B · `0283B158B63C4D9C…` | unchanged |
| `.data/memory/archive.db` | 45 056 B · `FBD6A060160F2C81…` | unchanged |
| `.data/memory/graph.db` | 32 768 B · `894012DE350E1E8F…` | unchanged |
| `.data/memory/cognitive/vault_v4.json` | 2 583 B · `F630BC1A7657E96D…` | unchanged |
| `.data/memory/unified.db-wal` | 0 B · `E3B0C44298FC1C14…` | unchanged |
| `.data/memory/unified.db-shm` | 32 768 B · `FD4C9FDA9CD3F9AE…` | unchanged |
| `config/{settings,models,sources}.toml` | hashed before the campaign | unchanged |

The boundary **prevents** access; it does not merely detect it afterwards. If any protected path
had been touched, the campaign would have stopped and reported the exact event — no event occurred.

## D.2 The boundary after R4-01

| Entry point | Production data | Production configuration |
| --- | --- | --- |
| `sqlite3.connect` (any mode: `ro`, `rw`, `rwc`) | blocked | blocked |
| `builtins.open`, `io.open`, `os.open`, `pathlib.Path.open` | blocked | modifications blocked |
| `os.mkdir`, `os.makedirs`, `os.remove`, `os.unlink`, `os.rename`, `os.replace` | blocked | blocked |
| `shutil.copy/copy2/copyfile/copytree/move/rmtree` | blocked | blocked |

**Aliases:** symlinks are resolved (`os.path.realpath`) and a hard-link alias is recognised by
its filesystem identity (`st_dev`, `st_ino`). **Children** install the same boundary through the
generated `sitecustomize.py` and **fail closed** if it cannot be installed.

**Stated honestly:** this is a Python-level defence-in-depth control, **not** an operating-system
sandbox (residual risk R11).

## D.3 Migration safety after R4-02/R4-03

* Every persistent transition — including the journal-mode-only repair — is preceded by a
  **completed** pre-mutation preservation whose copies are hash-verified.
* An **incomplete** preservation is retained, classified `incomplete`, and the run refuses; the
  destination and the manifest path are in the report and in the remediation text.
* A no-op migration creates **no** copy (proved byte-wise: the main file and the WAL are identical
  before and after).

## D.4 Verification safety after R4-04/R4-05

* The verification command never opens the original write-capable when recovery evidence is at
  risk; it verifies a **managed, disposable copy** whose artifacts are hash-verified against the
  sources before the open, and which is removed when the command ends.
* The forensic snapshot is **retained** and is not touched by the cleanup.
* The original main file and every existing sidecar are byte-identical after the command.

## D.5 Evidence classes used in this package

| Class | Meaning |
| --- | --- |
| REPRODUCED | an executable scenario demonstrates the defect or the correction |
| SOURCE-CONFIRMED | exact source inspection confirms the behaviour, but no separate executable reproduction was completed |
| NOT VERIFIED | the evidence is unavailable or incomplete (used for F36) |
