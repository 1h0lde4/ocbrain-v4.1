# Deliverable A — Authoritative consolidated findings register and crosswalk

**Corrective round 4 (Nov 11, 2026) · base:** HEAD `739e58c` on `independent/g4-fts-rev3-20261105` + the supplied change set (`g4-f01-f38-corrective-modified-files.zip`, SHA-256 `24af8d0e5bc968b160a437019e51b01c657c0810095eb44ec8c0751854072c6f`, 65 entries) · **all changes local and uncommitted**

This register is generated from `crosswalk.json` by `build_crosswalk.py`, which **validates deterministically** that every identifier (F01–F38, F39–F56, R39–R56, W01–W24) appears **exactly once**. The counts below are the single source of truth quoted by the report, the residual-risk register, the change log, the manifest and the handoff.

## A.1 Totals

| Set | Identifiers | FIXED | PARTIAL | NOT FIXED |
| --- | ---: | ---: | ---: | ---: |
| F01–F38 | 9 | 8 | 1 | 0 |
| F39–F56 | 10 | 8 | 2 | 0 |
| R39–R56 | 18 | 15 | 3 | 0 |
| W01–W24 | 24 | 20 | 4 | 0 |
| **ALL** | **98** | **83** | **14** | **1** |

### Work-package arithmetic (the correction this round demands)

| W | Disposition | Finding |
| --- | --- | --- |
| W01 | FIXED | SQLite object identity and ownership (case-variant collisions) |
| W02 | FIXED | Canonical trigger classification and repair authorization |
| W03 | FIXED | SQL tokenizer and DDL parsing |
| W04 | FIXED | Canonical index verification (DDL + live metadata) |
| W05 | FIXED | Housekeeping schema and migration-ledger integrity |
| W06 | FIXED | Migration state machine and no-op classification |
| W07 | FIXED | Foreign-key verification and exclusions |
| W08 | FIXED | Structural and integrity error classification |
| W09 | FIXED | Service connection and journal-mode policy |
| W10 | PARTIAL | Fresh-initialization concurrency and recovery |
| W11 | FIXED | Online backup creation, ownership and publication |
| W12 | PARTIAL | Complete backup snapshot verification |
| W13 | FIXED | Logical content digest and invariance |
| W14 | PARTIAL | Recovery-artifact preservation |
| W15 | FIXED | No-op preservation policy and disk-growth control |
| W16 | FIXED | Transaction outcome, commit uncertainty, ledger reconciliation |
| W17 | FIXED | Checkpoint status and post-commit reporting |
| W18 | FIXED | Diagnostic and verification recovery safety |
| W19 | PARTIAL | Canonical paths, file identity and migration locks |
| W20 | FIXED | Production-data protection and import isolation |
| W21 | FIXED | Strict regression-test quality |
| W22 | FIXED | CLI success must require the complete memory contract |
| W23 | FIXED | SQLite DDL and schema inventory completeness |
| W24 | FIXED | Evidence, documentation and residual risk |

**The headline used in the third-round package ("18 FIXED / 6 PARTIAL") was inconsistent with its own table and is hereby superseded: the authoritative totals are 20 FIXED / 4 PARTIAL (W10, W12, W14, W19).**

## A.2 Round-4 corrective findings (R4-01 … R4-06)

| ID | Finding | Disposition | Evidence |
| --- | --- | --- | --- |
| R4-01 | Windows SQLite URI bypass in the production protection boundary (the application's own `file:/C:/…` form did not match the protected root) | FIXED | test_g4_r4_corrections.py::TestR401UriProtection (11 cases: both drive-URI slash forms, UNC, percent-encoding, ro/rw/rwc rejection, the wrapped `sqlite3.connect` raising, the underlying connector never reached, the child inheriting the boundary, the child failing closed) |
| R4-02 | the journal-mode-only repair bypassed the pre-mutation preservation | FIXED | test_g4_r4_corrections.py::TestR402JournalModeRepairPreservation (3 cases: the snapshot exists and matches the pre-transition hash, a preservation failure refuses the transition, an existing recovery snapshot is reused) |
| R4-03 | incomplete preservation sets were not self-describing | FIXED | test_g4_r4_corrections.py::TestR403IncompletePreservation (3 cases: the partial set is retained with a matching hash, the failed artifact is identified, the manifest says `incomplete`, the destination is disclosed, a manifest-write failure still discloses the directory) |
| R4-04 | `memory-verify --json` error paths violated the CLI contract | FIXED | test_g4_r4_corrections.py::TestR404JsonContract (5 cases: the missing database, an open failure, an inspection failure, a contract failure with the full payload, and a successful run — every one parses as JSON and agrees with the exit code) |
| R4-05 | disposable verification copies were not disposed | FIXED | test_g4_r4_corrections.py::TestR405DisposableCopy (2 cases: the copy is removed while the forensic snapshot remains and the originals are byte-identical; an injected copy failure still removes the directory) |
| R4-06 | interaction scenarios H and I did not prove their advertised invariants | FIXED | tests/test_g4_interaction_scenarios.py::test_h_… (byte-wise artifact comparison with the `-shm` claim made precisely) and ::test_i_… (the FTS `rank=1` PASS precondition is now established independently and asserted exactly) |

## A.3 The complete crosswalk (98 identifiers, each exactly once)

| ID | Finding | Historical | Current | W | Evidence | Regression test / evidence | Residual risk | Superseding ref |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| **W01** | SQLite object identity and ownership (case-variant collisions) | FIXED (round 3) | **FIXED** | W01 | REPRODUCED | test_g4_r4_corrections.py::TestR401UriProtection; test_g4_f01_f38_remediation.py::TestF15ObjectOwnership | none for the memory contract; the general object-identity helper is not shared with unrelated schema objects | remediation4 §A, W01 |
| **W02** | Canonical trigger classification and repair authorization | FIXED (round 3) | **FIXED** | W02 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF16F32LegacyTriggerSets | none | remediation4 §A, W02 |
| **W03** | SQL tokenizer and DDL parsing | FIXED (round 3) | **FIXED** | W03 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF13F34SqlSemantics (18 cases) | none for the repository DDL subset | remediation4 §A, W03 |
| **W04** | Canonical index verification (DDL + live metadata) | FIXED (round 3) | **FIXED** | W04 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF14F33IndexAudit | none | remediation4 §A, W04 |
| **W05** | Housekeeping schema and migration-ledger integrity | FIXED (round 3) | **FIXED** | W05 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF20F35HousekeepingAndFreshness | none | remediation4 §A, W05 |
| **W06** | Migration state machine and no-op classification | FIXED (round 3) | **FIXED** | W06 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF03PostLockReinspectionFailsClosed; test_g4_interaction_scenarios.py::test_b_… | none | remediation4 §A, W06 |
| **W07** | Foreign-key verification and exclusions | FIXED (round 3) | **FIXED** | W07 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF18F19ForeignKeys | none | remediation4 §A, W07 |
| **W08** | Structural and integrity error classification | FIXED (round 3) | **FIXED** | W08 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF12StructuralErrorVersusFail | none | remediation4 §A, W08 |
| **W09** | Service connection and journal-mode policy | FIXED (round 3) | **FIXED** | W09 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF22F23ServiceLifecycle; test_g4_interaction_scenarios.py::test_d_… | none | remediation4 §A, W09 |
| **W10** | Fresh-initialization concurrency and recovery | PARTIAL (round 3) | **PARTIAL** | W10 | SOURCE-CONFIRMED | test_g4_interaction_scenarios.py::test_l_… (a partial database is never accepted as current; the second initialization fails loudly) | no dedicated initialization lock: two simultaneous first starts are serialized only by SQLite's own locking and the loser is not told it lost | remediation4 §A, W10; F_RESIDUAL_RISK_REGISTER R8 |
| **W11** | Online backup creation, ownership and publication | FIXED (round 3) | **FIXED** | W11 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF06F07F08Backup; test_g4_interaction_scenarios.py::test_e_… | none | remediation4 §A, W11 |
| **W12** | Complete backup snapshot verification | PARTIAL (round 3) | **PARTIAL** | W12 | SOURCE-CONFIRMED | test_g4_f01_f38_remediation.py::…::test_backup_verifies_a_complete_logical_snapshot | the verified scope is the content table plus schema/trigger/index identity; application-owned USER TABLES are not part of the verified digest scope | remediation4 §A, W12; F_RESIDUAL_RISK_REGISTER R6 |
| **W13** | Logical content digest and invariance | FIXED (round 3) | **FIXED** | W13 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF27F29F38HonestReporting; test_g4_interaction_scenarios.py::test_j_… | none | remediation4 §A, W13 |
| **W14** | Recovery-artifact preservation | PARTIAL (round 3) | **PARTIAL** | W14 | REPRODUCED | test_g4_r4_corrections.py::TestR403IncompletePreservation; test_g4_revg4_remediation.py::TestRevg406Preservation | the ordering, the manifest and the incomplete-set reporting are correct (R4-03), but there is still NO capacity preflight and NO detection of a source file changing during the copy | remediation4 §A, W14; F_RESIDUAL_RISK_REGISTER R7 |
| **W15** | No-op preservation policy and disk-growth control | FIXED (round 3) | **FIXED** | W15 | REPRODUCED | test_g4_interaction_scenarios.py::test_h_… (byte-wise, R4-06) | none | remediation4 §A, W15 |
| **W16** | Transaction outcome, commit uncertainty, ledger reconciliation | FIXED (round 3) | **FIXED** | W16 | REPRODUCED | test_g4_f01_f38_remediation.py::…::test_pre_commit_fault_reports_a_verified_rollback | none | remediation4 §A, W16 |
| **W17** | Checkpoint status and post-commit reporting | FIXED (round 3) | **FIXED** | W17 | REPRODUCED | test_g4_f01_f38_remediation.py::…::test_checkpoint_status_is_not_done_when_busy | none | remediation4 §A, W17 |
| **W18** | Diagnostic and verification recovery safety | FIXED (round 3) | **FIXED** | W18 | REPRODUCED | test_g4_interaction_scenarios.py::test_f_…; test_g4_r4_corrections.py::TestR405DisposableCopy | none | remediation4 §A, W18 |
| **W19** | Canonical paths, file identity and migration locks | PARTIAL (round 3) | **PARTIAL** | W19 | REPRODUCED | test_g4_f01_f38_remediation.py::…::test_lock_release_does_not_remove_a_foreign_lock | the LOCK identity is safe (device/inode verified at acquisition and release), but the DATABASE path identity is still not unified across relative/absolute, symlink, junction and hard-link aliases | remediation4 §A, W19; F_RESIDUAL_RISK_REGISTER R9 |
| **W20** | Production-data protection and import isolation | FIXED (round 3) | **FIXED** | W20 | REPRODUCED | test_g4_r4_corrections.py::TestR401UriProtection (the Windows URI bypass is closed); test_g4_interaction_scenarios.py::test_k_… | a Python-level defence-in-depth control, NOT an operating-system sandbox | remediation4 §A, W20; F_RESIDUAL_RISK_REGISTER R11 |
| **W21** | Strict regression-test quality | FIXED (round 3) | **FIXED** | W21 | SOURCE-CONFIRMED | the three corrective suites (61 + 12 + 24 tests) assert invariants rather than weak proxies | none | remediation4 §A, W21 |
| **W22** | CLI success must require the complete memory contract | FIXED (round 3) | **FIXED** | W22 | REPRODUCED | test_g4_r4_corrections.py::TestR404JsonContract; test_g4_interaction_scenarios.py::test_i_… (R4-06: the FTS rank=1 precondition is now proven) | none | remediation4 §A, W22 |
| **W23** | SQLite DDL and schema inventory completeness | FIXED (round 3) | **FIXED** | W23 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF20F35…; TestF13F34… | none | remediation4 §A, W23 |
| **W24** | Evidence, documentation and residual risk | FIXED (round 3) | **FIXED** | W24 | SOURCE-CONFIRMED | remediation4 deliverables A-H; report section 18 | none | remediation4 §A, W24 |
| **F01** | Doctor must never silently open a writable database | FIXED (round 2) | **FIXED** | W18 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF01DoctorNeverWrites | none | remediation4 §A, F01 |
| **F02** | Unsupported targets refused before persistent mutation | FIXED (round 2) | **FIXED** | W06 | REPRODUCED | test_g4_rev3_migration_lifecycle.py; test_g4_interaction_scenarios.py::test_a_… | none | remediation4 §A, F02 |
| **F03** | Failed post-lock re-inspection must fail closed | FIXED (round 2) | **FIXED** | W06 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF03PostLockReinspectionFailsClosed; test_g4_interaction_scenarios.py::test_g_… | none | remediation4 §A, F03 |
| **F04** | Missing/empty paths never created | FIXED (round 2) | **FIXED** | W06 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF06F07F08Backup | none | remediation4 §A, F04 |
| **F05** | DELETE-mode current database recovery route | FIXED (round 2) | **FIXED** | W06, W09, W20 | REPRODUCED | test_g4_r4_corrections.py::TestR402JournalModeRepairPreservation; test_g4_interaction_scenarios.py::test_d_… | none | remediation4 §A, F05 |
| **F06** | Backup publication atomic and non-overwriting | FIXED (round 2) | **FIXED** | W11 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF06F07F08Backup; test_g4_interaction_scenarios.py::test_e_… | none | remediation4 §A, F06 |
| **F07** | Backup temporary file exclusively owned | FIXED (round 2) | **FIXED** | W11 | REPRODUCED | test_g4_f01_f38_remediation.py::…::test_temporary_artifact_is_exclusively_owned | none | remediation4 §A, F07 |
| **F08** | Backup proves a complete consistent snapshot | PARTIAL (round 2, round 3) | **PARTIAL** | W12 | REPRODUCED | test_g4_f01_f38_remediation.py::…::test_backup_verifies_a_complete_logical_snapshot | application-owned user tables are outside the verified digest scope | remediation4 §A, F08 |
| **F09** | Raw preservation before recovery-capable opens | FIXED (round 2) | **FIXED** | W14 | REPRODUCED | test_g4_rev3_remediation.py::TestRevg406Preservation | none | remediation4 §A, F09 |
| **F10** | No-op migrations must not copy the whole database | PARTIAL (round 3) | **FIXED** | W15 | REPRODUCED | test_g4_interaction_scenarios.py::test_h_… (R4-06: byte-wise proof) | none - supersedes the round-3 PARTIAL verdict | remediation4 §A, F10 |
| **F11** | Partial preservation produces a truthful incomplete record | NOT FIXED (round 3) | **FIXED** | W14 | REPRODUCED | test_g4_r4_corrections.py::TestR403IncompletePreservation | none - supersedes the round-3 NOT FIXED verdict; the capacity preflight and copy-stability detection remain open under F36 | remediation4 §A, F11 |
| **F12** | Structural ERROR is not confirmed corruption | FIXED (round 2) | **FIXED** | W08 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF12StructuralErrorVersusFail | none | remediation4 §A, F12 |
| **F13** | SQL normalization preserves literal semantics | FIXED (round 2) | **FIXED** | W03 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF13F34SqlSemantics | none | remediation4 §A, F13 |
| **F14** | Index audit fails closed on unknown metadata | FIXED (round 2) | **FIXED** | W04 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF14F33IndexAudit | none | remediation4 §A, F14 |
| **F15** | Global name collisions never destroy objects | FIXED (round 2) | **FIXED** | W01, W09 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF15ObjectOwnership | none | remediation4 §A, F15 |
| **F16** | Legacy trigger recognition: explicit states only | FIXED (round 2) | **FIXED** | W02 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF16F32LegacyTriggerSets | none | remediation4 §A, F16 |
| **F17** | Repair scope never defaults to broad repair | FIXED (round 2) | **FIXED** | W02, W20 | REPRODUCED | test_g4_f01_f38_remediation.py::…::test_repair_scope_is_never_defaulted | none | remediation4 §A, F17 |
| **F18** | Foreign-key detection accurate; error is not not_applicable | FIXED (round 2) | **FIXED** | W07, W21 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF18F19ForeignKeys | none | remediation4 §A, F18 |
| **F19** | Foreign-key preflight failure prevents migration | FIXED (round 2) | **FIXED** | W07, W11 | REPRODUCED | test_g4_f01_f38_remediation.py::…::test_fk_preflight_failure_refuses_before_journal_mode_change | none | remediation4 §A, F19 |
| **F20** | Housekeeping + ledger contract validated | FIXED (round 2) | **FIXED** | W05, W19, W23 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF20F35HousekeepingAndFreshness | none | remediation4 §A, F20 |
| **F21** | SQLite file URIs safely encoded | FIXED (round 2) | **FIXED** | W03 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF21UriEncoding | none | remediation4 §A, F21 |
| **F22** | Service connections make no persistent mode change | FIXED (round 2) | **FIXED** | W09 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF22F23ServiceLifecycle | none | remediation4 §A, F22 |
| **F23** | Fresh-initialization concurrency and recovery | PARTIAL (round 3) | **PARTIAL** | W06, W10 | SOURCE-CONFIRMED | test_g4_interaction_scenarios.py::test_l_… | no dedicated initialization lock (see W10) | remediation4 §A, F23 |
| **F24** | Import-time singletons cannot reach production data | FIXED (round 2) | **FIXED** | W20 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF24ProductionBoundary; test_g4_r4_corrections.py::TestR401UriProtection | none | remediation4 §A, F24 |
| **F25** | No vacuous assertions or silent skips | FIXED (round 2) | **FIXED** | W07, W21 | SOURCE-CONFIRMED | the three corrective suites | none | remediation4 §A, F25 |
| **F26** | Verify success requires the complete contract | NOT FIXED (round 3) | **FIXED** | W08, W22 | REPRODUCED | test_g4_r4_corrections.py::TestR404JsonContract; test_g4_interaction_scenarios.py::test_i_… | none - supersedes the round-3 NOT FIXED verdict | remediation4 §A, F26 |
| **F27** | Logical invariance compares actual stored values | FIXED (round 2) | **FIXED** | W12, W13 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF27F29F38HonestReporting | none | remediation4 §A, F27 |
| **F28** | Writable verification must not consume recovery evidence | NOT FIXED (round 3) | **FIXED** | W07, W14, W18 | REPRODUCED | test_g4_r4_corrections.py::TestR405DisposableCopy; test_g4_interaction_scenarios.py::test_f_… | none - supersedes the round-3 NOT FIXED verdict | remediation4 §A, F28 |
| **F29** | Commit/rollback outcomes classified truthfully | FIXED (round 2) | **FIXED** | W16 | REPRODUCED | test_g4_f01_f38_remediation.py::…::test_pre_commit_fault_reports_a_verified_rollback | none | remediation4 §A, F29 |
| **F30** | Advisory-lock identity and lifecycle | FIXED (round 2) | **FIXED** | W16, W19 | REPRODUCED | test_g4_f01_f38_remediation.py::…::test_lock_release_does_not_remove_a_foreign_lock | none | remediation4 §A, F30 |
| **F31** | Sidecar side effects and reporting are truthful | PARTIAL (round 3) | **PARTIAL** | W18 | SOURCE-CONFIRMED | test_g4_interaction_scenarios.py::test_h_… (the -shm claim is now precise) | the checkpoint inventory still reports PRE-connection sidecar sizes for its own figures | remediation4 §A, F31 |
| **F32** | Arbitrary missing-trigger combinations rejected | FIXED (round 2) | **FIXED** | W02 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF16F32LegacyTriggerSets | none | remediation4 §A, F32 |
| **F33** | Index metadata inspection failures prevent PASS | FIXED (round 2) | **FIXED** | W04 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF14F33IndexAudit | none | remediation4 §A, F33 |
| **F34** | DDL parsers reject unrecognized grammar | FIXED (round 2) | **FIXED** | W03, W23 | REPRODUCED | test_g4_f01_f38_remediation.py::TestF13F34SqlSemantics | none | remediation4 §A, F34 |
| **F35** | Fresh-database classification inspects all objects | FIXED (round 2) | **FIXED** | W06, W10, W23 | REPRODUCED | test_g4_f01_f38_remediation.py::…::test_database_with_only_a_view_is_not_absent | none | remediation4 §A, F35 |
| **F36** | Recovery snapshot stable and storage-preflighted | NOT FIXED (round 3) | **NOT FIXED** | W14 | SOURCE-CONFIRMED | no executable evidence - the capacity preflight and the copy-stability detection are NOT implemented | OPEN: no capacity preflight and no detection of a source file changing during the copy; the deployment contract (quiescence) remains the only protection | remediation4 §A, F36 |
| **F37** | Lock acquisition/release failures handled safely | FIXED (round 2) | **FIXED** | W19 | REPRODUCED | test_g4_f01_f38_remediation.py::…::test_lock_release_does_not_remove_a_foreign_lock | none | remediation4 §A, F37 |
| **F38** | Busy checkpoints not reported as complete | FIXED (round 2) | **FIXED** | W17 | REPRODUCED | test_g4_f01_f38_remediation.py::…::test_checkpoint_status_is_not_done_when_busy | none | remediation4 §A, F38 |
| **F39** | alias of F15 | FIXED (round 3) | **FIXED** | W01 | REPRODUCED (through the consolidated test) | see W01 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, F39 |
| **F40** | alias of F16, F17 | FIXED (round 3) | **FIXED** | W02 | REPRODUCED (through the consolidated test) | see W02 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, F40 |
| **F41** | alias of F14, F33 | FIXED (round 3) | **FIXED** | W04 | REPRODUCED (through the consolidated test) | see W04 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, F41 |
| **F42** | alias of F04 | FIXED (round 3) | **FIXED** | W06 | REPRODUCED (through the consolidated test) | see W06 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, F42 |
| **F43** | alias of F02, F03 | FIXED (round 3) | **FIXED** | W06 | REPRODUCED (through the consolidated test) | see W06 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, F43 |
| **F44** | alias of F20, F29 | FIXED (round 3) | **FIXED** | W05, W16 | REPRODUCED (through the consolidated test) | see W05, W16 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, F44 |
| **F45** | alias of F18 | FIXED (round 3) | **FIXED** | W07 | REPRODUCED (through the consolidated test) | see W07 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, F45 |
| **F46** | alias of F09, F36 | PARTIAL (round 3) | **PARTIAL** | W14 | REPRODUCED (through the consolidated test) | see W14 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, F46 |
| **F47** | alias of F23, F35 | PARTIAL (round 3) | **PARTIAL** | W10 | REPRODUCED (through the consolidated test) | see W10 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, F47 |
| **F48** | alias of F28 | FIXED (round 3) | **FIXED** | W14, W18 | REPRODUCED (through the consolidated test) | see W14, W18 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, F48 |
| **F49** | alias of F11, F36 | NOT FIXED (round 3) | **FIXED** | W14 | REPRODUCED (through the consolidated test) | see W14 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, F49 |
| **F50** | alias of F24 | FIXED (round 3) | **FIXED** | W18, W20 | REPRODUCED (through the consolidated test) | see W18, W20 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, F50 |
| **F51** | alias of F20, F30 | PARTIAL (round 3) | **PARTIAL** | W19 | REPRODUCED (through the consolidated test) | see W19 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, F51 |
| **F52** | alias of F17 | FIXED (round 3) | **FIXED** | W02 | REPRODUCED (through the consolidated test) | see W02 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, F52 |
| **F53** | alias of F13, F20 | FIXED (round 3) | **FIXED** | W05, W23 | REPRODUCED (through the consolidated test) | see W05, W23 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, F53 |
| **F54** | alias of F10, F13, F34 | FIXED (round 3) | **FIXED** | W03, W23 | REPRODUCED (through the consolidated test) | see W03, W23 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, F54 |
| **F55** | alias of F13, F20, F35 | FIXED (round 3) | **FIXED** | W23 | REPRODUCED (through the consolidated test) | see W23 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, F55 |
| **F56** | alias of F23, F35 | PARTIAL (round 3) | **PARTIAL** | W10 | REPRODUCED (through the consolidated test) | see W10 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, F56 |
| **R39** | alias of F15 | FIXED (round 3) | **FIXED** | W01 | REPRODUCED (through the consolidated test) | see W01 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, R39 |
| **R40** | alias of F26 | FIXED (round 3) | **FIXED** | W22 | REPRODUCED (through the consolidated test) | see W22 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, R40 |
| **R41** | alias of F27 | FIXED (round 3) | **FIXED** | W13 | REPRODUCED (through the consolidated test) | see W13 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, R41 |
| **R44** | alias of F20, F29 | FIXED (round 3) | **FIXED** | W05, W16 | REPRODUCED (through the consolidated test) | see W05, W16 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, R44 |
| **R45** | alias of F10 | FIXED (round 3) | **FIXED** | W15 | REPRODUCED (through the consolidated test) | see W15 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, R45 |
| **R46** | alias of F09, F36 | PARTIAL (round 3) | **PARTIAL** | W14 | REPRODUCED (through the consolidated test) | see W14 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, R46 |
| **R48** | alias of F28 | FIXED (round 3) | **FIXED** | W14, W18 | REPRODUCED (through the consolidated test) | see W14, W18 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, R48 |
| **R49** | alias of F11, F36 | NOT FIXED (round 3) | **FIXED** | W14 | REPRODUCED (through the consolidated test) | see W14 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, R49 |
| **R50** | alias of F24 | FIXED (round 3) | **FIXED** | W18, W20 | REPRODUCED (through the consolidated test) | see W18, W20 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, R50 |
| **R51** | alias of F20, F30 | PARTIAL (round 3) | **PARTIAL** | W19 | REPRODUCED (through the consolidated test) | see W19 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, R51 |
| **R42** | alias of F04 | FIXED (round 3) | **FIXED** | W06 | REPRODUCED (through the consolidated test) | see W06 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, R42 |
| **R43** | alias of F02, F03 | FIXED (round 3) | **FIXED** | W06 | REPRODUCED (through the consolidated test) | see W06 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, R43 |
| **R47** | alias of F23, F35 | PARTIAL (round 3) | **PARTIAL** | W10 | REPRODUCED (through the consolidated test) | see W10 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, R47 |
| **R52** | alias of F17 | FIXED (round 3) | **FIXED** | W02 | REPRODUCED (through the consolidated test) | see W02 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, R52 |
| **R53** | alias of F13, F20 | FIXED (round 3) | **FIXED** | W05, W23 | REPRODUCED (through the consolidated test) | see W05, W23 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, R53 |
| **R54** | alias of F10, F13, F34 | FIXED (round 3) | **FIXED** | W03, W23 | REPRODUCED (through the consolidated test) | see W03, W23 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, R54 |
| **R55** | alias of F13, F20, F35 | FIXED (round 3) | **FIXED** | W23 | REPRODUCED (through the consolidated test) | see W23 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, R55 |
| **R56** | alias of F38 | FIXED (round 3) | **FIXED** | W17 | REPRODUCED (through the consolidated test) | see W17 and the aliased identifier's row | see the aliased identifier's row | remediation4 §A, R56 |

## A.4 Re-evaluation of the findings this round could supersede

| ID | Round-3 record | Re-evaluation | Evidence |
| --- | --- | --- | --- |
| F10 | PARTIAL (W15 narrowed the policy) | **FIXED** — the no-op policy copies nothing, and scenario H now proves it byte-wise (main + WAL identical, no journal, no preservation set). | test_g4_interaction_scenarios.py::test_h_… |
| F11 | NOT FIXED (no incomplete manifest) | **FIXED** — the preservation lifecycle now writes an `in_progress` manifest, marks it `incomplete` with the failed artifact, and raises `PreservationError` carrying the destination, the manifest path and the verified files. | test_g4_r4_corrections.py::TestR403IncompletePreservation |
| F26 | NOT FIXED (the CLI did not gate on the complete contract) | **FIXED** — the eleven-item contract gates PASS, and every early refusal and failure path now emits one parseable JSON object with the same schema and an agreeing exit code. | test_g4_r4_corrections.py::TestR404JsonContract |
| F28 | NOT FIXED (verification could consume recovery evidence) | **FIXED** — when recovery evidence is at risk the raw set is preserved first and the writable verification runs against a managed disposable copy that is removed afterwards; the originals stay byte-identical. | test_g4_r4_corrections.py::TestR405DisposableCopy; test_g4_interaction_scenarios.py::test_f_… |
| F31 | PARTIAL (the inventory reports pre-connection sizes) | **PARTIAL (unchanged)** — scenario H now makes the sidecar claim precise (the `-shm` is a coordination file whose bytes are not claimed to be preserved; the main file and the WAL are). The inventory's own pre-connection figures are still stale. | F_RESIDUAL_RISK_REGISTER R10 |
| F36 | NOT FIXED (no capacity preflight, no copy-stability detection) | **NOT FIXED (unchanged)** — R4-03 corrected the incomplete-manifest behaviour (F11), which is a DIFFERENT requirement; the capacity preflight and the source-stability detection are still not implemented. | F_RESIDUAL_RISK_REGISTER R7 |
| W10 | PARTIAL (no initialization lock) | **PARTIAL (unchanged)** — a partial database is still never accepted as current and a second initialization still fails loudly, but no dedicated lock exists. | F_RESIDUAL_RISK_REGISTER R8 |
| W12 | PARTIAL (user tables outside the verified scope) | **PARTIAL (unchanged)** | F_RESIDUAL_RISK_REGISTER R6 |
| W14 | PARTIAL (no capacity preflight / stability detection) | **PARTIAL (improved)** — the manifest lifecycle, the structured failure and the reuse policy are now correct (R4-03); the capacity preflight and the stability detection are still missing. | F_RESIDUAL_RISK_REGISTER R7 |
| W19 | PARTIAL (database-path identity not unified) | **PARTIAL (unchanged)** — the URI parsing was corrected (W20/R4-01) and the lock identity is safe, but the database path itself is still not canonicalised across aliases. | F_RESIDUAL_RISK_REGISTER R9 |

## A.5 What this register does NOT claim

* No G4 acceptance, closure, freeze or deployment certification.
* No runtime certification: the production SQLite is still **3.50.4** (inside the affected WAL-reset range) — Plan R1 remains a separate deployment gate.
* **DEBT-045 stays OPEN**; the hidden-rowid persistence question is not resolved by any measurement in this package.
* A finding is not FIXED because a function exists — every FIXED row names the executable evidence that proves it.
* The remaining PARTIAL/NOT FIXED rows are open risks, not deferred work: they are listed with their residual risk in `F_RESIDUAL_RISK_REGISTER.md`.
