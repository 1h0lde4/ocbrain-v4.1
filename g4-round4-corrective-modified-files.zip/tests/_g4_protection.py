"""
tests/_g4_protection.py — process-level protection of production data (F24/W20).

The Rev 3 corrective remediation found FOUR paths through which the test
suite could touch production data. A *detection* harness (compare file
sizes/mtimes AFTER a test has run) is too late — the production file had
already been written, and a same-size write could not be seen at all.

This module implements a PREVENTION boundary:

  * the protected paths are computed from the repository root and exported
    through the environment (`OCBRAIN_PROTECTED_PATHS`) so that CHILD
    processes inherit them;
  * `sqlite3.connect`, `builtins.open`, `io.open`, `os.open`,
    `pathlib.Path.open`, `os.mkdir`/`os.makedirs`, `os.remove`,
    `os.rename`, `os.replace` and the `shutil` copy/move/remove helpers
    are wrapped so that any access to a protected path raises
    `ProtectedPathError` — the access never happens;
  * the boundary resolves SYMLINK aliases and compares the filesystem
    identity (device/inode) of the candidate, so a hard-link alias of a
    protected file is caught too;
  * the boundary is installed at conftest IMPORT time, i.e. BEFORE pytest
    collects (and therefore before it imports) any test module, and before
    the orchestrator/memory import chains run;
  * a generated `sitecustomize.py` (placed on PYTHONPATH) installs the same
    boundary in every child Python process — and a FAILURE to install it
    fails the child closed rather than being swallowed.

SCOPE AND LIMITS (stated honestly): this is a **defense-in-depth
control inside the Python process, not an operating-system sandbox**. A
sufficiently determined process could bypass it (native code, a C
extension, a subprocess that does not inherit the environment). Where
OS-level isolation is available it is preferred; this boundary is the
portable fallback and it is paired with a dedicated temporary storage
environment for the tests.

The boundary is deliberately narrow: it protects production DATA
(`.data/memory/**` and the configured memory database paths) and the
production CONFIGURATION files (`config/*.toml`). Everything else — the
repository sources, the temporary databases the tests create — stays
accessible.
"""
from __future__ import annotations

import builtins
import io
import os
import shutil
import sqlite3
from typing import Iterable, List, Optional, Sequence
from urllib.parse import unquote

PROTECTED_PATHS_ENV = "OCBRAIN_PROTECTED_PATHS"
ALLOW_CONFIG_ENV = "OCBRAIN_TEST_ALLOW_CONFIG_WRITE"


class ProtectedPathError(PermissionError):
    """Raised when code attempts to touch a protected production path."""


def _norm(path: str) -> str:
    try:
        return os.path.normcase(os.path.abspath(str(path)))
    except (OSError, ValueError):
        return str(path)


def protected_paths_for(repo_root: str,
                        extra: Optional[Iterable[str]] = None) -> List[str]:
    """
    The protected paths for this repository: the whole production memory
    directory (database + sidecars + the cognitive vault) and the production
    configuration files.
    """
    root = _norm(repo_root)
    protected: List[str] = [
        os.path.join(root, ".data", "memory"),
    ]
    for name in ("settings.toml", "models.toml", "sources.toml"):
        protected.append(os.path.join(root, "config", name))
    for item in extra or ():
        protected.append(_norm(item))
    return protected


def _uri_to_path(target: str) -> str:
    """
    Convert a SQLite file URI into a native filesystem path (R4-01).

    The previous implementation simply stripped the ``file:`` prefix and the
    query string, which produced ``/C:/dir/db`` for the application's own
    Windows URI form (``file:/C:/dir/db``). That path does not normalize to
    the same location as the protected root (``C:\\dir``), so a URI could
    address a protected production database WITHOUT the boundary noticing —
    a bypass in the exact mechanism the application uses.

    This parser follows the URI structure:

    * the scheme is ``file:`` (case-insensitive);
    * the **query** starts at the FIRST ``?`` — and the split happens
      BEFORE percent-decoding, because a literal ``?`` inside a file name
      must be encoded as ``%3F``;
    * ``file://authority/path`` is the authority form: a non-empty authority
      is a UNC share (``\\\\server\\share\\...``), an empty authority is an
      absolute path (``file:///C:/dir/db`` → ``C:\\dir\\db``);
    * the path component is percent-decoded, so encoded spaces, ``#``,
      ``?``, ``%`` and non-ASCII characters are restored exactly;
    * on Windows the drive form (``/C:/...``) is converted to a native drive
      path and the separators are normalized.
    """
    text = str(target)
    if text[:5].lower() != "file:":
        return text
    rest = text[5:]

    # The query starts at the first '?' - BEFORE decoding (a literal '?' in
    # a file name must be percent-encoded, so it never appears raw here).
    query_at = rest.find("?")
    if query_at != -1:
        rest = rest[:query_at]

    if rest.startswith("//"):
        after = rest[2:]
        slash = after.find("/")
        if slash == -1:
            authority, tail = after, ""
        else:
            authority, tail = after[:slash], after[slash:]
        if authority:
            # UNC form: file://server/share/path
            decoded_authority = unquote(authority)
            decoded_tail = unquote(tail)
            if os.name == "nt":
                return ("\\\\" + decoded_authority
                        + decoded_tail.replace("/", "\\"))
            return "//" + decoded_authority + decoded_tail
        # Empty authority (file:///C:/dir/db) -> an absolute path.
        rest = tail

    path = unquote(rest)
    if os.name == "nt":
        # Windows drive form: /C:/dir/db -> C:\dir\db
        if (len(path) > 2 and path[0] == "/" and path[2] == ":"
                and path[1].isalpha()):
            path = path[1:]
        path = path.replace("/", "\\")
    return path


class _Guard:
    """The installed boundary state."""

    def __init__(self) -> None:
        self.protected: List[str] = []
        self.data_roots: List[str] = []
        self.config_roots: List[str] = []
        self.identities: set = set()      # (st_dev, st_ino) of protected files
        self.allow_config_write = False
        self.installed = False


_GUARD = _Guard()


def _identity(path: str):
    try:
        st = os.stat(path)
        return (st.st_dev, st.st_ino)
    except OSError:
        return None


def _refresh_identities() -> None:
    """Remember the filesystem identity of every existing protected file so
    that a HARD-LINK alias is recognised as the protected file."""
    ids = set()
    for root in _GUARD.protected:
        if os.path.isdir(root):
            for dirpath, _dirs, files in os.walk(root):
                for name in files:
                    ident = _identity(os.path.join(dirpath, name))
                    if ident:
                        ids.add(ident)
        else:
            ident = _identity(root)
            if ident:
                ids.add(ident)
    _GUARD.identities = ids


def _is_protected(target, protected: Optional[Sequence[str]] = None
                  ) -> Optional[str]:
    """
    Return the protected root that `target` falls under, else None.

    Symlink aliases are resolved (a symlink INTO the production directory
    is the protected directory), and a hard-link alias is recognised by its
    filesystem identity.
    """
    if target is None:
        return None
    raw = str(target)
    path = _uri_to_path(raw)
    roots = list(protected if protected is not None else _GUARD.protected)
    candidates = [_norm(path)]
    try:
        candidates.append(_norm(os.path.realpath(path)))
    except (OSError, ValueError):
        pass
    for root in roots:
        root_n = _norm(root)
        for candidate in candidates:
            if candidate == root_n:
                return root_n
            if candidate.startswith(root_n + os.sep):
                return root_n
    # hard-link alias: the candidate's identity is a protected file's identity
    ident = _identity(path)
    if ident is not None and ident in _GUARD.identities:
        return "hard-link-alias"
    return None


def install(protected: Sequence[str],
            allow_config_write: bool = False) -> None:
    """
    Install the prevention boundary in THIS process (idempotent).

    `allow_config_write` relaxes only the CONFIGURATION part of the
    boundary; production DATA is never writable under the boundary.
    """
    protected = [_norm(p) for p in protected]
    data_roots = [p for p in protected
                   if os.path.join(".data", "memory") in p]
    config_roots = [p for p in protected if p not in data_roots]
    _GUARD.protected = protected
    _GUARD.data_roots = data_roots
    _GUARD.config_roots = config_roots
    _GUARD.allow_config_write = allow_config_write
    _refresh_identities()

    real_connect = sqlite3.connect
    real_open = builtins.open
    real_io_open = io.open
    real_os_open = os.open
    real_remove = os.remove
    real_unlink = os.unlink
    real_rename = os.rename
    real_replace = os.replace
    real_mkdir = os.mkdir
    real_makedirs = os.makedirs
    real_path_open = None
    try:
        import pathlib
        real_path_open = pathlib.Path.open
    except Exception:                                  # pragma: no cover
        real_path_open = None

    def _check(target, write: bool) -> None:
        hit = _is_protected(target)
        if hit is None:
            return
        if hit == "hard-link-alias":
            raise ProtectedPathError(
                f"protected production data accessed through a hard-link "
                f"alias: {target!r}. The test environment must never open, "
                "write or initialize production data (F24/W20).")
        if hit in _GUARD.data_roots:
            # Production DATA: no access at all (read, write, create).
            raise ProtectedPathError(
                f"protected production data accessed: {target!r} is under "
                f"{hit!r}. The test environment must never open, write or "
                "initialize production data (F24/W20). Use an isolated "
                "temporary database instead.")
        # Production CONFIGURATION: modification is forbidden; reading the
        # configuration is how the application loads its settings and is
        # not a mutation.
        if not write:
            return
        if _GUARD.allow_config_write:
            return
        raise ProtectedPathError(
            f"protected production configuration modified: {target!r} is "
            f"under {hit!r}. The test environment must not rewrite the "
            "production configuration files (F24/W20).")

    def connect(target, *args, **kwargs):
        _check(target, write=not _is_readonly_connect(target, kwargs))
        return real_connect(target, *args, **kwargs)

    def open_(file, mode="r", *args, **kwargs):
        _check(file, write=any(c in str(mode) for c in "wxa+"))
        return real_open(file, mode, *args, **kwargs)

    def io_open(file, mode="r", *args, **kwargs):
        _check(file, write=any(c in str(mode) for c in "wxa+"))
        return real_io_open(file, mode, *args, **kwargs)

    def os_open(path, flags, *args, **kwargs):
        _check(path, write=bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT
                                         | os.O_APPEND | os.O_TRUNC)))
        return real_os_open(path, flags, *args, **kwargs)

    def remove(path, *args, **kwargs):
        _check(path, write=True)
        return real_remove(path, *args, **kwargs)

    def unlink(path, *args, **kwargs):
        _check(path, write=True)
        return real_unlink(path, *args, **kwargs)

    def rename(src, dst, *args, **kwargs):
        _check(src, write=True)
        _check(dst, write=True)
        return real_rename(src, dst, *args, **kwargs)

    def replace(src, dst, *args, **kwargs):
        _check(src, write=True)
        _check(dst, write=True)
        return real_replace(src, dst, *args, **kwargs)

    def mkdir(path, *args, **kwargs):
        _check(path, write=True)
        return real_mkdir(path, *args, **kwargs)

    def makedirs(name, *args, **kwargs):
        _check(name, write=True)
        return real_makedirs(name, *args, **kwargs)

    def path_open(self, *args, **kwargs):
        mode = args[0] if args else kwargs.get("mode", "r")
        _check(str(self), write=any(c in str(mode) for c in "wxa+"))
        if real_path_open is None:                    # pragma: no cover
            raise ProtectedPathError("pathlib.Path.open is unavailable")
        return real_path_open(self, *args, **kwargs)

    def _shutil_guard(fn, write=True):
        def guarded(src, dst=None, *args, **kwargs):
            _check(src, write=write)
            if dst is not None:
                _check(dst, write=write)
            return fn(src, dst, *args, **kwargs) if dst is not None \
                else fn(src, *args, **kwargs)
        return guarded

    sqlite3.connect = connect
    builtins.open = open_
    io.open = io_open
    os.open = os_open
    os.remove = remove
    os.unlink = unlink
    os.rename = rename
    os.replace = replace
    os.mkdir = mkdir
    os.makedirs = makedirs
    if real_path_open is not None:
        import pathlib
        pathlib.Path.open = path_open
    for name in ("copy", "copy2", "copyfile", "copytree", "move", "rmtree"):
        fn = getattr(shutil, name, None)
        if fn is not None:
            setattr(shutil, name, _shutil_guard(fn))
    _GUARD.installed = True


def _is_readonly_connect(target, kwargs) -> bool:
    """True when the connect arguments clearly request a read-only open."""
    text = str(target)
    if "mode=ro" in text:
        return True
    if kwargs.get("uri") and "mode=ro" in text:
        return True
    return False


def install_from_env() -> None:
    """
    Install the boundary from the exported environment (child processes).

    A failure to install is NOT swallowed: the child fails closed rather
    than running without protection.
    """
    raw = os.environ.get(PROTECTED_PATHS_ENV, "")
    paths = [p for p in raw.split(os.pathsep) if p]
    if not paths:
        raise RuntimeError(
            "production protection requested but no protected paths were "
            "exported — refusing to run without the boundary")
    allow = os.environ.get(ALLOW_CONFIG_ENV, "") == "1"
    install(paths, allow_config_write=allow)


def export_for_children(protected: Sequence[str],
                        allow_config_write: bool = False) -> None:
    """Export the protected paths (and the config opt-out) to children."""
    os.environ[PROTECTED_PATHS_ENV] = os.pathsep.join(
        _norm(p) for p in protected)
    if allow_config_write:
        os.environ[ALLOW_CONFIG_ENV] = "1"
