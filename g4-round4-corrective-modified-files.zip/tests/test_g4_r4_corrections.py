"""
tests/test_g4_r4_corrections.py — regression evidence for the corrective
round 4 findings R4-01 … R4-05.

  R4-01  the Windows SQLite URI bypass in the production protection
         boundary (the application's own URI form must not pass)
  R4-02  the journal-mode-only repair must not bypass the pre-mutation
         preservation
  R4-03  an incomplete preservation set must be self-describing
  R4-04  `memory-verify --json` must emit one parseable JSON object on
         EVERY path
  R4-05  the disposable verification copy must be disposed

Every database here is disposable; the production boundary is what makes
production access impossible.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import sqlite3
import subprocess
import sys

import pytest
from click.testing import CliRunner

from core.memory.sqlite_contract import sqlite_file_uri
from core.memory.sqlite_migration import (
    PreservationError,
    run_maintenance_migration,
)

REPO = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
PROTECTION_PATH = os.path.join(os.path.dirname(__file__), "_g4_protection.py")


def _load_protection():
    spec = importlib.util.spec_from_file_location("g4_protection_r4",
                                                  PROTECTION_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def make_current_db(path: str, rows: int = 2) -> str:
    from core.memory.backends.sqlite_storage import SQLiteStorageBackend
    SQLiteStorageBackend(str(path))
    conn = sqlite3.connect(str(path))
    try:
        conn.executemany(
            "INSERT INTO knowledge_entries(entry_id, layer, content, summary,"
            " created_at, updated_at, accessed_at) VALUES (?,?,?,?,?,?,?)",
            [(f"e{i}", "l1", f"interaction token{i}", "", 1.0, 1.0, 1.0)
             for i in range(rows)])
        conn.commit()
    finally:
        conn.close()
    return str(path)


def to_delete_mode(path: str) -> None:
    conn = sqlite3.connect(path)
    try:
        conn.execute("PRAGMA journal_mode=DELETE")
        conn.commit()
    finally:
        conn.close()


def journal_mode(path: str) -> str:
    conn = sqlite3.connect(sqlite_file_uri(path, "ro"), uri=True)
    try:
        return str(conn.execute("PRAGMA journal_mode").fetchone()[0]).lower()
    finally:
        conn.close()


# ── R4-01 — the Windows SQLite URI bypass ────────────────────────────────────

class TestR401UriProtection:
    def test_drive_uri_normalization_both_slash_forms(self):
        g4p = _load_protection()
        target = r"C:\Users\Produ\AppData\Repo\.data\memory\unified.db"
        expected = os.path.normcase(os.path.abspath(target))
        for uri in (f"file:{target.replace(chr(92), '/')}",
                    f"file:///{target.replace(chr(92), '/')}"):
            got = g4p._norm(g4p._uri_to_path(uri))
            assert got == expected, (uri, got, expected)

    def test_unc_uri_normalization(self):
        g4p = _load_protection()
        uri = "file://server/share/data/memory.db"
        got = g4p._uri_to_path(uri)
        assert "server" in got and "share" in got
        assert got.endswith("data" + os.sep + "memory.db")

    def test_percent_encoded_characters_are_restored(self):
        g4p = _load_protection()
        # a literal '?' or '#' in a file name must be percent-encoded, so
        # the URI is built from the ENCODED form
        raw = "/tmp/a%20b%23c%3Fd%25e/ü.db"
        got = g4p._uri_to_path("file:" + raw)
        assert " " in got and "#" in got and "?" in got and "%" in got
        assert "ü" in got

    def test_query_parameters_are_not_part_of_the_path(self):
        g4p = _load_protection()
        got = g4p._uri_to_path("file:/tmp/x.db?mode=ro&immutable=1")
        assert got == os.path.join("/tmp", "x.db") if os.name != "nt" \
            else got.endswith("x.db")
        assert "mode=ro" not in got

    def test_production_root_uri_is_recognized_as_protected(self):
        g4p = _load_protection()
        protected = g4p.protected_paths_for(REPO)
        target = os.path.join(REPO, ".data", "memory", "unified.db")
        uri = sqlite_file_uri(target, "ro")
        assert g4p._is_protected(uri, protected) is not None, \
            "the application's own URI form bypassed the boundary"

    @pytest.mark.parametrize("mode", ["ro", "rw", "rwc"])
    def test_every_connection_mode_is_rejected(self, mode):
        g4p = _load_protection()
        protected = g4p.protected_paths_for(REPO)
        target = os.path.join(REPO, ".data", "memory", "unified.db")
        uri = sqlite_file_uri(target, mode)
        assert g4p._is_protected(uri, protected) is not None, \
            f"mode={mode} was not rejected"

    def test_wrapped_connect_raises_and_never_reaches_the_connector(self,
                                                                     tmp_path,
                                                                     monkeypatch):
        """The ACTUAL interception is tested: the underlying SQLite
        connector must never be reached."""
        g4p = _load_protection()
        calls = []

        def recording_connect(*args, **kwargs):
            calls.append(args)
            raise AssertionError("the underlying connector was reached")

        monkeypatch.setattr(sqlite3, "connect", recording_connect)
        protected = g4p.protected_paths_for(REPO)
        g4p.install(protected)
        try:
            target = os.path.join(REPO, ".data", "memory", "unified.db")
            for mode in ("ro", "rw", "rwc"):
                with pytest.raises(g4p.ProtectedPathError):
                    sqlite3.connect(sqlite_file_uri(target, mode), uri=True)
            assert calls == [], "the underlying connector was reached"
        finally:
            g4p.install(protected)     # restore a consistent boundary

    def test_child_process_inherits_and_installs_the_protection(self,
                                                                 tmp_path):
        """A child interpreter installs the SAME boundary from the exported
        environment and is blocked."""
        child = tmp_path / "child.py"
        child.write_text(
            "import sqlite3, sys\n"
            "import _g4_protection\n"
            "_g4_protection.install_from_env()\n"
            "try:\n"
            "    sqlite3.connect(sys.argv[1], uri=True)\n"
            "    print('ACCESSED')\n"
            "except Exception as exc:\n"
            "    print('BLOCKED:' + type(exc).__name__)\n",
            encoding="ascii")
        target = os.path.join(REPO, ".data", "memory", "unified.db")
        env = dict(os.environ)
        env["PYTHONPATH"] = os.pathsep.join([
            os.path.join(os.path.dirname(__file__)), env.get("PYTHONPATH", "")])
        proc = subprocess.run(
            [sys.executable, "-X", "utf8", str(child),
             sqlite_file_uri(target, "ro")],
            capture_output=True, text=True, timeout=120, env=env)
        assert "ACCESSED" not in proc.stdout, \
            "the child reached the production database"
        assert "BLOCKED" in proc.stdout, proc.stdout + proc.stderr

    def test_child_fails_closed_when_the_protection_cannot_install(self,
                                                                   tmp_path):
        """A child whose protection import FAILS must not continue."""
        child = tmp_path / "child.py"
        child.write_text(
            "import sys\n"
            "try:\n"
            "    import _g4_protection\n"
            "except Exception:\n"
            "    print('NO-PROTECTION')\n"
            "    sys.exit(3)\n"
            "_g4_protection.install_from_env()\n"
            "print('INSTALLED')\n",
            encoding="ascii")
        env = dict(os.environ)
        # an empty PYTHONPATH means the import fails -> the child must not
        # proceed
        env["PYTHONPATH"] = str(tmp_path)
        env["OCBRAIN_PROTECTED_PATHS"] = ""
        proc = subprocess.run([sys.executable, "-X", "utf8", str(child)],
                              capture_output=True, text=True, timeout=120,
                              env=env)
        assert proc.returncode != 0, proc.stdout
        assert "INSTALLED" not in proc.stdout


# ── R4-02 — the journal-mode-only repair must preserve first ─────────────────

class TestR402JournalModeRepairPreservation:
    def test_successful_repair_has_a_pre_transition_snapshot(self, tmp_path):
        db = make_current_db(str(tmp_path / "a.db"))
        to_delete_mode(db)
        before = sha256_file(db)

        report = run_maintenance_migration(db)
        assert report.outcome == "repaired", report.failure
        assert journal_mode(db) == "wal"

        # the preservation snapshot exists and matches the pre-transition
        # bytes
        assert report.preserved_files, "no pre-mutation evidence was taken"
        preserved = report.preserved_files[0]
        assert sha256_file(preserved) == before, \
            "the preserved copy does not match the pre-transition database"
        assert report.preservation["disposition"] == "complete"
        assert report.preservation["destination_dir"]
        assert report.preservation["manifest_path"]

        # the narrow scope of the repair is unchanged
        steps = {s["step"]: s for s in report.steps}
        assert steps["fts_rebuild"]["status"] == "skipped"
        assert steps["replace_triggers"]["status"] == "skipped"
        assert steps["ensure_indexes"]["status"] == "skipped"
        conn = sqlite3.connect(sqlite_file_uri(db, "ro"), uri=True)
        try:
            ledger = conn.execute(
                "SELECT migration_id, COUNT(*) FROM _ocbrain_memory_migrations"
                " GROUP BY migration_id").fetchall()
        finally:
            conn.close()
        assert len(ledger) == 1 and ledger[0][1] == 1, \
            "the repair added a duplicate ledger row"

    def test_preservation_failure_refuses_the_transition(self, tmp_path,
                                                        monkeypatch):
        import core.memory.sqlite_migration as mig
        db = make_current_db(str(tmp_path / "b.db"))
        to_delete_mode(db)
        before = sha256_file(db)

        def failing_preserve(*args, **kwargs):
            raise mig.PreservationError(
                destination_dir=str(tmp_path / "partial"),
                manifest_path=str(tmp_path / "partial" / "manifest.json"),
                db_path=db, copied=[], verified=[],
                failed_file=db, stage="copy_or_verify",
                error="injected preservation failure", manifest_written=True)

        monkeypatch.setattr(mig, "_preserve_recoverable_state",
                            failing_preserve)
        report = run_maintenance_migration(db)
        assert report.outcome == "failed"
        assert journal_mode(db) == "delete", \
            "the journal mode was converted despite the preservation failure"
        assert sha256_file(db) == before, "the database was modified"
        assert report.preservation["disposition"] == "incomplete"
        assert report.preservation["destination_dir"] == str(
            tmp_path / "partial")
        assert "partial" in (report.remediation or "")

    def test_an_existing_recovery_snapshot_is_reused(self, tmp_path):
        """A recovery-risk preservation that already exists must not be
        duplicated for the pre-mutation snapshot."""
        db = make_current_db(str(tmp_path / "c.db"))
        to_delete_mode(db)
        # a hot journal makes the recovery-risk preservation fire
        with open(db + "-journal", "wb") as fh:
            fh.write(b"\x00" * 64)
        report = run_maintenance_migration(db)
        assert report.preserved_files
        destinations = {os.path.dirname(p) for p in report.preserved_files}
        assert len(destinations) == 1, \
            f"a second, unnecessary preservation set was created: {destinations}"
        assert report.preservation["reason"] == "preflight_recovery_snapshot"


# ── R4-03 — an incomplete preservation set is self-describing ───────────────

class TestR403IncompletePreservation:
    def test_copy_failure_leaves_a_truthful_incomplete_manifest(self, tmp_path,
                                                                monkeypatch):
        import core.memory.sqlite_migration as mig
        db = make_current_db(str(tmp_path / "a.db"))
        # a second artifact so the failure happens on the SECOND copy
        with open(db + "-wal", "wb") as fh:
            fh.write(b"WALDATA")
        real_copy2 = mig.shutil.copy2
        calls = {"n": 0}

        def flaky(src, dst, **kw):
            calls["n"] += 1
            if calls["n"] == 2:
                raise OSError("injected copy failure")
            return real_copy2(src, dst, **kw)

        monkeypatch.setattr(mig.shutil, "copy2", flaky)
        with pytest.raises(mig.PreservationError) as excinfo:
            mig._preserve_recoverable_state(db, "unit: injected copy failure")
        exc = excinfo.value

        # the first artifact is retained and matches its source
        assert exc.verified, "the verified artifact was not reported"
        assert os.path.exists(exc.verified[0])
        assert sha256_file(exc.verified[0]) == sha256_file(db)
        # the failed artifact is identified
        assert exc.failed_file and exc.failed_file.endswith("-wal")
        assert exc.stage == "copy_or_verify"
        assert "injected copy failure" in exc.error
        # the destination is available to the caller
        assert exc.destination_dir and os.path.isdir(exc.destination_dir)
        # the manifest says incomplete and lists the verified artifact
        manifest = json.loads(open(exc.manifest_path, encoding="utf-8").read())
        assert manifest["status"] == "incomplete"
        assert manifest["complete"] is False
        assert manifest["failed_file"]
        assert any(f.get("verified") for f in manifest["files"])
        assert manifest["originals_retained"] is True

    def test_manifest_write_failure_still_discloses_the_destination(
            self, tmp_path, monkeypatch):
        import core.memory.sqlite_migration as mig
        db = make_current_db(str(tmp_path / "b.db"))
        real_write = mig._write_preservation_manifest

        def failing_write(path, payload):
            raise OSError("injected manifest write failure")

        monkeypatch.setattr(mig, "_write_preservation_manifest", failing_write)
        with pytest.raises(mig.PreservationError) as excinfo:
            mig._preserve_recoverable_state(db, "unit: manifest write failure")
        exc = excinfo.value
        assert exc.manifest_written is False
        assert exc.destination_dir and os.path.isdir(exc.destination_dir)
        assert exc.stage == "manifest_write"

    def test_the_runner_refuses_when_the_preservation_is_incomplete(
            self, tmp_path, monkeypatch):
        import core.memory.sqlite_migration as mig
        db = make_current_db(str(tmp_path / "c.db"))
        to_delete_mode(db)
        real = mig._preserve_recoverable_state
        calls = {"n": 0}

        def failing(*args, **kwargs):
            calls["n"] += 1
            raise mig.PreservationError(
                destination_dir=str(tmp_path / "partial2"),
                manifest_path=str(tmp_path / "partial2" / "manifest.json"),
                db_path=db, copied=[], verified=[], failed_file=db,
                stage="copy_or_verify", error="injected", manifest_written=True)

        monkeypatch.setattr(mig, "_preserve_recoverable_state", failing)
        report = run_maintenance_migration(db)
        assert report.outcome == "failed"
        assert report.preservation["disposition"] == "incomplete"
        assert report.preserved_files == []
        assert journal_mode(db) == "delete"


# ── R4-04 — `memory-verify --json` always emits one JSON object ─────────────

class TestR404JsonContract:
    def _invoke(self, args):
        result = CliRunner().invoke(
            __import__("interface.cli", fromlist=["cli"]).cli, args,
            catch_exceptions=True)
        return result

    def test_missing_database_is_valid_json(self, tmp_path):
        from interface.cli import cli
        db = str(tmp_path / "absent.db")
        result = CliRunner().invoke(cli, ["memory-verify", "--db", db,
                                           "--json"],
                                    catch_exceptions=True)
        payload = json.loads(result.stdout)
        assert payload["ok"] is False
        assert payload["contract_passed"] is False
        assert payload["error"]["stage"] == "path_check"
        assert result.exit_code == 1
        assert not os.path.exists(db), "a database was created"

    def test_open_failure_is_valid_json(self, tmp_path, monkeypatch):
        from interface.cli import cli
        db = make_current_db(str(tmp_path / "m.db"))
        import interface.cli as cli_mod

        def failing_connect(*args, **kwargs):
            raise sqlite3.OperationalError("injected open failure")

        monkeypatch.setattr(sqlite3, "connect", failing_connect)
        result = CliRunner().invoke(cli, ["memory-verify", "--db", db,
                                           "--json"],
                                    catch_exceptions=True)
        payload = json.loads(result.stdout)
        assert payload["ok"] is False
        assert payload["error"]["stage"] == "open"
        assert result.exit_code == 1

    def test_inspection_failure_is_valid_json(self, tmp_path, monkeypatch):
        from interface.cli import cli
        db = make_current_db(str(tmp_path / "m.db"))
        import interface.cli as cli_mod

        def failing_validation(conn, *args, **kwargs):
            raise sqlite3.OperationalError("injected inspection failure")

        import core.memory.sqlite_integrity as integrity_mod
        monkeypatch.setattr(integrity_mod, "run_full_integrity_validation",
                            failing_validation)
        result = CliRunner().invoke(cli, ["memory-verify", "--db", db,
                                           "--json"],
                                    catch_exceptions=True)
        payload = json.loads(result.stdout)
        assert payload["ok"] is False
        assert payload["checks_ran"] is False
        assert result.exit_code == 1

    def test_contract_failure_still_emits_the_full_contract(self, tmp_path):
        from interface.cli import cli
        db = make_current_db(str(tmp_path / "m.db"))
        conn = sqlite3.connect(db)
        conn.execute("DROP TRIGGER ke_ad")
        conn.commit()
        conn.close()
        result = CliRunner().invoke(cli, ["memory-verify", "--db", db,
                                           "--json"],
                                    catch_exceptions=True)
        payload = json.loads(result.stdout)
        assert payload["contract_passed"] is False
        assert payload["contract"]["trigger_contract"]["status"] == "fail"
        assert len(payload["contract"]) == 11
        assert result.exit_code == 1

    def test_success_emits_the_full_contract_and_exit_zero(self, tmp_path):
        from interface.cli import cli
        db = make_current_db(str(tmp_path / "m.db"))
        result = CliRunner().invoke(cli, ["memory-verify", "--db", db,
                                           "--json"],
                                    catch_exceptions=True)
        payload = json.loads(result.stdout)
        assert payload["ok"] is True
        assert payload["contract_passed"] is True
        assert len(payload["contract"]) == 11
        assert result.exit_code == 0


# ── R4-05 — the disposable verification copy is disposed ────────────────────

class TestR405DisposableCopy:
    def _hot_journal_db(self, path: str) -> str:
        db = make_current_db(path)
        to_delete_mode(db)
        child = os.path.join(os.path.dirname(path), "child.py")
        with open(child, "w", encoding="ascii") as fh:
            fh.write(
                "import os, sqlite3, sys\n"
                "c = sqlite3.connect(sys.argv[1])\n"
                "c.execute('BEGIN')\n"
                "c.execute(\"UPDATE knowledge_entries SET content='x'\")\n"
                "os._exit(1)\n")
        subprocess.run([sys.executable, "-X", "utf8", child, db],
                       capture_output=True)
        return db

    def test_copy_is_removed_and_the_forensic_snapshot_remains(self, tmp_path):
        from interface.cli import cli
        db = self._hot_journal_db(str(tmp_path / "m.db"))
        assert os.path.exists(db + "-journal")
        main_before = sha256_file(db)
        journal_before = sha256_file(db + "-journal")

        result = CliRunner().invoke(cli, ["memory-verify", "--db", db,
                                           "--json"],
                                    catch_exceptions=True)
        payload = json.loads(result.stdout)
        # the forensic snapshot exists and matches the originals
        assert payload["recovery_evidence_preserved"]
        preserved = payload["recovery_evidence_preserved"]
        assert any(p.endswith("-journal") for p in preserved)
        for path in preserved:
            assert os.path.exists(path)
        # the verdict concerns the disposable copy
        assert "COPY" in payload["verdict_scope"]
        assert payload["verification_target_removed"] is True
        assert not os.path.exists(payload["verification_target"])
        # the originals are byte-identical
        assert sha256_file(db) == main_before
        assert sha256_file(db + "-journal") == journal_before
        # the forensic snapshot is NOT removed
        for path in preserved:
            assert os.path.exists(path), "the forensic snapshot was deleted"

    def test_copy_failure_still_removes_the_temporary_directory(self, tmp_path,
                                                                 monkeypatch):
        from interface.cli import cli
        import interface.cli as cli_mod
        db = self._hot_journal_db(str(tmp_path / "m.db"))
        import shutil as shutil_mod
        real_copy2 = shutil_mod.copy2
        created = {}

        def failing(src, dst, **kw):
            # fail ONLY the disposable verification copy - the forensic
            # preservation must still succeed
            if "ocbrain-verify-copy-" in str(dst):
                created["dir"] = os.path.dirname(dst)
                raise OSError("injected disposable copy failure")
            return real_copy2(src, dst, **kw)

        monkeypatch.setattr(shutil_mod, "copy2", failing)
        result = CliRunner().invoke(cli, ["memory-verify", "--db", db,
                                           "--json"],
                                    catch_exceptions=True)
        payload = json.loads(result.stdout)
        assert payload["ok"] is False
        assert payload["error"]["stage"] == "disposable_copy"
        assert result.exit_code == 1
        if created.get("dir"):
            assert not os.path.exists(created["dir"]), \
                "the temporary directory was left behind"
