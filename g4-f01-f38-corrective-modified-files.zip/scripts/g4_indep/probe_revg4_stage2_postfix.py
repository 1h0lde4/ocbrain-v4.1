#!/usr/bin/env python3
"""
g4_indep/probe_revg4_stage2_postfix.py - post-fix verification of the
corrective-remediation findings REV-G4-01..08.

This is the counterpart of scripts/g4_indep/probe_revg4_stage1_repro.py:
the SAME scenarios are re-measured against the CORRECTED code, and each one
must now report that the defect is GONE. The Stage-1 artifacts (the evidence
of the defects) are never overwritten - this script writes to
docs/reports/independent-g4-fts/remediation2/evidence/postfix/.

Safety contract (identical to Stage 1):
  * every scenario uses an isolated database under a fresh
    %TEMP%\\g4postfix_* directory;
  * the production database (.data/memory/unified.db) is NEVER opened;
  * OCBRAIN_MEMORY_RUNTIME_ACK=acknowledge is the documented TEST-ENV-ONLY
    mechanism for backend construction on this affected runtime - never a
    production certification.

Run from the repository root:
    python -X utf8 scripts/g4_indep/probe_revg4_stage2_postfix.py
"""
from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import subprocess
import sys
import tempfile
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))

from core.memory.sqlite_contract import CANONICAL_INDEX_DDL  # noqa: E402
from core.memory.sqlite_migration import (               # noqa: E402
    collect_checkpoint_inventory,
    create_online_backup,
    estimate_migration_space,
    initialize_schema,
    inspect_migration_state,
    run_maintenance_migration,
)
from core.memory.sqlite_integrity import validate_readiness  # noqa: E402

ART_DIR = (REPO / "docs" / "reports" / "independent-g4-fts" / "remediation2"
           / "evidence" / "postfix")
ART_DIR.mkdir(parents=True, exist_ok=True)

os.environ.setdefault("OCBRAIN_MEMORY_RUNTIME_ACK", "acknowledge")

RESULTS: list = []


def sha256(path: str):
    try:
        h = hashlib.sha256()
        with open(path, "rb") as fh:
            for chunk in iter(lambda: fh.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
    except OSError as exc:
        return f"unreadable: {exc}"


def snap(db_path: str) -> dict:
    out = {}
    for suffix in ("", "-wal", "-shm", "-journal"):
        p = str(db_path) + suffix
        out[suffix or "db"] = (
            {"bytes": os.path.getsize(p), "sha256": sha256(p)}
            if os.path.exists(p) else None)
    return out


def journal_mode_ro(db_path: str):
    if not os.path.exists(str(db_path)):
        return "missing-file"
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=5)
    try:
        return str(conn.execute("PRAGMA journal_mode").fetchone()[0])
    finally:
        conn.close()


def build_current_db(db_path: str, rows: int = 3) -> None:
    conn = sqlite3.connect(str(db_path))
    try:
        initialize_schema(conn)
        for i in range(rows):
            conn.execute(
                "INSERT INTO knowledge_entries(entry_id, layer, content, "
                "summary, created_at, updated_at, accessed_at) "
                "VALUES (?,?,?,?,?,?,?)",
                (f"entry:{i}", "l1", f"content token{i} alpha bravo",
                 "", 1.0, 1.0, 1.0))
        conn.commit()
    finally:
        conn.close()


def new_dir(name: str) -> str:
    return tempfile.mkdtemp(prefix=f"g4postfix_{name}_")


def record(tag: str, finding: str, data: dict) -> None:
    payload = {
        "probe": tag,
        "finding": finding,
        "phase": "post-fix verification (Stage 2)",
        "recorded_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "runtime": {"python": sys.version.split()[0],
                    "sqlite3_sqlite_version": sqlite3.sqlite_version},
        **data,
    }
    text = json.dumps(payload, indent=2, default=str)
    (ART_DIR / f"postfix_{tag}.txt").write_text(text, encoding="ascii",
                                                 errors="replace")
    RESULTS.append((tag, finding, data.get("defect_gone")))
    print(f"[{tag}] {finding}: defect_gone={data.get('defect_gone')}")


CRASH_CHILD_COMMIT = (
    "import os, sqlite3, sys\n"
    "c = sqlite3.connect(sys.argv[1])\n"
    "c.execute('PRAGMA journal_mode=WAL')\n"
    "c.execute('BEGIN')\n"
    "c.execute(\"INSERT INTO knowledge_entries(entry_id, layer, content, "
    "summary, created_at, updated_at, accessed_at) VALUES "
    "('crash','l1','crash tokens xqz','',1,1,1)\")\n"
    "c.commit()\n"
    "os._exit(1)\n")


def crash_child(db_path: str) -> None:
    child = str(db_path) + ".child.py"
    with open(child, "w", encoding="ascii") as fh:
        fh.write(CRASH_CHILD_COMMIT)
    proc = subprocess.run([sys.executable, "-X", "utf8", child, str(db_path)],
                          capture_output=True, text=True)
    os.remove(child)
    assert proc.returncode != 0


# ── REV-G4-01: the doctor no longer consumes recoverable WAL state ──────────
def p01():
    from click.testing import CliRunner
    from interface.cli import cli
    d = new_dir("p01")
    db = os.path.join(d, "unified.db")
    build_current_db(db)
    crash_child(db)
    before = snap(db)
    res = CliRunner().invoke(cli, ["memory-doctor", "--db", db, "--json"],
                              catch_exceptions=True)
    after = snap(db)
    # the strict invariants: the main image and any -wal frames are
    # byte-identical; only -shm/-wal scaffolding may differ
    main_same = before["db"] == after["db"]
    wal_same = (before["-wal"] is None
                or after["-wal"] == before["-wal"])
    record("p01_doctor_leaves_wal_untouched", "REV-G4-01", {
        "scenario": "memory-doctor --json against a WAL database with a "
                    "committed, uncheckpointed transaction",
        "main_image_unchanged": main_same,
        "wal_frames_unchanged": wal_same,
        "json_parsed": _json_ok(res.output),
        "defect_gone": bool(main_same and wal_same and _json_ok(res.output)),
        "note": ("the doctor opens strictly read-only; a read-only open may "
                 "create an EMPTY -wal/-shm coordination scaffold and may "
                 "churn -shm bytes, but it cannot consume frames or "
                 "rewrite the main image"),
    })


def _json_ok(text: str) -> bool:
    try:
        json.loads(text or "")
        return True
    except Exception:
        return False


# ── REV-G4-02: the runner refuses an unsupported database before mutating ──
def p02():
    d = new_dir("p02")
    db = os.path.join(d, "unified.db")
    conn = sqlite3.connect(db)
    conn.execute("CREATE TABLE unrelated_stuff(x TEXT)")
    conn.commit()
    conn.close()
    before = snap(db)
    mode_before = journal_mode_ro(db)
    report = run_maintenance_migration(db)
    after = snap(db)
    mode_after = journal_mode_ro(db)
    record("p02_unsupported_db_not_converted", "REV-G4-02", {
        "scenario": "run_maintenance_migration() against an unrelated "
                    "DELETE-journal database",
        "outcome": report.outcome,
        "journal_mode_before": mode_before,
        "journal_mode_after": mode_after,
        "filesystem_unchanged": before == after,
        "defect_gone": (mode_before == mode_after and before == after),
    })


# ── REV-G4-03: index drift is detected and repaired ─────────────────────────
def p03():
    d = new_dir("p03")
    db = os.path.join(d, "unified.db")
    build_current_db(db)
    conn = sqlite3.connect(db)
    conn.execute("DROP INDEX idx_ke_layer")
    conn.commit()
    conn.close()
    ro = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    readiness_failed = validate_readiness(ro)["passed"] is False
    state = inspect_migration_state(ro).state
    ro.close()
    report = run_maintenance_migration(db)
    ro = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    readiness_ok = validate_readiness(ro)["passed"]
    ro.close()
    record("p03_index_drift_detected_and_repaired", "REV-G4-03", {
        "scenario": "current database with idx_ke_layer dropped",
        "readiness_refuses_drift": readiness_failed,
        "state_before_repair": state,
        "runner_outcome": report.outcome,
        "readiness_after_repair": readiness_ok,
        "defect_gone": bool(readiness_failed and state != "current"
                            and report.outcome == "migrated"
                            and readiness_ok),
    })


def p03b():
    d = new_dir("p03b")
    db = os.path.join(d, "unified.db")
    build_current_db(db)
    conn = sqlite3.connect(db)
    conn.execute("DROP INDEX idx_ke_layer")
    conn.execute("CREATE INDEX idx_ke_layer ON knowledge_entries(source)")
    conn.commit()
    conn.close()
    ro = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    readiness_failed = validate_readiness(ro)["passed"] is False
    ro.close()
    record("p03b_wrong_definition_rejected", "REV-G4-03", {
        "scenario": "same-name idx_ke_layer with the WRONG definition",
        "readiness_refuses_wrong_definition": readiness_failed,
        "defect_gone": bool(readiness_failed),
    })


# ── REV-G4-04: a migration never creates a database ─────────────────────────
def p04():
    d = new_dir("p04")
    db = os.path.join(d, "unified.db")
    est = estimate_migration_space(db)
    created_by_estimate = os.path.exists(db)
    report = run_maintenance_migration(db)
    created_by_runner = os.path.exists(db)
    record("p04_missing_target_never_created", "REV-G4-04", {
        "scenario": "estimate + migration against a MISSING path",
        "estimate_error_reported": "error" in est,
        "created_by_estimate": created_by_estimate,
        "created_by_runner": created_by_runner,
        "outcome": report.outcome,
        "defect_gone": bool(not created_by_estimate and not created_by_runner),
    })


# ── REV-G4-05: the backup helper protects both sides ───────────────────────
def p05():
    d = new_dir("p05")
    src = os.path.join(d, "missing.db")
    dest = os.path.join(d, "backup.db")
    result = create_online_backup(src, dest)
    record("p05_backup_missing_source_not_created", "REV-G4-05", {
        "scenario": "create_online_backup() with a MISSING source",
        "result_ok": result.get("ok"),
        "error": result.get("error"),
        "source_created": os.path.exists(src),
        "destination_left_behind": os.path.exists(dest),
        "defect_gone": bool(not os.path.exists(src)
                            and not os.path.exists(dest)),
    })


# ── REV-G4-06: the rollback journal is preserved before any open ───────────
def p06():
    d = new_dir("p06")
    db = os.path.join(d, "unified.db")
    build_current_db(db)
    for suffix in ("-wal", "-shm", "-journal"):
        with open(db + suffix, "wb") as fh:
            fh.write(b"\x00" * 64)
    before = snap(db)
    from core.memory.sqlite_migration import _preserve_corrupt_database
    saved = _preserve_corrupt_database(db, "postfix: preservation check")
    names = {os.path.basename(p) for p in saved}
    record("p06_journal_is_preserved", "REV-G4-06", {
        "scenario": "preservation with main/-wal/-shm/-journal present",
        "preserved_files": sorted(names),
        "journal_preserved": any(n.endswith("-journal") for n in names),
        "originals_retained": snap(db) == before,
        "defect_gone": bool(any(n.endswith("-journal") for n in names)
                            and snap(db) == before),
    })


# ── REV-G4-07: the inspection connection is closed; the mode is invariant ──
def p07a():
    d = new_dir("p07a")
    db = os.path.join(d, "unified.db")
    build_current_db(db)
    os.remove(db)                       # force the fresh-init path
    import core.memory.backends.sqlite_storage as ss
    captured = {}
    real_vr = ss.validate_readiness

    def failing_vr(conn):
        captured["conn"] = conn
        raise RuntimeError("simulated validation failure (fault injection)")

    ss.validate_readiness = failing_vr
    exc_text = None
    try:
        try:
            from core.memory.backends.sqlite_storage import SQLiteStorageBackend
            SQLiteStorageBackend(db)
        except Exception as exc:        # noqa: BLE001
            exc_text = f"{type(exc).__name__}: {exc}"
        conn = captured.get("conn")
        still_open = False
        if conn is not None:
            try:
                conn.execute("SELECT 1").fetchall()
                still_open = True
            except sqlite3.Error:
                still_open = False
        removable = True
        try:
            os.remove(db)
        except OSError:
            removable = False
    finally:
        ss.validate_readiness = real_vr
    record("p07a_inspection_connection_closed", "REV-G4-07", {
        "scenario": "fresh-init path with an injected validation failure",
        "constructor_exception": exc_text,
        "connection_still_usable_after_failure": still_open,
        "file_removable_after_failure": removable,
        "defect_gone": bool(not still_open and removable),
    })


def p07b():
    d = new_dir("p07b")
    db = os.path.join(d, "unified.db")
    build_current_db(db)
    conn = sqlite3.connect(db)
    conn.execute("PRAGMA journal_mode=DELETE")
    conn.commit()
    conn.close()
    mode_before = journal_mode_ro(db)
    from core.memory.backends.sqlite_storage import SQLiteStorageBackend
    refused = False
    refusal = None
    try:
        SQLiteStorageBackend(db)
    except Exception as exc:            # noqa: BLE001
        refused = True
        refusal = f"{type(exc).__name__}: {exc}"[:220]
    mode_after = journal_mode_ro(db)
    record("p07b_delete_mode_database_refused", "REV-G4-07", {
        "scenario": "current-schema database externally flipped to "
                    "journal mode DELETE",
        "journal_mode_before": mode_before,
        "journal_mode_after": mode_after,
        "readiness_refused": refused,
        "refusal": refusal,
        "defect_gone": bool(refused and mode_before == mode_after),
    })


# ── REV-G4-08: the CLI says what it does ────────────────────────────────────
def p08():
    from click.testing import CliRunner
    from interface.cli import cli
    d = new_dir("p08")
    missing = os.path.join(d, "missing.db")
    res = CliRunner().invoke(cli, ["memory-doctor", "--db", missing, "--json"],
                              catch_exceptions=True)
    parsed = None
    try:
        parsed = json.loads(res.output or "")
    except Exception:
        parsed = None
    unavailable = bool(
        parsed
        and parsed.get("migration_state", {}).get("schema_state")
        == "unavailable"
        and parsed.get("readiness") is None)
    created = os.path.exists(missing)
    # repeated in-process invocations must keep working (REV-G4-08.B)
    repeat_ok = True
    for _ in range(3):
        r2 = CliRunner().invoke(cli, ["memory-doctor", "--db", missing,
                                       "--json"], catch_exceptions=True)
        if not _json_ok(r2.output):
            repeat_ok = False
    record("p08_doctor_reports_unavailable_truthfully", "REV-G4-08", {
        "scenario": "memory-doctor --json against a MISSING database",
        "json_parsed": parsed is not None,
        "reported_unavailable": unavailable,
        "database_created": created,
        "repeated_invocations_ok": repeat_ok,
        "defect_gone": bool(parsed is not None and unavailable
                            and not created and repeat_ok),
    })


def main() -> None:
    p01()
    p02()
    p03()
    p03b()
    p04()
    p05()
    p06()
    p07a()
    p07b()
    p08()
    print("=== post-fix verification summary ===")
    gone = sum(1 for _, _, g in RESULTS if g)
    for tag, finding, g in RESULTS:
        print(f"  {tag}: {finding} -> defect_gone={g}")
    print(f"{gone}/{len(RESULTS)} scenarios confirm the defect is gone")
    if gone != len(RESULTS):
        sys.exit(1)


if __name__ == "__main__":
    main()
