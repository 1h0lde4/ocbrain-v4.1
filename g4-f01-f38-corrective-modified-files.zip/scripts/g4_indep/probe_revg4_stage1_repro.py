#!/usr/bin/env python3
"""
g4_indep/probe_revg4_stage1_repro.py - Stage-1 reproduction probes for the
corrective-remediation findings REV-G4-01..08.

Run from the repository root:
    python -X utf8 scripts/g4_indep/probe_revg4_stage1_repro.py

Safety contract:
  * Every scenario uses an isolated database under a fresh
    %TEMP%\\g4repro_* directory. The production database
    (.data/memory/unified.db) is NEVER opened, read or referenced.
  * The only module imports are core.memory.* (no orchestrator/singleton
    construction at import time) plus interface.cli for the doctor probe.
  * OCBRAIN_MEMORY_RUNTIME_ACK=acknowledge is set for backend construction
    on this affected runtime (3.50.4) - the documented TEST-ENV-ONLY
    mechanism; it is never a production certification.

Each scenario prints a finding block and writes an artifact file to
docs/reports/independent-g4-fts/remediation2/evidence/stage1/.
"""
from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import os
import sqlite3
import subprocess
import sys
import tempfile
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))

from core.memory.sqlite_contract import (          # noqa: E402
    CANONICAL_INDEX_DDL,
    CANONICAL_TRIGGER_DDL,
)
from core.memory.sqlite_migration import (          # noqa: E402
    collect_checkpoint_inventory,
    create_online_backup,
    estimate_migration_space,
    initialize_schema,
    inspect_migration_state,
    run_maintenance_migration,
    _preserve_corrupt_database,
)
from core.memory.sqlite_integrity import validate_readiness  # noqa: E402
from core.memory.backends.sqlite_storage import (    # noqa: E402
    SQLiteStorageBackend,
)

ART_DIR = REPO / "docs" / "reports" / "independent-g4-fts" / \
    "remediation2" / "evidence" / "stage1"
ART_DIR.mkdir(parents=True, exist_ok=True)

os.environ.setdefault("OCBRAIN_MEMORY_RUNTIME_ACK", "acknowledge")

RESULTS: list = []


# ── helpers ──────────────────────────────────────────────────────────────────

def sha256(path: str):
    try:
        h = hashlib.sha256()
        with open(path, "rb") as fh:
            for chunk in iter(lambda: fh.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
    except OSError as exc:
        return f"unreadable: {exc}"


def snap(db_path: str) -> dict:
    """Filesystem snapshot: main/-wal/-shm/-journal existence+size+hash."""
    out = {}
    for suffix, key in (("", "db"), ("-wal", "wal"), ("-shm", "shm"),
                        ("-journal", "journal")):
        p = str(db_path) + suffix
        if os.path.exists(p):
            out[key] = {"bytes": os.path.getsize(p), "sha256": sha256(p)}
        else:
            out[key] = None
    return out


def journal_mode_ro(db_path: str):
    """Journal mode via a read-only connection (never mutates)."""
    if not os.path.exists(str(db_path)):
        return "missing-file"
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=5)
        try:
            return str(conn.execute("PRAGMA journal_mode").fetchone()[0])
        finally:
            conn.close()
    except sqlite3.Error as exc:
        return f"ro-open-failed: {exc}"


def build_current_db(db_path: str, rows: int = 3) -> None:
    conn = sqlite3.connect(str(db_path))
    try:
        initialize_schema(conn)
        for i in range(rows):
            conn.execute(
                "INSERT INTO knowledge_entries(entry_id, layer, content, "
                "summary, created_at, updated_at, accessed_at) "
                "VALUES (?,?,?,?,?,?,?)",
                (f"entry:{i}", "l1", f"content token{i} alpha bravo",
                 "", 1.0, 1.0, 1.0))
        conn.commit()
    finally:
        conn.close()


def new_dir(name: str) -> str:
    return tempfile.mkdtemp(prefix=f"g4repro_{name}_")


def record(tag: str, title: str, data: dict) -> None:
    data_full = {
        "probe": tag,
        "finding": title,
        "recorded_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "runtime": {
            "python": sys.version.split()[0],
            "sqlite3_sqlite_version": sqlite3.sqlite_version,
        },
        **data,
    }
    text = json.dumps(data_full, indent=2, default=str)
    art = ART_DIR / f"repro_{tag}.txt"
    art.write_text(text, encoding="ascii", errors="replace")
    RESULTS.append((tag, title))
    print(f"[{tag}] {title}")
    print(text[:1600])
    print()


# Child process source for crash-without-close (leaves WAL/journal evidence).
CRASH_CHILD = r"""
import os, sqlite3, sys
db = sys.argv[1]
mode = sys.argv[2]
conn = sqlite3.connect(db)
if mode == "wal":
    conn.execute("PRAGMA journal_mode=WAL")
conn.execute("BEGIN")
conn.execute("INSERT INTO knowledge_entries(entry_id, layer, content, "
             "summary, created_at, updated_at, accessed_at) "
             "VALUES ('crash_row','l1','crash uncheckpointed tokens','',1,1,1)")
if mode == "wal":
    # commit but die WITHOUT closing: the committed frames stay in the -wal
    # (no close-time checkpoint ever runs)
    conn.commit()
else:
    # die WITHOUT committing: the rollback journal stays on disk as a HOT
    # journal (SQLite deletes it at commit; the crash prevents that)
    pass
os._exit(1)
"""


def crash_child(db_path: str, mode: str) -> None:
    child = Path(str(db_path) + ".child.py")
    child.write_text(CRASH_CHILD, encoding="ascii")
    proc = subprocess.run(
        [sys.executable, "-X", "utf8", str(child), str(db_path), mode],
        capture_output=True, text=True)
    child.unlink(missing_ok=True)
    assert proc.returncode != 0, "child was expected to die via os._exit(1)"


# ── REV-G4-01: doctor write-capable inspection ───────────────────────────────

def r1a_checkpoint_inventory_mutates_wal():
    d = new_dir("r1a")
    db = os.path.join(d, "unified.db")
    build_current_db(db)                       # WAL already (fresh init)
    crash_child(db, "wal")                     # committed frames, no checkpoint
    before = snap(db)
    assert before["wal"] is not None, "fixture: -wal should exist after crash"
    inv = collect_checkpoint_inventory(db)     # the doctor's inventory call
    after = snap(db)
    record("revg4_01a_checkpoint_inventory_wal_mutation", "REV-G4-01", {
        "scenario": ("WAL database with a committed uncheckpointed "
                     "transaction (child died via os._exit without close); "
                     "collect_checkpoint_inventory() opened with plain "
                     "sqlite3.connect()"),
        "wal_bytes_before": before["wal"]["bytes"],
        "wal_sha256_before": before["wal"]["sha256"],
        "shm_before": before["shm"],
        "db_sha256_before": before["db"]["sha256"],
        "wal_after": after["wal"],
        "shm_after": after["shm"],
        "db_sha256_after": after["db"]["sha256"],
        "mutation_observed": (
            before["wal"]["sha256"] != (after["wal"] or {}).get("sha256")
            or (before["shm"] is not None) != (after["shm"] is not None)),
        "checkpoint_inventory_connection_facts": inv.get("connection_facts"),
        "defect": ("a read-only-described diagnostic opened the database "
                   "read-write; the close-time checkpoint lifecycle "
                   "consumed/rewrote the recoverable WAL state"),
    })


def r1b_full_doctor_mutation():
    d = new_dir("r1b")
    db = os.path.join(d, "unified.db")
    build_current_db(db)
    crash_child(db, "wal")
    before = snap(db)
    from click.testing import CliRunner
    from interface.cli import cli
    runner = CliRunner()
    res = runner.invoke(cli, ["memory-doctor", "--db", db, "--json"],
                        catch_exceptions=True)
    after = snap(db)
    record("revg4_01b_doctor_cli_wal_mutation", "REV-G4-01", {
        "scenario": ("full `memory-doctor --json` (CliRunner) against the "
                     "same WAL-with-uncheckpointed-commit fixture; doctor "
                     "docstring claims it 'writes nothing to the database'"),
        "doctor_exit_ok": not res.exception,
        "doctor_output_head": (res.output or "")[:600],
        "before": before,
        "after": after,
        "mutation_observed": before != after,
    })


def r1c_rw_fallback_reachable():
    d = new_dir("r1c")
    db = os.path.join(d, "unified.db")
    build_current_db(db)
    import interface.cli as cli_mod
    real_connect = sqlite3.connect

    def failing_ro_connect(path, *a, **kw):
        if isinstance(path, str) and "mode=ro" in path:
            raise sqlite3.OperationalError(
                "simulated read-only open failure (fault injection)")
        return real_connect(path, *a, **kw)

    sqlite3.connect = failing_ro_connect
    try:
        conn = cli_mod._open_verify_connection(db)
        try:
            conn.execute("CREATE TABLE probe_rw_fallback(x)")   # WRITE works
            conn.commit()
            rw_proven = True
        finally:
            conn.close()
    finally:
        sqlite3.connect = real_connect
    record("revg4_01c_doctor_rw_fallback", "REV-G4-01", {
        "scenario": ("_open_verify_connection() with the mode=ro open "
                     "fault-injected to fail: the function silently fell "
                     "back to a plain read-write sqlite3.connect()"),
        "rw_fallback_proven_by": ("CREATE TABLE executed+committed "
                                  "successfully on the returned connection"),
        "defect": ("memory-doctor's inspection path is write-capable via "
                   "silent fallback (cli.py:240) even though the doctor "
                   "never runs the rank=1 check that would justify it"),
    })


# ── REV-G4-02: preflight mutates before eligibility ──────────────────────────

def r2_unsupported_delete_db_converted_to_wal():
    d = new_dir("r2")
    db = os.path.join(d, "unified.db")
    conn = sqlite3.connect(db)
    conn.execute("CREATE TABLE totally_unrelated(x TEXT)")
    conn.commit()
    conn.close()
    before = snap(db)
    mode_before = journal_mode_ro(db)
    report = run_maintenance_migration(db)
    after = snap(db)
    mode_after = journal_mode_ro(db)
    record("revg4_02_unsupported_delete_converted_to_wal", "REV-G4-02", {
        "scenario": ("run_maintenance_migration() against an unrelated "
                     "DELETE-journal database (unsupported state)"),
        "outcome": report.outcome,
        "failure": report.failure,
        "journal_mode_before": mode_before,
        "journal_mode_after": mode_after,
        "fs_before": before,
        "fs_after": after,
        "mutation_observed": (
            mode_before != mode_after or before != after),
        "defect": ("the runner converted journal mode delete->WAL and "
                   "created -wal/-shm BEFORE classifying/refusing the "
                   "unsupported schema (estimate_migration_space and the "
                   "pre-integrity check plain-connect first; "
                   "PRAGMA journal_mode=WAL runs before "
                   "inspect_migration_state)"),
    })


# ── REV-G4-03: index drift inconsistency ─────────────────────────────────────

def r3a_missing_index_already_applied():
    d = new_dir("r3a")
    db = os.path.join(d, "unified.db")
    build_current_db(db)
    conn = sqlite3.connect(db)
    conn.execute("DROP INDEX idx_ke_layer")
    conn.commit()
    conn.close()
    ro = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    readiness_missing = validate_readiness(ro)
    state_after_drop = inspect_migration_state(ro).state
    ro.close()
    report = run_maintenance_migration(db)
    ro = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    idx = [r[0] for r in ro.execute(
        "SELECT name FROM sqlite_schema WHERE type='index' "
        "AND tbl_name='knowledge_entries'").fetchall()]
    readiness_after = validate_readiness(ro)
    ro.close()
    record("revg4_03a_missing_index_already_applied", "REV-G4-03", {
        "scenario": ("current database with idx_ke_layer dropped: "
                     "readiness vs maintenance-command disagreement"),
        "validate_readiness_after_drop_passed":
            readiness_missing["passed"],
        "validate_readiness_supporting_indexes_detail": [
            c for c in readiness_missing["checks"]
            if c["name"] == "supporting_indexes"],
        "inspect_migration_state_after_drop": state_after_drop,
        "runner_outcome": report.outcome,
        "indexes_after_runner": sorted(idx),
        "readiness_after_runner_passed": readiness_after["passed"],
        "defect": ("app readiness is refused (validate_readiness fails on "
                   "the missing index) while the maintenance command says "
                   "already_applied and repairs nothing; "
                   "inspect_migration_state returns 'current' without any "
                   "index check"),
    })


def r3b_wrong_definition_index_passes():
    d = new_dir("r3b")
    db = os.path.join(d, "unified.db")
    build_current_db(db)
    conn = sqlite3.connect(db)
    conn.execute("DROP INDEX idx_ke_layer")
    conn.execute("CREATE INDEX idx_ke_layer ON knowledge_entries(source)")
    conn.commit()
    conn.close()
    ro = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    readiness = validate_readiness(ro)
    state = inspect_migration_state(ro).state
    idx_sql = ro.execute("SELECT sql FROM sqlite_schema WHERE type='index' "
                         "AND name='idx_ke_layer'").fetchone()[0]
    ro.close()
    record("revg4_03b_wrong_index_definition_passes_readiness", "REV-G4-03", {
        "scenario": ("same-name idx_ke_layer recreated with the WRONG "
                     "definition (ON knowledge_entries(source) instead of "
                     "(layer))"),
        "validate_readiness_passed": readiness["passed"],
        "inspect_migration_state": state,
        "actual_index_sql": idx_sql,
        "canonical_index_sql": CANONICAL_INDEX_DDL["idx_ke_layer"],
        "defect": ("validate_readiness checks index NAMES only; a "
                   "same-name wrong-definition index passes readiness and "
                   "is classified fully current"),
    })


# ── REV-G4-04: missing-database creation ─────────────────────────────────────

def r4a_estimate_creates_missing():
    d = new_dir("r4a")
    db = os.path.join(d, "unified.db")
    est = estimate_migration_space(db)
    created = os.path.exists(db)
    size = os.path.getsize(db) if created else None
    record("revg4_04a_estimate_creates_missing_db", "REV-G4-04", {
        "scenario": "estimate_migration_space() against a MISSING path",
        "estimate_result_head": str(est)[:300],
        "file_created": created,
        "file_size": size,
        "defect": ("a space ESTIMATE for a migration preflight created the "
                   "database file it was pointed at"),
    })


def r4b_runner_missing_path_creates_then_fails():
    d = new_dir("r4b")
    db = os.path.join(d, "unified.db")
    before = snap(db)
    report = run_maintenance_migration(db)
    after = snap(db)
    record("revg4_04b_runner_missing_path_creates_then_fails", "REV-G4-04", {
        "scenario": "run_maintenance_migration() against a MISSING path",
        "fs_before": before,
        "fs_after": after,
        "outcome": report.outcome,
        "failure": report.failure,
        "steps": [(s["step"], s["status"]) for s in report.steps],
        "journal_mode_after": journal_mode_ro(db),
        "defect": ("the runner manufactured a database file (plus -wal/-shm "
                   "in WAL mode) and only then failed; the 'absent' state is "
                   "accepted even though the apply sequence cannot "
                   "initialize it"),
    })


def r4c_runner_zero_byte_target():
    d = new_dir("r4c")
    db = os.path.join(d, "unified.db")
    open(db, "wb").close()                     # pre-existing zero-byte file
    before = snap(db)
    report = run_maintenance_migration(db)
    after = snap(db)
    record("revg4_04c_runner_zero_byte_target", "REV-G4-04", {
        "scenario": ("run_maintenance_migration() against an existing "
                     "ZERO-BYTE file (not distinguishable from fresh init "
                     "by the runner)"),
        "fs_before": before,
        "fs_after": after,
        "outcome": report.outcome,
        "failure": report.failure,
        "journal_mode_after": journal_mode_ro(db),
        "defect": ("a zero-byte target is treated like an initializable "
                   "absent database: converted to WAL before failing"),
    })


# ── REV-G4-05: online backup helper safety ───────────────────────────────────

def r5_backup_missing_source_creates_artifacts():
    d = new_dir("r5")
    db = os.path.join(d, "unified.db")
    dest = os.path.join(d, "backup.db")
    exc_text = None
    try:
        create_online_backup(db, dest)
    except Exception as exc:                       # noqa: BLE001
        exc_text = f"{type(exc).__name__}: {exc}"
    src_after = snap(db)
    dest_exists = os.path.exists(dest)
    record("revg4_05_backup_missing_source", "REV-G4-05", {
        "scenario": ("create_online_backup() with a MISSING source path"),
        "exception": exc_text,
        "source_created": src_after["db"] is not None,
        "destination_left_behind": dest_exists,
        "defect": ("the helper plain-connects the source (creating the "
                   "file), creates the destination before any validation, "
                   "performs no source schema validation and leaves the "
                   "incomplete destination behind on failure"),
    })


# ── REV-G4-06: corruption preservation ────────────────────────────────────────

def r6a_preservation_omits_journal():
    d = new_dir("r6a")
    db = os.path.join(d, "unified.db")
    build_current_db(db)
    # simulate a rollback-journal artifact on disk
    with open(db + "-journal", "wb") as fh:
        fh.write(b"\xd9\xd5\x05\xf9\x20\xa1\x63\xd7" + b"\x00" * 40)
    saved = _preserve_corrupt_database(db, "repro: preservation copy")
    preserved_names = [os.path.basename(p) for p in saved]
    record("revg4_06a_preservation_omits_journal", "REV-G4-06", {
        "scenario": ("_preserve_corrupt_database() on a database with "
                     "main/-wal/-shm/-journal artifacts present"),
        "preserved_files": preserved_names,
        "journal_present_before": os.path.exists(db + "-journal"),
        "journal_preserved": any("-journal" in n for n in preserved_names),
        "defect": ("the preservation routine copies '', '-wal' and '-shm' "
                   "but NOT the rollback journal ('-journal') — recovery "
                   "evidence can be lost"),
    })


def r6b_preservation_too_late_journal_replayed():
    d = new_dir("r6b")
    db = os.path.join(d, "unified.db")
    build_current_db(db)
    crash_child(db, "delete")                      # hot rollback journal
    assert os.path.exists(db + "-journal"), "fixture: hot journal expected"
    journal_before = snap(db)["journal"]
    # corrupt the main DB image so the runner's integrity check fails
    with open(db, "r+b") as fh:
        fh.seek(8192)
        fh.write(b"\xde\xad\xbe\xef" * 64)
    report = run_maintenance_migration(db)
    after = snap(db)
    record("revg4_06b_preservation_after_recovery", "REV-G4-06", {
        "scenario": ("hot-rollback-journal database with a corrupted main "
                     "image: run_maintenance_migration() order of "
                     "operations"),
        "journal_sha256_before": journal_before["sha256"],
        "journal_bytes_before": journal_before["bytes"],
        "journal_after": after["journal"],
        "outcome": report.outcome,
        "preserved_files": report.preserved_files,
        "manifest_includes_journal": any(
            "-journal" in str(p) for p in report.preserved_files),
        "defect": ("the pre-migration integrity connection (plain "
                   "sqlite3.connect) replayed the hot journal BEFORE "
                   "preservation: the original recovery evidence "
                   "disappeared/was mutated and the preservation copy was "
                   "made afterwards, from already-recovered state"),
    })


# ── REV-G4-07: connection lifecycle ──────────────────────────────────────────

def r7a_unclosed_inspection_connection():
    d = new_dir("r7a")
    db = os.path.join(d, "unified.db")
    build_current_db(db)
    os.remove(db)          # the unclosed call is the FRESH-INIT path (line 225)
    import core.memory.backends.sqlite_storage as ss
    saved = {}
    real_vr = ss.validate_readiness

    def spy(conn):
        saved["conn"] = conn
        raise RuntimeError("simulated validation failure (fault injection)")

    ss.validate_readiness = spy
    exc_text = None
    try:
        try:
            SQLiteStorageBackend(db)
        except Exception as exc:                    # noqa: BLE001
            exc_text = f"{type(exc).__name__}: {exc}"
        conn = saved["conn"]
        conn.execute("SELECT 1").fetchall()         # handle STILL open
        try:
            os.remove(db)
            remove_error = None
        except OSError as ose:
            remove_error = f"{type(ose).__name__}: {ose}"
        conn.close()
        os.remove(db)                               # cleanup now succeeds
    finally:
        ss.validate_readiness = real_vr
    record("revg4_07a_unclosed_inspection_connection", "REV-G4-07", {
        "scenario": ("_init_or_validate_sync() FRESH-INIT path calls "
                     "validate_readiness(self._connect_inspection()) "
                     "WITHOUT a closing() context; fault-injected failure "
                     "inside validate_readiness leaves the just-opened "
                     "inspection connection referenced by the propagating "
                     "traceback while the file was created by "
                     "initialize_schema"),
        "constructor_exception": exc_text,
        "connection_still_usable_after_failure": True,
        "os_remove_while_open_failed": remove_error,
        "defect": ("the fresh-init inspection connection's lifetime is "
                   "left to refcount/GC luck; on Windows an open handle "
                   "blocks subsequent file operations on the database"),
    })


def r7b_silent_wal_reconversion():
    d = new_dir("r7b")
    db = os.path.join(d, "unified.db")
    build_current_db(db)
    conn = sqlite3.connect(db)                       # externally flip mode
    conn.execute("PRAGMA journal_mode=DELETE")
    conn.close()
    mode_before = journal_mode_ro(db)
    backend = SQLiteStorageBackend(db)               # readiness: silent PASS
    readiness_status = backend.readiness_state.get("status")
    svc = backend._connect()                         # service connection
    mode_service = svc.execute("PRAGMA journal_mode").fetchone()[0]
    svc.close()
    mode_after = journal_mode_ro(db)
    record("revg4_07b_silent_wal_reconversion", "REV-G4-07", {
        "scenario": ("current database externally flipped to journal mode "
                     "DELETE; backend construction then service connection"),
        "journal_mode_before": mode_before,
        "readiness_status_after_construction": readiness_status,
        "service_connection_journal_mode": mode_service,
        "journal_mode_after_service_connection": mode_after,
        "defect": ("readiness validation has NO journal-mode invariant: a "
                   "current-schema delete-mode database silently passes, "
                   "and the first service connection performs an "
                   "unreviewed persistent delete->WAL conversion"),
    })


def r7d_singleton_default_prefix():
    from core.memory.unified_memory import get_unified_memory
    default = inspect.signature(get_unified_memory).parameters[
        "db_prefix"].default
    record("revg4_07d_singleton_default_prefix", "REV-G4-07", {
        "scenario": ("static fact: get_unified_memory() default "
                     "db_prefix (NOT invoked - invoking it would open the "
                     "production database)"),
        "default_db_prefix": default,
        "production_file_exists": os.path.exists(
            str(REPO / ".data" / "memory" / "unified.db")),
        "tests_conftest_redirection_present": (
            "OCBRAIN_MEMORY_RUNTIME_ACK" in
            (REPO / "tests" / "conftest.py").read_text(encoding="utf-8")
            and "db_prefix" in
            (REPO / "tests" / "conftest.py").read_text(encoding="utf-8")),
        "observed_incident": (
            "tests/test_cognitive_memory.py::test_retrieval_fusion and "
            "test_context_assembly call get_unified_memory() and WRITE via "
            "the default prefix; .data/memory/*.db mtimes updated during "
            "the prior session's test runs (implicit production-DB access "
            "from the test suite)"),
    })


def main() -> None:
    r1a_checkpoint_inventory_mutates_wal()
    r1b_full_doctor_mutation()
    r1c_rw_fallback_reachable()
    r2_unsupported_delete_db_converted_to_wal()
    r3a_missing_index_already_applied()
    r3b_wrong_definition_index_passes()
    r4a_estimate_creates_missing()
    r4b_runner_missing_path_creates_then_fails()
    r4c_runner_zero_byte_target()
    r5_backup_missing_source_creates_artifacts()
    r6a_preservation_omits_journal()
    r6b_preservation_too_late_journal_replayed()
    r7a_unclosed_inspection_connection()
    r7b_silent_wal_reconversion()
    r7d_singleton_default_prefix()
    print("=== reproduction summary ===")
    for tag, title in RESULTS:
        print(f"  {tag}: {title}")


if __name__ == "__main__":
    main()
