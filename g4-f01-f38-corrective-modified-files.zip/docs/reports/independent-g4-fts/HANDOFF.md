# Handoff — Independent G4–FTS Rev 3 Remediation (§8)

Workstream: independent G4–FTS Rev 3 remediation
Branch: `independent/g4-fts-rev3-20261105` (worktree off candidate `g4-fix` @ `283920e`, merge base `2491ae4`)
Base candidate state analyzed as baseline only — **the parallel workstream's outputs were never inspected, copied, or imported** (the old workspace stayed off-limits for the entire session).
Date: Nov 10, 2026.  Final commits: `c0aa9a5` + the post-review correction commit (see §3.7 for the session4b retarget it carries).

---

## Verdict: **NOT READY**

(Exactly one verdict of {READY, NOT READY, BLOCKED}.)

**NOT READY** — the implementation is complete and every gate that can be decided on this machine passes, but deployment is **certification-refused on the affected production runtime** (CPython 3.14.3 + SQLite 3.50.4, stdlib): Amendment 12 forbids certification while a runtime inside the affected WAL-reset range is in place. The remaining path is Plan R1 (runtime upgrade), and until it runs the deployment-readiness value stays `ready_degraded_runtime_not_supported`.

*Why this is NOT "READY":* Amendment 12 + the runtime gate (enforce mode) refuse certification on 3.50.4; the batch-E caveat surfaces this honestly on every successful migration.
*Why this is NOT "BLOCKED":* certification is the only refused step — all evidence exists (primary-source research, three-engine probes, 246-test verification), the code is implemented and test-covered, and the post-upgrade acceptance battery is fully specified and executed against temp databases, so evaluation itself was never obstructed.
*G4 itself stays OPEN* (never closed by this workstream): G4's closure additionally requires the runtime upgrade (Plan R1) plus the re-verification battery on the fixed runtime.

> **See §8 (dated superseding addendum, Nov 10 2026).** A subsequent corrective-remediation pass found and fixed **eight further defects (REV-G4-01 … REV-G4-08 + 08.B)** in the Rev 3 implementation and added a 59-test regression suite. The verdict above (**NOT READY**) is **unchanged**; §1–§7 remain the historical record (including the 246-test verification).

---

## 1. What was delivered (batches → commits)

| Batch | Commit | Content |
| --- | --- | --- |
| Research | `e5233f4` | Primary-source study (fts5.html §4.4.3/§4.4.4/§6.3/§6.7, wal.html §11, lang_vacuum.html §3) + probes on three engines (stdlib 3.50.4; official DLLs 3.51.3/3.54.1 via ctypes) + evidence artifacts |
| A — trigger contract | `f958619` | `ke_ad` corrected to the fts5-documented `'delete'`-command form (old.* values); plain-DELETE shape retained as a *recognized legacy* definition; V2 migration identity (`mlc_v2_fts_delete_command_contract`); "current" verdict now verifies ACTUAL schema (ledger alone is insufficient); drift is fail-closed but repairable; ledger upsert |
| B — connection lifecycle | `aed84e2` | `_connect_inspection()` opens `mode=ro`; validation-only startup path (no mutation before readiness is decided); `inspection_connection_read_only=True`; refusal never mutates the database |
| C — migration honesty | `763ee16` | Post-commit checkpoint faults honestly reported as `migrated_post_commit_fault` with `MaintenanceReport.committed` (None→False→True), `verification.post_commit_fault=True`, step trace; recovery paths (`already_applied` on re-run, `--skip-checkpoint`); CLI exit 0 with honest text (Amendment 11 caveat: the data IS committed) |
| D — runtime gate lower bound | `080f6f5` | Vendor-provenance can never approve a pre-WAL build (lower bound `WAL_AFFECTED_LAST_VERSION=(3,51,2)`); affected-range message corrected to `3.7.0 .. 3.51.2` (3.51.3 is the FIX boundary, never described as affected); version facts unchanged |
| E — CLI diagnostics honesty | `e7ce48a` | Read-only diagnostics refuse missing DBs without creating them (`_open_verify_connection`, `memory_verify`, `collect_checkpoint_inventory`); doctor's verdict computed WITH configured vendor provenance (`load_configured_vendor_provenance`, `vendor_evidence` in JSON); migrate success prints the `Runtime-certification caveat` (wal_safe=False) or the certified line (True) |
| F — debt-wording correction | `7344ac7` | DEBT-045 / report §9 `VACUUM` claims corrected (observed-behavior wording per `lang_vacuum.html` §3 — rowid preservation is NOT a documented guarantee for a TEXT-PK shape); **status unchanged: OPEN** |
| G — hygiene | `de68913` | `data/context.sqlite` + `tests/__pycache__/*.pyc` untracked (files kept on disk); explicit `.gitignore` entry |
| Artifact relocation | `89d54a7` | batch-E probe artifact moved to the canonical evidence tree (`docs/reports/independent-g4-fts/evidence/independent-fix/batch_E/`); docstring references fixed |
| Venv-sweep corrections | `aaec7b5`, `8d4fb94` | see §4 (process-slips record) |

## 2. Verification (§5/§6 evidence)

* `docs/reports/independent-g4-fts/evidence/independent-fix/verification/full_run_246.txt` — full run: **246 passed** (0 failures/errors/skips).
  Arithmetic = candidate baseline **214** (105 Rev3 suites + 109 dependent baselines, counts identical to the candidate matrix) + **32** new independent tests (5 suites: 8/4/5/6/9).
* **Post-review out-of-set sweep** (beyond the candidate's affected-set protocol, run to bound blast radius of the shared-surface changes): the memory-adjacent out-of-set suites (`test_orchestrator_memory_migration`, `test_session4b_memory_hardening`, `test_memory_vault`, `test_cognitive_memory`, `test_audit_fixes`, `test_config`, `test_k2_2_runtime_migration`) — all green after the session4b retarget in §3.7. `test_check_drift.py` shows **3 pre-existing failures on Windows** (path-separator assertions, e.g. expecting `"core/cognitive/rogue.py"` while the checker produces `"core\\cognitive\\rogue.py"`); the file is byte-identical to base `283920e` and the failures are therefore independent of this workstream — left untouched (out of scope; the parallel workstream will reproduce them identically).
* Per-batch artifacts:
  - `evidence/affected-3_50_4/probe_fts_sync.txt` (+constructor-mutation, ro-connections, vacuum-rowid, cli-diagnostics) — pre-fix measurements on 3.50.4;
  - `evidence/fixed-runtime/sqlite_3_51_3/, sqlite_3_54_1/` — RF-2 is a trigger-pattern defect; identical on the fix boundary and latest release;
  - `independent-fix/batch_B/probe_constructor_mutation_after_fix.txt` (bytes_changed=false);
  - `independent-fix/batch_E/probe_cli_diagnostics_after_fix.txt` (diagnostics refuse + deliberate raw-connect control row).
* Machine deployment state (recorded exactly once, maintenance window, no processes running): the production `.data/memory/unified.db` was migrated V1→V2 through the documented operator flow (`memory-migrate` → all steps ok, ledger row `mlc_v2_fts_delete_command_contract` applied, final checkpoint busy=0; `memory-doctor` inspection passes at cost 0.000547s). This mirrors the candidate report's own §11 record of the same flow. The production DB was never used as a test fixture (all test fixtures are temp DBs).

## 3. Candidate-suite updates (each = the semantic correction a checklist fix directly pins)

1. `test_session4c_architecture.py` — (candidate's own pre-existing retargets; unchanged by this workstream).
2. `test_g4_rev3_mutation_atomicity.py` (batch A) — delete-path fault injection now denies `SQLITE_INSERT` (the corrected trigger's op code; identical rollback intent, because the corrected 'delete'-command trigger executes INSERTs, not DELETEs).
3. `test_g4_rev3_migration_lifecycle.py` (batch A) — ledger-identity assertions moved V1→V2 where they hardcoded V1 (+import of the V2 id).
4. `test_g4_rev3_search_regression.py` (batch A) — `TestRuntimeFindingRank1AfterDelete` asserts the UNCONDITIONAL rank=1 pass post-delete (the conditional "defect follows the runtime" expectation was refuted by the three-engine probes).
5. `test_g4_rev3_search_regression.py` (batch B) — `TestRuntimeFindingStaleMatchAfterDelete` likewise corrected to the cross-runtime-invariant form.
6. `test_g4_rev3_failure_recovery.py` (batch C) — `TestPostCommitCheckpointFault` pinned the old "failed" misreport; updated to `migrated_post_commit_fault` honesty.
7. `test_session4b_memory_hardening.py` (post-review completion of the candidate's own retarget) — `TestGoal4TransactionIntegrity::test_fts5_triggers_keep_index_in_sync_declaratively` was still probing `SQLiteStorageBackend._init_sync`, removed by the candidate's Rev 3 DDL move (the candidate retargeted its session4c siblings but missed this one; the failure predates this workstream — `_init_sync` is already absent at base `283920e`). Retargeted to `sqlite_contract.CANONICAL_TRIGGER_DDL` exactly like the session4c precedent; suite green 41/41.
8. Batches D, E, F, G: **no candidate updates** (no candidate assertion pinned the pre-WAL provenance hole, the create-on-missing diagnostics, the provenance-less doctor verdict, or the caveat text).

## 4. Process slips (recorded, not hidden)

1. **Batch C commit attempt** initially used PowerShell `-m` with embedded double quotes; the message was corrupted and the commit refused (no damage; message files + `git commit -F` became the standing method).
2. **Config hot-reload race probe** (batch E debugging): `core.config`'s watcher replaces `_settings` on its first pass (mtime map starts empty), racing per-test freezes — root-caused with traced stacks; fixed via the module-scoped `_stable_config` fixture in the new suite. The same latent race exists in candidate `_freeze_config` whenever its module is the first `core.config` importer in a pytest process; left untouched (out of scope, worth a future hygiene pass).
3. **Sweep artifact** (`89d54a7`): a wholesale `git add -A .` committed the local, uv-managed `.venv312-build/` venv (no ignore rule matched it). The first correction (`aaec7b5`) itself slipped — its `git rm` pathspec dropped the second `v` and failed silently into the commit, whose message then over-claimed. `8d4fb94` completed the untrack (560 index deletions; files retained on disk; `git ls-files .venv312-build` empty; status clean). Standing rule reconfirmed: **stage by exact path, never `-A .`**.
4. The verification artifact and this handoff record the true file count (560); `8d4fb94`'s own message says "~1093" — an estimate made before counting; superseded by these numbers.

## 5. Environment notes

* `.venv312-build/` — uv-managed CPython 3.12.15 build used during batch-B/E development as a second interpreter for probe/generation work; machine-local, deleted from the index twice-over (above), now explicitly gitignored. Its presence/absence has zero effect on tests.
* PowerShell specifics honored throughout: message-file commits, `python -X utf8`, `Out-File -Encoding ascii` for artifacts, never round-tripping sources through `Get-/Set-Content`.
* `tests/__pycache__/` occasionally served stale bytecode between edits; purged before reruns and untracked in batch G.
* Fixed-runtime engine provenance: official sqlite.org DLL **zips** retained at `%TEMP%\opencode\dlls\3_51_3.zip` and `3_54_1.zip`; at probe time the contained `sqlite3.dll` was extracted and loaded via `scripts/g4_indep/ctypes_sqlite_helper.load()` (selected by the `G4INDEP_SQLITE_DLL` env var). The extracted DLLs are ephemeral temp files (not preserved); the authoritative engine identity per probe run is recorded in each artifact header (sqlite_version + source_id) and is reproducible by re-extracting the zips.

## 6. What still blocks READY (for the receiving workstream to compare)

1. **Plan R1** — one of: interpreter/bundled-SQLite ≥ 3.51.3 (or 3.53.0+, noting 3.52.0 is Withdrawn upstream), a documented backport build (3.44.6 / 3.50.7), or a vendor build certified via the full provenance record.
2. After the upgrade: re-run the seven Rev 3 gate suites + two baseline suites WITHOUT `OCBRAIN_MEMORY_RUNTIME_ACK` (enforce mode must accept the fixed runtime), assert the strict fixed-build forms of the runtime-conditional tests, and confirm `classify_wal_safety().wal_safe == True`. Only then may any "all gates pass" deployment claim be written.
3. DEBT-045 stays OPEN (by design; identity risk is structural, no rewrite authorized). The corrected VACUUM wording (batch F) must not be re-classified into a closed item.
4. The hot-reload watcher race in candidate `_freeze_config` (§4.2) is a known latent flake for whoever runs candidate suites first-importing `core.config` in a fresh pytest process.

## 7. Integrity statement

No rebase/reset/push/PR/merge was performed; `main` and `g4-fix` were never touched; G4 was never closed; DEBT-045 stays OPEN with corrected wording only; CTX-* memory-isolation findings were not reclassified; no parallel-workstream artifact was opened. All test fixtures used temp databases. The single production interaction was the documented, windowed operator migration recorded in §2.

---

# §8. Superseding addendum — corrective remediation pass (Nov 10, 2026)

**This section is dated and additive.** Nothing in §1–§7 above is rewritten: the batch/commit history, the 246-test verification record and the process-slip notes remain the historical record of the Rev 3 workstream. Where this addendum disagrees with them, **this addendum governs from Nov 10 2026 onward**.

## 8.1 What this pass was

A second, independent review of the Rev 3 workstream found **eight new defects** in the shipped code (plus one sub-finding). Each was **reproduced first**, then corrected, then covered by a dedicated regression test. All changes are **local and uncommitted** on top of HEAD `739e58c` (branch `independent/g4-fts-rev3-20261105`): **no** branch, commit, staging, push, PR, merge or rebase; **no** issue closure; **no** governance change.

| ID | One-line defect | Disposition |
| --- | --- | --- |
| REV-G4-01 | `memory-doctor` opened the database **write-capable** and consumed recoverable WAL state | **FIXED** — doctor strictly read-only, no writable fallback; uninspectable WAL reported UNAVAILABLE; `memory-verify` keeps writability but *proves* non-mutation |
| REV-G4-02 | The migration runner mutated (journal-mode conversion) **before** classifying the target | **FIXED** — precheck → lock → preservation → read-only estimate → read-only inspection → classify → refuse before any persistent change |
| REV-G4-03 | Index drift was invisible (name-only checks); `already_applied` while readiness refused | **FIXED** — semantic index contract + narrow, explicit repair scope (index-only repair skips the FTS rebuild); unknown drift fails closed |
| REV-G4-04 | A migration against a missing path **created** the database | **FIXED** — `absent` is not a migration target; non-creating path precheck; read-only space estimate |
| REV-G4-05 | The backup helper created the source, created the destination first, validated nothing, left unverified output | **FIXED** — both sides protected, verified temporary file, atomic non-overwriting publish, failure removes only its own temp |
| REV-G4-06 | Preservation omitted `-journal`, and the hot journal was replayed **before** preservation | **FIXED** — raw byte-verified preservation of all four artifacts **before any SQLite open**; fail-closed on copy failure |
| REV-G4-07 | (A) unclosed inspection connection, (B) delete-mode database silently passed readiness and was converted to WAL, (C) unreviewed `journal_mode=WAL`, (D) tests wrote to the **production** database | **FIXED** — explicit closure; WAL journal-mode invariant in readiness; documented `_connect()` pragma; conftest singleton redirects + production-access guard |
| REV-G4-08 | Diagnostics over-claimed ("writes nothing"), the verify refusal text pointed at a non-existent "create/migrate", unavailable inspections were reported as data findings, and `--json` was **not parseable** (rich wrapping) | **FIXED** — truthful messages, UNAVAILABLE states, `click.echo` for machine-readable output, failed batteries reported as "NOT a verified result" |
| REV-G4-08.B | The click group's custom parser dropped its own **Options** after the first subcommand invocation → every **second** in-process CLI call died with `TypeError` | **FIXED** — the group's parameter list is restored completely |

Reproduction evidence (15 scenarios, all reproduced before correction): `docs/reports/independent-g4-fts/remediation2/evidence/stage1/` — produced by `scripts/g4_indep/probe_revg4_stage1_repro.py`.

## 8.2 Tests added

`tests/test_g4_revg4_remediation.py` — **61 tests**, one class per finding (`TestRevg401…` … `TestRevg408`), all against isolated `tmp_path` databases. They fail against the pre-correction implementation and pass against the corrected one.

## 8.3 Verification (this pass)

* **Affected set + memory-adjacent out-of-set set + full repository suite**: re-run after the corrections — see Deliverable E (`docs/reports/independent-g4-fts/remediation2/E_TEST_EXECUTION_EVIDENCE.md`) for the exact commands and counts.
* The **246-test** record of §2 is **preserved** as the Nov 2026 historical record; the numbers in §2 were measured on the **pre-correction** tree and are **not** restated here. The refreshed numbers are reported separately.
* `tests/test_check_drift.py` still shows its **3 pre-existing Windows path-separator failures** (byte-identical to base `283920e`) — **left untouched, out of scope**, reported not hidden.

## 8.4 Honest disclosure — production-data access

Four implicit production-data access paths from the test suite were found during this pass and are disclosed in full (report §16.6): the historical one (`.data/memory/*.db` written by `get_unified_memory()` with its default prefix); the one detected by the **new** guard (`.data/memory/cognitive/vault_v4.json`, written through the module-level `cognitive_vault` singleton); a **third** one the first version of the guard did **not** catch — the module-level `graph_engine` singleton (`.data/memory/graph.db`), because that write did not change the file's **size** (the guard now fingerprints `(size, mtime_ns)`); and a **fourth**, in a **spawned worker**: `core/workers/curator.py` constructs the memory backend at import time, so the subprocess spawned by `tests/test_workflow_crash_restart_subprocess.py` opened the production database (read-only, for the readiness inspection) and left a `-shm` artifact. All three production-default singletons (memory, cognitive vault, graph engine) are now redirected to isolated temp directories by `tests/conftest.py`, the spawned-child helper installs the same isolation before its heavy imports, and the autouse guard fails any test that changes a file under `.data/memory`. The production vault file was **not** rewritten — this workstream does not modify production data.

## 8.5 Renamed suites (superseding §3 items 4–5)

`TestRuntimeFindingRank1AfterDelete` → **`TestCorrectedFindingRank1AfterDelete`**; `TestRuntimeFindingStaleMatchAfterDelete` → **`TestCorrectedFindingStaleMatchAfterDelete`**; the conditional ("runtime-scoped") assertions were **de-conditioned** — the stale-match / `rank=1` anomaly follows the pre-fix V1 trigger shape, not the SQLite build (EVIDENCE_NOTE §3.1, report §16.1). Report §13 step 5's reference to the old names is superseded.

## 8.6 What still blocks READY — unchanged

1. **Plan R1** — runtime ≥ 3.51.3 (or a documented backport 3.44.6 / 3.50.7, or a provenance-registered vendor build). This machine still runs **CPython 3.14.3 + SQLite 3.50.4** → **affected** → certification **refused**; readiness stays `ready_degraded_runtime_not_supported`.
2. After the upgrade: re-run the Rev 3 gate suites + the new corrective suite **without** `OCBRAIN_MEMORY_RUNTIME_ACK` (enforce mode must accept the fixed runtime) and confirm `classify_wal_safety().wal_safe == True`.
3. **DEBT-045 stays OPEN** (structural hidden-rowid risk; no rewrite authorized).
4. The new defects of this pass are **fixed in the working tree**, but a **fresh reviewer must re-verify** them against the exact tested source before any acceptance decision (Deliverable G).

## 8.7 Governance disposition

**G4 remains OPEN / NOT ACCEPTED.** This pass closes no issue, accepts no deliverable, certifies no runtime and changes no governance state. `OCBRAIN_MEMORY_RUNTIME_ACK=acknowledge` remains **test-environment-only**.

---

# §9. Superseding addendum — definitive corrective remediation (Nov 10–11, 2026)

**Dated and additive.** §1–§8 above are the historical record of the Rev 3 workstream and of the first corrective pass; they are **not** rewritten. Where this addendum disagrees with them, **this addendum governs from Nov 10 2026 onward**.

## 9.1 What this pass was

An independent adversarial review of the Rev 3 implementation raised **38 findings (F01–F38)** covering database lifecycle management, schema verification, migration safety, backups, recovery preservation, testing and evidence. Each was classified (REPRODUCED / SOURCE-CONFIRMED / NOT VERIFIED), the reproducible ones were demonstrated, and the corrections were implemented in the working tree.

**Disposition summary (details: `remediation3/A_FINDINGS_REGISTER.md`):**

* **FIXED:** F01, F02, F03, F04, F05, F06, F07, F08, F09, F12, F13, F14, F15, F16, F17, F18, F19, F20, F21, F22, F24, F25, F27, F29, F30, F32, F33, F34, F35, F37, F38
* **PARTIAL:** F10 (preservation policy), F23 (fresh-init serialization), F31 (sidecar reporting)
* **NOT FIXED (reported, never presented as resolved):** F11, F26, F28, F36

## 9.2 The state of the workstream

| Item | State |
| --- | --- |
| Branch / HEAD | `independent/g4-fts-rev3-20261105` @ `739e58c` — unchanged |
| Changes | **local and uncommitted**; no branch, commit, staging, push, PR, merge or rebase |
| New tests | `tests/test_g4_f01_f38_remediation.py` — **65** tests, one class per finding group |
| Affected set + memory-adjacent | **459 passed**, 0 failed |
| Full repository suite | see `remediation3/C_REGRESSION_EVIDENCE.md` (compared against a **pristine HEAD clone**: identical failure/error sets, +65 passing) |
| Production data | **not accessed** — a prevention boundary now blocks it before collection, in the parent and in child processes |
| G4 | **OPEN / NOT ACCEPTED** |
| DEBT-045 | **OPEN** |
| Runtime certification | **NOT READY** — SQLite 3.50.4 is inside the affected range; Plan R1 unchanged |

## 9.3 What changed for operators

* `memory-migrate` can now **repair** a current-schema database whose journal mode was
  changed externally (outcome `repaired`; no trigger/index/FTS/ledger change).
* A pre-commit failure is classified from the **durable ledger** — committed,
  confirmed rollback, or the new `outcome_uncertain` outcome.
* A busy checkpoint is reported as `blocked`, not `done`.
* `memory-doctor` is strictly read-only with no writable fallback.
* The maintenance runner refuses unsupported databases **before** any persistent
  change, and refuses when the foreign-key preflight fails.

## 9.4 Historical facts that are preserved, not rewritten

* The **246-test** record of §2 remains the pre-correction measurement; it is not
  restated as if it covered the current source. The 59/61/65 counts are reconciled per
  file and per class in `remediation3/C_REGRESSION_EVIDENCE.md` §C.6.
* The **15 Stage-1 scenarios** and the **10 Stage-2 probes** are mapped explicitly in
  `remediation2/B_REPRODUCTION_EVIDENCE.md`.
* The **production-data contamination** of the earlier passes is not denied: four paths
  are documented (memory singleton, cognitive vault, graph database, spawned worker),
  the polluted vault file still holds three duplicate test-entry pairs, and it was
  **not** rewritten by this work (an operator may clear it).

## 9.5 The next reviewer

Start with `remediation3/A_FINDINGS_REGISTER.md` (what was found and how it was
classified), then `remediation3/H_FRESH_REVIEW_HANDOFF.md` (the review order and the
claims to re-derive). A fresh reviewer must **not** rely on any previous chat message.
