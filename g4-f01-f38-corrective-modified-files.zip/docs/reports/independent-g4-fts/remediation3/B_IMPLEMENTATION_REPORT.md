# Deliverable B — Implementation report (definitive remediation, Nov 10–11 2026)

**Scope:** findings F01–F38 of the definitive G4 corrective remediation.
**State:** all changes are local and uncommitted on top of HEAD `739e58c` + the supplied change set.

## 1. Architectural changes

### 1.1 A quote-aware SQL front end (`core/memory/sqlite_contract.py`)
The contract module now owns a small SQL tokenizer (`tokenize_sql`) and a canonical
`normalize_sql`. Comments are recognised only outside quoted content; string literal
values are preserved byte-for-byte; identifiers are folded with ASCII-only lower-casing
(SQLite's identifier comparison is ASCII case-insensitive, not Unicode case folding);
unterminated quotes/comments raise `SqlParseError` instead of being compared
optimistically. `parse_create_index` and `parse_create_virtual_table` were rewritten on
top of it: they validate the object name, the table/module, every clause and that no
trailing SQL remains, and they reject an unrecognized grammar as UNKNOWN.

### 1.2 A semantic, fail-closed schema auditor (`core/memory/sqlite_integrity.py`)
* `audit_index_contract()` compares the stored DDL **and** the live SQLite metadata
  (`index_list` + `index_xinfo`): uniqueness, partial flag, column order, DESC, collation,
  expression terms. A PRAGMA failure is an ERROR; a same-name index owned by another
  table is `foreign_owned`; unknown drift outranks repairable drift.
* `audit_trigger_contract()` looks trigger names up **globally** (a trigger name is
  database-wide) and matches the trigger SET against the enumerated historical
  configurations.
* `audit_housekeeping_contract()` validates the exact shape of the two bookkeeping
  tables and the marker/ledger cardinality.
* `logical_content_digest()` produces a deterministic, type-aware, length-delimited
  digest over every stored value plus the hidden-rowid mapping.
* Foreign-key detection now uses an **exact** allowlist of internal/shadow tables, keeps
  every violation row, and distinguishes “inspection unavailable” from “no
  relationships”.

### 1.3 An explicit migration state machine (`core/memory/sqlite_migration.py`)
States: `absent`, `fresh_current`/`current`, `legacy_pending_migration`,
`repairable_drift`, `invalid`, `inspection_unavailable`, `preserved_corrupt`,
`outcome_uncertain`. A repairable state carries a **complete, validated** repair scope;
there is no broad default any more. The runner enforces the foreign-key preflight
before any persistent change, distinguishes a structural ERROR from confirmed
corruption, refuses when the post-lock re-inspection fails, and classifies the durable
transaction outcome from evidence (committed / confirmed rollback / uncertain).

### 1.4 A production-safe backup (`create_online_backup`)
The temporary artifact is allocated **exclusively** (`O_CREAT|O_EXCL`) and its identity
is tracked; publication uses an atomic **no-replace** primitive (`os.link`), never
`os.rename` (which replaces on POSIX); the source is read through **one** read
transaction that spans both the source reads and the backup call; the copy is verified
(structural integrity, foreign keys, FTS `rank=1`, schema/trigger/index equality and a
full logical content digest) **before** publication.

### 1.5 A boundary-free service connection (`core/memory/backends/sqlite_storage.py`)
Service connections no longer issue `PRAGMA journal_mode=WAL`: they open the existing
file non-creating (`mode=rw`), **verify** the journal mode and refuse if it changed
after readiness validation. The creating connection exists only on the fresh-init path
(`_connect_initializing`).

### 1.6 A prevention boundary for the test environment (`tests/_g4_protection.py` + `tests/conftest.py`)
Before pytest collects anything, the conftest (a) establishes a temporary memory path
through `OCBRAIN_MEMORY_DIR` so the production-default singletons never build a
production store, and (b) installs a boundary that **blocks** access to the production
memory directory and the production configuration files — in the parent process and in
every child process (through a generated `sitecustomize.py`). The previous
detection-after-the-fact harness remains as a secondary net.

## 2. Behaviour changes an operator will notice

| Change | Why | Observable |
| --- | --- | --- |
| A DELETE-mode current database can be repaired by `memory-migrate` | F05 | new outcome `repaired`; no ledger row is written |
| A failed pre-commit migration may report `outcome_uncertain` | F29 | the durable ledger is consulted before any verdict |
| A busy checkpoint reports `blocked` (not `done`) | F38 | `report.checkpoint["status"]` |
| A structural ERROR is no longer reported as corruption | F12 | outcome `failed`, not `preserved_corrupt` |
| A foreign-key preflight failure stops the migration | F19 | the journal mode is not changed |
| An unknown trigger/index configuration is never repaired | F14/F15/F16 | outcome `failed`, nothing is dropped |
| `memory-doctor` reports `unavailable` instead of `unreadable` | F01/REV-G4-08 | JSON `migration_state.schema_state` |

## 3. What was deliberately NOT changed

* `wal_autocheckpoint` policy, `secure_delete`, the space factor 2.0 estimate, the
  runtime gate's version table and provenance rules, the advisory-lock-is-not-fencing
  disclosure, the quiescence contract and the canonical DDL are untouched.
* No production database was opened, migrated, backed up or repaired by this pass.
* No governance state, issue or debt item was changed.
