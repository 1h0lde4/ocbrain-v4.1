# Deliverable E — Documentation reconciliation

**Method:** dated, additive superseding sections. No historical report was rewritten;
the Nov 5 2026 text remains the record of what was believed and measured then.

| Document | Original problem | Correction | Evidence |
| --- | --- | --- | --- |
| `docs/reports/G4_FTS_REV3_REMEDIATION_REPORT.md` | §5 described the delete-path fault-injection instrument as `SQLITE_DELETE` (action 9) | **corrected to `SQLITE_INSERT` (action 18)** with a dated pointer — the corrected V2 `ke_ad` removes the FTS row through the special `'delete'`-command INSERT, so the authorizer instrument that intercepts it is the INSERT denial (the test implements it that way) | §5 correction note |
| same | §0/RF-2 classified the stale-MATCH/`rank=1` anomaly as a consequence of the **SQLite build** | **superseded**: the anomaly follows the **pre-fix V1 `ke_ad` trigger shape**, reproduced identically on 3.50.4/3.51.3/3.54.1; the WAL runtime gate (a separate hazard) is untouched and the certification refusal **stands** | §16.1 (previous pass) |
| same | Gate 4A/6A verdicts “PASS (runtime-conditional)” | **PASS (unconditional)** — the conditional assertions were removed and the strict forms asserted | §16.3 (previous pass) |
| same | no record of the corrective findings | new **§17 dated addendum** with the F01–F38 dispositions, the state machine, the operator-facing behaviour changes and the explicit non-claims | §17 (this pass) |
| same | §12 file manifest listed only the Nov 5 files | dated pointer to the manifest of this pass (Deliverable G) | §12 note (previous pass) + §17 |
| `docs/reports/independent-g4-fts/EVIDENCE_NOTE.md` §5 | implied 3.51.2 was measured and inferred the backport builds’ FTS behaviour | **corrected**: measured engines are **3.50.4 / 3.51.3 / 3.54.1**; **3.51.2 was NOT measured**; **no FTS inference** is made for 3.44.6 / 3.50.7 (never downloaded or executed) | §5 correction (previous pass) |
| `docs/reports/independent-g4-fts/HANDOFF.md` | described the previous delivery as the final word | new **§9 dated superseding addendum**: the F01–F38 findings, the not-fixed list, the new test counts, the runtime blocker unchanged, the production-data history preserved | §9 (this pass) |
| `KNOWN_ISSUES.md` | DEBT-045 wording; no erasure caveat | dated addendum: DEBT-045 stays **OPEN**; the `secure_delete`-OFF **erasure caveat** is recorded (a DELETE frees the row but does not overwrite its bytes — the text survives in freed pages, in backups and in forensic copies); the test-isolation incidents are disclosed | Addendum A1–A3 (previous pass) + this pass |
| `KNOWN_ISSUES.md` | — | the four production-data incidents and the current prevention boundary are recorded with the operator action for the polluted vault file | this pass |
| CLI operator instructions | the previous addendum described the commands before this pass | **§17.6** documents the new operator-visible behaviour (`repaired` outcome, `outcome_uncertain`, `blocked` checkpoint, `unavailable` doctor states, the refusal wording) | §17.6 (this pass) |
| `docs/reports/independent-g4-fts/remediation2/*` | Stage-1 evidence (defects) and Stage-2 (post-fix) | preserved; the **scenario mapping** between the 15 Stage-1 scenarios and the 10 Stage-2 probes is now explicit | remediation2/B (previous pass) |
| `docs/reports/independent-g4-fts/remediation3/*` | — | **new**: Deliverables A–H for this pass | this pass |

### Corrections that were *not* applied, and why

* The Nov 5 2026 report text was **not** rewritten: each correction is a dated
  superseding note beside the original statement.
* The historical 246-test evidence was **not** restated as if it measured the current
  source; it is explicitly labelled as the pre-correction record.
* The historical production-data contamination was **not** denied; it is restated in
  Deliverable D §D.5 and in the HANDOFF addendum.
