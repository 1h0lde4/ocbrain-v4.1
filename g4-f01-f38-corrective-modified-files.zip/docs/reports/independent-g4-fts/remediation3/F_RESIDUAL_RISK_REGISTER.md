# Deliverable F — Residual-risk register (Nov 10–11, 2026)

Everything below is **still open**. Nothing here is closed, accepted or certified by this pass. The
per-finding dispositions are in `A_FINDINGS_REGISTER.md`; the implementation detail in `CHANGES.md`.

| # | Risk | Status | Why it is still open |
| --- | --- | --- | --- |
| **R1** | **SQLite WAL-reset runtime incompatibility** (3.7.0 – 3.51.2 affected; 3.51.3+ fixed; backports 3.44.6 / 3.50.7) | **OPEN — blocks deployment certification** | This machine runs SQLite **3.50.4**. The Amendment 1 gate refuses certification; readiness stays `ready_degraded_runtime_not_supported`. Only Plan R1 (runtime upgrade / backport / provenance-registered vendor build) changes it. A corrected FTS trigger does **not** certify the runtime. |
| **R2** | **DEBT-045 — hidden-rowid persistence** | **OPEN** | The external-content FTS identity rests on implicit content-table rowids. Rowid preservation across `VACUUM` is *not* a documented SQLite guarantee for this table shape. No table rewrite or `INTEGER PRIMARY KEY` migration is authorized; none was made. Observed behaviour is not a guarantee. |
| **R3** | **Physical erasure is not guaranteed** (`secure_delete` OFF) | **OPEN** | A DELETE frees the row but does not overwrite its bytes; the text survives in freed pages, in backups and in forensic preservation copies. The setting was deliberately **not** changed (Amendment 6 remains investigation-only; the regulatory question stays with the owner). |
| **R4** | **Advisory locking is not process fencing** | **OPEN by disclosure** | The maintenance lock serializes cooperating migrators only. A non-cooperating writer can still mutate the database during a maintenance window; the deployment contract (all processes stopped and drained) is what closes that gap. |
| **R5** | **The backup's verified scope is the content table** (W12/F08) | **OPEN (partial)** | The copy is verified for the content table (full digest), the schema, the triggers, the indexes, the FTS and the foreign keys — but **application-owned user tables** are not part of the verified digest scope. |
| **R6** | **The preservation copy has no capacity preflight and no stability check** (W14/F36/R46) | **OPEN (not fixed)** | A snapshot taken while another process writes is not guaranteed consistent; the deployment contract (quiescence) remains the only protection. |
| **R7** | **Partial preservation sets are not self-describing** (W14/F11/R49) | **OPEN (partial)** | A failed copy is **retained** and reported as `incomplete` with its destination path — but no dedicated incomplete-manifest file is written. |
| **R8** | **No dedicated initialization lock** (W10/F23/F47/F56) | **OPEN (partial)** | Two simultaneous first starts are serialized only by SQLite's own locking, and the loser is not told it lost. A partially initialized database is **never** accepted as `current` (scenario L), so the failure is loud — but not coordinated. |
| **R9** | **Database-path identity is not unified** (W19/F20/R51) | **OPEN (partial)** | The **lock** identity is safe (device/inode verified at acquisition and release), but the *database* path itself is not canonicalized across relative/absolute, symlink, junction and hard-link aliases. |
| **R10** | **The checkpoint inventory reports pre-connection sidecar sizes** (W18/F31) | **OPEN (partial)** | The verification command reports the post-operation facts; the inventory's own figures can still be stale. |
| **R11** | **The Python boundary is not an OS sandbox** (W20) | **OPEN by disclosure** | The boundary prevents production access from Python code paths (including children) and covers aliases — but it is defence in depth, not OS-level isolation. Where OS isolation is available it is preferred. |
| **R12** | **The production vault file still holds test pollution** | **OPEN** | `.data/memory/cognitive/vault_v4.json` contains three duplicate test-entry pairs written by the earlier passes. It was **not** rewritten (production data is not modified by this work); an operator may clear it — the application recreates it. |
| **R13** | **21 pre-existing test failures + 51 errors remain** | **OPEN (pre-existing)** | Linux-only seccomp/POSIX tests on Windows, Windows path-separator/NUL-byte/symlink-privilege cases, two CI-gate cases, one console-encoding case, and the `test_module_name_containment.py` errors that need the repository's ignored data directories. Identical in the pristine-HEAD baseline. |
| **R14** | **The configuration manager still rewrites `config/*.toml` when flushed** | **OPEN (pre-existing)** | The boundary now *contains* it for tests (`CONFIG_DIR` is redirected to a temporary copy and a production write is refused), but the manager's operator-visible flush semantics were not changed. |
| **R15** | **The WAL runtime gate and the FTS trigger correction are independent** | **OPEN by disclosure** | A correct trigger contract removes the repository-level FTS defect; it says nothing about the SQLite WAL-reset hazard, which is what actually blocks certification. |

## Governance position (unchanged)

* **G4 is OPEN and NOT ACCEPTED.** This pass does not accept the deliverable and does not close the issue.
* **DEBT-045 is OPEN.**
* **Production runtime certification remains a separate deployment gate** (Plan R1) — *not ready*.
* The implementation agent issues **no acceptance decision**.
