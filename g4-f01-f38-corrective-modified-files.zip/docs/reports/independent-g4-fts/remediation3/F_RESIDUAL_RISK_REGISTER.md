# Deliverable F — Residual-risk register

Everything below is **still open**. Nothing here is closed, accepted or certified by
this pass.

| # | Risk | Status | Why it is still open |
| --- | --- | --- | --- |
| R1 | **SQLite WAL-reset runtime incompatibility** (3.7.0 – 3.51.2 affected; 3.51.3+ fixed; backports 3.44.6 / 3.50.7) | **OPEN — blocks deployment certification** | This machine runs SQLite **3.50.4**. The Amendment 1 gate refuses certification; readiness stays `ready_degraded_runtime_not_supported`. Only Plan R1 (runtime upgrade / backport / provenance-registered vendor build) changes it. |
| R2 | **DEBT-045 — hidden-rowid persistence** | **OPEN** | The external-content FTS identity rests on implicit content-table rowids. Rowid preservation across `VACUUM` is *not* a documented SQLite guarantee for this table shape. No table rewrite or `INTEGER PRIMARY KEY` migration is authorized, and this pass made no change here. |
| R3 | **Physical erasure is not guaranteed** (`secure_delete` OFF) | **OPEN** | A DELETE frees the row but does not overwrite its bytes; the text survives in freed pages, in backups and in forensic preservation copies. The setting was deliberately **not** changed (Amendment 6 remains investigation-only; the regulatory question stays with the owner). |
| R4 | **Advisory locking is not process fencing** | **OPEN by disclosure** | The maintenance lock serializes cooperating migrators only. A non-cooperating writer can still mutate the database during a maintenance window; the deployment contract (all processes stopped and drained) is what closes that gap. |
| R5 | **Preservation policy can duplicate a whole database on repeated runs** (F10) | **OPEN (not fixed)** | The preservation step copies the full file set when sidecars exist. A safe, cheaper alternative was not demonstrated. |
| R6 | **Partial preservation sets are not self-describing** (F11) | **OPEN (not fixed)** | A failed copy raises and leaves the partial set on disk, but no *incomplete manifest* is written. |
| R7 | **`memory-verify` does not gate on the complete contract** (F26) | **OPEN (not fixed)** | It checks the integrity battery, identity and logical invariance, but not the trigger/index/FTS-configuration classifications. |
| R8 | **`memory-verify` can consume recovery evidence** (F28) | **OPEN (not fixed)** | It opens the original write-capable for the FTS5 `rank=1` command; that open can trigger WAL/journal recovery on the original. |
| R9 | **Recovery snapshots are not space-preflighted nor stability-checked** (F36) | **OPEN (not fixed)** | A copy taken while another process writes is not guaranteed consistent; the deployment contract (quiescence) is the only protection. |
| R10 | **Fresh initialization is not serialized** (F23) | **OPEN (partial)** | Two processes starting simultaneously on a brand-new path can race; SQLite's locking makes one initialization win, but the loser is not told. |
| R11 | **Sidecar side effects are reported, not eliminated** (F31) | **OPEN (partial)** | A read-only open of a WAL database may create an empty `-wal`/`-shm` scaffold and churn `-shm` bytes. This is SQLite's coordination behaviour; it is documented and never mistaken for a checkpoint. |
| R12 | **The production vault file still holds test pollution** | **OPEN** | `.data/memory/cognitive/vault_v4.json` contains three duplicate test-entry pairs from the earlier passes. It was **not** rewritten (production data is not modified by this work); an operator may clear it — the application recreates it. |
| R13 | **21 pre-existing test failures + 51 errors remain** | **OPEN (pre-existing)** | Linux-only seccomp/POSIX tests on Windows, Windows path-separator/NUL-byte/symlink-privilege cases, two CI-gate cases and one console-encoding case. Identical in the pristine HEAD baseline — not introduced here, and not in scope. |
| R14 | **The config manager still rewrites `config/*.toml` when flushed** | **OPEN (pre-existing)** | The boundary now *blocks* such a rewrite in the test environment, so the affected test(s) fail loudly instead of silently mutating the production configuration. The manager's flush semantics are an operator-visible behaviour and were not changed. |
| R15 | **The maintenance runner's own space estimate opens SQLite** | **OPEN (documented)** | `estimate_migration_space()` is read-only and runs *after* the raw recovery preservation, so it cannot consume recovery evidence — but it is not a substitute for a space preflight before copying (see R9). |

## Governance position (unchanged)

* **G4 is OPEN and NOT ACCEPTED.** This pass does not accept the deliverable and does
  not close the issue.
* **DEBT-045 is OPEN.**
* **Production runtime certification remains a separate deployment gate** (Plan R1).
* The implementation agent does not issue its own acceptance decision.
