# Deliverable H — Fresh independent-review handoff (Nov 10–11, 2026)

**You did not produce this work.** Everything you need is in this repository; do not rely on any earlier chat message. Re-derive the claims rather than trusting them.

## 0. The one-paragraph version

An independent Rev 3 delivery (G4–FTS) was reviewed adversarially twice. The first review produced eight defects (REV-G4-01…08 + 08.B) and 61 regression tests; this pass produced a further **38 findings (F01–F38)**, of which 31 are FIXED, 3 PARTIAL and 4 explicitly **NOT FIXED**. The runtime is still affected (SQLite 3.50.4), so **certification is refused and G4 remains OPEN / NOT ACCEPTED**.

## 1. Where everything is

| Item | Path |
| --- | --- |
| Working tree (authoritative) | `C:\Users\Produ\Downloads\ocbrain-g4-indep\wt` — branch `independent/g4-fts-rev3-20261105` @ `739e58c`, **all changes uncommitted** |
| The supplied change set | `C:\Users\Produ\Downloads\ocbrain-g4-indep\g4-revg4-remediation-modified-files.zip` (SHA-256 `2D73E808F70C6C97808CEAD725C810C534EC8AC65F9BC25E47A91C703E3F9EFC`, 50 entries, forward-slash paths, byte-identical to the working tree) |
| Findings register (A) | `docs/reports/independent-g4-fts/remediation3/A_FINDINGS_REGISTER.md` |
| Implementation report (B) | `docs/reports/independent-g4-fts/remediation3/B_IMPLEMENTATION_REPORT.md` |
| Regression evidence (C) | `docs/reports/independent-g4-fts/remediation3/C_REGRESSION_EVIDENCE.md` |
| Database safety evidence (D) | `docs/reports/independent-g4-fts/remediation3/D_DATABASE_SAFETY_EVIDENCE.md` |
| Documentation reconciliation (E) | `docs/reports/independent-g4-fts/remediation3/E_DOCUMENTATION_RECONCILIATION.md` |
| Residual risks (F) | `docs/reports/independent-g4-fts/remediation3/F_RESIDUAL_RISK_REGISTER.md` |
| Source manifest (G) | `docs/reports/independent-g4-fts/remediation3/G_SOURCE_MANIFEST.md` |
| This handoff (H) | this file |
| New regression suite | `tests/test_g4_f01_f38_remediation.py` (65 tests) |
| Previous pass's suite | `tests/test_g4_revg4_remediation.py` (61 tests) |
| The prevention boundary | `tests/_g4_protection.py` + `tests/conftest.py` |
| Report addenda | `docs/reports/G4_FTS_REV3_REMEDIATION_REPORT.md` §16 (previous pass) and §17 (this pass) |
| Handoff addenda | `docs/reports/independent-g4-fts/HANDOFF.md` §8 (previous pass) and §9 (this pass) |

## 2. Review order that saves the most time

1. **Read Deliverable A.** For each finding it states the evidence class, the correction
   and the proving test. Check the *evidence class* first: a SOURCE-CONFIRMED finding
   is an argument from the code; a REPRODUCED one is a scenario you can re-run.
2. **Re-run the new suite** (`tests/test_g4_f01_f38_remediation.py`, 65 tests) and read
   the tests as the specification — each assertion states an invariant, not an
   implementation detail.
3. **Re-derive the safety claims yourself:**
   * point `memory-doctor` at a WAL database with a committed, uncheckpointed
     transaction and compare the hashes before/after (the main image and any existing
     `-wal` must be byte-identical; an **empty** `-wal`/`-shm` scaffold is SQLite's
     coordination behaviour and is documented, not a checkpoint);
   * point `memory-migrate` at an unsupported database and confirm the file is
     byte-identical afterwards and that the journal mode did not change;
   * run the backup against a destination that appears between allocation and
     publication and confirm the racer's bytes survive;
   * delete a current database after constructing the backend and confirm a service
     call does **not** silently re-create it.
4. **Verify the boundary.** Open `.data/memory/unified.db` from a test and confirm the
   access is **blocked** (not detected afterwards); check that a spawned child process
   is blocked too (the `sitecustomize.py` mechanism).
5. **Re-run the affected set and the full suite**, and compare against the **pristine
   HEAD clone** result in Deliverable C. The failure sets must be identical.

## 3. Claims you should distrust first

| Claim | How to falsify it |
| --- | --- |
| "the migration never modifies an unsupported database" | create a DELETE-mode unrelated database, run the runner, compare hashes and the journal mode |
| "the backup is a complete consistent snapshot" | change a stored value in the source between the backup and the verification and check that the digest comparison fails |
| "the index contract is verified physically" | break an index's metadata (`PRAGMA index_xinfo` failure) and confirm the verdict is UNKNOWN, not PASS |
| "the legacy trigger recognition is exact" | try every partial trigger combination and confirm only the two documented sets are `legacy_compatible` |
| "the transaction outcome is honest" | inject a fault before the commit and read the durable ledger yourself; the report must not claim a rollback it cannot evidence |
| "the test environment cannot touch production" | try to open a production path from a test and from a child process — both must raise |
| "nothing regressed" | run the full suite in a clone of HEAD and compare the failure sets |

## 4. What is explicitly NOT claimed

* No runtime is certified (SQLite 3.50.4 is affected).
* G4 is **not** closed and **not** accepted; DEBT-045 is **not** closed.
* F10, F11, F23, F26, F28 and F36 are **not** fixed — see Deliverable F.
* The historical production-data contamination is **not** denied and was not “cleaned”.

## 5. Open items a reviewer should press on

1. Is the journal-mode-only repair (F05) too narrow — should a DELETE-mode database with
   *drifted* indexes also be repairable?
2. Does the read-only boundary (F24) belong in the test harness only, or should the
   product itself refuse to construct a store under a configured production prefix?
3. The `repairable_drift` state now covers index drift, trigger drift and the journal
   mode — is the *combination* of two drifts at once (e.g. index drift **and** a
   delete-mode journal) still refused? It currently is (the scope builder rejects a
   contradictory scope).
4. `memory-verify` still does not gate on the complete contract (F26) — decide
   whether that is a defect or a deliberate scope.
5. The preservation policy (F10) can copy a whole database on a no-op run — decide
   whether a cheaper, still-safe policy is required before G4 can be accepted.

---

## 6. Third round (Nov 11, 2026) — what a fresh reviewer must re-check

The candidate now contains **three** corrective rounds. The review order in §2 still
holds; add these checks:

1. **Object ownership (W01):** create `IDX_KE_LAYER` (upper case) on another table and
   `KE_AD` on another table; the runner must refuse and the unrelated objects and their
   data must survive.
2. **The verification contract (W22):** drop `ke_ad` from a healthy database and run
   `memory-verify --json`: `contract_passed` must be `false` and
   `contract.trigger_contract.status` must be `fail` even though `fts_rank1` passes.
3. **The digest in the CLI (W13):** change one content value (same row count, same
   schema) and confirm `logical_digest_invariance` fails.
4. **Recovery protection (W18):** create a hot rollback journal and run
   `memory-verify --json`: `recovery_evidence_preserved` must be non-empty and
   `verdict_scope` must say the verdict concerns a copy; the original journal's hash
   must be unchanged.
5. **The no-op policy (W15):** run the migration against a healthy database with live
   sidecars: `report.preserved_files` must be **empty** (no full-database copy).
6. **The boundary (W20):** open a production path through a symlink from a child
   process: it must be blocked before the application code runs.
7. **The interaction scenarios:** `tests/test_g4_interaction_scenarios.py` (A–L) is the
   consolidated evidence — run it first; it is the fastest way to see whether the
   combinations still hold.

**What is still NOT claimed:** no runtime certification, no G4 acceptance, no DEBT-045
closure, and six partial items (initialization lock, backup scope, preservation
capacity/stability, incomplete manifests, database-path identity, stale inventory
figures) are listed with their residual risk in `F_RESIDUAL_RISK_REGISTER.md`.
