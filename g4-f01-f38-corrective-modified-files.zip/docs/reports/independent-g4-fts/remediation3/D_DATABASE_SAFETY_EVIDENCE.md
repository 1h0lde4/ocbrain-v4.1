# Deliverable D — Database safety evidence

**Rule:** every number in this document concerns a **disposable** database under a
temporary directory. No production database was opened, read, written, migrated,
verified, backed up, checkpointed or repaired by this pass — and the boundary that
enforces this is described in §D.4.

## D.1 Production path state — before and after this pass

| Path | State before this pass | State after this pass | Changed by this pass? |
| --- | --- | --- | --- |
| `.data/memory/unified.db` | 86 016 B, mtime 09:46:39 (previous session) | identical (hash + mtime) | **no** |
| `.data/memory/archive.db` | 45 056 B, mtime 09:46:39 | identical | **no** |
| `.data/memory/graph.db` | 32 768 B, mtime 15:27:14 (previous pass) | identical | **no** |
| `.data/memory/cognitive/vault_v4.json` | 2 583 B, mtime 15:22:36 (previous pass) | identical | **no** |
| `.data/memory/unified.db-wal` | 0 B, mtime 16:01:32 (previous pass) | identical | **no** |
| `.data/memory/unified.db-shm` | 32 768 B, mtime 16:03:59 (previous pass) | identical | **no** |
| `config/settings.toml`, `config/models.toml`, `config/sources.toml` | restored to HEAD before this pass | identical | **no** |

The remaining test byproducts (two `untracked` directories created by a test,
`modules/test_rce001_name_tmp/` and `modules/test_rce001_tmp/`) are left in place —
deleting untracked files is out of bounds — and are documented in the final manifest.

## D.2 Disposable-database evidence

Every figure below was produced against a temporary database.

| Property | How it is established |
| --- | --- |
| Main DB hash | SHA-256 of the main file, before and after each operation |
| WAL/SHM/journal hash | SHA-256 of each sidecar (or “absent”), before and after |
| Journal mode | `PRAGMA journal_mode` read through a read-only connection |
| Content digest | `logical_content_digest()` — type-aware, length-delimited, over every stored value plus the rowid mapping |
| Schema identity | SHA-256 over the ordered `sqlite_schema` rows (schema, triggers, indexes) |
| Migration ledger | the exact rows of `_ocbrain_memory_migrations` (id, status, completed_at) |
| Backup verification | integrity, foreign keys, FTS `rank=1`, schema/trigger/index equality, content digest — all compared against the source snapshot |
| Recovery manifest | `manifest.json` written beside every preservation set: source and destination paths, sizes, SHA-256 of each artifact, the reason, “originals retained” |

## D.3 What each correction guarantees (and the test that proves it)

| Guarantee | Test |
| --- | --- |
| The doctor cannot consume WAL frames or rewrite the image | `TestF01DoctorNeverWrites::test_doctor_leaves_main_wal_and_journal_untouched` |
| The doctor never removes a sidecar | `TestF01DoctorNeverWrites::test_doctor_never_removes_sidecars` |
| An unsupported database is refused byte-identical | `TestF05JournalModeRecoveryRoute::test_unsupported_delete_db_stays_unmodified` |
| A missing source is never created by a backup | `TestF06F07F08Backup::test_backup_of_missing_source_creates_nothing` |
| A concurrent destination is never overwritten | `TestF06F07F08Backup::test_destination_appearing_before_publication_is_not_overwritten` |
| The backup is one verified logical snapshot | `TestF06F07F08Backup::test_backup_verifies_a_complete_logical_snapshot` |
| An unrelated object with a canonical name is never dropped | `TestF15ObjectOwnership::test_unrelated_object_survives_a_refused_migration` |
| A service connection cannot convert the journal mode | `TestF22F23ServiceLifecycle::test_service_connection_does_not_change_the_journal_mode` |
| A service connection cannot silently re-create a deleted database | `TestF22F23ServiceLifecycle::test_missing_database_is_not_recreated_by_a_service_connection` |
| A foreign lock is never removed by a release | `TestF35F36F37ClassificationAndLocks::test_lock_release_does_not_remove_a_foreign_lock` |
| Production access is impossible, not merely detected | `TestF24ProductionBoundary` (3 tests) |

## D.4 The protective boundary (F24)

Established at **conftest import time** — before pytest collects (and therefore before
it imports) any test module and before the orchestrator/worker import chains run:

1. **A temporary memory path before any import.** `OCBRAIN_MEMORY_DIR` is set to a
   fresh temporary directory; the memory, cognitive-vault and graph-engine singletons
   resolve their default path from it. Replacing a singleton *after* import is too
   late — the import itself constructs the store.
2. **A prevention boundary.** `sqlite3.connect`, `builtins.open`, `os.remove`,
   `os.rename` and `os.replace` are wrapped: any access to the production memory
   directory raises `ProtectedPathError` **before** the access happens, and any
   *modification* of the production configuration files is refused.
3. **Child-process inheritance.** The protected paths are exported through the
   environment and a generated `sitecustomize.py` (placed on `PYTHONPATH`) installs the
   same boundary in every child interpreter — the spawned-worker path that previously
   opened the production database is now blocked there too.
4. **A failed boundary installation aborts the run** rather than degrading to
   detection-after-the-fact.

**Verified positively:** `TestF24ProductionBoundary::test_the_boundary_is_installed_in_this_process`
opens the production database path inside the test session and asserts that the
`ProtectedPathError` is raised — i.e. the access never happened.

**Secondary net:** the previous detection harness still walks `.data/memory` around
every test and fails the test if any file changed (fingerprint `(size, mtime_ns)`, so
a same-size write is caught).

## D.5 Historical production-data access — not denied

The previous pass documented that the **test suite itself** wrote to production data
(the memory singleton, the cognitive vault, the graph database and a spawned worker).
Those writes happened **before** the boundary existed; the production vault file still
contains the three duplicate test-entry pairs. This pass **prevented** further access
and did **not** rewrite the polluted file (that is an operator decision).
