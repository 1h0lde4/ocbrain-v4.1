# Deliverable G — Final source manifest

**Branch:** `independent/g4-fts-rev3-20261105`  **HEAD:** `739e58ce185a527d2d2f58c7622c5108f5b0e0db`  (unchanged — every modification below is **uncommitted**).

**Working-tree entries:** 28 (18 modified, 10 untracked).

## G.1 Modified tracked files

| Path | Bytes | SHA-256 |
| --- | ---: | --- |
| `KNOWN_ISSUES.md` | 248631 | `cefb081dc21901027321f79c6595182bd1ed92b2995e06dd70d6288d22666204` |
| `core/memory/backends/sqlite_storage.py` | 30566 | `13bb47e809aee2f13d59f180626d1af794169e48da076a36aacf52000c46d534` |
| `core/memory/cognitive_vault.py` | 4264 | `5de7f0fca133d1552cef253793a8436518c2ae3e4c596bc2828a3ef30604ee4f` |
| `core/memory/graph/graph_engine.py` | 15783 | `d473da72d38d5c35412d29c5ba9029c0fa519e314b9e51ff51527f7ab861e540` |
| `core/memory/sqlite_contract.py` | 37024 | `9e3d08db8d363efc7f769b1c3d554114fdd913445f6460292e0bbd40373ae78d` |
| `core/memory/sqlite_integrity.py` | 51309 | `11562a6a91345f01afe08e91dd37fdaa7ee8b8b76496de3c480f238fa0444d3a` |
| `core/memory/sqlite_migration.py` | 110136 | `c766f420db5bedf04938532677775e6ffab691b0975f3049b745aed32e515347` |
| `core/memory/unified_memory.py` | 58892 | `96ae01c228eaa76b66f208aa3105ad632cd09d1ee258286d3b5fc066353fcff5` |
| `docs/reports/G4_FTS_REV3_REMEDIATION_REPORT.md` | 73441 | `5e1cca08eaf35c18652c7bf40a35b8f51942a587cad2a15121b77bb267b9e459` |
| `docs/reports/independent-g4-fts/EVIDENCE_NOTE.md` | 17183 | `640762f4f39f8c4c3eb03dc2139bf6fd97c3f8e7a993ebb27f1d9bd029fcda3e` |
| `docs/reports/independent-g4-fts/HANDOFF.md` | 24167 | `f244876a071680036e25b4802e9caa6c0e024a72a7fb243d2d314ad119c4e16b` |
| `interface/cli.py` | 44545 | `bc278c35da00fdc045fea94532dd6903c6e5cbb14be88c371c420d847d345f6e` |
| `tests/_crash_restart_child.py` | 4176 | `e381179bbe755d90998de6c3505de25326286c797db042e40e68b7eb1501b774` |
| `tests/conftest.py` | 8544 | `0f012c9e5d2def4bafd9506d18e09352bb3cf0afe172ed684a6789d2a163d8fd` |
| `tests/test_g4_indep_trigger_contract.py` | 13935 | `746a8a66707d695380a81c98b4e8e3c3897f0a4226b83c00a7fdafa8daab2492` |
| `tests/test_g4_rev3_mutation_atomicity.py` | 14588 | `a9b9fbbafb58ce71e7b4eb39cd9c776073ff30479d785c8cc71d3207727f29a6` |
| `tests/test_g4_rev3_search_regression.py` | 13945 | `3025fe5651737407a703a1049e3224f67c4ce4c89406c6b7776363cc8ed73570` |
| `tests/test_g4_rev3_sqlite_contract.py` | 30359 | `ffc7da62472f5ddeec4914db91591992db485c72003c4ddfc0f612303dc164df` |

## G.2 New (untracked) paths

| Path | Bytes | SHA-256 |
| --- | ---: | --- |
| `docs/reports/independent-g4-fts/remediation2//` | 88428 (32 files) | — |
| `docs/reports/independent-g4-fts/remediation3//` | 92975 (9 files) | — |
| `modules/test_rce001_name_tmp//` | 191944 (3 files) | — |
| `modules/test_rce001_tmp//` | 192152 (3 files) | — |
| `scripts/g4_indep/probe_revg4_stage1_repro.py` | 26410 | `31e8d32619dcf5f31b0cc47e4ca8d1e880f0d7738c4831b3cee7447c6c3d81d5` |
| `scripts/g4_indep/probe_revg4_stage2_postfix.py` | 16189 | `8f5e6af18730512914b5136dcf1d53d834483e2dfd4612e1e90080cea8083709` |
| `tests/_g4_protection.py` | 12822 | `5264b6cfc999d998ae6bf39b06866630befb8b54750ab0d6267d0f766bfa709b` |
| `tests/test_g4_f01_f38_remediation.py` | 35019 | `92eaf8397e3286a5d4515e5b8c308e06d645749b1ef65a09fbb099d6b99eeeae` |
| `tests/test_g4_interaction_scenarios.py` | 17846 | `5da0ee04a282ed66c5872c1f2f633836c59bfbaeff1cf23509cfdeef516c3328` |
| `tests/test_g4_revg4_remediation.py` | 45119 | `b7d7d46ef8e41c079d93cf9fa6f62f637c1b1800c1af65e2f9b5c12a41ad1312` |

## G.3 Diff statistics (tracked files)

```
 KNOWN_ISSUES.md                                  |   93 ++
 core/memory/backends/sqlite_storage.py           |  106 +-
 core/memory/cognitive_vault.py                   |   13 +-
 core/memory/graph/graph_engine.py                |   10 +-
 core/memory/sqlite_contract.py                   |  619 ++++++++-
 core/memory/sqlite_integrity.py                  |  684 +++++++++-
 core/memory/sqlite_migration.py                  | 1592 +++++++++++++++++++---
 core/memory/unified_memory.py                    |   25 +-
 docs/reports/G4_FTS_REV3_REMEDIATION_REPORT.md   |  250 +++-
 docs/reports/independent-g4-fts/EVIDENCE_NOTE.md |   29 +-
 docs/reports/independent-g4-fts/HANDOFF.md       |  114 ++
 interface/cli.py                                 |  505 +++++--
 tests/_crash_restart_child.py                    |   22 +
 tests/conftest.py                                |  182 ++-
 tests/test_g4_indep_trigger_contract.py          |   27 +-
 tests/test_g4_rev3_mutation_atomicity.py         |   36 +-
 tests/test_g4_rev3_search_regression.py          |   74 +-
 tests/test_g4_rev3_sqlite_contract.py            |   67 +-
 18 files changed, 4005 insertions(+), 443 deletions(-)
```

## G.4 Removed files

**None.** No file was deleted or renamed in this pass; the two untracked test by-product directories (`modules/test_rce001_name_tmp/`, `modules/test_rce001_tmp/`) were left in place (deleting untracked files is out of bounds).

## G.5 Git operations performed

**None.** No branch was created, nothing was staged, committed, pushed, rebased or merged; no PR was opened or closed; no governance state was changed.
