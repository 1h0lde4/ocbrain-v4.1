# Deliverable A — Findings register F01–F38 (definitive remediation, Nov 10–11 2026)

**Base:** HEAD `739e58c` (branch `independent/g4-fts-rev3-20261105`) + the supplied change set
(`g4-revg4-remediation-modified-files.zip`, verified byte-identical to the working tree).
**State:** every change is **local and uncommitted**; no branch, commit, staging, push, PR, merge or rebase.

**Evidence classification used below**

| Class | Meaning |
| --- | --- |
| **REPRODUCED** | demonstrated against the shipped code by an executable scenario in this pass |
| **SOURCE-CONFIRMED** | confirmed by reading the exact source at the base revision (no separate scenario needed) |
| **NOT VERIFIED** | could not be established — reported as such, never as PASS |

**Disposition vocabulary:** FIXED · NOT FIXED · NOT VERIFIED · NOT APPLICABLE (with justification).

## Summary table

| ID | Finding (short) | Evidence | Disposition | Primary regression test |
| --- | --- | --- | --- | --- |
| F01 | doctor must never silently open a writable database | REPRODUCED | **FIXED** | `TestF01DoctorNeverWrites` (5) |
| F02 | unsupported targets refused before persistent mutation | REPRODUCED | **FIXED** | `TestF05…::test_unsupported_delete_db_stays_unmodified` + existing lifecycle suite |
| F03 | failed post-lock re-inspection must fail closed | REPRODUCED | **FIXED** | `TestF03PostLockReinspectionFailsClosed` (1) |
| F04 | missing/empty paths never created | REPRODUCED | **FIXED** | `TestF06F07F08Backup::test_backup_of_missing_source_creates_nothing` + `TestF22F23…` |
| F05 | DELETE-mode current DB needs an authorized recovery route | REPRODUCED | **FIXED** | `TestF05JournalModeRecoveryRoute` (4) |
| F06 | backup publication atomic and non-overwriting | REPRODUCED | **FIXED** | `TestF06F07F08Backup` (2 publication tests) |
| F07 | backup temp file exclusively owned | SOURCE-CONFIRMED | **FIXED** | `…::test_temporary_artifact_is_exclusively_owned` |
| F08 | backup proves a complete consistent snapshot | SOURCE-CONFIRMED | **FIXED** | `…::test_backup_verifies_a_complete_logical_snapshot` |
| F09 | raw recovery preservation before recovery-capable opens | REPRODUCED | **FIXED** (previous pass) | `TestRevg406Preservation` (5) |
| F10 | no-op migrations must not duplicate the whole database | SOURCE-CONFIRMED | **PARTIAL — see F36** | (open item) |
| F11 | partial preservation produces a truthful incomplete record | SOURCE-CONFIRMED | **NOT FIXED** | — |
| F12 | structural ERROR ≠ confirmed corruption | REPRODUCED | **FIXED** | `TestF12StructuralErrorVersusFail` (1) |
| F13 | SQL normalization preserves literal semantics | REPRODUCED | **FIXED** | `TestF13F34SqlSemantics` (9 parametrized + 2) |
| F14 | index audit fails closed on unknown/unverified metadata | REPRODUCED | **FIXED** | `TestF14F33IndexAudit` (2) |
| F15 | global index/trigger name collisions never destroyed | REPRODUCED | **FIXED** | `TestF15ObjectOwnership` (3) |
| F16 | legacy trigger recognition: explicit states only | REPRODUCED | **FIXED** | `TestF16F32LegacyTriggerSets` (3) |
| F17 | repair scope never defaults to broad repair | SOURCE-CONFIRMED | **FIXED** | `TestF35F36F37…::test_repair_scope_is_never_defaulted` |
| F18 | FK detection accurate; error ≠ not_applicable | REPRODUCED | **FIXED** | `TestF18F19ForeignKeys::test_prefix_similar_user_table_is_inspected` |
| F19 | FK preflight failure prevents migration | REPRODUCED | **FIXED** | `TestF18F19ForeignKeys::test_fk_preflight_failure_refuses…` |
| F20 | housekeeping + ledger contract validated | REPRODUCED | **FIXED** | `TestF20F35HousekeepingAndFreshness` (3) |
| F21 | SQLite file URIs safely encoded | SOURCE-CONFIRMED | **FIXED** | `TestF21UriEncoding` (6) |
| F22 | service connections make no persistent mode changes | REPRODUCED | **FIXED** | `TestF22F23ServiceLifecycle` (2) |
| F23 | fresh initialization concurrency + recovery | SOURCE-CONFIRMED | **PARTIAL** | (see residual risks) |
| F24 | import-time singletons cannot access production data | REPRODUCED | **FIXED** | `TestF24ProductionBoundary` (3) |
| F25 | no vacuous assertions / silent skips | SOURCE-CONFIRMED | **FIXED** (this file) | (this file) |
| F26 | verify success requires the complete contract | SOURCE-CONFIRMED | **NOT FIXED** | — |
| F27 | logical invariance compares actual stored values | SOURCE-CONFIRMED | **FIXED** | `TestF27F29F38…` (2 digest tests) |
| F28 | writable verification must not consume recovery evidence | SOURCE-CONFIRMED | **NOT FIXED** | — |
| F29 | commit/rollback outcomes classified truthfully | REPRODUCED | **FIXED** | `TestF27F29F38…::test_pre_commit_fault_reports_a_verified_rollback` |
| F30 | advisory lock identity + lifecycle | SOURCE-CONFIRMED | **FIXED** | `TestF35F36F37…::test_lock_release_does_not_remove_a_foreign_lock` |
| F31 | sidecar side effects reported truthfully | REPRODUCED | **PARTIAL** | `TestF01…::test_doctor_leaves_main_wal_and_journal_untouched` |
| F32 | arbitrary missing-trigger combinations rejected | REPRODUCED | **FIXED** | `TestF16F32LegacyTriggerSets` (2) |
| F33 | index metadata inspection failures prevent PASS | REPRODUCED | **FIXED** | `TestF14F33IndexAudit::test_pragma_failure_prevents_pass` |
| F34 | DDL parsers reject unrecognized grammar | REPRODUCED | **FIXED** | `TestF13F34SqlSemantics` (7) |
| F35 | fresh-database classification inspects all objects | REPRODUCED | **FIXED** | `TestF20F35…::test_database_with_only_a_view_is_not_absent` |
| F36 | recovery snapshot stable + space-preflighted | SOURCE-CONFIRMED | **NOT FIXED** | — |
| F37 | lock acquisition/release failures handled safely | SOURCE-CONFIRMED | **FIXED** | `TestF35F36F37…` |
| F38 | busy checkpoints not reported as complete | REPRODUCED | **FIXED** | `TestF27F29F38…::test_checkpoint_status_is_not_done_when_busy` |

## Detailed dispositions (the non-obvious ones)

### F01 — the doctor must never silently open a writable database
*Evidence:* REPRODUCED — the doctor’s inventory connection was read-write and the
`_open_verify_connection` fallback silently opened a plain connection; a WAL database
with a committed, uncheckpointed transaction was mutated (frames consumed, main image
rewritten).
*Correction:* `interface/cli.py` gained `_open_inspection_connection()` — strictly
`mode=ro`, **failing closed** with no writable fallback. The checkpoint inventory
collects filesystem facts for the main file and **all** sidecars without a writable
connection; an uninspectable state is reported as **UNAVAILABLE**. The doctor never
removes a sidecar. `memory-verify` keeps its writable connection (it needs the FTS5
`rank=1` command) and now *proves* its non-mutation claim.
*Residual:* a read-only open of a WAL database may create an **empty** `-wal`/`-shm`
coordination scaffold and may churn `-shm` bytes — reported, never checkpointed (F31).

### F05 — DELETE-mode recovery route
*Evidence:* REPRODUCED — a current-schema database whose journal mode was changed
externally was refused by startup, and the maintenance command could not restore it
(the classification did not account for the journal-mode invariant, so it answered
`already_applied`).
*Correction:* the classifier recognizes exactly one new **repairable drift**: canonical
schema + valid ledger + canonical triggers/indexes + `journal_mode = delete`, with an
explicit repair scope `{"journal_mode": "wal", "triggers": False, "indexes": ([], []),
"fts_rebuild": False}`. The runner restores the mode through a dedicated path that opens
**no migration transaction**, replaces no trigger, recreates no index, rebuilds no FTS
index and writes **no ledger row**; it verifies the mode SQLite actually returns and
re-runs the full readiness contract. A second invocation reports `already_applied`.
An unsupported DELETE-mode database is still refused and left byte-identical.

### F13 / F34 — SQL semantics
*Evidence:* REPRODUCED — `normalize_sql()` removed comments with a whole-statement
regular expression (destroying string literals containing `--` or `/* … */`) and
compared with `str.casefold()` (so `'unknown'` and `'UNKNOWN'` compared EQUAL, and
Unicode identifiers were folded in a way SQLite never folds them).
*Correction:* a quote-aware tokenizer (`tokenize_sql`) recognises `--`/`/* */` comments
only **outside** quoted content, preserves string literal values **byte-for-byte**,
folds identifiers with **ASCII-only** lower-casing, and raises `SqlParseError` on
unterminated quotes/comments. Both DDL parsers were rewritten on top of it and now
validate the object name, the table/module, every clause, and that **no trailing SQL
remains**; an unrecognized grammar produces UNKNOWN, never CANONICAL.

### F14 / F33 — index contract
*Correction:* `audit_index_contract()` now cross-checks the stored DDL against the
**live** SQLite metadata (`PRAGMA index_list` + `PRAGMA index_xinfo`): uniqueness,
partial flag, column order, DESC flag, collation, expression terms and key/auxiliary
columns. A PRAGMA failure is an **ERROR** (never a PASS). A same-name index owned by
**another table** is `foreign_owned` (F15) and is never dropped. Unknown drift takes
precedence over repairable drift, so a missing index plus an unknown extra index is
`unknown_drift`.

### F16 / F32 — legacy trigger states
*Evidence:* REPRODUCED — the classifier accepted *any* combination of
canonical/known-legacy/missing, so an arbitrary partial trigger set was classified
`legacy_compatible`.
*Correction:* the repository history was inspected (`42818a7`, `da99c12`) and exactly
two historical trigger SETS are enumerated in `LEGACY_TRIGGER_CONFIGURATIONS`:
pre-Session-4C (canonical ke_ai, raw-UPDATE ke_au, plain-DELETE ke_ad) and Session-4C
V1 (canonical ke_ai/ke_au, plain-DELETE ke_ad). A missing trigger, a mixed set or an
unknown body is now **unsupported** and fails closed.

### F20 / F35 — housekeeping, ledger and freshness
*Correction:* `audit_housekeeping_contract()` verifies the exact column list and
types, the primary key, the NOT NULL columns, the marker cardinality and the ledger
cardinality (exactly one applied row for the current migration, no duplicates). A
database with **no** application tables but a view/index/trigger is no longer
classified `absent` (F35) — the classifier now inspects **all** `sqlite_schema` object
types.

### F24 — the production boundary
*Evidence:* REPRODUCED — four distinct paths let the suite touch production data
(the memory singleton, the cognitive vault, the graph engine, and a spawned worker
importing `core/workers/curator.py`).
*Correction:* two layers, both installed **before pytest collects**:
1. a temporary memory path is established **before any OCBrain module is imported**
   (`OCBRAIN_MEMORY_DIR`), so the production-default singletons never construct a
   production store (replacing a singleton after import is too late — the import
   itself constructs it);
2. a **prevention** boundary (`tests/_g4_protection.py`) blocks `sqlite3.connect`,
   `open`, `os.remove/rename/replace` against the production memory directory and the
   production configuration files, and is inherited by child processes through a
   generated `sitecustomize.py`. The previous *detection* harness (compare after the
   fact) remains as a secondary net and now fingerprints `(size, mtime_ns)` so a
   same-size write cannot pass unnoticed.

### F29 / F38 — honest transaction and checkpoint outcomes
*Correction:* a failure before the commit no longer claims “the transaction rolled
back”. The durable ledger row is re-read through a safe read-only connection and
compared with the row that existed **before** this transaction; the outcome is
classified as **committed**, **confirmed rollback** or **`outcome_uncertain`** (a new
outcome value). A swallowed ROLLBACK error escalates an unestablished outcome to
`outcome_uncertain`. The post-commit checkpoint is reported as `completed` or
**`blocked`** with the log/checkpointed frame counts; a busy checkpoint no longer
says `done` and never claims truncation.

### F30 / F37 — advisory lock
*Correction:* the lock’s identity is established at acquisition (PID written and
flushed while the descriptor is open); a failure to write it removes the lock again
instead of leaving an **unowned** lock. Release removes the pathname **only** when it
still refers to the object this process created (device/inode identity) — a replaced
lock is never removed, and a release failure is logged honestly.

## Findings NOT fixed (with reasons)

| ID | Why | Risk accepted |
| --- | --- | --- |
| **F10** | the preservation policy is still "copy everything when sidecars exist"; a **safe** alternative (e.g. hashing-only) was not demonstrated within this pass | repeated maintenance runs can duplicate a full database copy; bounded by the operator’s disk budget. Tracked as an open item. |
| **F11** | a failed copy currently raises and the partial set is retained on disk, but no **incomplete manifest** is written | a partial preservation set is discoverable by its directory name but not self-describing. |
| **F23** | the fresh-init path is still “create then initialize”; a competing first-start process is not serialized by a dedicated lock | two processes starting simultaneously on a brand-new path can race; SQLite’s own locking makes the outcome one of the two initializations, but the loser is not told it lost. |
| **F26** | `memory-verify` still gates on the integrity battery, identity and logical invariance, but not on the trigger/index/FTS-configuration classifications | a database with canonical-looking rows but a wrong trigger can still be reported as “verified”. |
| **F28** | `memory-verify` still opens the original database write-capable for `rank=1` | opening it can trigger WAL/journal recovery on the original. |
| **F36** | the recovery snapshot is not space-preflighted and does not detect a source file changing during the copy | a copy taken while another process writes is not guaranteed consistent (the deployment contract requires quiescence). |

These are reported as **NOT FIXED** with the residual risk — never as PASS.
