# CHANGES — G4 definitive corrective remediation (F01–F38)

**Date:** Nov 10–11, 2026
**Base:** HEAD `739e58c` on `independent/g4-fts-rev3-20261105`, plus the supplied change set
(`g4-revg4-remediation-modified-files.zip`, SHA-256 `2D73E808…`, verified byte-identical to the working tree)
**State:** **all changes are local and uncommitted.** No branch, commit, staging, push, PR, merge or rebase;
no issue closed; no governance decision taken.
**Size:** 18 modified tracked files — **3 659 insertions / 401 deletions** — plus 4 new source/test files and
the `remediation3/` deliverable set.
**Runtime of every measurement:** CPython **3.14.3** · bundled SQLite **3.50.4** (an *affected* engine).

This document is the **implementation** record. The finding-by-finding dispositions live in
`A_FINDINGS_REGISTER.md`; the regression evidence in `C_REGRESSION_EVIDENCE.md`; the residual risks in
`F_RESIDUAL_RISK_REGISTER.md`; the per-file hashes in `G_SOURCE_MANIFEST.md`.

---

## 1. Change map at a glance

| Area | Files | Findings |
| --- | --- | --- |
| SQL front end (tokenizer, parsers, legacy states, URI) | `core/memory/sqlite_contract.py` | F13, F16, F21, F32, F34 |
| Schema auditors (index, trigger, housekeeping, FK, digest) | `core/memory/sqlite_integrity.py` | F14, F15, F18, F20, F27, F33 |
| Migration lifecycle (states, preflight, backup, locks, reporting) | `core/memory/sqlite_migration.py` | F02, F03, F05, F06, F07, F08, F10, F11, F12, F17, F19, F29, F30, F36, F37, F38 |
| Service connection + initialization | `core/memory/backends/sqlite_storage.py` | F22, F23 |
| Import-time singleton paths | `core/memory/unified_memory.py`, `core/memory/cognitive_vault.py`, `core/memory/graph/graph_engine.py` | F24 |
| CLI diagnostics | `interface/cli.py` | F01, F04, F26, F28, F31 |
| Test environment (boundary, isolation, suites) | `tests/conftest.py`, `tests/_g4_protection.py`, `tests/test_g4_f01_f38_remediation.py`, `tests/_crash_restart_child.py`, 4 pre-existing suites | F24, F25, F25 |
| Documentation | report §17, `HANDOFF.md` §9, `KNOWN_ISSUES.md` addendum, `EVIDENCE_NOTE.md` §5 | Part VI |

---

## 2. File-by-file changes

### 2.1 `core/memory/sqlite_contract.py` (+619 / −)

The contract module became the home of a **quote-aware SQL front end** and of the enumerated legacy states.

* **New `SqlParseError`** — raised when SQL cannot be tokenized or parsed unambiguously. An ambiguous
  statement is never compared optimistically.
* **New `tokenize_sql(sql)`** — a quote-aware tokenizer producing typed tokens (`word`, `string`,
  `quoted_ident`, `number`, `punct`, `comment`). It recognises `--` line comments and `/* … */` block comments
  **only outside quoted content**; handles `''` escapes in string literals, `""` in double-quoted identifiers,
  backtick identifiers and `[bracketed]` identifiers; raises on an unterminated quote or block comment.
* **`_ascii_lower(text)`** — ASCII-only folding. SQLite compares identifiers ASCII case-insensitively;
  `str.lower()`/`str.casefold()` are Unicode-aware and would change identifier semantics (e.g. `İ` → two code
  points).
* **Rewritten `normalize_sql(sql)`** — the previous version removed comments with a whole-statement regular
  expression (`--[^\n]*|/\*.*?\*/`) and compared with `str.casefold()`. Both were unsound: a string literal
  containing `--` or `/* … */` was destroyed, and **string literal values were lower-cased**, so
  `'unknown'` and `'UNKNOWN'` compared **equal**. The new form preserves literal values byte-for-byte,
  folds identifiers ASCII-only, collapses whitespace to a single separator and keeps dotted identifiers intact
  (`old.rowid` stays `old.rowid`).
* **Rewritten `parse_create_index(sql)`** — token-driven and strict: it validates `CREATE [UNIQUE] INDEX … ON
  <table> (terms) [WHERE …]`, checks the object name, the table name and every clause, rejects an unbalanced or
  unterminated definition, tolerates **no trailing SQL**, splits terms at top level only, and understands
  `COLLATE`/`ASC`/`DESC`. It returns the previous keys plus `terms` (each term records whether it is a plain
  column or an **expression** — an expression can never equal a canonical column term).
* **Rewritten `parse_create_virtual_table(sql)`** — validates the object name, the module (`fts5` only), every
  argument clause and that no trailing SQL remains; a non-column, non-option token raises instead of being
  accepted.
* **New `LEGACY_TRIGGER_CONFIGURATIONS`** — the **only** two historically documented trigger *sets*:
  `("canonical", "known_legacy_unsafe", "known_legacy_unsafe")` (pre-Session-4C, `42818a7`) and
  `("canonical", "canonical", "known_legacy_unsafe")` (Session-4C V1, `da99c12`). No configuration contains
  `"missing"`, so an arbitrary partial trigger set can no longer be classified as repairable.
* **New `HOUSEKEEPING_TABLE_CONTRACTS`** — the exact column list and types, primary key and NOT NULL columns of
  `_ocbrain_memory_meta` and `_ocbrain_memory_migrations`.
* **New `sqlite_file_uri(db_path, mode)`** — a correctly encoded **absolute** SQLite file URI
  (`file:/C:/…?mode=ro`, UNC authority form, percent-encoded `#`, `?`, `%`, spaces and non-ASCII). Raw path
  concatenation into `file:{path}?mode=ro` was replaced everywhere.

### 2.2 `core/memory/sqlite_integrity.py` (+671 / −)

* **New `audit_index_contract(conn)`** — the previous version compared only the **stored DDL** and swallowed
  `PRAGMA index_list` errors. It now cross-checks the live metadata: `_index_physical_facts()` reads
  `PRAGMA index_list` (uniqueness, origin, partial flag) and `PRAGMA index_xinfo` (column order, DESC flag,
  collation, expression terms, key/auxiliary columns), and `_index_terms_match()` requires the parsed
  definition **and** the physical facts to agree. Outcomes per index: `canonical`, `missing`,
  `wrong_definition`, `unparseable`, `foreign_owned` (same name, **another table** — F15) and `unknown`
  (metadata unavailable or inconsistent). The aggregate is `canonical` / `repairable_drift` / `unknown_drift`,
  and **unknown drift outranks repairable drift** (a missing index plus an unknown extra index is
  `unknown_drift`, never auto-repaired).
* **Rewritten `audit_trigger_contract(conn)`** — the trigger lookup is now **global** (a trigger name is
  database-wide): a canonical name owned by another table is `foreign_owned`. The classification matches the
  trigger **set** against `LEGACY_TRIGGER_CONFIGURATIONS` instead of accepting any combination of
  canonical/known-legacy/**missing**.
* **New `audit_housekeeping_contract(conn)`** — validates both bookkeeping tables' exact shape (columns, types,
  primary key, NOT NULL), the schema-state marker's cardinality and value, and the ledger's cardinality
  (exactly one applied row for the current migration, no duplicate rows, status values). It distinguishes
  `canonical` / `malformed` / `unreadable` — a **missing** ledger and an **unreadable** ledger are different
  states.
* **Foreign-key inspection rewritten** — `_user_tables()` keeps every non-`sqlite_%` table;
  `FTS5_SHADOW_TABLE_NAMES` and `HOUSEKEEPING_TABLE_NAMES` are **exact** allowlists (the previous code skipped
  any table whose name merely *started with* `knowledge_entries_fts` or `_ocbrain_`, silently ignoring user
  tables such as `knowledge_entries_fts_custom`). `_foreign_key_relationship_status()` returns
  `found` / `none` / `unavailable` — an inspection error is **never** collapsed into "no relationships".
  `classify_foreign_key_violations()` returns a **list** (every violation row preserved) instead of a
  dictionary keyed by a composite string. Identifiers are quoted with `_quote_ident()` (embedded double quotes
  escaped).
* **New `logical_content_digest(conn)`** — a deterministic, type-aware, length-delimited digest over **every**
  stored value of the content table plus the hidden-rowid mapping. Equal row counts and an equal schema hash
  prove nothing about content; this does.
* **`validate_readiness()`** — the "supporting indexes" check now uses the semantic **and** physical audit and
  fails with the specific reason (missing / wrong definition / unparseable / unknown extra).

### 2.3 `core/memory/sqlite_migration.py` (+1512 / −)

* **New `_path_precheck()`** — non-creating filesystem validation (missing, not a regular file, unreadable,
  zero-byte, invalid SQLite header).
* **New `sqlite_file_uri()` usage** — every read-only open now uses the encoded URI (see 2.1).
* **New `LEGACY_TRIGGER_CONFIGURATIONS` consumption** — the classification of a trigger set is exact.
* **Rewritten `inspect_migration_state()`** — the state machine is explicit: `absent`, `current`,
  `legacy_pending_migration`, `repairable_drift`, `invalid`, `inspection_unavailable`. It now
  (a) inspects **all** `sqlite_schema` object types, so a file holding only a view/index/trigger is **not**
  `absent` (F35); (b) validates the housekeeping contract and the ledger cardinality before granting
  `current` (F20); (c) recognises the **journal-mode-only repairable drift** (F05) with the explicit scope
  `{"journal_mode": "wal", "triggers": False, "indexes": ([], []), "fts_rebuild": False}`.
* **Rewritten `_repair_scope_for_state()`** — the broad fallback is **gone** (F17). A repairable state must
  carry a complete, validated scope: allowed keys, boolean flags, a two-element index list, a consistent
  `journal_mode` value, and no contradiction (an FTS rebuild without trigger replacement is rejected). A missing,
  malformed or contradictory scope fails closed (`None`).
* **Runner ordering** — path precheck → advisory lock → raw recovery preservation → read-only space estimate →
  read-only inspection + pre-integrity → **foreign-key preflight** → classification → refusal of
  unsupported/absent **before any persistent change** → only then `journal_mode=WAL` + `BEGIN IMMEDIATE`.
  * **F19**: a failing or unavailable foreign-key preflight now **refuses before** the journal-mode change
    (previously the finding was recorded and the migration continued).
  * **F12**: a structural **ERROR** (the check could not complete) is no longer reported as confirmed
    corruption — it refuses with "this is NOT a corruption verdict"; only a structural **FAIL** preserves and
    refuses as `preserved_corrupt`.
  * **F03**: if the post-lock re-inspection is unavailable, the run **fails closed**; the pre-lock state is
    never reused for a success verdict.
* **New `_repair_journal_mode_only()`** — the F05 recovery route: opens the database, restores WAL, verifies
  the mode SQLite actually returns, re-runs the full readiness contract, and reports the new outcome
  `repaired`. It opens **no migration transaction**, replaces no trigger, recreates no index, rebuilds no FTS
  index and writes **no ledger row**; the step trace records `replace_triggers: skipped` and
  `fts_rebuild: skipped`.
* **New `_restate_readonly()`** usage** — the post-lock re-read is read-only and fails closed (see above).
* **Rewritten `create_online_backup()`** —
  * *F07*: the temporary artifact is allocated **exclusively** (`O_CREAT|O_EXCL`) next to the destination, and
    its device/inode identity is recorded; cleanup removes **only** that identity.
  * *F06*: publication uses `os.link()` — an atomic **no-replace** primitive (it fails with `EEXIST` when the
    destination exists). `os.rename()` is deliberately not used: on POSIX it silently **replaces** an existing
    destination. A dangling symlink counts as an existing name (`os.path.lexists`); a destination directory, a
    missing destination directory and a hard link to the source are refused; if no atomic no-replace primitive
    is available the operation **fails closed**.
  * *F08*: the source is opened read-only and **one read transaction** spans both the source reads and the
    backup call, so the validation and the copy describe the same snapshot. The copy is verified (structural
    integrity, foreign keys, FTS `rank=1`, schema/trigger/index equality and the full logical content digest)
    **before** publication.
* **New `_durable_migration_state()` + `_reconcile_transaction_outcome()`** — **F29**. A failure before the
  commit no longer claims "the transaction rolled back; nothing was recorded". The durable ledger row is re-read
  through a safe read-only connection and compared with the row captured **before** the transaction (a
  fresh-initialized database already carries a ledger row, so its mere presence proves nothing about *this*
  run). The outcome is classified as **committed**, **confirmed rollback** (reported only with that evidence) or
  **`outcome_uncertain`** — a new outcome value. A swallowed ROLLBACK error escalates an unestablished outcome
  to `outcome_uncertain`.
* **Checkpoint reporting** — **F38**. A busy checkpoint is reported as `status: "blocked"` with
  `truncated: false`, the log and checkpointed frame counts, and a note that the readers are never forced; the
  migration transaction itself stays committed and successful. The step is no longer reported as `done`.
* **Rewritten `_acquire_lock_file()` / `_release_lock_file()`** — **F30/F37**. At acquisition the PID is written
  and flushed **while the descriptor is still open**; if that fails the lock is removed again (an unowned lock
  would block every later run) and the descriptor is closed. At release the pathname is removed **only** when it
  still refers to the object this process created (device/inode identity); a replaced lock is never removed and a
  release failure is logged honestly.
* **Preservation** — `_preserve_recoverable_state()` copies main/`-wal`/`-shm`/`-journal`, verifies every copy by
  SHA-256 and writes a manifest; it runs **before any SQLite open**. (F10's "no full copy on a no-op run" and
  F11's "incomplete manifest" remain **not fixed** — see the register.)

### 2.4 `core/memory/backends/sqlite_storage.py` (+106 / −)

* `_connect()` (the **service** connection) no longer issues `PRAGMA journal_mode=WAL`. It opens the existing
  file **non-creating** (`mode=rw`), **verifies** the journal mode and raises `MemoryReadinessError` when the
  mode is not WAL — i.e. when the database changed after readiness validation — instead of silently converting
  it. If any per-connection initialization fails, the connection is closed before the error propagates.
  `PRAGMA synchronous=NORMAL` and `PRAGMA foreign_keys=ON` are preserved.
* **New `_connect_initializing()`** — the only *creating* connection in the backend (`mode=rwc`), used solely by
  the documented fresh-init path; it sets WAL explicitly because the fresh-init contract produces a WAL database.
* `_connect_inspection()` uses the shared URI helper.

### 2.5 Import-time singleton paths (F24)

* `core/memory/unified_memory.py` — `UnifiedMemory.__init__` and `get_unified_memory()` resolve their default
  prefix from `OCBRAIN_MEMORY_DIR` (falling back to `.data/memory`), so a test environment can establish a
  temporary path **before the module is imported**.
* `core/memory/cognitive_vault.py` — the vault's default storage directory resolves from the same variable
  (`.data/memory/cognitive` → `<temp>/cognitive`); the module-level singleton therefore never touches the
  production vault at import time.
* `core/memory/graph/graph_engine.py` — the graph database path resolves from the same variable.

### 2.6 `interface/cli.py` (+208 / −)

* The read-only inspection helper opens through the encoded URI and **fails closed** — no writable fallback
  (F01). The writable verification connection is now reserved for `memory-verify`, which genuinely needs it for
  the FTS5 `rank=1` command.
* The doctor reports an uninspectable state as **UNAVAILABLE** and never claims a pass it did not measure
  (F31).
* The verification refusal text points at the application's own initialization path (a migration never creates a
  database — F04); an incomplete battery is reported as "NOT a verified result" with a non-zero exit.

### 2.7 Test environment

* **New `tests/_g4_protection.py`** — the prevention boundary: it blocks `sqlite3.connect`, `open`,
  `os.remove`, `os.rename` and `os.replace` against the production memory directory (any access) and the
  production configuration files (any modification), exports the protected paths for child processes and installs
  the boundary from the environment in a child.
* **Rewritten `tests/conftest.py`** — installs the boundary **at import time** (before pytest collects and
  before the orchestrator/worker import chains run), establishes the temporary memory path
  (`OCBRAIN_MEMORY_DIR`), generates a `sitecustomize.py` on `PYTHONPATH` so **child processes** inherit the
  boundary, redirects `core.config.CONFIG_DIR` to a **copy** of the configuration in a temporary directory (so a
  test's configuration write never lands in the repository), and keeps the previous detection harness as a
  secondary net with a `(size, mtime_ns)` fingerprint.
* **New `tests/test_g4_f01_f38_remediation.py`** — **65 tests**, one class per finding group.
* **New `tests/_crash_restart_child.py` change** — the spawned worker installs the memory-singleton isolation
  before its heavy imports (`core/workers/curator.py` constructs the memory backend at import time).
* **Four pre-existing suites changed** — each because it pinned the *defective* behavior:
  `test_g4_rev3_sqlite_contract.py` (the canonical fixture now builds the real **WAL** shape; the
  missing-trigger expectation now expects `unknown`; a new test covers the undocumented trigger *mix*),
  `test_g4_indep_trigger_contract.py` (the tampered-schema state is now the explicit `repairable_drift`),
  `test_g4_rev3_search_regression.py` (stale "runtime finding" names/docstrings renamed and the conditional
  assertion de-conditioned), `test_g4_rev3_mutation_atomicity.py` (strict `rank1_status == "pass"` after the
  rejected operation, stale `ke_ad` docstring corrected).

### 2.8 Documentation

* `docs/reports/G4_FTS_REV3_REMEDIATION_REPORT.md` — new **§17** dated addendum (state machine, readiness
  contract, quote-aware SQL, fail-closed auditors, runner ordering, operator-visible changes, the test boundary,
  explicit non-claims); the Amendment 5 delete-path instrument corrected (`SQLITE_DELETE` → `SQLITE_INSERT`).
* `docs/reports/independent-g4-fts/HANDOFF.md` — new **§9** dated superseding addendum.
* `docs/reports/independent-g4-fts/EVIDENCE_NOTE.md` — §5 corrected: measured engines are 3.50.4 / 3.51.3 /
  3.54.1, **3.51.2 was not measured**, and **no FTS inference** is made for the backport builds.
* `KNOWN_ISSUES.md` — dated addendum: DEBT-045 stays OPEN with the `secure_delete`-OFF **erasure caveat**, the
  four production-data incidents, the new boundary and the configuration containment.
* `docs/reports/independent-g4-fts/remediation3/` — new: this file plus deliverables A–H.

---

## 3. Operator-visible behaviour changes

| Change | Where it shows up |
|---|---|
| A DELETE-mode current database becomes repairable | `memory-migrate` → outcome `repaired`; no ledger row is written |
| A pre-commit failure may report `outcome_uncertain` | `MaintenanceReport.outcome`; `verification.transaction_outcome_evidence` |
| A busy checkpoint reports `blocked` | `report.checkpoint["status"]`, `report.checkpoint["truncated"]` |
| A structural ERROR is no longer "corruption" | outcome `failed` instead of `preserved_corrupt` |
| A foreign-key preflight failure stops the migration | outcome `failed`, journal mode untouched |
| Unknown trigger/index configurations are never repaired | outcome `failed`; the unrelated object survives |
| The doctor reports `unavailable` instead of `unreadable` | JSON `migration_state.schema_state` |
| A service connection refuses a drifted journal mode | `MemoryReadinessError(kind="journal_mode_drift")` |

## 4. Deliberately **not** changed

`wal_autocheckpoint` policy · `secure_delete` (still OFF) · the space factor 2.0 estimate · the runtime gate's
version table and provenance rules · the advisory-lock-is-not-fencing disclosure · the quiescence contract · the
canonical DDL · `DEBT-045` · the G4 governance state · every production database, configuration file and
governance record.

## 5. Verification summary

| Run | Result |
| --- | --- |
| New regression suite | **65 passed** |
| Affected set + memory-adjacent (23 suites) | **459 passed**, 0 failed |
| Full repository suite | 22 failed / 2 312 passed / 51 errors — **identical failure and error sets** to the pristine-HEAD clone (the single extra failure is a **pre-existing flaky timing test**, reproduced as flaky in the clone) |
| `tests/test_live_citation_check.py` (excluded from the comparison run) | 36 passed |
| Production data | **unaccessed** — hashes and mtimes unchanged; the boundary makes access impossible |

## 6. Governance statement

**G4 remains OPEN / NOT ACCEPTED. DEBT-045 remains OPEN. Production runtime certification remains NOT READY**
(SQLite 3.50.4 is inside the affected range; Plan R1 is a separate deployment gate). Six findings are
**not fixed** and are listed with their residual risk in `A_FINDINGS_REGISTER.md` and
`F_RESIDUAL_RISK_REGISTER.md` — none is presented as resolved. This document does not constitute an acceptance
decision.

---

# 7. Third round — the W01–W24 work packages (Nov 11, 2026)

This section records the changes made for the consolidated work packages
`W01–W24` (and the historical identifiers they consolidate — see
`A_FINDINGS_REGISTER.md` §2 for the full traceability table).

## 7.1 Ownership and identifier semantics (W01)

`audit_index_contract()` and `audit_trigger_contract()` looked their canonical
object names up with **exact Python string equality**. SQLite compares object
names **ASCII case-insensitively**, so `IDX_KE_LAYER` is the *same name* as
`idx_ke_layer`. The old lookup therefore classified a case-variant collision on
another table as "the canonical index is simply missing" — a **repairable**
state — and the repair would have proceeded on a database that in fact held an
unknown collision.

The ownership lookups are now keyed by the ASCII-lowered name, so a case variant
is recognised as `foreign_owned` (→ `unknown_drift` → refuse) and the unrelated
object is never dropped. The "unknown extra index" scan uses the same
case-insensitive key set.

## 7.2 The complete verification contract (W22) and the digest in the CLI (W13)

`memory-verify` previously reported success when the integrity battery, the
content-row identity and a **schema-hash + row-count** comparison passed. Two
false-success paths followed from that:

* a database whose **synchronization triggers are wrong** still reported success
  (a passing FTS `rank=1` check says nothing about the triggers);
* a **changed content value** with an unchanged row count and schema reported
  "logical invariance: UNCHANGED".

The command now evaluates **eleven named contract requirements**:

| Requirement | Source |
| --- | --- |
| `structural_integrity` | the battery |
| `foreign_keys` | the battery (PASS, or a justified NOT_APPLICABLE) |
| `fts_rank1` | the battery |
| `retrieval_probes` | a **positive** MATCH probe using a real token from the database (an explicit NOT_APPLICABLE justification for an empty database) |
| `fts_configuration` | `read_fts_configuration` |
| `trigger_contract` | `audit_trigger_contract` |
| `index_contract` | `audit_index_contract` (semantic **and** physical) |
| `housekeeping_ledger` | `audit_housekeeping_contract` |
| `content_row_identity` | `verify_content_row_identity` |
| `logical_digest_invariance` | the **full type-aware digest** (every stored value + the hidden-rowid mapping) |
| `all_inspections_completed` | the run itself |

Any `fail`, `unknown` or unavailable result prevents PASS. The command gained a
`--json` channel; in JSON mode **only** the payload is written to stdout, and
the payload, the text verdict and the exit code agree.

## 7.3 Verification protects recovery evidence (W18)

A writable open can consume recovery evidence (a hot rollback journal, or a WAL
whose `-shm` is missing). `memory-verify` now assesses the artifact set
**before** opening the original:

* no at-risk evidence → the original is verified directly;
* at-risk evidence → the raw artifact set is **preserved first** and the
  writable verification runs against a **disposable copy**; the verdict states
  which file it concerns ("a DISPOSABLE COPY — the original's recovery evidence
  was preserved first").

## 7.4 Preservation is triggered by recovery risk, not by sidecars (W15)

Preservation previously ran whenever *any* sidecar existed, so an
already-applied (no-op) migration on a healthy database produced a **full
database copy every time** — uncontrolled disk growth.

Preservation is now triggered by actual risk and its reason/disposition are
recorded separately:

| Reason | Trigger |
| --- | --- |
| `preflight_recovery_snapshot` | a hot rollback journal, or a WAL without its `-shm` (a writable open could consume it) |
| `pre_mutation_snapshot` | the run **will** change the file (the required pre-mutation evidence) |
| `confirmed_corruption_preservation` | a confirmed structural failure |
| `incomplete_preservation` | the copy could not be completed — the run then refuses |

A **no-op** run on a healthy database now creates **no** copy at all, and a
failed pre-mutation preservation refuses the migration instead of proceeding.

## 7.5 The protection boundary covers more entry points and fails closed (W20)

The boundary now also wraps `io.open`, `os.open`, `pathlib.Path.open`,
`os.mkdir`/`os.makedirs` and the `shutil` copy/move/remove helpers; it resolves
**symlink aliases** and recognises **hard-link aliases** by filesystem identity
(`st_dev`, `st_ino`); and the generated `sitecustomize.py` **fails closed** —
previously an import failure in a child was swallowed, letting the child run
unprotected.

The module states plainly what it is: a **Python-level defence-in-depth
control, not an operating-system sandbox**. Where OS-level isolation is
available it is preferred.

## 7.6 The interaction scenarios (Part V §11)

`tests/test_g4_interaction_scenarios.py` adds the twelve required combined
scenarios (A–L): unknown object + missing index; missing trigger + unreadable
ledger; DELETE mode + FK violation; DELETE mode + valid integrity; backup race
+ source change; hot journal + verify; failed post-lock re-read; no-op +
sidecars; `rank=1` passing with invalid triggers; changed content with
unchanged count and schema; production symlink + child import; partial
initialization + a second process.
