# Deliverable C — Regression evidence (commands, environment, counts)

**Environment:** CPython **3.14.3** · bundled SQLite **3.50.4** (affected engine — Deliverable F) ·
Windows x64 · branch `independent/g4-fts-rev3-20261105` @ `739e58c` + the supplied change set.
**Command form:** `python -X utf8 -m pytest <targets> -p no:cacheprovider -q`

## C.1 The new regression suites (this round and the previous one)

```
python -X utf8 -m pytest tests\test_g4_f01_f38_remediation.py tests\test_g4_interaction_scenarios.py -p no:cacheprovider -q
```

**Result: 77 passed** (65 + 12), plus the previous round's `tests/test_g4_revg4_remediation.py`
(61 passed) — **138 new tests** in total, one class per finding group and one test per required
interaction scenario.

| Suite | Tests | Coverage |
| --- | --- | --- |
| `TestF01DoctorNeverWrites` | 5 | F01 |
| `TestF03PostLockReinspectionFailsClosed` | 1 | F03 |
| `TestF05JournalModeRecoveryRoute` | 4 | F05 |
| `TestF06F07F08Backup` | 6 | F04, F06, F07, F08 |
| `TestF12StructuralErrorVersusFail` | 1 | F12 |
| `TestF13F34SqlSemantics` | 18 | F13, F34 |
| `TestF14F33IndexAudit` | 2 | F14, F33 |
| `TestF15ObjectOwnership` | 3 | F15 |
| `TestF16F32LegacyTriggerSets` | 3 | F16, F32 |
| `TestF18F19ForeignKeys` | 2 | F18, F19 |
| `TestF20F35HousekeepingAndFreshness` | 3 | F20, F35 |
| `TestF21UriEncoding` | 6 | F21 |
| `TestF22F23ServiceLifecycle` | 2 | F22, F23 |
| `TestF24ProductionBoundary` | 3 | F24 |
| `TestF27F29F38HonestReporting` | 4 | F27, F29, F38 |
| `TestF35F36F37ClassificationAndLocks` | 2 | F17, F37 |
| `test_g4_interaction_scenarios.py` | 12 | the required combined scenarios A–L |

## C.2 The affected set (G4 gate suites + the corrective suites + memory-adjacent)

```
python -X utf8 -m pytest tests/test_g4_rev3_sqlite_contract.py tests/test_g4_rev3_search_regression.py `
  tests/test_g4_rev3_runtime_gate.py tests/test_g4_rev3_policy_disposition.py `
  tests/test_g4_rev3_mutation_atomicity.py tests/test_g4_rev3_migration_lifecycle.py `
  tests/test_g4_rev3_failure_recovery.py tests/test_g4_indep_trigger_contract.py `
  tests/test_g4_indep_runtime_gate_lower_bound.py tests/test_g4_indep_readonly_diagnostics.py `
  tests/test_g4_indep_post_commit_reporting.py tests/test_g4_indep_conn_lifecycle.py -p no:cacheprovider -q
python -X utf8 -m pytest tests/test_g4_revg4_remediation.py tests/test_g4_f01_f38_remediation.py `
  tests/test_g4_interaction_scenarios.py tests/test_unified_memory.py tests/test_cognitive_memory.py `
  tests/test_memory_vault.py tests/test_orchestrator_memory_migration.py `
  tests/test_k2_2_runtime_migration.py tests/test_k2_2_retrieval_cutover.py `
  tests/test_session4b_memory_hardening.py tests/test_session4c_architecture.py -p no:cacheprovider -q
```

**Result: 138 passed + 333 passed = 471 passed — 0 failed, 0 errors, 0 skipped.**

## C.3 The full repository suite (with the F24/W20 protection active)

```
python -X utf8 -m pytest tests -p no:cacheprovider -q --deselect tests/test_live_citation_check.py
```

`tests/test_live_citation_check.py` is excluded from the comparison run (a slow in-process harness
suite) and is reported separately in C.4. The **exact** result is in C.5.

## C.4 The excluded file

```
python -X utf8 -m pytest tests\test_live_citation_check.py -p no:cacheprovider -q
```

**Result: 36 passed (799.85 s)** — it does not exercise the memory/G4 surface.

## C.5 Comparison with the pristine-HEAD baseline

The baseline is a **git clone of HEAD** (`739e58c`) — a real git checkout with pristine code
(verified free of `_path_precheck`, `audit_index_contract`, `_restate_readonly`,
`KNOWN_LEGACY_TRIGGER_KE_AD`, `MIGRATION_ID_V2`). Both trees were run with the identical command:

```
python -X utf8 -m pytest tests -p no:cacheprovider -q --deselect tests/test_live_citation_check.py
```

| Measurement | Baseline (pristine HEAD) | Working tree (corrected) | Delta |
| --- | ---: | ---: | ---: |
| passed | 2 186 | **2 324** | **+138** (= 61 + 65 + 12 new tests) |
| failed | 21 | 22 | +1 — the flaky timing test (below) |
| errors | 51 | 51 | 0 |
| skipped | 27 | 27 | 0 |
| deselected | 36 | 36 | 0 |
| xfailed | 1 | 1 | 0 |

A set-level comparison of the `FAILED`/`ERROR` lines:

```
=== FAILED: baseline=21 working-tree=22 common=21
--- only in WORKING TREE (1):
    tests/test_b2c_cancellation.py::test_cancelling_one_request_does_not_affect_a_concurrent_request
--- only in BASELINE (0):
=== ERROR: baseline=51 working-tree=51 common=51
--- only in WORKING TREE (0):
--- only in BASELINE (0):
```

**The single difference is a pre-existing flaky test, not a regression.**
`tests/test_b2c_cancellation.py::test_cancelling_one_request_does_not_affect_a_concurrent_request`
is timing-sensitive: five consecutive runs in the working tree gave 3 passes / 2 failures; five
consecutive runs in the **pristine HEAD clone** gave 4 passes / 1 failure. The flake exists at HEAD,
independently of this remediation, and is reported rather than hidden.

**The 21 pre-existing failures** (identical in both trees): Linux seccomp / POSIX process tests on
Windows (`tests/core/sandbox/test_seccomp.py` ×3, `tests/core/sandbox/test_stub_backend.py` ×2),
the three documented Windows path-separator assertions in `tests/test_check_drift.py`, two
`tests/test_ci_test_gate.py` cases, the Windows path/NUL-byte cases in
`tests/test_import_bundle_boundary.py` (×3), the source-generation cases in
`tests/test_module_factory_security.py` (×2), the symlink-privilege cases in
`tests/test_module_paths_direct_child.py` (×5) and the console-encoding case in
`tests/test_live_check_repeat.py`. **The 51 errors** are all in
`tests/test_module_name_containment.py`, which needs the repository's ignored data directories.

### C.5.1 The historical table in the prompt, verified

The prompt's historical comparison is **2 247 passed / 21 failed / 51 errors / 27 skipped /
36 deselected / 1 xfailed** for the working tree against **2 186 / 21 / 51 / 27 / 36 / 1** for the
baseline. Measured on the tree as it stood **before** this round, the working tree measured
**2 247 passed** with the same 21/51/27/36/1 — i.e. the prompt's figure is confirmed, and the
current tree measures **2 324** because this round added **77** further tests (65 + 12) and the
previous round's 126. The 21 failures and 51 errors are unchanged throughout.

### C.5.2 Two pre-existing production-config writes the boundary surfaced

The first full-suite run of the previous round reported **nine** additional cases in
`tests/test_module_factory.py`, `tests/test_module_factory_security.py` and
`tests/test_model_router.py`. The cause was **not** a regression: those tests write to the
**production** `config/settings.toml` / `config/models.toml` (via `core.config.set()` /
`set_module_state()`), which the prevention boundary refuses. The fix is the repository's own
precedent (`tests/test_audit_fixes.py`): `tests/conftest.py` redirects `core.config.CONFIG_DIR` to a
**copy** of the configuration in a temporary directory for every test, so the write lands in the
copy and the repository's configuration is never modified. The nine cases are green again and the
configuration files are unchanged by a test run.

## C.6 The interaction scenarios (Part V §11)

`tests/test_g4_interaction_scenarios.py` — **12 passed**. Each scenario combines the defects and
the safety properties the way an operator would meet them:

| Scenario | Expectation | Result |
| --- | --- | --- |
| A — unknown object + missing index | refusal without mutation | ✅ the unrelated object and its data survive |
| B — missing trigger + unreadable ledger | inspection unavailable; not legacy, not repairable | ✅ `invalid`, not repairable |
| C — current V2 + DELETE mode + FK violation | refusal **before** the journal-mode conversion | ✅ the mode stays `delete` |
| D — current V2 + DELETE mode + valid integrity | WAL-only recovery, no FTS rebuild, no duplicate ledger row | ✅ `repaired`, both skipped, one ledger row |
| E — backup destination race + source change | no destination overwrite; content change detected | ✅ the racer's bytes survive; the digest changes |
| F — hot rollback journal + `memory-verify` | evidence preserved or refused; no unreported recovery | ✅ evidence preserved, verdict scope = copy, journal hash unchanged |
| G — failed post-lock re-read | no stale-state success | ✅ `failed`, `committed` not true |
| H — no-op migration + live sidecars | no uncontrolled full-database copies; sidecars intact | ✅ no preservation copy, the WAL survives |
| I — `rank=1` passes but the triggers are invalid | `memory-verify` fails | ✅ `contract_passed: false`, exit ≠ 0 |
| J — content change with the same count and schema | digest mismatch | ✅ the digest changes |
| K — production symlink + child import | the child is blocked | ✅ no access |
| L — partial initialization + a second process | never accepted as current | ✅ not `current`; the second init fails loudly |

## C.7 Historical evidence — reconciled, not restated

* The **246-test** record of the first workstream stays the pre-correction measurement; it is not
  restated as if it covered the current source.
* **59 vs 61 vs 65 vs 12:** the four suites are counted separately, per file and per class:
  `test_g4_revg4_remediation.py` (61 functions), `test_g4_f01_f38_remediation.py` (65),
  `test_g4_interaction_scenarios.py` (12). Parametrized cases are reported separately from test
  functions.
* **Stage-1 (15 scenarios) vs Stage-2 (10 probes):** mapped explicitly in
  `remediation2/B_REPRODUCTION_EVIDENCE.md`.
* The **historical production-data contamination is not denied**: four paths are documented, the
  polluted vault file still holds three duplicate test-entry pairs, and it was **not** rewritten.
