# Deliverable C — Regression evidence (commands, environment, counts)

**Environment:** CPython **3.14.3** · bundled SQLite **3.50.4** (affected engine — Deliverable F) ·
Windows x64 · branch `independent/g4-fts-rev3-20261105` @ `739e58c` + the supplied change set.
**Command form:** `python -X utf8 -m pytest <targets> -p no:cacheprovider -q`

## C.1 The new regression suite

```
python -X utf8 -m pytest tests\test_g4_f01_f38_remediation.py -p no:cacheprovider -q
```

**Result: 65 passed.** One class per finding group:

| Class | Tests | Findings |
| --- | --- | --- |
| `TestF01DoctorNeverWrites` | 5 | F01 |
| `TestF03PostLockReinspectionFailsClosed` | 1 | F03 |
| `TestF05JournalModeRecoveryRoute` | 4 | F05 (incl. the unsupported-DB counter-case) |
| `TestF06F07F08Backup` | 6 | F06, F07, F08, F04 |
| `TestF12StructuralErrorVersusFail` | 1 | F12 |
| `TestF13F34SqlSemantics` | 18 | F13, F34 |
| `TestF14F33IndexAudit` | 2 | F14, F33 |
| `TestF15ObjectOwnership` | 3 | F15 |
| `TestF16F32LegacyTriggerSets` | 3 | F16, F32 |
| `TestF18F19ForeignKeys` | 2 | F18, F19 |
| `TestF20F35HousekeepingAndFreshness` | 3 | F20, F35 |
| `TestF21UriEncoding` | 6 | F21 |
| `TestF22F23ServiceLifecycle` | 2 | F22, F23 |
| `TestF24ProductionBoundary` | 3 | F24 |
| `TestF27F29F38HonestReporting` | 4 | F27, F29, F38 |
| `TestF35F36F37ClassificationAndLocks` | 2 | F17, F37 |

## C.2 The affected set (G4 gate suites + the corrective suites + memory-adjacent)

```
python -X utf8 -m pytest `
  tests\test_g4_rev3_sqlite_contract.py tests\test_g4_rev3_search_regression.py `
  tests\test_g4_rev3_runtime_gate.py tests\test_g4_rev3_policy_disposition.py `
  tests\test_g4_rev3_mutation_atomicity.py tests\test_g4_rev3_migration_lifecycle.py `
  tests\test_g4_rev3_failure_recovery.py tests\test_g4_indep_trigger_contract.py `
  tests\test_g4_indep_runtime_gate_lower_bound.py tests\test_g4_indep_readonly_diagnostics.py `
  tests\test_g4_indep_post_commit_reporting.py tests\test_g4_indep_conn_lifecycle.py `
  tests\test_g4_revg4_remediation.py tests\test_g4_f01_f38_remediation.py `
  tests\test_unified_memory.py tests\test_cognitive_memory.py tests\test_memory_vault.py `
  tests\test_orchestrator_memory_migration.py tests\test_k2_2_runtime_migration.py `
  tests\test_k2_2_retrieval_cutover.py tests\test_session4b_memory_hardening.py `
  tests\test_session4c_architecture.py -p no:cacheprovider -q
```

**Result: 459 passed — 0 failed, 0 errors, 0 skipped (157.91 s).**

## C.3 The full repository suite (with the F24 protection active)

```
python -X utf8 -m pytest tests -p no:cacheprovider -q --deselect tests/test_live_citation_check.py
```

`tests/test_live_citation_check.py` is excluded from the comparison run (it is a slow
in-process harness suite — 13 min 20 s on this machine) and is reported separately in
C.4. The **exact** result is in §C.5.

## C.4 The excluded file

```
python -X utf8 -m pytest tests\test_live_citation_check.py -p no:cacheprovider -q
```

**Result: 36 passed (799.85 s)** — it does not exercise the memory/G4 surface.

## C.5 Comparison with the pristine baseline

The baseline is a **git clone of HEAD** (`739e58c`) into a scratch directory — a real
git checkout containing pristine code (verified free of `_path_precheck`,
`audit_index_contract`, `_restate_readonly`, `KNOWN_LEGACY_TRIGGER_KE_AD`,
`MIGRATION_ID_V2`). Both trees were run with the identical command
(`pytest tests -q --deselect tests/test_live_citation_check.py`).

| | baseline (pristine HEAD) | working tree (corrected) | delta |
| --- | ---: | ---: | ---: |
| passed | 2 186 | **2 312** | **+126** (the 61 + 65 new tests) |
| failed | 21 | 22 | +1 — the flaky timing test (see below) |
| errors | 51 | 51 | 0 |
| skipped / deselected / xfailed | 27 / 36 / 1 | 27 / 36 / 1 | 0 |

A set-level comparison of the `FAILED`/`ERROR` lines:

```
=== FAILED: baseline=21 working-tree=22 common=21
--- only in WORKING TREE (1):
    tests/test_b2c_cancellation.py::test_cancelling_one_request_does_not_affect_a_concurrent_request
--- only in BASELINE (0):
=== ERROR: baseline=51 working-tree=51 common=51
--- only in WORKING TREE (0):
--- only in BASELINE (0):
```

**The single difference is a pre-existing flaky test, not a regression.**
`tests/test_b2c_cancellation.py::test_cancelling_one_request_does_not_affect_a_concurrent_request`
is timing-sensitive. Five consecutive runs in the working tree: 3 passed / 2 failed;
five consecutive runs in the **pristine HEAD clone**: 4 passed / 1 failed. The flake
exists at HEAD, independently of this remediation, and is reported rather than hidden.

**The 21 pre-existing failures** (identical in both trees): Linux seccomp / POSIX
process tests on Windows (`tests/core/sandbox/test_seccomp.py` ×3,
`tests/core/sandbox/test_stub_backend.py` ×2), the three documented Windows
path-separator assertions in `tests/test_check_drift.py`, two `tests/test_ci_test_gate.py`
cases, the Windows path/NUL-byte cases in `tests/test_import_bundle_boundary.py` (×3),
the source-generation cases in `tests/test_module_factory_security.py` (×2), the
symlink-privilege cases in `tests/test_module_paths_direct_child.py` (×5), and the
console-encoding case in `tests/test_live_check_repeat.py`. **The 51 errors** are all in
`tests/test_module_name_containment.py`, which needs the repository's ignored data
directories.

### C.5.1 Two pre-existing production-config writes the boundary surfaced

The first full-suite run of this pass reported **nine** additional cases in
`tests/test_module_factory.py`, `tests/test_module_factory_security.py` and
`tests/test_model_router.py`. The cause was **not** a regression: those tests write to
the **production** `config/settings.toml` / `config/models.toml` (via
`core.config.set()` / `set_module_state()`), which the new prevention boundary
refuses. The fix is the repository's own precedent (`tests/test_audit_fixes.py`):
`tests/conftest.py` now redirects `core.config.CONFIG_DIR` to a **copy** of the
configuration in a temporary directory for every test, so the write lands in the copy
and the repository's configuration is never modified. The nine cases are green again
and the configuration files are unchanged by a test run.

## C.6 Historical evidence — reconciled, not restated

* The **246-test** record of the previous workstream (`evidence/independent-fix/
  verification/full_run_246.txt`) was measured on the pre-correction tree and is
  **preserved as history**; it is not a substitute for the numbers above.
* **59 vs 61 vs 65:** `tests/test_g4_revg4_remediation.py` contains **61** test
  *functions* (the previous pass's suite) and `tests/test_g4_f01_f38_remediation.py`
  contains **65** more; the parametrized cases are counted separately (the previous
  report's "59" was a function-vs-case count). The numbers are now stated per file and
  per class.
* **Stage-1 (15 scenarios) vs Stage-2 (10 probes):** Stage 1 reproduced the eight
  REV-G4 findings with 15 scenarios (several findings needed more than one scenario);
  Stage 2 re-measures the same defect scenarios and reports 10 — one per finding
  family. The mapping is explicit in `remediation2/B_REPRODUCTION_EVIDENCE.md`.
* The **historical production-data contamination is not denied**: four paths are
  documented (memory singleton, cognitive vault, graph database, spawned worker), the
  production vault file still holds three duplicate test-entry pairs, and it was
  **not** rewritten by this work.

## C.6 Historical evidence — reconciled, not restated

* The **246-test** record of the previous workstream (`evidence/independent-fix/
  verification/full_run_246.txt`) was measured on the pre-correction tree and is
  **preserved as history**; it is not a substitute for the numbers above.
* **59 vs 61 vs 65:** `tests/test_g4_revg4_remediation.py` contains **61** test
  *functions* (the previous pass's suite) and `tests/test_g4_f01_f38_remediation.py`
  contains **65** more. The 59/61 discrepancy in the previous report was a
  function-vs-case count (two of the 61 are parametrized); the counts are now stated
  per file and per class, and the parametrized cases are reported separately.
* **Stage-1 (15 scenarios) vs Stage-2 (10 scenarios):** the Stage-1 probe reproduced
  the eight REV-G4 findings with 15 scenarios (several findings needed more than one
  scenario); the Stage-2 post-fix probe re-measures the same defect scenarios and
  reports 10 — one per finding family. The mapping is in
  `remediation2/B_REPRODUCTION_EVIDENCE.md` (Stage-2 section), which lists each
  Stage-2 scenario against the Stage-1 artifacts it corresponds to.
* The **historical production-data contamination is not denied**: the previous pass
  documented three incidents (the memory singleton, the cognitive vault, the graph
  database) and the spawned-worker incident; the production vault file
  (`.data/memory/cognitive/vault_v4.json`) still contains the three duplicate test
  pairs and was **not** rewritten by this work.
