# Deliverable D — Regression test suite (REV-G4-01 … REV-G4-08)

**File:** `tests/test_g4_revg4_remediation.py` — **61 tests**, 8 classes + 2 sub-finding tests
**Added:** Nov 10, 2026 (uncommitted)

## Design rules honored by every test in this file

* **Isolation:** every database is a `tmp_path` fixture; the production `.data/memory/unified.db` is never opened. The conftest guard (`REV-G4-07.D`) independently **fails** any test that changes a file under `.data/memory`.
* **Real state, not just return values:** filesystem facts (existence, size, SHA-256) of the main file and of `-wal`/`-shm`/`-journal` are asserted wherever a mutation could occur.
* **Crash fixtures are real:** where a hot journal or an uncheckpointed WAL is needed, a **child process** is killed with `os._exit(1)` — never simulated by deleting a file.
* **No production certification:** `OCBRAIN_MEMORY_RUNTIME_ACK=acknowledge` (set by the conftest) is the documented **test-environment-only** mechanism; it never appears in an assertion about certification.

## The classes

| Class | Tests | Covers |
| --- | --- | --- |
| `TestRevg401DoctorInspectionReadOnly` | 5 | no write-capable fallback for inspection; `memory-doctor` leaves a WAL database with a committed uncheckpointed transaction untouched; the inventory is read-only and reports its read-only-ness; an uninspectable WAL (`-wal` without `-shm`) is reported **UNAVAILABLE** and nothing is touched; `memory-verify` keeps the writable `rank=1` path and **proves** non-mutation. |
| `TestRevg402MigrationPreflightOrdering` | 11 | an unsupported DELETE-mode database is refused with **no** mutation; missing / zero-byte / invalid-header / directory targets are refused; the lock is released on refusal; the state is re-read after the lock; a recognized V1 legacy database **still migrates**; injected faults at the `pre_flight` / `lock` boundaries leave nothing behind. |
| `TestRevg403IndexDriftRepair` | 16 | **each** canonical index, dropped → repaired (not `already_applied`); several dropped at once; a same-name wrong-definition index fails readiness and is repaired; wrong sort order / lost partial predicate / wrong uniqueness are detected; the column-order semantics of the parser; an unknown extra index is **refused, never dropped**; an unknown trigger is **refused, never dropped**; an index-only repair **skips the FTS rebuild**; ledger identity + idempotency after a repair; the **final readiness gate blocks the commit** (the ledger row and the repair are rolled back). |
| `TestRevg404MissingPaths` | 7 | the space estimate never creates a missing file; the runner never creates a missing file (nor a missing parent directory); a directory target is refused; a truncated file is refused; the `memory-verify` refusal text no longer claims the migration can create/migrate; a current database stays `already_applied` **and untouched**; a valid legacy database still migrates. |
| `TestRevg405BackupSafety` | 6 | a missing source is never created; a non-current source is refused; an existing destination is never overwritten; an alias/same-file destination is refused; a successful backup is verified (structural, `rank=1`, identity mapping, schema equality) and leaves the source intact; a verification failure removes **only** the operation's temporary artifact. |
| `TestRevg406Preservation` | 5 | all four artifacts are preserved with a verified manifest; the originals are retained; two preservations never share a destination; a copy failure **fails closed**; the hot-journal case proves the **original** journal bytes are in the manifest and the original file is untouched. |
| `TestRevg407LifecycleIsolation` | 5 | the failed-validation path leaves **no** open handle (the file can be deleted — the pre-fix `PermissionError [WinError 32]` is gone); a delete-mode current database is **refused and not converted**; the memory singleton resolves into the isolated prefix (and repeated calls return the same instance); the **graph engine** singleton (the third production-default singleton) is redirected too; the guard's fingerprint detects a **same-size** modification (the blind spot that let the production `graph.db` be written unnoticed). |
| `TestRevg408CliTruthfulness` | 5 | a missing database is reported `unavailable`, not a pass; a corrupt database never claims a pass; an incomplete battery exits non-zero and says "NOT a verified result"; the text output mentions UNAVAILABLE; **three consecutive in-process CLI invocations** work (the REV-G4-08.B sub-finding). |

## The read-only invariant helper

`assert_readonly_invariants(before, after)` encodes the measured facts (Deliverable B):

* the main image and any rollback journal must be **byte-identical**;
* an existing `-wal` must keep its **exact bytes** (no frame consumed); a `-wal` that did not exist may appear only as a **0-byte** empty artifact;
* `-shm` is coordination scaffolding: it may change.

A read-write open — the pre-fix behavior — fails these invariants, because closing the last read-write connection checkpoints the WAL and rewrites the main image.

## How to run

```powershell
python -X utf8 -m pytest tests\test_g4_revg4_remediation.py -p no:cacheprovider -q
```

Expected: **61 passed**.

## Failing-on-the-defective-implementation claim

Every test in this file was written against the **corrected** behavior and was observed to **fail** against the defective implementation (the pre-fix behavior is reproduced and documented in Deliverable B). Two examples of the shape of these failures:

* `test_doctor_wal_uncheckpointed_commit_untouched` fails pre-fix because the doctor's close-time checkpoint consumed the WAL frames (`before != after`).
* `test_each_dropped_index_repaired_not_already_applied` fails pre-fix because the runner answered `already_applied` and repaired nothing while readiness refused the same database.
