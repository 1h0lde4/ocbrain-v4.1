# Deliverable C — Correction record (file-by-file)

**Date:** Nov 10, 2026 · **Base:** HEAD `739e58c` (branch `independent/g4-fts-rev3-20261105`)
**State:** every change below is **local and uncommitted**. No branch, commit, staging, push, PR, merge or rebase was performed; no issue was closed; no governance state changed.

## 1. Production code

### `core/memory/sqlite_contract.py` (+72)

* **New `parse_create_index(sql)`** — parses a `CREATE [UNIQUE] INDEX` definition into semantic parts: name, target table, uniqueness, the **ordered** column list with per-column collation and ASC/DESC direction, and a normalized `WHERE` predicate. Comma splitting is depth-aware (nested parentheses and quoted literals are respected). Required by REV-G4-03: a same-name index is **not** proof of a canonical definition.

### `core/memory/sqlite_integrity.py` (+149 / −)

* **New `audit_index_contract(conn)`** — semantic comparison of every canonical index against `CANONICAL_INDEX_DDL`, cross-checked against SQLite's own `PRAGMA index_list` uniqueness flag. Per-index classification `canonical` / `missing` / `wrong_definition` / `unparseable`, plus `unknown_extra`; aggregate `canonical` / `repairable_drift` / `unknown_drift`.
* **`validate_readiness()`** — the "supporting indexes" check now uses the semantic audit and **fails** with the specific reason (missing / wrong definition / unparseable / unknown extra); a new **WAL journal-mode invariant** check was added (a current database that is not in WAL mode fails readiness — REV-G4-07.B); the report gains `summary["journal_mode"]` and `summary["index_contract"]`.

### `core/memory/sqlite_migration.py` (+882 / −)

* **New `_path_precheck(db_path)`** — non-creating filesystem validation (missing / not a regular file / unreadable / zero-byte / invalid SQLite header). Used by the runner and by the backup helper (REV-G4-02/04/05).
* **New `_preserve_recoverable_state(db_path, reason)`** and **`sha256_file(path)`** — raw, byte-verified preservation of the main file **and `-wal`, `-shm`, `-journal`** into a unique directory, originals retained, `manifest.json` written, copy failures raised (fail closed) (REV-G4-06).
* **New `_repair_scope_for_state(state)`** and **`_restate_readonly(db_path)`** — the explicit repair scope the runner may execute, and the read-only post-lock re-read (Amendment 2 §E).
* **`estimate_migration_space()`** — now opens `mode=ro` and never creates a missing file; an unusable target is an `error` result (REV-G4-04).
* **`collect_checkpoint_inventory()`** — filesystem facts for **all four** artifacts without a writable connection; connection facts come from a read-only connection; an uninspectable state is reported as **`unavailable`** (REV-G4-01).
* **`inspect_migration_state()`** — `current` now requires the **index contract** to verify; drift is classified as *repairable* only for the two explicitly recognized shapes; everything else is **not repairable** and fails closed with the reason spelled out; `absent` is explicitly **not** a migration target (REV-G4-03/04).
* **`create_online_backup()`** — fully rebuilt: source precheck + "must be a current memory database" + read-only source (no writable fallback) + WAL/`-shm` guard; destination existence / alias / same-file refusal; unique temporary file; verification battery (integrity, FK, `rank=1`, schema equality, identity mapping) **before** publication; atomic non-overwriting rename; failures remove only this operation's temporary artifact; the established result contract (`ok`, `method`, `note`, `identity_preserved`, `identities_compared`) is preserved (REV-G4-05).
* **`run_maintenance_migration()`** — **reordered** (see Deliverable A, REV-G4-02): path precheck → advisory lock → raw recovery-evidence preservation → read-only space estimate → read-only inspection + pre-integrity → classification (refuse unsupported/absent) → only then `journal_mode=WAL` + `BEGIN IMMEDIATE` → in-transaction re-read → scoped apply → verification → ledger → **final readiness gate** → commit → checkpoint. The step names `pre_integrity_check`, `pre_foreign_key_check`, `re_read_migration_state`, `replace_triggers`, `ensure_indexes`, `fts_rebuild`, `verification`, `record_migration`, `final_readiness`, `commit` are preserved; `fts_rebuild` is **skipped** for an index-only repair; unknown trigger/index definitions abort the migration instead of being dropped.

### `core/memory/backends/sqlite_storage.py` (+16 / −)

* The fresh-init inspection connection now has an **explicit `closing()`** context (the only unclosed connection in the file — REV-G4-07.A).
* `_connect()` documents that its `PRAGMA journal_mode=WAL` **states** the mode the database already has (established by fresh initialization or the maintenance migration) and is never an unreviewed silent conversion (REV-G4-07.C).

### `interface/cli.py` (+207 / −)

* **New `_open_inspection_connection()`** — strictly read-only (`mode=ro`), **fails closed** with no writable fallback; used by `memory-doctor` (REV-G4-01).
* `_open_verify_connection()` is now reserved for `memory-verify` (which genuinely needs write access for the FTS `rank=1` command) and documents why.
* `memory-doctor` — rewritten: WAL/`-shm` uninspectable states are reported as **UNAVAILABLE**; an inspection that could not run yields `"schema_state": "unavailable"` and `readiness: null` (never a silent pass); the text output says *"NOT EVALUATED — this is not a pass"*; the `--json` channel is emitted with **`click.echo`** (byte-exact, parseable JSON) (REV-G4-01/08).
* `memory-verify` — the refusal text no longer claims the migration can "create/migrate" a database; the writable connection's non-mutation claim is now **measured** (logical facts before/after, reported as `UNCHANGED`/`CHANGED`); an incomplete battery is reported as **"NOT a verified result"** and exits non-zero (REV-G4-04/08).
* `SubcommandFirstGroup.parse_args()` — the group's parameter list is now restored **completely** after a subcommand-first parse (REV-G4-08.B).

## 2. Tests

| File | Change |
| --- | --- |
| `tests/test_g4_revg4_remediation.py` | **NEW** — 59 regression tests, one class per finding (Deliverable D). |
| `tests/conftest.py` | **All three** production-default singletons redirected to isolated temp directories at conftest import time (memory `get_unified_memory`, `cognitive_vault`, `graph_engine`); **autouse guard** that fails any test changing a file under `.data/memory`, fingerprinting **(size, mtime_ns)** so a same-size write cannot pass unnoticed; the test-env-only `OCBRAIN_MEMORY_RUNTIME_ACK` and the `enforce_runtime_gate` fixture are unchanged (REV-G4-07.D). |
| `tests/test_g4_rev3_sqlite_contract.py` | `_canonical_db()` now builds the **WAL** canonical shape (the old DELETE-mode fixture pinned the defect REV-G4-07.B corrected). |
| `tests/test_g4_indep_trigger_contract.py` | `_apply_canonical_schema()` now sets `PRAGMA journal_mode=WAL` (same fixture correction). |
| `tests/test_g4_rev3_search_regression.py` | stale "runtime finding" module/class docstrings rewritten; the direct-surface deletion assertion **de-conditioned** (`== []` on every runtime); the stale test/class names renamed (the anomaly follows the pre-fix V1 trigger, not the runtime). |
| `tests/test_g4_rev3_mutation_atomicity.py` | strict `rank1_status == "pass"` after the **rejected** operation (and after the successful delete — the "or error" escape hatch removed); the stale `ke_ad` class docstring corrected to the `'delete'`-command INSERT shape. |
| `tests/_crash_restart_child.py` | the child-process helper now installs the **memory-singleton isolation before its heavy imports**: `core/workers/curator.py` constructs the memory backend **at import time** with the default production prefix, so the spawned worker used to open the **production** `unified.db` (read-only, for the readiness inspection) and leave a `-shm` artifact in the production directory. The new REV-G4-07.D guard caught exactly that (it is how the third production-writing path was found). |

## 3. Documentation

| File | Change |
| --- | --- |
| `docs/reports/G4_FTS_REV3_REMEDIATION_REPORT.md` | new **§16 dated addendum** (the full corrective record); the Amendment 5 delete-path instrument corrected (`SQLITE_DELETE` → `SQLITE_INSERT`) with a dated pointer; dated correction pointers added to §0, RF-1, RF-2, §4 (backup), the Gate 4A / Gate 6A rows and the acceptance section. The Nov 5 text is **not** rewritten — it remains the historical record. |
| `docs/reports/independent-g4-fts/EVIDENCE_NOTE.md` | §5 corrected: the measured engines are **3.50.4 / 3.51.3 / 3.54.1**; **3.51.2 was NOT measured**; **no FTS inference** is made for the backport builds (never downloaded/executed). The overreaching original sentences are quoted and withdrawn rather than silently rewritten. |
| `docs/reports/independent-g4-fts/HANDOFF.md` | new **§8 dated superseding addendum** (findings, dispositions, tests, runtime blocker, renames, production-data disclosure) plus a pointer at the top. §1–§7 — including the 246-test record — are preserved unchanged. |
| `KNOWN_ISSUES.md` | new **dated addendum**: DEBT-045 stays OPEN with its scope restated; a new recorded caveat that `secure_delete` OFF means a DELETE does **not** erase the content from the database file (nor from backups or forensic copies) — recorded, **not** changed; the test-isolation incidents disclosed. |
| `docs/reports/independent-g4-fts/remediation2/` | **NEW** — Deliverables A–G + the Stage-1 (defects) and Stage-2 (post-fix) evidence trees. |
| `scripts/g4_indep/probe_revg4_stage1_repro.py` | **NEW** — the Stage-1 reproduction probe (15 scenarios; every finding reproduced against the shipped code). |
| `scripts/g4_indep/probe_revg4_stage2_postfix.py` | **NEW** — the Stage-2 post-fix probe (10 scenarios; the same defects re-measured against the corrected code — **10/10 confirm the defect is gone**). Writes to `evidence/postfix/`; the Stage-1 artifacts are never overwritten. |

## 4. Files touched by the **test runs** (not by the remediation)

Running the suite rewrites two **tracked** chroma fixture databases and the **tracked** `tests/core/cognitive/__pycache__/*.pyc` build artifacts. These are test-run side effects, not part of the remediation; they are restored to their HEAD state so that the verification package's diff contains only intentional changes (restoration = narrow, path-specific `git checkout --`; **no** `git clean`, **no** `git reset --hard`, **no** `git add -A`).

## 5. Explicitly unchanged

`wal_autocheckpoint` policy · `secure_delete` (stays OFF) · the space factor 2.0 estimate and its contractual basis string · the runtime gate's version table and provenance rules · the advisory lock (still advisory, **not** fencing) · the per-database ledger model · the canonical DDL (the `ke_ad` `'delete'`-command form from the earlier workstream is preserved) · every operator-facing exit code that was already honest.
