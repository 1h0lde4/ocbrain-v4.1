# Deliverable E — Test execution evidence (Nov 10, 2026)

**Environment:** CPython **3.14.3** · bundled SQLite **3.50.4** (an **affected** engine — see Deliverable F) · Windows x64
**Working tree:** `C:\Users\Produ\Downloads\ocbrain-g4-indep\wt` · branch `independent/g4-fts-rev3-20261105` @ `739e58c` · **all corrections uncommitted**
**Command form used throughout:** `python -X utf8 -m pytest <targets> -p no:cacheprovider -q`

## 1. The three runs, and what each one is for

The task asked for **three distinct results** — they are deliberately not the same measurement:

| # | Run | What it establishes |
| --- | --- | --- |
| **A** | the **affected set** (the G4/Rev3 gate suites + the new corrective suite) **plus** the memory-adjacent out-of-set suites | that the corrections did not break the workstream they belong to, and that the new findings are fixed and covered |
| **B** | the **full repository suite** in the working tree | blast radius across the whole repository |
| **C** | the **same full repository suite** in a **pristine HEAD checkout** (a `git clone` of HEAD into a scratch directory — a real git checkout containing pristine code) | which failures are **pre-existing** and which are **introduced** — the comparison that makes B interpretable |

## 2. Run A — affected set + memory-adjacent out-of-set set (with the corrected conftest)

```
python -X utf8 -m pytest `
  tests\test_g4_rev3_sqlite_contract.py tests\test_g4_rev3_search_regression.py `
  tests\test_g4_rev3_runtime_gate.py tests\test_g4_rev3_policy_disposition.py `
  tests\test_g4_rev3_mutation_atomicity.py tests\test_g4_rev3_migration_lifecycle.py `
  tests\test_g4_rev3_failure_recovery.py tests\test_g4_indep_trigger_contract.py `
  tests\test_g4_indep_runtime_gate_lower_bound.py tests\test_g4_indep_readonly_diagnostics.py `
  tests\test_g4_indep_post_commit_reporting.py tests\test_g4_indep_conn_lifecycle.py `
  tests\test_g4_revg4_remediation.py tests\test_unified_memory.py tests\test_cognitive_memory.py `
  tests\test_memory_vault.py tests\test_orchestrator_memory_migration.py `
  tests\test_k2_2_runtime_migration.py tests\test_k2_2_retrieval_cutover.py `
  tests\test_session4b_memory_hardening.py tests\test_session4c_architecture.py `
  -p no:cacheprovider -q
```

**Result: `393 passed` — 0 failed, 0 errors, 0 skipped (exit code 0), 162.75 s.**

This set contains the **61 new corrective tests** and every pre-existing suite the Rev 3 workstream owns or depends on.

### Run A2 — the new corrective suite alone

```
python -X utf8 -m pytest tests\test_g4_revg4_remediation.py -p no:cacheprovider -q
```

**Result: `61 passed`** (8 classes, one per finding; 2 further tests for the CLI sub-finding and the guard's same-size blind spot).

### Run A3 — the earlier (pre-correction) state of the same set, for the record

Before the corrections, the same 21-file set reported **391 passed + 1 error**, where the error was the **new REV-G4-07.D production-access guard firing**: `tests/test_cognitive_memory.py::test_cognitive_storage_and_provenance` had written through the module-level `cognitive_vault` singleton into `.data/memory/cognitive/vault_v4.json` (1723 → 2583 bytes). After the redirect, the same set is clean (Run A).

## 3. Run B — full repository suite (working tree)

```
python -X utf8 -m pytest tests -p no:cacheprovider -q --deselect tests/test_live_citation_check.py
```

`tests/test_live_citation_check.py` is excluded from the comparison run and handled **separately** (Run B2) because it is a slow in-process harness suite (**13 min 20 s** for 36 tests on this machine) that does not exercise the memory/G4 surface at all.

**Result: `21 failed, 2247 passed, 27 skipped, 36 deselected, 1 xfailed, 51 errors` (359.22 s).**

## 4. Run C — full repository suite in a pristine HEAD checkout (baseline)

The baseline is a **git clone** of HEAD (`739e58c`) into a scratch directory — a real git checkout (so tests that require one do not skip) containing pristine code (verified: no `_path_precheck`, no `_preserve_recoverable_state`, no new test file):

```powershell
git clone --no-hardlinks "C:\Users\Produ\Downloads\ocbrain-g4-indep\wt" "$env:TEMP\g4_head_clone"
# in the clone:
python -X utf8 -m pytest tests -p no:cacheprovider -q --deselect tests/test_live_citation_check.py
```

**Result: `21 failed, 2186 passed, 27 skipped, 36 deselected, 1 xfailed, 51 errors` (361.90 s).**

### 4.1 The comparison — the decisive result

| | baseline (pristine HEAD) | working tree (corrected) |
| --- | --- | --- |
| failed | 21 | **21** |
| passed | 2186 | **2247** (+61 = the new corrective suite) |
| errors | 51 | **51** |
| skipped / deselected / xfailed | 27 / 36 / 1 | 27 / 36 / 1 |

A set-level comparison of the two runs' `FAILED`/`ERROR` lines:

```
=== FAILED: baseline=21 working-tree=21 common=21
--- only in WORKING TREE (0):
--- only in BASELINE (0):
=== ERROR: baseline=51 working-tree=51 common=51
--- only in WORKING TREE (0):
--- only in BASELINE (0):
```

**The failure and error sets are identical — zero regressions introduced by the corrective remediation.** The only difference is the **+61 passing tests** (the new corrective suite).

### 4.2 What the 21 pre-existing failures are (all present at HEAD, none touched by this pass)

| Failure(s) | Classification |
| --- | --- |
| `tests/core/sandbox/test_seccomp.py` ×3, `tests/core/sandbox/test_stub_backend.py` ×2 | **environment** — Linux seccomp / POSIX process APIs on Windows |
| `tests/test_check_drift.py` ×3 | **pre-existing Windows path-separator assertions** (`core\cognitive\other.py` vs `core/cognitive/other.py`) — the failures the previous workstream already recorded; the file is byte-identical to base and was **not** touched here |
| `tests/test_ci_test_gate.py` ×2 | **pre-existing** (the same file fails at HEAD) |
| `tests/test_import_bundle_boundary.py` ×3, `tests/test_module_factory_security.py` ×2, `tests/test_module_paths_direct_child.py` ×5 | **pre-existing** — Windows path/NUL-byte and symlink-privilege behaviour (verified: the pristine clone fails the identical set) |
| `tests/test_live_check_repeat.py::test_real_worker_in_offline_mode_is_isolated_end_to_end` | **pre-existing** — a Windows console-encoding bug in the test harness (`UnicodeDecodeError: 'utf-8' codec can't decode byte 0x97`); reproduced in the pristine clone. It was **skipped** in the earlier zip-extracted baseline (no `.git` → the test skips when it is not a git checkout), which is why the clone was used for the final comparison. |

The **51 errors** are all in `tests/test_module_name_containment.py` (the sinks need the repository's ignored `data/` directories) and are identical in both runs.

### 4.3 Two failures that appeared mid-pass and were **diagnosed and closed** — not hidden

During the first full-suite attempts, three additional failures appeared that the pristine clone did **not** show. Both were diagnosed to the last cause:

1. **`tests/test_workflow_crash_restart_subprocess.py`** — the guard caught the real cause: the **spawned child process** transitively imported `core/workers/curator.py`, which constructs the memory backend **at import time** with the default production prefix, so the child opened the **production** `unified.db` (read-only, for the readiness inspection) and left `-wal`/`-shm` artifacts in the production directory. **Fixed** by isolating the memory singleton in the child helper *before* its heavy imports — the test now passes and the production directory is untouched.
2. **`tests/test_live_check_repeat.py::test_real_worker_in_offline_mode_is_isolated_end_to_end`** — a **pre-existing** Windows console-encoding failure, reproduced in the pristine clone (the earlier zip baseline had skipped it).
3. **`tests/test_b2c_cancellation.py::test_cancelling_one_request_does_not_affect_a_concurrent_request`** — a **timing-sensitive** test that passes in isolation in both trees; it appeared once under heavy parallel load and is absent from both final runs.

### 4.4 A pre-existing test-suite side effect on **production configuration** (disclosed, not introduced here)

A full-suite run rewrites `config/settings.toml`, `config/models.toml` and `config/sources.toml`: the config manager persists the settings it loaded, and a TOML round-trip **drops comments and normalizes dashes** (the em-dashes in the `[memory] wal_gate_mode` documentation become hyphens). The values are unchanged — the rewrite is functionally equivalent — but the explanatory comments in a **production configuration file** are lost.

This is **pre-existing and not introduced by this pass**: the pristine HEAD clone shows the **identical** rewrite (same diffstat: 101 insertions / 133 deletions across the three files). It was found while restoring the test-run byproducts and is **disclosed rather than silently fixed** — changing the config manager's flush semantics is an operator-visible behavior change and is outside this remediation's mandate. The three files were restored to their HEAD content for the verification package.

The same class of test-run byproduct (tracked files rewritten by test runs, restored to HEAD for the package): `modules/**/knowledge.db/chroma.sqlite3` and the chroma index files under `modules/mock/knowledge.db/`. Two **untracked** directories — `modules/test_rce001_name_tmp/` and `modules/test_rce001_tmp/` — are created by a test and are present in the pristine clone as well; they were **left in place** (deleting untracked files is out of bounds).

## 5. Run B2 — the excluded network/harness-bound file

```
python -X utf8 -m pytest tests\test_live_citation_check.py -p no:cacheprovider -q
```

**Result: `36 passed` (799.85 s).** The file is a self-contained harness suite (scripted stand-in model, `--dry-run`); it is slow on this machine and does not touch the memory/G4 surface.

## 6. How to reproduce every number in this document

```powershell
# A  (affected + out-of-set)  -> 393 passed
# A2 (new suite)                -> 61 passed
# B  (full suite)               -> see §3.1
# C  (baseline)                 -> see §4
# B2 (excluded file)            -> 36 passed
```

No command in this document points at `.data/memory/unified.db` (or `archive.db` / `graph.db`); every fixture is a temporary database.
