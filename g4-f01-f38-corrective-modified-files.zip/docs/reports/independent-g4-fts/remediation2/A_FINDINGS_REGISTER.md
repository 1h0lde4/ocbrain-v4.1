# Deliverable A — Findings register (REV-G4-01 … REV-G4-08 + 08.B)

**Workstream:** corrective remediation of the independent G4–FTS Rev 3 workstream
**Date:** Nov 10, 2026
**Branch / HEAD:** `independent/g4-fts-rev3-20261105` @ `739e58c` — **all corrections are local and uncommitted**
**Runtime of the measurements:** CPython 3.14.3, bundled SQLite **3.50.4** (an **affected** engine — see Deliverable F)

**Method (identical for every finding, in this order):**

1. **Reproduce first** — a standalone probe scenario that demonstrates the defect against the shipped code, with the artifact written to `evidence/stage1/` (`scripts/g4_indep/probe_revg4_stage1_repro.py`, 15 scenarios, **all 15 reproduced**).
2. **Correct** — the production code change, with the rationale in the code comments.
3. **Prove** — a dedicated regression test in `tests/test_g4_revg4_remediation.py` that **fails against the defective implementation** and passes against the corrected one.

No finding was closed without all three steps.

---

## REV-G4-01 — the read-only diagnostics could write to (and consume) the database

**Severity:** P0 — the diagnostic could destroy recoverable state.
**Reproduced:** `evidence/stage1/repro_revg4_01a_checkpoint_inventory_wal_mutation.txt` (inventory call mutates the WAL), `…_01b_doctor_cli_wal_mutation.txt` (the whole `memory-doctor --json` mutates), `…_01c_doctor_rw_fallback.txt` (the inspection connection accepts a `CREATE TABLE`).

**Defect.** `collect_checkpoint_inventory()` opened the database with a plain `sqlite3.connect()` (read-write), and `interface/cli._open_verify_connection()` silently fell back to a plain read-write connection whenever the `mode=ro` open failed. Both are used by `memory-doctor`, whose own docstring claimed it *"writes nothing to the database"*. On a WAL database holding a committed-but-uncheckpointed transaction, closing the last read-write connection **checkpoints**: the recoverable frames are consumed and the main image is rewritten. The doctor therefore destroyed the very state an operator would run it to inspect.

**Correction.**
- `interface/cli.py`: new `_open_inspection_connection()` — strictly `mode=ro`, **fails closed** (re-raises) when the read-only open fails; **no writable fallback**. `_open_verify_connection()` is now reserved for `memory-verify` (which genuinely needs write access for the `rank=1` command) and is documented as such.
- `core/memory/sqlite_migration.py`: `collect_checkpoint_inventory()` now collects the filesystem facts of the main file **and all sidecars** (`-wal`, `-shm`, `-journal`) without a writable connection; the connection facts come from a read-only connection; a state that cannot be inspected read-only is reported as **`unavailable`** — never replaced by a writable connection.
- `interface/cli.py` (`memory-verify`): the writable connection's non-mutation claim is now **measured** — logical facts (schema hash + content-row count) before and after the battery, reported as `UNCHANGED` / `CHANGED`; a battery that could not complete is reported as **"NOT a verified result"** with exit code 1.
- `memory-doctor --json` is emitted with `click.echo` (byte-exact JSON) — see REV-G4-08.

**Proven by:** `TestRevg401DoctorInspectionReadOnly` (5 tests) — including the WAL-uncheckpointed-commit case, the missing-`-shm` case, and the "no write-capable fallback" case.

**Measured invariant (empirical, `Temp/opencode/shm_probe.py`):** a read-only open of a WAL database may create an **empty** `-wal` and a 32 KB `-shm` (coordination scaffolding) and may churn `-shm` bytes; it **never** changes the main image, never consumes `-wal` frames and never creates a rollback journal. The regression tests assert exactly that invariant (`assert_readonly_invariants`), so the scaffolding is tolerated **and** bounded, while the pre-fix write-capable behavior (checkpoint + main-image rewrite) fails them.

---

## REV-G4-02 — the migration runner mutated the target before it classified it

**Severity:** P0 — an unsupported database was modified before being refused.
**Reproduced:** `evidence/stage1/repro_revg4_02_unsupported_delete_converted_to_wal.txt` (journal mode `delete` → `wal`, sidecars created, `mutation_observed: true`).

**Defect.** The preflight ran `estimate_migration_space()` (plain connect), then a plain pre-integrity connect, then `PRAGMA journal_mode=WAL` — and only *after* that did `inspect_migration_state()` classify the database. A database that was about to be **refused** was already converted to WAL.

**Correction — the runner was reordered so that every boundary refuses before any persistent change:**

| # | Step | Property |
| --- | --- | --- |
| 1 | `_path_precheck()` | non-creating filesystem validation (missing / directory / zero-byte / invalid header) — **no SQLite connection at all** |
| 2 | advisory maintenance lock | independent migrators serialize before any state-touching connection |
| 3 | raw recovery-evidence preservation | `-wal`/`-shm`/`-journal` copied **before any SQLite open** (REV-G4-06) |
| 4 | read-only space estimate | `mode=ro`; never creates a file |
| 5 | read-only inspection + pre-integrity | a state that resists read-only inspection → **fail closed**, reported honestly |
| 6 | classification | `absent` / unsupported are **refused here** — before any persistent change |
| 7 | `journal_mode=WAL` + `BEGIN IMMEDIATE` | only an **eligible** target gets here |
| 8 | state re-read in-transaction | Amendment 2 §E (authoritative re-read after the write lock) |

The TOCTOU window between the read-only classification and the persistent `PRAGMA journal_mode=WAL` is **documented in the code**: the pragma is persistent and cannot run inside a transaction, so the deployment contract (all processes stopped and drained) plus the advisory lock is what closes the window. Process fencing is **not** claimed.

**Proven by:** `TestRevg402MigrationPreflightOrdering` (11 tests) — including "unsupported DELETE database refused without mutation" (journal mode still `delete`, no sidecars), "missing/zero-byte/invalid-header/directory refused", and the preserved legacy-V1 migration still working.

---

## REV-G4-03 — index drift was invisible; readiness and the maintenance command disagreed

**Severity:** P0 — the two authoritative surfaces disagreed about the same database.
**Reproduced:** `evidence/stage1/repro_revg4_03a_missing_index_already_applied.txt` (readiness FAILS while the runner says `already_applied` and repairs nothing), `…_03b_wrong_index_definition_passes_readiness.txt` (a same-name index on the wrong column **passes** readiness).

**Defect.** `validate_readiness()` checked index **names** only; `inspect_migration_state()` did not look at indexes at all, so a database whose canonical index had been dropped or redefined was classified `current` — while the application refused to start on it.

**Correction.**
- `core/memory/sqlite_contract.py`: new `parse_create_index()` — parses `CREATE [UNIQUE] INDEX … ON t (col [COLLATE c] [ASC|DESC], …) [WHERE …]` into semantic parts (name, table, uniqueness, ordered column list with collation and direction, normalized predicate).
- `core/memory/sqlite_integrity.py`: new `audit_index_contract()` — compares every canonical index **semantically** against `CANONICAL_INDEX_DDL` (and cross-checks SQLite's own `PRAGMA index_list` uniqueness flag). Per-index classification: `canonical` / `missing` / `wrong_definition` / `unparseable`; plus `unknown_extra` (any unknown index on the content table). Aggregate: `canonical` / `repairable_drift` / `unknown_drift`.
- `validate_readiness()` now **fails** on any non-canonical index contract, and reports *which* index is missing or wrong.
- `inspect_migration_state()` only returns `current` when the index contract verifies; drift is classified as **repairable** only for the two explicitly recognized shapes (index-only drift, and the recognized legacy trigger shape). Everything else — unparseable definitions, unknown extra indexes — is **not repairable** and fails closed.
- The maintenance runner executes **only** the repair scope it was given: an index-only repair recreates/repairs the indexes and **skips the FTS rebuild** (no unnecessary full-index rebuild); a legacy repair also replaces the triggers and rebuilds. Unknown trigger or index definitions abort the migration instead of being dropped.

**Proven by:** `TestRevg403IndexDriftRepair` (16 tests) — one per canonical index (dropped → repaired, not `already_applied`), wrong column / wrong sort order / lost partial predicate / wrong uniqueness (all detected), unknown extra index and unknown trigger (**refused, never dropped**), index-only repair skips the FTS rebuild, ledger identity preserved and idempotent, and the **final readiness gate blocks the commit**.

---

## REV-G4-04 — a migration against a missing path created the database

**Severity:** P0 — the command created files it was documented never to create.
**Reproduced:** `evidence/stage1/repro_revg4_04a_estimate_creates_missing_db.txt` (the *space estimate* created a 0-byte file), `…_04b_runner_missing_path_creates_then_fails.txt`, `…_04c_runner_zero_byte_target.txt` (a zero-byte file was WAL-converted before failing).

**Defect.** `estimate_migration_space()` plain-connected its target (creating it when missing) and the runner accepted the `absent` state — creating a database, converting it to WAL, and only then failing with *"no such table: main.knowledge_entries"*.

**Correction.** `absent` is **not a migration target**: a migration never creates or initializes a database — that is the application's own startup path (`initialize_schema`). A non-creating `_path_precheck()` refuses missing / directory / zero-byte / invalid-header targets **before any connection**; the space estimate is read-only and reports an `error` instead of creating anything. The refusal message tells the operator exactly how to get a canonical database (start the application once on that path).

**Proven by:** `TestRevg404MissingPaths` (7 tests) — including "the estimate never creates", "the runner never creates", "a zero-byte target is untouched", and the corrected refusal text of `memory-verify` (no "create/migrate" claim).

---

## REV-G4-05 — the backup helper could create its source and publish an unverified destination

**Severity:** P0 — a "backup" could be an empty or unverified artifact.
**Reproduced:** `evidence/stage1/repro_revg4_05_backup_missing_source.txt` (source created, destination left behind on failure).

**Defect.** `create_online_backup()` plain-connected the source (**creating it** when missing), created the destination **before** validating anything, never validated that the source is a memory database at all, and on failure left the incomplete destination on disk.

**Correction — both sides are protected now:**
- *Source*: path precheck (never created) + "must verify as the **current** memory contract" + **read-only** open; a WAL source whose `-shm` scaffolding is missing fails closed instead of letting SQLite create it; **no** write-capable fallback.
- *Destination*: an existing destination is refused; alias / same-file (`realpath`) is refused; the backup is written to a **unique temporary file**; the temporary file is **fully verified** (structural integrity, foreign keys, FTS `rank=1`, schema equality, content-row identity mapping) **before** publication; publication is an **atomic rename that cannot overwrite** a destination created concurrently; on any failure **only this operation's temporary artifact** is removed — never a pre-existing destination or recovery copy.
- The established result contract (`ok`, `method`, `note`, `identity_preserved`, `identities_compared`) is preserved, with the new per-check `checks` block added.

**Proven by:** `TestRevg405BackupSafety` (6 tests) — missing source never created, non-current source refused, existing destination untouched, alias refused, successful backup verified with the source preserved, and a verification failure that removes only the temporary artifact.

---

## REV-G4-06 — the recovery evidence was destroyed before it was preserved

**Severity:** P0 — the preservation step preserved nothing of the hot journal, and the runner had already replayed it.
**Reproduced:** `evidence/stage1/repro_revg4_06a_preservation_omits_journal.txt` (`-journal` absent from the preserved set), `…_06b_preservation_after_recovery.txt` (a 33 344-byte hot journal was replayed by the pre-integrity connect **before** preservation; the manifest contained no journal).

**Defect.** `_preserve_corrupt_database()` copied the main file, `-wal` and `-shm` — but **not** the rollback journal. Worse, the pre-migration integrity check opened the database with a plain connection **before** any preservation, so a hot journal was **replayed** (and thereby altered/destroyed) before the "preservation" copy was taken.

**Correction.** A new raw preservation routine (`_preserve_recoverable_state`) copies the main file **and** `-wal`, `-shm`, `-journal` into a **unique** directory (never overwriting a previous set), **retains the originals**, **verifies every copy by SHA-256** and writes a `manifest.json` (reason, per-file size + hash, "originals retained"). It runs **before any SQLite open** in the runner, so the evidence is captured before recovery can touch it. A copy failure raises and the caller fails closed. The `preserved_corrupt` outcome now **extends** the earlier preservation set rather than replacing it.

**Proven by:** `TestRevg406Preservation` (5 tests) — all four artifacts preserved with a verified manifest, originals retained, unique destinations, copy failure fails closed, and the hot-journal case proving the **original** journal bytes are recorded and the original file is untouched.

---

## REV-G4-07 — connection lifecycle, journal-mode invariant and test isolation

**Severity:** P0 (test isolation: the test suite wrote to the **production** database).
**Reproduced:** `evidence/stage1/repro_revg4_07a_unclosed_inspection_connection.txt` (the fresh-init path left the connection open — `PermissionError [WinError 32]` on Windows), `…_07b_silent_wal_reconversion.txt` (a delete-mode current database **passed** readiness; the first service connection converted it to WAL), `…_07d_singleton_default_prefix.txt` (the default prefix is `.data/memory`).

**Defect.**
- **A.** `_init_or_validate_sync()` called `validate_readiness(self._connect_inspection())` **without** a `closing()` context — the connection's lifetime was left to refcount/GC, and on Windows the open handle blocked later file operations on the database.
- **B.** Readiness had **no journal-mode invariant**: a current-schema database whose journal mode had been changed externally passed readiness, and the first service connection then performed an unreviewed, persistent `delete → WAL` conversion.
- **C.** `SQLiteStorageBackend._connect()` set `PRAGMA journal_mode=WAL` unconditionally, which read as an implicit conversion path.
- **D.** `get_unified_memory()` defaults to `db_prefix=".data/memory"` — the **production** database directory. Tests that called the singleton without an argument (e.g. `tests/test_cognitive_memory.py::test_retrieval_fusion`) constructed a backend on, and **wrote to**, the production database. The module-level `cognitive_vault` singleton had the same problem with its default storage directory, and the module-level `graph_engine` singleton with `.data/memory/graph.db`.

**Correction.**
- **A.** Every opened connection now has an explicit closure (`with closing(...)`), including the fresh-init inspection connection.
- **B.** `validate_readiness()` carries a **WAL journal-mode invariant**: a current database that is not in WAL mode **fails** readiness and is refused, pointing at the maintenance command for the authorized transition. (The authorized transition — `journal_mode=WAL` — is performed by the maintenance runner only.)
- **C.** `_connect()` documents that its pragma *states* the mode the database already has.
- **D.** `tests/conftest.py` redirects **all three** production-default singletons (memory, cognitive vault, graph engine) to isolated temp directories **at conftest import time** (before any test module binds them), and installs an **autouse guard** that `os.stat`-walks `.data/memory` around every test and **fails the test** if any file there changed. Files are only stat-ed — never opened. The guard fingerprints **(size, mtime_ns)**: a write that does not change a file's size must still be detected — that is exactly how the production `graph.db` was modified during this pass **without** the first (size-only) version of the guard noticing.

**Proven by:** `TestRevg407LifecycleIsolation` (5 tests) — the failed-validation path leaves no open handle (the file can be removed), a delete-mode current database is refused **and not converted**, the memory singleton resolves into the isolated prefix, the graph-engine singleton is redirected too, and the guard detects a same-size modification.

---

## REV-G4-08 — the diagnostics claimed more than they did

**Severity:** P1 — operator-facing claims were false in both directions.
**Reproduced:** `evidence/stage1/repro_revg4_01b_doctor_cli_wal_mutation.txt` (the doctor mutated while claiming "writes nothing"), `…_08_*.txt` (see `evidence/stage1/`), and the CLI JSON channel (rich soft-wrapped the payload, producing **unparseable** JSON).

**Defect.**
- `memory-doctor`'s docstring claimed *"Writes nothing to the database"* while it could write (REV-G4-01).
- `memory-verify`'s refusal message told the operator to *"run `ocbrain memory-migrate` … to create/migrate"* a database — a command that (correctly) refuses to create databases.
- An inspection that **could not run** was reported as `"unreadable"` data (as if the database had been inspected) and the readiness section was simply omitted, which reads as "no problems found".
- The `--json` output was printed through `rich`, whose soft wrapping **breaks JSON parsing** — the machine-readable channel was not machine-readable.

**Correction.**
- The doctor documents exactly what it does (strictly read-only; an uninspectable state is **UNAVAILABLE**, never a pass).
- The verify refusal points at the application's own initialization path and states that `memory-migrate` **never** creates or initializes a database.
- Unavailable inspections are reported as `"schema_state": "unavailable"` with `readiness: null` and the text output says **"NOT EVALUATED — this is not a pass"**.
- The JSON channel is emitted with `click.echo` (no wrapping) → byte-exact, parseable JSON.
- A verification battery that cannot complete is reported as **"NOT a verified result"** with exit code 1.

**Proven by:** `TestRevg408CliTruthfulness` (5 tests) — missing database → `unavailable` (not a pass), corrupt database → never claims a pass, incomplete battery → non-zero exit, text output mentions UNAVAILABLE, and repeated in-process invocations work.

---

## REV-G4-08.B — the CLI group dropped its own options after the first subcommand call (sub-finding)

**Severity:** P1 — every *second* in-process CLI invocation failed.
**Discovered while building the regression suite** (the CLI tests could not run at all).

**Defect.** `SubcommandFirstGroup.parse_args()` temporarily removed the group's **Argument** params for a subcommand-first parse and restored **only the Arguments** in its `finally` block — permanently dropping the group's **Options** (`--module`) from `self.params`. The first in-process subcommand invocation worked; every later one died with `TypeError: cli() missing 1 required positional argument: 'module'`. Any script, supervisor or test harness calling the CLI twice in one process hit this.

**Correction.** The group's parameter list is restored **completely** (`original_params`) after the parse.

**Proven by:** `test_cli_group_survives_repeated_in_process_invocations` (three consecutive `memory-doctor --json` invocations in one process, each producing parseable JSON).

---

## Summary

| ID | Severity | Reproduced | Corrected | Regression test(s) |
| --- | --- | --- | --- | --- |
| REV-G4-01 | P0 | 3 scenarios | yes | `TestRevg401…` (5) |
| REV-G4-02 | P0 | 1 scenario | yes | `TestRevg402…` (11) |
| REV-G4-03 | P0 | 2 scenarios | yes | `TestRevg403…` (16) |
| REV-G4-04 | P0 | 3 scenarios | yes | `TestRevg404…` (7) |
| REV-G4-05 | P0 | 1 scenario | yes | `TestRevg405…` (6) |
| REV-G4-06 | P0 | 2 scenarios | yes | `TestRevg406…` (5) |
| REV-G4-07 | P0 | 3 scenarios | yes | `TestRevg407…` (5) |
| REV-G4-08 | P1 | (see 01b + CLI evidence) | yes | `TestRevg408…` (5) |
| REV-G4-08.B | P1 | found while testing | yes | 1 test in `TestRevg408…` |

**Total: 61 regression tests, one class per finding.**
