# Deliverable F — Runtime record and certification status (Nov 10, 2026)

**Purpose:** to state, with measurements, exactly which runtime this verification was executed on, what that runtime's verdict is under the Amendment 1 gate, and — explicitly — that **no runtime certification is claimed by this pass**.

## Measured runtime

| Item | Measured value |
| --- | --- |
| Interpreter | **CPython 3.14.3** (3.14.3, tags/v3.14.3:323c59a, Feb 3 2026) |
| Bundled SQLite (`sqlite3.sqlite_version`) | **3.50.4** |
| `SELECT sqlite_version()` | **3.50.4** |
| `sqlite_source_id()` | `2025-07-30 19:33:53 4d8adfb30e03f9cf27f800a2c1ba3c48fb4ca1b08b0f5ed59a4d5ecbf45e20a3` |
| Platform | Windows x64 |
| Documented backport installed? | **No** (3.44.6 / 3.50.7 are source-tree backport builds; neither is present) |
| Registered vendor-build provenance | **None** (`config/settings.toml [memory] wal_gate.approved_vendor_builds` is empty) |

## Gate verdict (Amendment 1 — `core/memory/sqlite_runtime.py`)

* Affected range: **3.7.0 – 3.51.2**; fixed in **3.51.3+**; documented backports **3.44.6** and **3.50.7**.
* **3.50.4 is inside the affected range** → `wal_safe = False`, `affected_by_wal_reset_bug = True`, `full_wal_support = False`.
* The verdict is computed from the **actual runtime report**, never from the Python version, and the FTS feature probe is explicitly **not** accepted as evidence of WAL safety.
* `classify_wal_safety().wal_safe == False` on this machine, with no vendor-build record matching this `source_id`.

**Certification status: REFUSED.** The deployment readiness value stays `ready_degraded_runtime_not_supported` until the runtime is fixed. This is unchanged by the corrective pass.

## What `OCBRAIN_MEMORY_RUNTIME_ACK=acknowledge` is (and is not)

* It is the documented **test-environment-only** escape that lets the suite construct memory backends on an affected runtime. `tests/conftest.py` sets it via `setdefault` for that reason.
* Under it, the gate **never lies**: every readiness report stays `ready_degraded_runtime_not_supported` and `memory_ready` stays `False`.
* It is **not** a certification, **not** a production recommendation and **not** a way to mark this deployment ready. The production default (`enforce`, or any invalid value) fails closed.
* Every run in this pass executed with that acknowledgement in place — which is precisely why the certification statement above is *refused* rather than granted.

## Cross-engine evidence that exists (and its limits)

Measured in the **earlier** workstream (see `docs/reports/independent-g4-fts/EVIDENCE_NOTE.md` §1): the FTS trigger-shape behaviour was reproduced **identically** on 3.50.4, **3.51.3** and **3.54.1** (the fixed boundary and the latest release, loaded from the official sqlite.org DLLs via ctypes).

**Limits, stated precisely (EVIDENCE_NOTE §5, corrected Nov 10 2026):**

* **3.51.2 was NOT measured.** The probe set spans the affected→fixed boundary 3.50.4 → 3.51.3; no claim is made about 3.51.2's FTS behaviour.
* **No FTS inference is made for the backport builds.** 3.44.6 and 3.50.7 were never downloaded or executed; "they contain only the WAL-reset fix" is a source-tree reading, not a measurement.
* The WAL-reset hazard itself is a **separate** runtime condition governed by the Amendment 1 gate and is independent of the FTS trigger shape.

## What would make this deployment certifiable (unchanged — Plan R1)

1. **Full runtime upgrade** to SQLite **≥ 3.51.3** (or 3.53.0+; 3.52.0 is withdrawn upstream), OR
2. a **documented backport build** (3.44.6 or 3.50.7), OR
3. a **vendor build** with a complete provenance record registered in `config/settings.toml` (`source_id`, `distribution`, `evidence_url`, `verified_on` — partial records fail closed).

Then, in a maintenance window with all processes stopped and drained: `memory-doctor` → `create_online_backup` → `memory-migrate` → re-run the Rev 3 gate suites **and** `tests/test_g4_revg4_remediation.py` **without** `OCBRAIN_MEMORY_RUNTIME_ACK`, and confirm `classify_wal_safety().wal_safe == True`.

## Explicit non-claims of this pass

* This pass does **not** certify any runtime, and it does not re-open, weaken or bypass the Amendment 1 gate.
* It does **not** change `wal_autocheckpoint`, does **not** enable `secure_delete`, and does **not** change any operator policy.
* It does **not** close G4 and does **not** accept the G4 deliverable.
