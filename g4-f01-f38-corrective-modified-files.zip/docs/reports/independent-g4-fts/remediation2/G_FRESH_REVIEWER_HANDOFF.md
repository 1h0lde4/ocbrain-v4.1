# Deliverable G — Fresh-reviewer handoff (corrective remediation, Nov 10, 2026)

**You are reading this because you did not produce the work.** Everything below is written so that you can re-derive the claims rather than trust them. Nothing here asks you to accept the deliverable.

## 0. The one-paragraph version

A previous independent workstream delivered the G4–FTS Rev 3 remediation (branch `independent/g4-fts-rev3-20261105`, HEAD `739e58c`). A second review pass found **eight further defects (REV-G4-01 … REV-G4-08, plus the sub-finding 08.B)** in that delivery, reproduced them, corrected them, and added a 59-test regression suite. All of it is **local and uncommitted**. The delivery remains **NOT READY / G4 OPEN** — the runtime on this machine is still affected, so certification is still refused.

## 1. Where things are

| Item | Path |
| --- | --- |
| Working tree (all changes live here) | `C:\Users\Produ\Downloads\ocbrain-g4-indep\wt` (branch `independent/g4-fts-rev3-20261105`, HEAD `739e58c`) |
| Findings register (Deliverable A) | `docs/reports/independent-g4-fts/remediation2/A_FINDINGS_REGISTER.md` |
| Reproduction evidence (B) | `docs/reports/independent-g4-fts/remediation2/evidence/stage1/` (15 artifacts) + `scripts/g4_indep/probe_revg4_stage1_repro.py` |
| Correction record (C) | `docs/reports/independent-g4-fts/remediation2/C_CORRECTION_RECORD.md` |
| Regression suite (D) | `tests/test_g4_revg4_remediation.py` (61 tests) |
| Test evidence (E) | `docs/reports/independent-g4-fts/remediation2/E_TEST_EXECUTION_EVIDENCE.md` |
| Runtime record (F) | `docs/reports/independent-g4-fts/remediation2/F_RUNTIME_CERTIFICATION_RECORD.md` |
| This handoff (G) | this file |
| Dated report addendum | `docs/reports/G4_FTS_REV3_REMEDIATION_REPORT.md` §16 |
| Dated handoff addendum | `docs/reports/independent-g4-fts/HANDOFF.md` §8 |
| Debt/erasure addendum | `KNOWN_ISSUES.md` (addendum at the end) |

## 2. Review order that saves you the most time

1. **Read `A_FINDINGS_REGISTER.md`** — it states, per finding: the defect, the reproduction artifact, the correction, the proving test. Check the *reproduction* first: if the artifact does not show the defect, the rest of the finding is worthless.
2. **Run the reproduction probe yourself** (`python -X utf8 scripts\g4_indep\probe_revg4_stage1_repro.py`) and confirm 15/15 scenarios still reproduce against the **pre-correction** code — you can do that by stashing nothing: check out the four affected production files at `739e58c` into a scratch copy and point the probe at it, or simply read the recorded artifacts and confirm each maps to a defect in the source at `739e58c`.
3. **Run the regression suite** (59 tests) and then **read the tests as the specification**: each assertion states an invariant, not an implementation detail. The strongest evidence is in the assertions that inspect **real filesystem state** (SHA-256 of the main file, `-wal`, `-journal`), not return values.
4. **Read the diff of the four production files** (`core/memory/sqlite_contract.py`, `sqlite_integrity.py`, `sqlite_migration.py`, `core/memory/backends/sqlite_storage.py`, `interface/cli.py`) and check the **ordering** claims, not just the code: the whole point of REV-G4-02/04/06 is *when* each step happens relative to the first persistent change.
5. **Re-run the affected set + out-of-set set + full suite** and compare against Deliverable E. If your numbers differ, the discrepancy is yours to explain (different machine, different runtime version) — the *counts* must match.

## 3. What to distrust (and how to check it)

| Claim | How to falsify it yourself |
| --- | --- |
| "the doctor cannot write" | Run `memory-doctor --json` against a WAL database with a committed uncheckpointed transaction and compare the file hashes before/after. Note the **scaffolding** caveat: a read-only open may create an empty `-wal` and a 32 KB `-shm`; the main image and `-wal` frames must be byte-identical. |
| "a migration never creates a database" | Point the runner at a missing path, a zero-byte file and a directory; assert nothing appears on disk. |
| "the runner refuses before it mutates" | Use the `fault_injection` hook at each step name (`pre_flight`, `lock`, `recovery_preservation`, `inspection`, `journal_mode`, `apply`, `rebuild`, `verify`, `record`, `final_readiness`, `commit`, `checkpoint`) and observe the step order. |
| "preservation happens before recovery" | Build a hot-journal database (child process killed with `os._exit(1)` **without committing**), corrupt the main image, run the runner, and check the manifest for the **original** journal bytes. |
| "the index contract is semantic" | Replace a canonical index with a same-name wrong-definition one (different column, lost `DESC`, lost `WHERE`, wrong uniqueness) and check that readiness fails and the runner repairs it. |
| "the test suite cannot touch production data" | Read `tests/conftest.py` (redirects + autouse guard). Try to break it: the guard `os.stat`-walks `.data/memory` and fails the test on any change — it fingerprints **(size, mtime_ns)**, so a write that does not change a file's size is still caught (a size-only guard missed the production `graph.db` write during this pass). |
| "no runtime is certified" | `python -X utf8 -c "from core.memory.sqlite_runtime import collect_runtime_inventory, classify_wal_safety; ..."` — the verdict comes from the runtime report, not from the Python version. |

## 4. Facts a reviewer must not confuse

* **The `rank=1` / stale-MATCH anomaly is NOT a runtime property.** It followed the pre-fix V1 `ke_ad` trigger shape and is reproduced identically on 3.50.4, 3.51.3 and 3.54.1. The report's §0 framing and RF-2 heading were **withdrawn** by the dated addendum (§16.1).
* **The certification refusal is NOT withdrawn.** It rests on the **WAL** runtime gate (a different, still-verified hazard). SQLite 3.50.4 is affected → refused.
* **`OCBRAIN_MEMORY_RUNTIME_ACK=acknowledge` is test-environment-only.** Under it, readiness stays `ready_degraded_runtime_not_supported`; it never certifies anything.
* **`tests/test_check_drift.py` has 3 pre-existing Windows path-separator failures** — byte-identical to the base commit, out of scope, reported not hidden.
* **3.51.2 was never measured; the backport builds were never executed.** No FTS inference is made for them (EVIDENCE_NOTE §5, corrected).

## 5. What is explicitly NOT in scope for acceptance

* No branch, commit, staging, push, PR, merge or rebase was performed; **no issue was closed**; **no governance state changed**.
* No production database was opened by any test or probe, and no production file was rewritten by this workstream.
* `wal_autocheckpoint` unchanged; `secure_delete` stays **OFF** (recorded as an erasure caveat, not changed).
* **G4 remains OPEN / NOT ACCEPTED.** DEBT-045 remains **OPEN**.

## 6. Open items a fresh reviewer should press on

1. **Is the journal-mode invariant too strict?** A current-schema database in DELETE mode is now **refused** (the authorized transition lives in the maintenance runner). If the operator story needs a different policy, that is a **decision**, not a bug — but it must be explicit.
2. **Is the scaffolding tolerance in the read-only invariant acceptable?** The main image, `-wal` frames and `-journal` are strict; `-shm` is not. A stricter reviewer may want `-shm` compared too (it would then require a different diagnostic design).
3. **Does the narrowing of the repairable classification lose a legitimate case?** `inspect_migration_state` now returns `current` only when the index contract verifies, and only two drift shapes are repairable. Anything else fails closed — check that no in-the-wild database shape silently stops migrating (it fails loudly instead).
4. **Is the raw preservation step's cost acceptable?** It copies the whole file set before every migration that has sidecars. For a very large database that is a real cost — measured in the runner's step trace, not hidden.
5. **The production vault pollution** (`.data/memory/cognitive/vault_v4.json`, three duplicate test pairs) was **not** cleaned by this workstream. Decide whether an operator clears it.
