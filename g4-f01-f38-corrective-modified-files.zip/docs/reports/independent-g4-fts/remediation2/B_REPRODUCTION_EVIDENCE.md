# Deliverable B — Stage-1 reproduction evidence (index)

**Date:** Nov 10, 2026 · **Runtime:** CPython 3.14.3 / SQLite **3.50.4** (affected engine)
**Probe script:** `scripts/g4_indep/probe_revg4_stage1_repro.py`
**Artifacts:** `evidence/stage1/` — **15 scenario artifacts, all 15 reproduced**

## How to regenerate

```powershell
python -X utf8 scripts\g4_indep\probe_revg4_stage1_repro.py
```

Each scenario prints a finding block and writes `evidence/stage1/repro_<tag>.txt` (JSON, ASCII-encoded).

## Safety contract of the probe (honored)

* Every scenario uses an isolated database under a fresh `%TEMP%\g4repro_*` directory.
* The **production** database (`.data/memory/unified.db`, `archive.db`, `graph.db`) is **never** opened, read or referenced — the probe only imports `core.memory.*` and `interface.cli`; it never imports the orchestrator or constructs the memory singleton.
* `OCBRAIN_MEMORY_RUNTIME_ACK=acknowledge` is set for backend construction on this affected runtime — the documented **test-environment-only** mechanism; it is never a production certification.
* Crash fixtures are produced by **child processes** (`os._exit(1)`) so that the parent observes genuine crash artifacts (an uncheckpointed WAL, a hot rollback journal) rather than a clean shutdown.

## Artifact index

| Artifact | Finding | What it demonstrates |
| --- | --- | --- |
| `repro_revg4_01a_checkpoint_inventory_wal_mutation.txt` | REV-G4-01 | `collect_checkpoint_inventory()` on a WAL database with a committed, uncheckpointed transaction **mutates** it (`mutation_observed: true`). |
| `repro_revg4_01b_doctor_cli_wal_mutation.txt` | REV-G4-01 | The **whole** `memory-doctor --json` run mutates the same database — while its docstring claims it "writes nothing". |
| `repro_revg4_01c_doctor_rw_fallback.txt` | REV-G4-01 | With the read-only open fault-injected to fail, the inspection path **silently falls back to a read-write connection** (proved by a successful `CREATE TABLE`). |
| `repro_revg4_02_unsupported_delete_converted_to_wal.txt` | REV-G4-02 | An unsupported DELETE-mode database is converted to WAL (and gets `-wal`/`-shm`) **before** it is refused (`journal_mode_before: delete` → `journal_mode_after: wal`). |
| `repro_revg4_03a_missing_index_already_applied.txt` | REV-G4-03 | A dropped canonical index makes readiness **fail** while the maintenance runner answers `already_applied` and repairs nothing (`inspect_migration_state_after_drop: current`). |
| `repro_revg4_03b_wrong_index_definition_passes_readiness.txt` | REV-G4-03 | A **same-name, wrong-definition** index (`ON knowledge_entries(source)` instead of `(layer)`) **passes** readiness and is classified `current`. |
| `repro_revg4_04a_estimate_creates_missing_db.txt` | REV-G4-04 | A **space estimate** creates the missing database file it was pointed at. |
| `repro_revg4_04b_runner_missing_path_creates_then_fails.txt` | REV-G4-04 | The runner manufactures a database (plus sidecars in WAL mode) and only then fails. |
| `repro_revg4_04c_runner_zero_byte_target.txt` | REV-G4-04 | A pre-existing zero-byte target is treated as initializable and WAL-converted before failing. |
| `repro_revg4_05_backup_missing_source.txt` | REV-G4-05 | The backup helper **creates the source** and leaves the **destination behind** on failure. |
| `repro_revg4_06a_preservation_omits_journal.txt` | REV-G4-06 | The preservation routine omits the rollback journal (`-journal` absent from the preserved set). |
| `repro_revg4_06b_preservation_after_recovery.txt` | REV-G4-06 | The pre-migration integrity connect **replays the hot journal before preservation** (`journal_bytes_before: 33344`, manifest contains no journal). |
| `repro_revg4_07a_unclosed_inspection_connection.txt` | REV-G4-07 | The fresh-init path leaves the inspection connection open — `PermissionError: [WinError 32]` when the file is removed while the handle is live. |
| `repro_revg4_07b_silent_wal_reconversion.txt` | REV-G4-07 | A current-schema database flipped to DELETE mode **passes** readiness, and the first service connection converts it to WAL. |
| `repro_revg4_07d_singleton_default_prefix.txt` | REV-G4-07 | The singleton's default prefix is `.data/memory` (the production directory), and the conftest had no redirection. |

## Supporting probe (not a finding — an invariant measurement)

`Temp/opencode/shm_probe.py` measured the read-only/WAL facts that the regression tests rely on:

* a `mode=ro` open of a WAL database may create an **empty** `-wal` and a 32 KB `-shm` (coordination scaffolding) and may churn `-shm` bytes;
* it **never** changes the main image, **never** consumes `-wal` frames and **never** creates a rollback journal;
* a **read-write** open (the pre-fix behavior) *does* consume the WAL and rewrite the main image.

The regression suite encodes this as `assert_readonly_invariants()`: the main image and any rollback journal must be byte-identical, an existing `-wal` must keep its exact bytes, and only `-shm` scaffolding may differ.

---

# Stage 2 — post-fix verification (the same scenarios, re-measured)

**Script:** `scripts/g4_indep/probe_revg4_stage2_postfix.py`
**Artifacts:** `evidence/postfix/` — **10 scenarios, 10/10 confirm the defect is gone**

This is the counterpart of Stage 1: the **same** defect scenarios are re-measured against the **corrected** code. The Stage-1 artifacts (the evidence of the defects) are never overwritten — Stage 2 writes to its own directory.

```powershell
python -X utf8 scripts\g4_indep\probe_revg4_stage2_postfix.py
```

| Scenario | Finding | Post-fix measurement |
| --- | --- | --- |
| `p01_doctor_leaves_wal_untouched` | REV-G4-01 | `main_image_unchanged: true`, `wal_frames_unchanged: true`, JSON parseable |
| `p02_unsupported_db_not_converted` | REV-G4-02 | journal mode still `delete`; filesystem unchanged; the runner refuses |
| `p03_index_drift_detected_and_repaired` | REV-G4-03 | readiness refuses the drift, the state is no longer `current`, the runner **migrates** and readiness passes afterwards |
| `p03b_wrong_definition_rejected` | REV-G4-03 | a same-name wrong-definition index is refused by readiness |
| `p04_missing_target_never_created` | REV-G4-04 | neither the estimate nor the runner creates the file |
| `p05_backup_missing_source_not_created` | REV-G4-05 | no source, no destination left behind |
| `p06_journal_is_preserved` | REV-G4-06 | the `-journal` **is** in the preserved set; the originals are retained |
| `p07a_inspection_connection_closed` | REV-G4-07 | the connection is **not** usable after the failure and the file is removable (no `WinError 32`) |
| `p07b_delete_mode_database_refused` | REV-G4-07 | readiness **refuses** the externally-flipped database and the journal mode is **not** converted |
| `p08_doctor_reports_unavailable_truthfully` | REV-G4-08 (+08.B) | JSON parseable, state reported `unavailable`, readiness `null`, nothing created, and **three consecutive in-process invocations** all work |

The same safety contract as Stage 1 applies (isolated `%TEMP%\g4postfix_*` databases only; the production database is never opened).
