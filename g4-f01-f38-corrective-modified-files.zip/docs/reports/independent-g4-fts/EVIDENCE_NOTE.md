# Independent G4–FTS Rev 3 Workstream — Research & Evidence Note (§4)

Location: `docs/reports/independent-g4-fts/EVIDENCE_NOTE.md`
Branch: `independent/g4-fts-rev3-20261105` (worktree off candidate `g4-fix` @ `283920e`, merge base `2491ae4`)

Status: research-complete. This note records (a) the primary-source facts,
(b) the measured probe results with exact engine provenance, (c) the RF-2
reclassification decision, and (d) the defect inventory that drives the
checklist A–G implementation. It does not close G4 and makes no readiness
verdict; the final §8 handoff report does that.

## 0. Working rules honored here

* All database artifacts referenced by the probes are temporary throwaway
  files under `%TEMP%\g4indep_*`; no production database was used as a
  fixture.
* The candidate implementation was analyzed by reading the candidate branch
  as the baseline it is; no parallel-workstream implementation was consulted.
* The CTX-* memory-isolation findings and DEBT-045's OPEN state are untouched.

## 1. Engine provenance for all measured runs

| Engine | sqlite_version | source_id | How loaded |
| --- | --- | --- | --- |
| Affected runtime | 3.50.4 | `2025-07-30 19:33:53 4d8adfb30e03f9cf27f800a2c1ba3c48fb4ca1b08b0f5ed59a4d5ecbf45e20a3` | interpreter-stdlib `sqlite3` module (CPython 3.14.3 build) |
| Fixed boundary | 3.51.3 | `2026-03-13 10:38:09 737ae4a34738ffa0c3ff7f9bb18df914dd1cad163f28fd6b6e114a344fe6d618` | official `sqlite-dll-win-x64-3510300.zip` (sqlite.org, 2026 dir), loaded via ctypes (`scripts/g4_indep/ctypes_sqlite_helper.py`) |
| Latest release | 3.54.1 | `2026-10-16 14:45:20 555e07ef33f69a0957d24d8e555b702464a131d6f1607f4c3c1e4551e8e6ca76` | official `sqlite-dll-win-x64-3540100.zip` (sqlite.org, 2026 dir), loaded via ctypes |

The stdlib `sqlite3` module cannot be re-pointed at a different SQLite build,
so the two fixed-runtime runs execute the pure-SQL probes through a minimal
ctypes binding of the official DLLs. Both fts-sync and vacuum probes are
pure-SQL (schema DDL, triggers, upsert/delete, MATCH, integrity-check); no
repository code is involved in them, so the ctypes substitution fully
determines the engine.

## 2. Primary-source findings (sqlite.org)

### 2.1 WAL reset bug — the candidate's version facts are correct

`wal.html` §11 (anchored `#walresetbug`) states, for the WAL-reset database
corruption bug: affected versions **3.7.0 through 3.51.2**, fix included in
**3.51.3**, and documents **backports 3.44.6 and 3.50.7** — the wal.html
section links the actual source-tree fix check-ins
(sqlite.org/src/info/863c171b76cd36e0 and …/c7facf7ac58d2cda). `chronology.html`
lists neither backport as a release (they are src-tree backport builds, not
release-log entries — consistent with the release log of 3.51.3 item
"Fix the WAL-reset database corruption bug"). So the Rev 3 runtime gate's
version table (Amendment 1) is substantiated as written, including the
backport list. The gate module's *message range* is wrong, however: the
readiness error text says the affected range is "(3.7.0 .. 3.51.3)" while
3.51.3 IS the fixed boundary — the true affected bound is 3.51.2. (Fix in
checklist D.)

Incidentally, release 3.52.0 (2026-03-06) is **Withdrawn** on sqlite.org with
its features moved to 3.53.0 (2026-04-09, which re-lists the WAL-reset fix) —
any version comparison code that treats 3.52.0 as a real release would
mis-order versions around the boundary; the gate does not do that today
(no regression to make, but the withdrawn release is noted as a trap for
future version-string logic).

### 2.2 FTS5 external-content contract — what the shipped triggers must do

* fts5.html §4.4.3 ("External Content Tables"): the documented trigger set
  writes the initial content, and handles UPDATE/DELETE with the FTS5
  **special `'delete'` command**, i.e.
  `INSERT INTO fts(fts, rowid, col…) VALUES('delete', old.rowid, old.col…);`
  — old.* values from the content row, which still exist at trigger time.
* fts5.html §4.4.4: direct writes to an external-content FTS table (exactly
  what a plain `DELETE FROM fts WHERE rowid=…` trigger is) work by
  **querying the content table at execution time** and warn: if the values
  the FTS table is given "do not match" what was indexed, "some tokens may
  be left in the FTS index"; §4.4.4.1 in particular requires the FTS index
  update to happen **while the content row is still present** ("the FTS5
  table must be updated first (so that the content table row is still
  available to it)"). An AFTER DELETE trigger runs after the content row was
  deleted — there is nothing to query.
* fts5.html §6.3: the `'delete'` command requires values that match what was
  indexed; mismatches corrupt.
* fts5.html §6.7: the `INSERT INTO fts(fts,rank) VALUES('integrity-check',1)`
  command fails with `SQLITE_CORRUPT_VTAB` ("database disk image is
  malformed") when the FTS5 b-trees disagree with the content table linkage
  — this is the command's *designed* detection method. Note for checklist E:
  on all measured builds, rank=1 is refused on a `mode=ro` connection AND
  under `PRAGMA query_only=1` (it performs writes internally), which explains
  why the CLI's `_open_verify_connection` has a read-write fallback at all;
  the defect is that the fallback silently **creates** missing databases
  (see §3.5).

### 2.3 VACUUM and rowids — the DEBT-045-adjacent claim

`lang_vacuum.html` §3: "The VACUUM command **may change the ROWIDs** of
entries in any tables that do not have an explicit INTEGER PRIMARY KEY."
`knowledge_entries`' explicit key is `entry_id TEXT PRIMARY KEY` — not an
INTEGER PRIMARY KEY alias — so the documentation does NOT guarantee
rowid preservation for it. This matters because the FTS external-content
linkage is rowid-based (`content_rowid='rowid'`).

## 3. Measured probe results

All probe outputs are saved verbatim under
`docs/reports/independent-g4-fts/evidence/`:
`affected-3_50_4/` (stdlib engine) and `fixed-runtime/sqlite_3_51_3/`,
`fixed-runtime/sqlite_3_54_1/` (ctypes-loaded official DLLs).
Probes live in `scripts/g4_indep/` and read an env var (`G4INDEP_SQLITE_DLL`)
to pick the engine; each artifact records its own engine identification.

### 3.1 probe_fts_sync.py — the RF-2 classifier (three engines)

The probe builds three minimal external-content FTS5 setups that are
byte-identical except for the delete trigger, then applies the same
mutation script (insert, update, upsert, delete, insert-after-delete,
failed-insert/rollback, delete, rebuild) taking an 8-step snapshot per
strategy across tokens left in the index (match surface), pass-through
(count/rowid/docsize), the public content JOIN, and rank=1.

Composite verdict (delta = token of deleted row 2; kilo = token of row
inserted and later deleted):

| Strategy | 3.50.4 | 3.51.3 | 3.54.1 |
| --- | --- | --- | --- |
| `candidate_ke_ad` — plain `DELETE FROM fts WHERE rowid=old.rowid` in an AFTER DELETE trigger | STALE: deleted tokens remain MATCH-findable; rank=1 fails `SQLITE_CORRUPT_VTAB` from the first DELETE; `fts_docsize` uninitialized from failed runs; stale rowids never removed | **identical** | **identical** |
| `documented_delete_cmd` — §4.4.3 `'delete'` command with `old.*` | correct at every step | correct | correct |
| `plain_delete_before` — plain DELETE in a BEFORE trigger | correct | correct | correct |

Detail beyond the composite:

* The candidate failure mode is total and permanent for the affected rows:
  tokens remain MATCH-findable at their stale rowids, `public JOIN` looks
  correct only because the stale rowids no longer join against the content
  table (masking, not correctness), `fts_docsize` bookkeeping goes stale, and
  only the FTS5 `'rebuild'` command heals the index. rank=1 stays green
  until the first DELETE of each session and fails thereafter.
* The sibling update trigger (`ke_au`, which uses the `'delete'`-command +
  insert pattern) behaves correctly on all builds — the defect is isolated
  to the delete trigger shape.
* Consequence: **RF-2 is a trigger-pattern defect in the shipped canonical
  contract, replicated identically on the fixed runtime boundary and the
  latest release.** Upgrading the runtime *cannot* fix it. The candidate
  report's §9 reading ("affected runtime ⇒ deleted entries remain searchable;
  rank=1 fails") is empirically wrong on the trigger surface and must be
  reframed: the runtime gate remains valid only for the *different* WAL-reset
  hazard (wal.html §11), while FTS correctness requires the in-repo trigger
  replacement (checklist A).

### 3.2 probe_vacuum_rowid.py — VACUUM vs rowids (three engines)

* On all three engines, a TEXT-PK rowid table (the knowledge_entries shape)
  kept its rowid mapping unchanged across both plain `VACUUM` and
  `VACUUM INTO`, and an external-content FTS5 integrity-check passed after
  the VACUUM.
* Interpretation for checklist F: the claim in DEBT-045 and the candidate
  report ("VACUUM does not renumber rowids") is *empirically corroborated*
  on every measured build, but it is **not a SQLite guarantee** —
  lang_vacuum.html §3 reserves the right to renumber rowids in exactly this
  table shape, and the FTS external-content design is rowid-based.
  The corrected position: preservation is observed behavior to be verified
  after every VACUUM (which rank=1 already does — see sqlite_integrity.py's
  primary post-maintenance checks), not an invariant to assert. The DEBT-045
  row stays **OPEN** and gets this corrected, primary-sourced wording.

### 3.3 probe_ro_connections.py — read-only connections and rank=1 (3.50.4)

* `mode=ro` connections **refuse** rank=1 (`attempt to write a readonly
  database`) — MATCH reads work.
* `PRAGMA query_only=1` connections **refuse** rank=1 as well; real writes
  are refused; MATCH reads work.
* A plain (writable) connection runs rank=1 successfully.
* Legacy (delete-journal) databases give the same answers — the rank=1
  requirement of a writable connection is version-independent on the
  measured builds.
* Provenance note: an earlier version of this probe reported a
  `query_only` result mistakenly from a *plain* connection (label bug in the
  probe script); the script was fixed (`plain_writable_rank1` is the plain
  run; `query_only_rank1_probe` is the corrected explicit sequence) and the
  affected-runtime artifact regenerated.

### 3.4 probe_constructor_mutation.py — refusing readiness mutates the DB (3.50.4)

Snapshot/sha256 around a REFUSED construction (OCBRAIN_MEMORY_RUNTIME_ACK set
so the runtime gate does not pre-empt the readiness refusal):

* before: journal_mode `delete`, no sidecars, hash b50f479342d1e280.
* after:  journal_mode `wal`, -wal AND -shm sidecars exist, hash e1bae9a15c3ee24d.

The refused construction therefore **mutated the pre-existing legacy
database it refused to serve** (header field + new files) — directly
contradicting Amendment 2's "normal startup is validation-only; the
constructor never mutates a pre-existing database". The mutation is the
unconditional `PRAGMA journal_mode=WAL` in the storage backend's shared
connection opening path (checklist B).

### 3.5 probe_cli_diagnostics.py — "read-only" diagnostics create DBs (3.50.4)

All three diagnostic/surface helpers, when pointed at a NONEXISTENT path,
**created the file** instead of reporting a clean failure:

* `interface.cli._open_verify_connection` (opens, then `inspect_migration_state`
  reads `state='absent'` from the file it just created);
* `core.memory.sqlite_migration.collect_checkpoint_inventory`;
* the plain `sqlite3.connect()` inside `memory-verify`.

Checklist E: read-only diagnostics must fail-closed on a missing database
(or, for the CLI, reject `--db <missing>` before opening), never create it.

## 4. Where this leaves the checklist

* **A (trigger contract):** Replace the shipped `ke_ad` plain DELETE with the
  fts5.html §4.4.3-documented `'delete'` command form (old.* values), in
  canonical schema, migration definitions, and recognition patterns, so that
  legacy databases are *recognized* under both historical shapes while only
  the documented contract is canonical.
* **B (connection lifecycle):** The unconditional `PRAGMA journal_mode=WAL`
  on every `_connect` — including inspection connections used *before*
  readiness is decided — refuses and simultaneously mutates. Split
  inspection connections (read-only/profile) from write connections and
  enforce "no mutation on refusal" (probe §3.4).
* **C (migration honesty):** `already_applied` short-circuit without
  actual-schema verification; post-commit checkpoint faults labeled
  `outcome="failed"` with "nothing was recorded" remediation text (they are
  committed) — verify actual schema for "current", and make post-commit
  failures report committed data honestly.
* **D (runtime gate):** Version facts correct (backports real, via wal.html
  §11) but vendor-provenance path can bless a pre-WAL build
  (no lower bound), and the readiness message's range states the affected
  bound as 3.51.3 instead of 3.51.2. Add the lower bound + fix messaging;
  clarify that the gate covers the WAL-reset hazard only, never FTS
  correctness (RF-2).
* **E (CLI diagnostics):** no creation of missing DBs by "read-only"
  diagnostics (§3.5), runtime-consistent verdicts (CLI paths currently don't
  consider configured vendor provenance), and runtime-aware messaging for
  `memory-migrate` success.
* **F (VACUUM claim):** correct DEBT-045 and report §9 as §3.2 above, keep
  OPEN, cite lang_vacuum.html §3. *(Applied in this branch: the DEBT-045 row
  and report §9/DBT-R3-IDENTITY were reworded to the observed-behavior
  position with the §3 citation; status unchanged, OPEN.)*
* **G (hygiene):** untrack `data/context.sqlite` and `tests/__pycache__/*.pyc`
  (pytest runs mutate the latter), add `.gitignore` entries. No working-tree
  content changes.

## 5. Limitations of this evidence set

* ctypes-driven runs report integrity failures as
  `OperationalError: database disk image is malformed` while stdlib reports
  the same condition as a `DatabaseError` (both are the same
  SQLITE_CORRUPT_VTAB condition; exception-class naming is cosmetic).
* The vacuum probe's FTS sub-scenario uses an explicit INTEGER PRIMARY KEY
  content table (the FTS5 linkage table itself, where VACUUM cannot renumber
  rowids per its docs). The TEXT-PK preservation/FSM behavior for the exact
  repo shape is covered by the separate rowid-mapping probe in the same file.*

  > **CORRECTION (Nov 10 2026) — the two sentences that followed this bullet
  > in the Nov 2026 text ("The documented backport builds (3.44.6, 3.50.7)
  > were not separately downloaded: the FTS anomaly reproduces across the
  > version boundary (3.51.2→3.51.3) *identically*, and the backports contain
  > only the WAL-reset fix, so their FTS behavior is the same class as the
  > measured engines.") overstated what was measured and are withdrawn as
  > stated.** Precisely:
  >   * **Measured engines: 3.50.4, 3.51.3, 3.54.1** (§1). The FTS trigger-shape
  >     result (§3.1) was reproduced **identically** on all three.
  >   * **3.51.2 was NOT measured.** The affected-range boundary is documented
  >     in wal.html §11 (affected 3.7.0–3.51.2, fixed 3.51.3); the probe set
  >     spans the boundary **3.50.4 → 3.51.3**, not 3.51.2 itself. No claim is
  >     made about 3.51.2's FTS behavior.
  >   * **No FTS inference is made for the backport builds.** 3.44.6 and 3.50.7
  >     were never downloaded or executed. That they "contain only the WAL-reset
  >     fix" is a **source-tree reading**, not a measurement; their FTS behavior
  >     is **unverified**. What the measurements do establish is that the FTS
  >     anomaly is a **trigger-shape defect** (§3.1), reproducible on the fixed
  >     boundary and the latest release alike — so no runtime upgrade can fix it,
  >     and no runtime upgrade is needed to fix it either.
  >   * The WAL-reset hazard itself remains a **separate** runtime condition and
  >     is governed by the Amendment 1 gate (wal.html §11), which is
  >     independent of the FTS trigger shape.
* rank=1's refusal under `mode=ro` / `query_only=1` was measured on all
  three engines for SQLite (ft-sync) and affected for ro-probe only; its
  behavior on unmeasured engines is assumed identical because it is
  documented behavior, not a quirk.
* The probe ran on CPython 3.14.3 stdlib + WinDLL-dll engines on Windows x64;
  the candidate CI runs Python 3.12 on ubuntu-latest. Trigger/SQL semantics
  are version-bound (SQLite), not platform-bound; this is stated for
  transparency.

## 6. Verification context (§6.1 cross-ref)

The candidate's claimed numbers were reproduced exactly on this machine
*before any independent change*:

* 105/105 G4-gate tests (7 suites), 109/109 baselines, 214/214 combined,
  exit 0 — on CPython 3.14.3 / SQLite 3.50.4 (the affected runtime).
* After the independent remediation: re-run of all suites + full
  `pytest tests/ -q` per §6, and the §8 handoff verdict will be exactly one
  of READY / NOT READY / BLOCKED.
