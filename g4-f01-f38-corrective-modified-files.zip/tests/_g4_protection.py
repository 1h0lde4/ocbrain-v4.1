"""
tests/_g4_protection.py — process-level protection of production data (F24).

The Rev 3 corrective remediation found FOUR paths through which the test
suite could touch production data. The previous mitigation was a
*detection* harness: it compared file sizes/mtimes AFTER a test had run and
failed the test afterwards. That is too late — the production file had
already been written, and a same-size write could not be seen at all.

This module implements a PREVENTION boundary:

  * the protected paths are computed from the repository root and exported
    through the environment (`OCBRAIN_PROTECTED_PATHS`) so that CHILD
    processes inherit them;
  * `sqlite3.connect`, `builtins.open`, `os.remove`, `os.rename` and
    `os.replace` are wrapped so that any access to a protected path raises
    `ProtectedPathError` — the access never happens;
  * the boundary is installed at conftest IMPORT time, i.e. BEFORE pytest
    collects (and therefore before it imports) any test module, and before
    the orchestrator/memory import chains run;
  * a generated `sitecustomize.py` (placed on PYTHONPATH) installs the same
    boundary in every child Python process.

The boundary is deliberately narrow: it protects production DATA
(`.data/memory/**` and the configured memory database paths) and the
production CONFIGURATION files (`config/*.toml`). Everything else — the
repository sources, the temporary databases the tests create — stays
accessible.
"""
from __future__ import annotations

import builtins
import os
import sqlite3
from typing import Iterable, List, Optional, Sequence
from urllib.parse import unquote

PROTECTED_PATHS_ENV = "OCBRAIN_PROTECTED_PATHS"
ALLOW_CONFIG_ENV = "OCBRAIN_TEST_ALLOW_CONFIG_WRITE"


class ProtectedPathError(PermissionError):
    """Raised when code attempts to touch a protected production path."""


def _norm(path: str) -> str:
    try:
        return os.path.normcase(os.path.abspath(str(path)))
    except (OSError, ValueError):
        return str(path)


def protected_paths_for(repo_root: str,
                        extra: Optional[Iterable[str]] = None) -> List[str]:
    """
    The protected paths for this repository: the whole production memory
    directory (database + sidecars + the cognitive vault) and the production
    configuration files.
    """
    root = _norm(repo_root)
    protected: List[str] = [
        os.path.join(root, ".data", "memory"),
    ]
    for name in ("settings.toml", "models.toml", "sources.toml"):
        protected.append(os.path.join(root, "config", name))
    for item in extra or ():
        protected.append(_norm(item))
    return protected


def _uri_to_path(target: str) -> str:
    """Best-effort conversion of a SQLite URI to its filesystem path."""
    text = str(target)
    if text.startswith("file:"):
        text = text[len("file:"):]
        for sep in ("?", "#"):
            idx = text.find(sep)
            if idx != -1:
                text = text[:idx]
        if text.startswith("//"):
            # file://server/share — keep the authority form
            text = "/" + text[2:]
        text = unquote(text)
    return text


def _is_protected(target, protected: Sequence[str]) -> Optional[str]:
    """Return the protected root that `target` falls under, else None."""
    if target is None:
        return None
    raw = str(target)
    path = _uri_to_path(raw)
    candidate = _norm(path)
    for root in protected:
        root_n = _norm(root)
        if candidate == root_n:
            return root_n
        if candidate.startswith(root_n + os.sep):
            return root_n
    return None


def install(protected: Sequence[str],
            allow_config_write: bool = False) -> None:
    """
    Install the prevention boundary in THIS process (idempotent).

    `allow_config_write` relaxes only the CONFIGURATION part of the
    boundary; production DATA is never writable under the boundary.
    """
    protected = [_norm(p) for p in protected]
    data_roots = [p for p in protected if p.endswith(os.path.join(".data", "memory"))
                  or os.path.join(".data", "memory") in p]
    config_roots = [p for p in protected if p not in data_roots]

    real_connect = sqlite3.connect
    real_open = builtins.open
    real_remove = os.remove
    real_rename = os.rename
    real_replace = os.replace

    def _check(target, write: bool) -> None:
        hit = _is_protected(target, protected)
        if hit is None:
            return
        if hit in data_roots:
            # Production DATA: no access at all (read, write, create).
            raise ProtectedPathError(
                f"protected production data accessed: {target!r} is under "
                f"{hit!r}. The test environment must never open, write or "
                "initialize production data (F24). Use an isolated "
                "temporary database instead.")
        # Production CONFIGURATION: modification is forbidden; reading the
        # configuration is how the application loads its settings and is
        # not a mutation.
        if not write:
            return
        if allow_config_write:
            return
        raise ProtectedPathError(
            f"protected production configuration modified: {target!r} is "
            f"under {hit!r}. The test environment must not rewrite the "
            "production configuration files (F24).")

    def connect(target, *args, **kwargs):
        _check(target, write=not _is_readonly_connect(target, kwargs))
        return real_connect(target, *args, **kwargs)

    def open_(file, mode="r", *args, **kwargs):
        _check(file, write=any(c in str(mode) for c in "wxa+"))
        return real_open(file, mode, *args, **kwargs)

    def remove(path, *args, **kwargs):
        _check(path, write=True)
        return real_remove(path, *args, **kwargs)

    def rename(src, dst, *args, **kwargs):
        _check(src, write=True)
        _check(dst, write=True)
        return real_rename(src, dst, *args, **kwargs)

    def replace(src, dst, *args, **kwargs):
        _check(src, write=True)
        _check(dst, write=True)
        return real_replace(src, dst, *args, **kwargs)

    sqlite3.connect = connect
    builtins.open = open_
    os.remove = remove
    os.rename = rename
    os.replace = replace


def _is_readonly_connect(target, kwargs) -> bool:
    """True when the connect arguments clearly request a read-only open."""
    text = str(target)
    if "mode=ro" in text:
        return True
    uri = kwargs.get("uri")
    if uri and "mode=ro" in text:
        return True
    return False


def install_from_env() -> None:
    """Install the boundary from the exported environment (child processes)."""
    raw = os.environ.get(PROTECTED_PATHS_ENV, "")
    paths = [p for p in raw.split(os.pathsep) if p]
    if not paths:
        return
    allow = os.environ.get(ALLOW_CONFIG_ENV, "") == "1"
    install(paths, allow_config_write=allow)


def export_for_children(protected: Sequence[str],
                        allow_config_write: bool = False) -> None:
    """Export the protected paths (and the config opt-out) to children."""
    os.environ[PROTECTED_PATHS_ENV] = os.pathsep.join(
        _norm(p) for p in protected)
    if allow_config_write:
        os.environ[ALLOW_CONFIG_ENV] = "1"
