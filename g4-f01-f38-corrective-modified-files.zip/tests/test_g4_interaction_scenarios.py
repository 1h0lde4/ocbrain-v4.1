"""
tests/test_g4_interaction_scenarios.py — the combined scenarios required by
the definitive remediation (Part V, §11).

Individual component tests are not sufficient: these scenarios combine the
defects and the safety properties the way an operator would meet them.

A — unknown object plus missing index
B — missing trigger plus unreadable ledger
C — current V2 plus DELETE mode plus FK violation
D — current V2 plus DELETE mode and valid integrity
E — backup destination race plus source changes
F — hot rollback journal plus memory-verify
G — failed post-lock reread plus concurrent migrator
H — no-op migration plus existing sidecars
I — FTS rank=1 passes but the triggers are invalid
J — content changes but the row count and schema do not
K — production-path symlink plus child import
L — initialization failure while a second process starts

Every database here is disposable (tmp_path); the production boundary
installed by `tests/conftest.py` makes production access impossible.
"""
from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import subprocess
import sys

import pytest
from click.testing import CliRunner

from core.memory.sqlite_contract import (
    CANONICAL_INDEX_DDL,
    CANONICAL_TRIGGER_DDL,
    KNOWN_LEGACY_DEFINITIONS,
    sqlite_file_uri,
)
from core.memory.sqlite_integrity import logical_content_digest
from core.memory.sqlite_migration import (
    create_online_backup,
    inspect_migration_state,
    run_maintenance_migration,
)


# ── helpers ──────────────────────────────────────────────────────────────────

def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def make_current_db(path: str, rows: int = 2) -> str:
    from core.memory.backends.sqlite_storage import SQLiteStorageBackend
    SQLiteStorageBackend(str(path))
    conn = sqlite3.connect(str(path))
    try:
        conn.executemany(
            "INSERT INTO knowledge_entries(entry_id, layer, content, summary,"
            " created_at, updated_at, accessed_at) VALUES (?,?,?,?,?,?,?)",
            [(f"e{i}", "l1", f"interaction token{i} content", "", 1.0, 1.0, 1.0)
             for i in range(rows)])
        conn.commit()
    finally:
        conn.close()
    return str(path)


def make_legacy_v1_db(path: str) -> str:
    from core.memory.sqlite_contract import (
        CANONICAL_FTS_DDL, CANONICAL_KNOWLEDGE_ENTRIES_DDL)
    conn = sqlite3.connect(str(path))
    try:
        conn.execute(CANONICAL_KNOWLEDGE_ENTRIES_DDL)
        conn.execute(CANONICAL_FTS_DDL)
        conn.execute(CANONICAL_TRIGGER_DDL["ke_ai"])
        conn.execute(CANONICAL_TRIGGER_DDL["ke_au"])
        conn.execute(KNOWN_LEGACY_DEFINITIONS["ke_ad_plain_delete"])
        conn.commit()
    finally:
        conn.close()
    return str(path)


def to_delete_mode(path: str) -> None:
    conn = sqlite3.connect(path)
    try:
        conn.execute("PRAGMA journal_mode=DELETE")
        conn.commit()
    finally:
        conn.close()


def journal_mode(path: str) -> str:
    conn = sqlite3.connect(sqlite_file_uri(path, "ro"), uri=True)
    try:
        return str(conn.execute("PRAGMA journal_mode").fetchone()[0]).lower()
    finally:
        conn.close()


def add_fk_violation(path: str) -> None:
    """A user table with a foreign key whose child row has no parent."""
    conn = sqlite3.connect(path)
    try:
        conn.execute(
            "CREATE TABLE fk_child (id INTEGER PRIMARY KEY,"
            " parent TEXT REFERENCES knowledge_entries(entry_id))")
        conn.execute("INSERT INTO fk_child (id, parent) VALUES (1, 'nope')")
        conn.commit()
    finally:
        conn.close()


# ── A — unknown object plus missing index ───────────────────────────────────

def test_a_unknown_object_plus_missing_index_is_refused(tmp_path):
    db = make_current_db(str(tmp_path / "a.db"))
    conn = sqlite3.connect(db)
    conn.execute("DROP INDEX idx_ke_layer")
    conn.execute("CREATE TABLE operator_table(x TEXT)")
    conn.execute("CREATE INDEX idx_ke_layer ON operator_table(x)")
    conn.execute("INSERT INTO operator_table VALUES ('keep')")
    conn.commit()
    conn.close()
    before = sha256_file(db)

    report = run_maintenance_migration(db)
    assert report.outcome == "failed"
    assert sha256_file(db) == before, "the database was modified"
    conn = sqlite3.connect(db)
    try:
        rows = conn.execute("SELECT x FROM operator_table").fetchall()
    finally:
        conn.close()
    assert rows == [("keep",)], "the unrelated object was destroyed"


# ── B — missing trigger plus unreadable ledger ──────────────────────────────

def test_b_missing_trigger_plus_unreadable_ledger_is_not_legacy(tmp_path,
                                                                monkeypatch):
    db = make_current_db(str(tmp_path / "b.db"))
    conn = sqlite3.connect(db)
    conn.execute("DROP TRIGGER ke_ad")
    conn.commit()
    conn.close()
    # make the ledger unreadable for the inspection
    import core.memory.sqlite_integrity as integrity
    real = integrity.audit_housekeeping_contract

    def unreadable(c):
        return {"classification": "unreadable", "reason": "simulated ledger "
                "read failure", "tables": {}, "marker": None,
                "ledger": {"unreadable": True, "error": "simulated"}}

    monkeypatch.setattr(
        "core.memory.sqlite_migration.audit_housekeeping_contract", unreadable)
    conn = sqlite3.connect(sqlite_file_uri(db, "ro"), uri=True)
    try:
        state = inspect_migration_state(conn)
    finally:
        conn.close()
    assert state.state == "invalid", state.state
    assert state.repairable is False


# ── C — current V2 plus DELETE mode plus FK violation ───────────────────────

def test_c_fk_violation_refuses_before_the_journal_mode_transition(tmp_path):
    db = make_current_db(str(tmp_path / "c.db"))
    to_delete_mode(db)
    add_fk_violation(db)
    assert journal_mode(db) == "delete"

    report = run_maintenance_migration(db)
    assert report.outcome == "failed"
    assert "foreign-key preflight" in (report.failure or "")
    assert journal_mode(db) == "delete", \
        "the journal mode was converted despite the FK violation"


# ── D — current V2 plus DELETE mode and valid integrity ─────────────────────

def test_d_delete_mode_is_repaired_without_fts_rebuild_or_duplicate_ledger(
        tmp_path):
    db = make_current_db(str(tmp_path / "d.db"))
    to_delete_mode(db)
    before_rows = sqlite3.connect(sqlite_file_uri(db, "ro"), uri=True).execute(
        "SELECT COUNT(*) FROM knowledge_entries").fetchone()[0]

    report = run_maintenance_migration(db)
    assert report.outcome == "repaired", report.failure
    assert journal_mode(db) == "wal"
    steps = {s["step"]: s for s in report.steps}
    assert steps["fts_rebuild"]["status"] == "skipped"
    assert steps["replace_triggers"]["status"] == "skipped"

    conn = sqlite3.connect(sqlite_file_uri(db, "ro"), uri=True)
    try:
        ledger = conn.execute(
            "SELECT migration_id, COUNT(*) FROM _ocbrain_memory_migrations"
            " GROUP BY migration_id").fetchall()
        rows = conn.execute("SELECT COUNT(*) FROM knowledge_entries").fetchone()[0]
    finally:
        conn.close()
    assert rows == before_rows, "the content changed"
    assert len(ledger) == 1 and ledger[0][1] == 1, \
        "the ledger gained a duplicate row"


# ── E — backup destination race plus source changes ─────────────────────────

def test_e_backup_race_does_not_overwrite_and_content_change_is_detected(
        tmp_path, monkeypatch):
    import core.memory.sqlite_migration as mig
    src = make_current_db(str(tmp_path / "e_src.db"))
    dest = str(tmp_path / "e_dest.db")
    real_link = os.link

    def racing_link(a, b, **kw):
        with open(b, "wb") as fh:
            fh.write(b"RACER")
        return real_link(a, b, **kw)

    monkeypatch.setattr(mig.os, "link", racing_link)
    result = create_online_backup(src, dest)
    assert result["ok"] is False
    with open(dest, "rb") as fh:
        assert fh.read() == b"RACER", "the racer was overwritten"

    # a source change with an unchanged row count and schema must change the
    # digest (scenario J shares this mechanism)
    monkeypatch.undo()
    dest2 = str(tmp_path / "e_dest2.db")
    ok = create_online_backup(src, dest2)
    assert ok["ok"] is True, ok
    conn = sqlite3.connect(src)
    try:
        digest_before = logical_content_digest(conn)["sha256"]
        conn.execute("UPDATE knowledge_entries SET content='changed value'")
        conn.commit()
        digest_after = logical_content_digest(conn)["sha256"]
    finally:
        conn.close()
    assert digest_before != digest_after


# ── F — hot rollback journal plus memory-verify ──────────────────────────────

def test_f_hot_rollback_journal_plus_verify_preserves_evidence(tmp_path):
    from interface.cli import cli
    db = make_current_db(str(tmp_path / "f.db"))
    # a hot rollback journal: a WAL database has no rollback journal, so the
    # database is put into DELETE mode first; a child process that dies with
    # an open transaction then leaves the journal on disk
    to_delete_mode(db)
    child = str(tmp_path / "child.py")
    with open(child, "w", encoding="ascii") as fh:
        fh.write(
            "import os, sqlite3, sys\n"
            "c = sqlite3.connect(sys.argv[1])\n"
            "c.execute('BEGIN')\n"
            "c.execute(\"UPDATE knowledge_entries SET content='x'\")\n"
            "os._exit(1)\n")
    subprocess.run([sys.executable, "-X", "utf8", child, db], capture_output=True)
    assert os.path.exists(db + "-journal"), "the fixture did not create a journal"
    journal_before = sha256_file(db + "-journal")

    result = CliRunner().invoke(cli, ["memory-verify", "--db", db, "--json"],
                                 catch_exceptions=True)
    payload = json.loads(result.output)
    assert payload["recovery_evidence_preserved"], \
        "the recovery evidence was not preserved"
    assert "COPY" in payload["verdict_scope"]
    assert sha256_file(db + "-journal") == journal_before, \
        "the original journal was modified"
    assert result.exit_code in (0, 1)   # a verdict, never a crash


# ── G — failed post-lock reread plus concurrent migrator ────────────────────

def test_g_failed_post_lock_reread_never_yields_success(tmp_path, monkeypatch):
    import core.memory.sqlite_migration as mig
    db = make_current_db(str(tmp_path / "g.db"))
    monkeypatch.setattr(mig, "_restate_readonly", lambda p: None)
    report = run_maintenance_migration(db)
    assert report.outcome == "failed"
    assert report.committed is not True
    assert "re-inspection" in (report.failure or "")


# ── H — no-op migration plus existing sidecars ───────────────────────────────

def test_h_noop_migration_does_not_copy_the_whole_database(tmp_path):
    db = make_current_db(str(tmp_path / "h.db"))
    # a WAL/SHM pair is present (the normal state of a live WAL database)
    conn = sqlite3.connect(db)
    conn.execute("INSERT INTO knowledge_entries(entry_id, layer, content,"
                 " summary, created_at, updated_at, accessed_at)"
                 " VALUES ('live','l1','live row','',1,1,1)")
    conn.commit()
    conn.close()
    # the close removed the sidecars; recreate a WAL pair by keeping a
    # second connection open
    keeper = sqlite3.connect(db)
    keeper.execute("PRAGMA journal_mode=WAL")
    keeper.execute("BEGIN")
    keeper.execute("INSERT INTO knowledge_entries(entry_id, layer, content,"
                   " summary, created_at, updated_at, accessed_at)"
                   " VALUES ('live2','l1','live row 2','',1,1,1)")
    try:
        assert os.path.exists(db + "-wal")
        report = run_maintenance_migration(db)
        assert report.outcome == "already_applied", report.outcome
        # no full-database preservation copy for a no-op run
        assert not report.preserved_files, \
            "a no-op run created a full-database preservation copy"
        assert report.preservation.get("reason") in (None, ""), \
            report.preservation
        # the live sidecars are untouched
        assert os.path.exists(db + "-wal"), "a live sidecar was removed"
    finally:
        keeper.rollback()
        keeper.close()


# ── I — FTS rank=1 passes but the triggers are invalid ───────────────────────

def test_i_rank1_passing_but_invalid_triggers_fails_verification(tmp_path):
    from interface.cli import cli
    db = make_current_db(str(tmp_path / "i.db"))
    conn = sqlite3.connect(db)
    conn.execute("DROP TRIGGER ke_ad")
    conn.execute(KNOWN_LEGACY_DEFINITIONS["ke_ad_plain_delete"])
    conn.commit()
    conn.close()
    result = CliRunner().invoke(cli, ["memory-verify", "--db", db, "--json"],
                                 catch_exceptions=True)
    payload = json.loads(result.output)
    assert payload["contract_passed"] is False
    assert payload["contract"]["trigger_contract"]["status"] == "fail"
    assert result.exit_code != 0
    # the FTS integrity check itself may pass — that is exactly why the
    # contract needs more than rank=1
    assert payload["contract"]["fts_rank1"]["status"] in ("pass", "fail")


# ── J — content changes but the row count and schema do not ──────────────────

def test_j_content_change_with_same_count_and_schema_is_detected(tmp_path):
    db = make_current_db(str(tmp_path / "j.db"))
    conn = sqlite3.connect(db)
    try:
        schema_before = conn.execute(
            "SELECT name, sql FROM sqlite_schema ORDER BY name").fetchall()
        count_before = conn.execute(
            "SELECT COUNT(*) FROM knowledge_entries").fetchone()[0]
        digest_before = logical_content_digest(conn)["sha256"]
        conn.execute("UPDATE knowledge_entries SET content='a different value'")
        conn.commit()
        schema_after = conn.execute(
            "SELECT name, sql FROM sqlite_schema ORDER BY name").fetchall()
        count_after = conn.execute(
            "SELECT COUNT(*) FROM knowledge_entries").fetchone()[0]
        digest_after = logical_content_digest(conn)["sha256"]
    finally:
        conn.close()
    assert count_before == count_after
    assert schema_before == schema_after
    assert digest_before != digest_after, \
        "the logical digest did not detect the content change"


# ── K — production-path symlink plus child import ───────────────────────────

def test_k_child_process_cannot_reach_a_production_symlink(tmp_path):
    """A symlink INTO the production memory directory must not give a child
    process a way around the boundary."""
    repo = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    prod = os.path.join(repo, ".data", "memory")
    if not os.path.isdir(prod):
        pytest.skip("this checkout has no production memory directory")
    alias = tmp_path / "alias.db"
    try:
        os.symlink(os.path.join(prod, "unified.db"), alias)
    except (OSError, NotImplementedError):
        pytest.skip("symlinks are not available on this platform")

    child = tmp_path / "child.py"
    with open(child, "w", encoding="ascii") as fh:
        fh.write(
            "import sqlite3, sys\n"
            "try:\n"
            "    c = sqlite3.connect(sys.argv[1])\n"
            "    c.execute('SELECT COUNT(*) FROM knowledge_entries').fetchone()\n"
            "    print('ACCESSED')\n"
            "except Exception as exc:\n"
            "    print('BLOCKED:' + type(exc).__name__)\n")
    proc = subprocess.run([sys.executable, "-X", "utf8", str(child), str(alias)],
                          capture_output=True, text=True, timeout=60,
                          env={**os.environ})
    assert "ACCESSED" not in proc.stdout, \
        "the child reached the production database through the symlink"


# ── L — initialization failure while a second process starts ─────────────────

def test_l_a_partially_initialized_database_is_never_current(tmp_path):
    """A failed initialization must not leave a database that a later run
    treats as an authorized fresh target."""
    db = str(tmp_path / "l.db")
    conn = sqlite3.connect(db)
    try:
        # a partially initialized database: the content table exists, the
        # housekeeping tables do not
        conn.execute("CREATE TABLE knowledge_entries (entry_id TEXT PRIMARY KEY)")
        conn.commit()
    finally:
        conn.close()
    conn = sqlite3.connect(sqlite_file_uri(db, "ro"), uri=True)
    try:
        state = inspect_migration_state(conn)
    finally:
        conn.close()
    assert state.state != "current", "a partial database was accepted as current"

    # a second initialization attempt must fail loudly, not silently succeed
    from core.memory.backends.sqlite_storage import SQLiteStorageBackend
    with pytest.raises(Exception):
        SQLiteStorageBackend(db)
