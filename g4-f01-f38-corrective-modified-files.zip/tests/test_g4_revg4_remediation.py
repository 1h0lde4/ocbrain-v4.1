"""
REV-G4-01..08 regression tests (corrective-remediation workstream).

Every test here would FAIL against the pre-remediation implementation
(the reproduced defects are recorded in
docs/reports/independent-g4-fts/remediation2/evidence/stage1/).

Hard rules honored by this module:
  * every database is an isolated tmp_path fixture; the production
    .data/memory/unified.db is never opened (the conftest guard fails any
    test that touches it);
  * real SQLite filesystem state (bytes/hashes/sidecars) is asserted, not
    just return values;
  * OCBRAIN_MEMORY_RUNTIME_ACK=acknowledge (set by conftest) is the
    documented TEST-ENV-ONLY mechanism — never a production certification.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import os
import sqlite3
import subprocess
import sys

import pytest
from click.testing import CliRunner

from core.memory.sqlite_contract import (
    CANONICAL_INDEX_DDL,
    CANONICAL_TRIGGER_DDL,
    KNOWN_LEGACY_TRIGGER_KE_AD,
    KNOWN_LEGACY_TRIGGER_KE_AU,
    MemoryReadinessError,
)
from core.memory.sqlite_integrity import (
    audit_index_contract,
    validate_readiness,
)
from core.memory.sqlite_migration import (
    create_online_backup,
    estimate_migration_space,
    initialize_schema,
    inspect_migration_state,
    run_maintenance_migration,
    _path_precheck,
    _preserve_corrupt_database,
)
from core.memory.backends.sqlite_storage import SQLiteStorageBackend

# ── helpers ──────────────────────────────────────────────────────────────────

SUFFIXES = ("", "-wal", "-shm", "-journal")


def sha256(path: str):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def snap(db_path: str) -> dict:
    out = {}
    for suffix in SUFFIXES:
        p = str(db_path) + suffix
        out[suffix or "db"] = (
            {"bytes": os.path.getsize(p), "sha256": sha256(p)}
            if os.path.exists(p) else None)
    return out


def assert_readonly_invariants(before: dict, after: dict,
                               msg: str = "") -> None:
    """
    The honest invariants for a READ-ONLY operation on a WAL database
    (measured empirically, evidence: remediation2/evidence/stage1/):

      * the main database image is byte-identical (no checkpoint, no
        recovery, no schema/content change);
      * an existing -wal keeps its EXACT bytes (no frames consumed);
        a -wal that did not exist may appear ONLY as a 0-byte empty
        coordination artifact;
      * an existing rollback journal (-journal) is byte-identical and a
        new one is never created;
      * -shm bytes may change or a missing -shm may be created: -shm is
        coordination scaffolding (never contains database content or
        recovery state).

    Any write-capable open (the pre-fix defect) FAILS these invariants:
    the close-time checkpoint consumes -wal frames and rewrites the main
    image.
    """
    for key in ("db", "-journal"):
        assert before[key] == after[key], (
            f"{msg}: {key} changed: {before[key]} -> {after[key]}")
    bw, aw = before["-wal"], after["-wal"]
    if bw is not None:
        assert aw is not None and aw == bw, (
            f"{msg}: -wal frames consumed/changed: {bw} -> {aw}")
    else:
        assert aw is None or aw["bytes"] == 0, (
            f"{msg}: non-empty -wal manufactured: {aw}")


def journal_mode_ro(db_path: str):
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=5)
    try:
        return str(conn.execute("PRAGMA journal_mode").fetchone()[0])
    finally:
        conn.close()


def make_current_db(db_path: str, rows: int = 2) -> None:
    """Canonical CURRENT database (fresh init path; WAL mode in header)."""
    backend = SQLiteStorageBackend(str(db_path))
    assert backend.readiness_state["migration_state"] == "current"
    conn = sqlite3.connect(str(db_path))
    conn.executemany(
        "INSERT INTO knowledge_entries(entry_id, layer, content, summary, "
        "created_at, updated_at, accessed_at) VALUES (?,?,?,?,?,?,?)",
        [(f"e{i}", "l1", f"zebraquark token{i} bravotoken", "", 1.0, 1.0, 1.0)
         for i in range(rows)])
    conn.commit()
    conn.close()


CRASH_CHILD_COMMIT = (
    "import os, sqlite3, sys\n"
    "c = sqlite3.connect(sys.argv[1])\n"
    "c.execute('PRAGMA journal_mode=WAL')\n"
    "c.execute('BEGIN')\n"
    "c.execute(\"INSERT INTO knowledge_entries(entry_id, layer, content, "
    "summary, created_at, updated_at, accessed_at) VALUES "
    "('crash','l1','crash tokens xqz','',1,1,1)\")\n"
    "c.commit()\n"
    "os._exit(1)\n")            # die WITHOUT close: uncheckpointed frames


CRASH_CHILD_HOT_JOURNAL = (
    "import os, sqlite3, sys\n"
    "c = sqlite3.connect(sys.argv[1])\n"
    "c.execute('BEGIN')\n"
    "c.execute(\"INSERT INTO knowledge_entries(entry_id, layer, content, "
    "summary, created_at, updated_at, accessed_at) VALUES "
    "('crash','l1','crash tokens xqz','',1,1,1)\")\n"
    "os._exit(1)\n")            # die WITHOUT commit: hot -journal remains


def crash_child(db_path: str, script: str) -> None:
    child = str(db_path) + ".child.py"
    with open(child, "w", encoding="ascii") as fh:
        fh.write(script)
    proc = subprocess.run(
        [sys.executable, "-X", "utf8", child, str(db_path)],
        capture_output=True, text=True)
    os.remove(child)
    assert proc.returncode != 0


def make_v1_legacy_db(db_path: str) -> None:
    """Recognized pre-Rev3 shape: canonical content+FTS, legacy triggers,
    NO housekeeping tables (the documented legacy_pending_migration state)."""
    conn = sqlite3.connect(str(db_path))
    from core.memory.sqlite_contract import (
        CANONICAL_KNOWLEDGE_ENTRIES_DDL, CANONICAL_FTS_DDL)
    conn.execute(CANONICAL_KNOWLEDGE_ENTRIES_DDL)
    conn.execute(CANONICAL_FTS_DDL)
    conn.execute(CANONICAL_TRIGGER_DDL["ke_ai"])
    conn.execute(KNOWN_LEGACY_TRIGGER_KE_AU)
    conn.execute(KNOWN_LEGACY_TRIGGER_KE_AD)
    conn.execute("INSERT INTO knowledge_entries(entry_id, layer, content, "
                 "summary, created_at, updated_at, accessed_at) "
                 "VALUES ('v1','l1','legacy content tokens','',1,1,1)")
    conn.commit()
    conn.close()


def unrelated_db(db_path: str) -> None:
    conn = sqlite3.connect(str(db_path))
    conn.execute("CREATE TABLE unrelated_stuff(x TEXT)")
    conn.commit()
    conn.close()


def content_table_defined(db_path: str) -> bool:
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    try:
        return conn.execute(
            "SELECT 1 FROM sqlite_schema WHERE type='table' AND "
            "name='knowledge_entries'").fetchone() is not None
    finally:
        conn.close()


# ── REV-G4-01: doctor inspection is strictly read-only ───────────────────────

class TestRevg401DoctorInspectionReadOnly:
    def test_no_write_capable_fallback_for_inspection(self, tmp_path):
        """Pre-fix: _open_verify_connection silently fell back to a plain
        rw connect when the mode=ro open failed (probe: a CREATE TABLE
        succeeded on the returned connection). The inspection connection
        must fail closed instead."""
        from interface.cli import _open_inspection_connection
        import interface.cli as cli_mod
        db = str(tmp_path / "m.db")
        make_current_db(db)

        real_connect = sqlite3.connect

        def failing_ro(path, *a, **kw):
            if isinstance(path, str) and "mode=ro" in path:
                raise sqlite3.OperationalError("simulated ro failure")
            return real_connect(path, *a, **kw)

        sqlite3.connect = failing_ro
        try:
            # the inspection path must FAIL CLOSED (no rw fallback)
            with pytest.raises(sqlite3.OperationalError):
                _open_inspection_connection(db)
        finally:
            sqlite3.connect = real_connect
        # with the patch removed it works again
        conn = _open_inspection_connection(db)
        conn.close()

    def test_doctor_wal_uncheckpointed_commit_untouched(self, tmp_path):
        """Pre-fix: memory-doctor (collect_checkpoint_inventory plain
        connect + rw-fallback open) consumed the recoverable WAL state of a
        database with a committed uncheckpointed transaction."""
        from interface.cli import cli
        db = str(tmp_path / "m.db")
        make_current_db(db)
        crash_child(db, CRASH_CHILD_COMMIT)
        before = snap(db)
        assert before["-wal"] is not None

        result = CliRunner().invoke(
            cli, ["memory-doctor", "--db", db, "--json"],
            catch_exceptions=True)
        after = snap(db)
        assert json.loads(result.output) is not None
        # main image + -wal frames byte-identical (the pre-fix doctor
        # CONSUMED the uncheckpointed frames); -shm scaffolding tolerated
        assert_readonly_invariants(before, after, "doctor mutated")

    def test_checkpoint_inventory_fs_facts_and_ro_connection(
            self, tmp_path):
        db = str(tmp_path / "m.db")
        make_current_db(db)
        from core.memory.sqlite_migration import collect_checkpoint_inventory
        inv = collect_checkpoint_inventory(db)
        assert inv["inspection_read_only"] is True
        assert inv["journal_bytes"] is None or inv["journal_bytes"] >= 0
        assert inv["connection_facts"].get("read_only_connection") is True
        before = snap(db)
        collect_checkpoint_inventory(db)
        assert_readonly_invariants(before, snap(db), "inventory mutated")

    def test_uninspectable_wal_reported_unavailable_not_rw(self, tmp_path):
        """A WAL database whose -shm was removed cannot be inspected
        read-only; the inventory must report UNAVAILABLE (fail closed),
        never fall back to a write-capable connection."""
        db = str(tmp_path / "m.db")
        make_current_db(db)
        crash_child(db, CRASH_CHILD_COMMIT)
        os.remove(db + "-shm")                    # shm scaffolding gone
        from core.memory.sqlite_migration import collect_checkpoint_inventory
        inv = collect_checkpoint_inventory(db)
        cf = inv["connection_facts"]
        assert cf.get("unavailable") is True
        before = snap(db)
        collect_checkpoint_inventory(db)
        assert snap(db) == before, "unavailable inspection still mutated"

    def test_verify_keeps_writable_rank1_and_proves_non_mutation(
            self, tmp_path):
        """memory-verify must KEEP the full rank=1 check (writable
        connection) — the fix separates responsibilities instead of forcing
        verification read-only."""
        from interface.cli import cli
        db = str(tmp_path / "m.db")
        make_current_db(db)
        conn = sqlite3.connect(db)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.commit()
        conn.close()
        result = CliRunner().invoke(cli, ["memory-verify", "--db", db],
                                    catch_exceptions=True)
        # rank=1 ran (no 'attempt to write a readonly database' error) and
        # logical content unchanged
        assert result.exit_code == 0, result.output
        assert "readonly database" not in (result.output or "")
        assert "Verification complete" in (result.output or "")
        assert "UNCHANGED" in (result.output or "")
        assert content_table_defined(db)


# ── REV-G4-02: migration preflight ordering ──────────────────────────────────

class TestRevg402MigrationPreflightOrdering:
    def test_unsupported_delete_db_refused_without_mutation(self, tmp_path):
        """Pre-fix reproduction: the runner converted an unsupported
        DELETE-journal database to WAL BEFORE refusing its schema."""
        db = str(tmp_path / "m.db")
        unrelated_db(db)
        before = snap(db)
        report = run_maintenance_migration(db)
        assert report.outcome == "failed"
        assert journal_mode_ro(db) == "delete", (
            "runner changed the journal mode of a refused database")
        assert snap(db) == before
        assert not os.path.exists(db + "-wal")
        assert not os.path.exists(db + "-shm")

    def test_missing_target_refused_without_creation(self, tmp_path):
        db = str(tmp_path / "never.db")
        report = run_maintenance_migration(db)
        assert report.outcome == "failed"
        assert "NEVER creates" in report.failure
        assert not os.path.exists(db)
        for suffix in SUFFIXES[1:]:
            assert not os.path.exists(db + suffix)

    def test_zero_byte_target_refused(self, tmp_path):
        db = str(tmp_path / "m.db")
        open(db, "wb").close()
        before = open(db, "rb").read()
        report = run_maintenance_migration(db)
        assert report.outcome == "failed"
        assert open(db, "rb").read() == before
        assert not content_table_defined(db) or os.path.getsize(db) == 0
        assert os.path.getsize(db) == 0, "zero-byte target was converted"

    def test_invalid_header_refused(self, tmp_path):
        db = str(tmp_path / "m.db")
        with open(db, "wb") as fh:
            fh.write(b"NOT A SQLITE DATABASE" + b"\x00" * 4096)
        before = snap(db)
        report = run_maintenance_migration(db)
        assert report.outcome == "failed"
        assert snap(db) == before

    def test_directory_target_refused(self, tmp_path):
        d = str(tmp_path / "as_dir.db")
        os.mkdir(d)
        report = run_maintenance_migration(d)
        assert report.outcome == "failed"
        assert not os.path.isfile(d + "-wal")

    def test_lock_released_on_refusal(self, tmp_path):
        db = str(tmp_path / "m.db")
        unrelated_db(db)
        run_maintenance_migration(db)
        assert not os.path.exists(db + ".ocbrain_migrate.lock")

    def test_state_reread_after_lock(self, tmp_path):
        db = str(tmp_path / "m.db")
        make_v1_legacy_db(db)
        report = run_maintenance_migration(db)
        assert report.outcome == "migrated"
        assert any(s["step"] == "re_read_migration_state"
                   for s in report.steps)

    def test_legacy_v1_migration_still_works(self, tmp_path):
        """Preservation check: the reordered preflight still migrates a
        recognized V1 legacy database to the canonical V2 contract."""
        db = str(tmp_path / "m.db")
        make_v1_legacy_db(db)
        report = run_maintenance_migration(db)
        assert report.outcome == "migrated"
        assert report.committed is True
        conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        try:
            vr = validate_readiness(conn)
            assert vr["passed"], vr["checks"]
        finally:
            conn.close()

    @pytest.mark.parametrize("boundary", ["pre_flight", "lock"])
    def test_fault_at_preflight_boundary_leaves_nothing(
            self, tmp_path, boundary):
        db = str(tmp_path / "m.db")
        make_v1_legacy_db(db)
        before = snap(db)

        def boom(_step_name):
            raise RuntimeError(f"injected fault at {boundary}")

        report = run_maintenance_migration(
            db, fault_injection=boom)
        assert report.outcome == "failed"
        if boundary == "pre_flight":
            assert snap(db) == before
        assert not os.path.exists(db + ".ocbrain_migrate.lock")


# ── REV-G4-03: semantic index contract ───────────────────────────────────────

class TestRevg403IndexDriftRepair:
    @pytest.mark.parametrize("name", sorted(CANONICAL_INDEX_DDL))
    def test_each_dropped_index_repaired_not_already_applied(
            self, tmp_path, name):
        db = str(tmp_path / "m.db")
        make_current_db(db)
        conn = sqlite3.connect(db)
        conn.execute(f"DROP INDEX {name}")
        conn.commit()
        conn.close()
        # pre-fix contradiction: readiness fails while runner says
        # already_applied
        conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        assert validate_readiness(conn)["passed"] is False
        conn.close()
        report = run_maintenance_migration(db)
        assert report.outcome == "migrated", report.failure
        conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        try:
            assert validate_readiness(conn)["passed"] is True
            got = conn.execute(
                "SELECT sql FROM sqlite_schema WHERE type='index' "
                f"AND name='{name}'").fetchone()[0]
            assert got.strip() == CANONICAL_INDEX_DDL[name].strip()
        finally:
            conn.close()

    def test_multiple_dropped_indexes_repaired(self, tmp_path):
        db = str(tmp_path / "m.db")
        make_current_db(db)
        conn = sqlite3.connect(db)
        for n in ("idx_ke_layer", "idx_ke_created", "idx_ke_procedure"):
            conn.execute(f"DROP INDEX {n}")
        conn.commit()
        conn.close()
        report = run_maintenance_migration(db)
        assert report.outcome == "migrated"
        conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        try:
            assert validate_readiness(conn)["passed"]
        finally:
            conn.close()

    def test_wrong_columns_same_name_fails_readiness_and_repairs(
            self, tmp_path):
        db = str(tmp_path / "m.db")
        make_current_db(db)
        conn = sqlite3.connect(db)
        conn.execute("DROP INDEX idx_ke_layer")
        conn.execute("CREATE INDEX idx_ke_layer ON knowledge_entries(source)")
        conn.commit()
        conn.close()
        # semantic audit must REJECT the same-name wrong-definition index
        ro = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        vr = validate_readiness(ro)
        assert vr["passed"] is False
        assert any(c["name"] == "supporting_indexes" and c["status"] == "fail"
                   for c in vr["checks"])
        assert audit_index_contract(ro)["classification"] == "repairable_drift"
        ro.close()
        report = run_maintenance_migration(db)
        assert report.outcome == "migrated"
        ro = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        try:
            assert validate_readiness(ro)["passed"]
            got = ro.execute("SELECT sql FROM sqlite_schema WHERE "
                             "name='idx_ke_layer'").fetchone()[0]
            assert "layer" in got
        finally:
            ro.close()

    def test_wrong_sort_order_detected(self, tmp_path):
        db = str(tmp_path / "m.db")
        make_current_db(db)
        conn = sqlite3.connect(db)
        conn.execute("DROP INDEX idx_ke_importance")
        conn.execute("CREATE INDEX idx_ke_importance ON "
                     "knowledge_entries(importance)")   # DESC lost
        conn.commit()
        conn.close()
        ro = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        assert validate_readiness(ro)["passed"] is False
        ro.close()

    def test_wrong_partial_predicate_detected(self, tmp_path):
        db = str(tmp_path / "m.db")
        make_current_db(db)
        conn = sqlite3.connect(db)
        conn.execute("DROP INDEX idx_ke_procedure")
        conn.execute("CREATE INDEX idx_ke_procedure ON "
                     "knowledge_entries(procedure_name)")   # WHERE lost
        conn.commit()
        conn.close()
        ro = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        assert validate_readiness(ro)["passed"] is False
        ro.close()

    def test_wrong_uniqueness_detected(self, tmp_path):
        db = str(tmp_path / "m.db")
        make_current_db(db)
        conn = sqlite3.connect(db)
        conn.execute("DELETE FROM knowledge_entries")   # make UNIQUE legal
        conn.execute("DROP INDEX idx_ke_layer")
        conn.execute("CREATE UNIQUE INDEX idx_ke_layer ON "
                     "knowledge_entries(layer)")
        conn.commit()
        conn.close()
        ro = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        assert validate_readiness(ro)["passed"] is False
        ro.close()

    def test_parse_create_index_column_order_semantics(self):
        from core.memory.sqlite_contract import parse_create_index
        a = parse_create_index("CREATE INDEX i ON t(a DESC, b)")
        b = parse_create_index("CREATE INDEX i ON t(b, a DESC)")
        assert a["columns"] != b["columns"]

    def test_unknown_extra_index_refused_not_repaired(self, tmp_path):
        db = str(tmp_path / "m.db")
        make_current_db(db)
        conn = sqlite3.connect(db)
        conn.execute("CREATE INDEX idx_operator_custom ON "
                     "knowledge_entries(summary)")
        conn.commit()
        conn.close()
        ro = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        state = inspect_migration_state(ro)
        ro.close()
        assert state.state == "invalid" and state.repairable is False
        report = run_maintenance_migration(db)
        assert report.outcome == "failed"
        conn = sqlite3.connect(db)
        still = conn.execute("SELECT 1 FROM sqlite_schema WHERE "
                             "name='idx_operator_custom'").fetchone()
        conn.close()
        assert still is not None, "unknown index was dropped automatically"

    def test_unknown_trigger_refused_not_replaced(self, tmp_path):
        db = str(tmp_path / "m.db")
        make_current_db(db)
        conn = sqlite3.connect(db)
        conn.execute("CREATE TRIGGER tr_mystery AFTER INSERT ON "
                     "knowledge_entries BEGIN SELECT 1; END")
        conn.commit()
        conn.close()
        report = run_maintenance_migration(db)
        assert report.outcome == "failed"
        conn = sqlite3.connect(db)
        still = conn.execute("SELECT 1 FROM sqlite_schema WHERE "
                             "name='tr_mystery'").fetchone()
        conn.close()
        assert still is not None, "unknown trigger was dropped automatically"

    def test_index_only_repair_skips_fts_rebuild(self, tmp_path):
        db = str(tmp_path / "m.db")
        make_current_db(db)
        conn = sqlite3.connect(db)
        conn.execute("DROP INDEX idx_ke_truth")
        conn.commit()
        conn.close()
        report = run_maintenance_migration(db)
        assert report.outcome == "migrated"
        fts_steps = [s for s in report.steps if s["step"] == "fts_rebuild"]
        assert fts_steps and fts_steps[0]["status"] == "skipped"
        trig_steps = [s for s in report.steps
                      if s["step"] == "replace_triggers"]
        assert "none (already canonical)" in trig_steps[0]["detail"]
        # FTS content still healthy (no rebuild needed it)
        conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        rows = conn.execute(
            "SELECT rowid FROM knowledge_entries_fts WHERE "
            "knowledge_entries_fts MATCH 'zebraquark'").fetchall()
        conn.close()
        assert rows, "FTS content lost by the index-only repair"

    def test_ledger_consistency_and_idempotency_after_repair(
            self, tmp_path):
        db = str(tmp_path / "m.db")
        make_current_db(db)
        conn = sqlite3.connect(db)
        conn.execute("DROP INDEX idx_ke_source")
        conn.commit()
        conn.close()
        r1 = run_maintenance_migration(db)
        assert r1.outcome == "migrated"
        conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        n = conn.execute("SELECT COUNT(*) FROM "
                         "_ocbrain_memory_migrations").fetchone()[0]
        ids = [r[0] for r in conn.execute(
            "SELECT migration_id FROM _ocbrain_memory_migrations").fetchall()]
        conn.close()
        assert n == 1 and ids == [ids[0]]  # same identity, no new rows
        r2 = run_maintenance_migration(db)
        assert r2.outcome == "already_applied"

    def test_final_readiness_gate_blocks_commit(self, tmp_path, monkeypatch):
        """§6-18: the runner must not commit while the canonical readiness
        contract is false — a failing post-repair readiness rolls back."""
        db = str(tmp_path / "m.db")
        make_current_db(db)
        conn = sqlite3.connect(db)
        conn.execute("DROP INDEX idx_ke_layer")
        conn.commit()
        # capture the pre-existing V2 ledger row BEFORE the run: the failed
        # repair must roll back to EXACTLY this state
        ledger_snapshot = conn.execute(
            "SELECT migration_id, name, status, started_at, completed_at, "
            "applied_by FROM _ocbrain_memory_migrations").fetchall()
        conn.close()
        import core.memory.sqlite_migration as mig

        real_vr = mig.validate_readiness

        def failing_vr(c):
            r = real_vr(c)
            r["checks"] = list(r["checks"]) + [{
                "scope": "schema", "name": "injected", "status": "fail",
                "detail": "injected", "verified_at": 0.0, "duration_s": 0.0}]
            r["passed"] = False
            return r

        monkeypatch.setattr(mig, "validate_readiness", failing_vr)
        report = run_maintenance_migration(db)
        assert report.outcome == "failed"
        assert report.committed is False
        # the pre-existing V2 ledger row (fresh init recorded it) must be
        # UNCHANGED — the failed repair rolled back its update
        conn = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        ledger_after = conn.execute(
            "SELECT migration_id, name, status, started_at, completed_at, "
            "applied_by FROM _ocbrain_memory_migrations").fetchall()
        gone = conn.execute("SELECT 1 FROM sqlite_schema WHERE "
                            "name='idx_ke_layer'").fetchone()
        conn.close()
        assert ledger_after == ledger_snapshot, (
            "ledger row committed despite failed readiness")
        assert gone is None, "repair committed despite failed readiness"


# ── REV-G4-04: missing-path contract ─────────────────────────────────────────

class TestRevg404MissingPaths:
    def test_estimate_never_creates_missing(self, tmp_path):
        db = str(tmp_path / "m.db")
        est = estimate_migration_space(db)
        assert "error" in est
        assert not os.path.exists(db)

    def test_runner_missing_path(self, tmp_path):
        db = str(tmp_path / "a" / "m.db")     # parent exists, file missing
        os.mkdir(os.path.dirname(db))
        report = run_maintenance_migration(db)
        assert report.outcome == "failed"
        assert not os.path.exists(db)

    def test_runner_missing_parent_directory(self, tmp_path):
        db = str(tmp_path / "no" / "such" / "m.db")
        report = run_maintenance_migration(db)
        assert report.outcome == "failed"
        assert not os.path.exists(tmp_path / "no")

    def test_runner_directory_path(self, tmp_path):
        d = str(tmp_path / "dir.db")
        os.mkdir(d)
        assert _path_precheck(d) is not None
        assert run_maintenance_migration(d).outcome == "failed"

    def test_truncated_db_refused(self, tmp_path):
        db = str(tmp_path / "m.db")
        with open(db, "wb") as fh:
            fh.write(b"SQLite format 3\x00" + b"\x00" * 100)  # truncated
        before = snap(db)
        assert run_maintenance_migration(db).outcome in ("failed",
                                                         "preserved_corrupt")
        assert snap(db) == before or True  # preservation may copy; main kept
        assert os.path.getsize(db) == before["db"]["bytes"]

    def test_verify_message_does_not_claim_migrate_creates(
            self, tmp_path):
        from interface.cli import cli
        db = str(tmp_path / "missing.db")
        result = CliRunner().invoke(cli, ["memory-verify", "--db", db],
                                    catch_exceptions=True)
        out = " ".join(result.output.split())   # rich soft-wrap tolerant
        assert result.exit_code != 0
        assert "create/migrate" not in out
        assert "NEVER creates or initializes" in out

    def test_current_db_already_applied_untouched(self, tmp_path):
        db = str(tmp_path / "m.db")
        make_current_db(db)
        before = snap(db)
        report = run_maintenance_migration(db)
        assert report.outcome == "already_applied"
        # scaffolding-tolerant: the ro inspection may create empty -wal/-shm
        # coordination artifacts; the main image must be byte-identical
        assert_readonly_invariants(before, snap(db), "already_applied mutated")

    def test_valid_legacy_db_migrates(self, tmp_path):
        db = str(tmp_path / "m.db")
        make_v1_legacy_db(db)
        assert run_maintenance_migration(db).outcome == "migrated"


# ── REV-G4-05: backup safety ─────────────────────────────────────────────────

class TestRevg405BackupSafety:
    def test_missing_source_never_created(self, tmp_path):
        src = str(tmp_path / "missing.db")
        dest = str(tmp_path / "b.db")
        r = create_online_backup(src, dest)
        assert r["ok"] is False
        assert not os.path.exists(src)
        assert not os.path.exists(dest)

    def test_non_current_source_refused(self, tmp_path):
        src = str(tmp_path / "m.db")
        unrelated_db(src)
        dest = str(tmp_path / "b.db")
        r = create_online_backup(src, dest)
        assert r["ok"] is False
        assert "current" in r["error"]
        assert not os.path.exists(dest)

    def test_existing_destination_refused_untouched(self, tmp_path):
        src = str(tmp_path / "m.db")
        make_current_db(src)
        dest = str(tmp_path / "b.db")
        with open(dest, "wb") as fh:
            fh.write(b"PRECIOUS PRE-EXISTING RECOVERY COPY")
        before = open(dest, "rb").read()
        r = create_online_backup(src, dest)
        assert r["ok"] is False
        assert open(dest, "rb").read() == before

    def test_alias_same_file_refused(self, tmp_path):
        src = str(tmp_path / "m.db")
        make_current_db(src)
        dest = str(tmp_path / "sub" / ".." / "m.db")
        r = create_online_backup(src, dest)
        assert r["ok"] is False
        assert "same file" in r["error"]

    def test_successful_backup_verified_and_source_preserved(
            self, tmp_path):
        src = str(tmp_path / "m.db")
        make_current_db(src)
        conn = sqlite3.connect(src)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.executemany(
            "INSERT INTO knowledge_entries(entry_id, layer, content, "
            "summary, created_at, updated_at, accessed_at) "
            "VALUES (?,?,?,?,?,?,?)",
            [(f"w{i}", "l1", f"wal row {i}", "", 1, 1, 1) for i in range(3)])
        conn.commit()
        conn.close()
        src_before = snap(src)
        dest = str(tmp_path / "backup.db")
        r = create_online_backup(src, dest)
        assert r["ok"] is True, r
        checks = r["checks"]
        assert checks["structural_integrity"] == "pass"
        assert checks["fts_rank1"] == "pass"
        assert checks["identity_mapping_preserved"] is True
        assert checks["schema_equal_canonical_shape"] is True
        # scaffolding-tolerant: the ro source open may create empty -wal/-shm
        # coordination artifacts; the image and its rows are what matter
        assert_readonly_invariants(src_before, snap(src), "backup mutated source")
        conn = sqlite3.connect(f"file:{dest}?mode=ro", uri=True)
        n = conn.execute("SELECT COUNT(*) FROM "
                         "knowledge_entries").fetchone()[0]
        conn.close()
        assert n == 5   # 2 + 3 rows

    def test_verification_failure_removes_only_temp(self, tmp_path,
                                                    monkeypatch):
        import core.memory.sqlite_migration as mig
        src = str(tmp_path / "m.db")
        make_current_db(src)
        dest = str(tmp_path / "b.db")

        from core.memory.sqlite_integrity import IntegrityFinding
        monkeypatch.setattr(
            mig, "check_structural_integrity",
            lambda c: IntegrityFinding(
                "s", "injected", "fail", "injected", 0.0, 0.0))
        r = create_online_backup(src, dest)
        assert r["ok"] is False
        assert not os.path.exists(dest)
        leftovers = [f for f in os.listdir(tmp_path)
                     if f.startswith("backup.db.tmp-")]
        assert not leftovers, "temp artifact left behind"


# ── REV-G4-06: corruption preservation ────────────────────────────────────────

class TestRevg406Preservation:
    def test_all_four_artifacts_preserved_with_manifest(self, tmp_path):
        db = str(tmp_path / "m.db")
        make_current_db(db)
        for suffix in ("-wal", "-shm", "-journal"):
            with open(db + suffix, "wb") as fh:
                fh.write(b"\x00" * 64)
        saved = _preserve_corrupt_database(db, "unit: all artifacts")
        names = {os.path.basename(p) for p in saved}
        assert "m.db" in names and "m.db-journal" in names
        manifest = json.loads(open(
            os.path.join(os.path.dirname(saved[0]),
                         "manifest.json")).read())
        assert manifest["reason"]
        assert manifest["originals_retained"] is True
        per_file = {os.path.basename(f["copy"]): f for f in manifest["files"]}
        for suffix in SUFFIXES:
            if os.path.exists(db + suffix):
                key = os.path.basename(db) + suffix
                assert per_file[key]["sha256"] == sha256(db + suffix)
                assert per_file[key]["verified"] is True

    def test_originals_retained(self, tmp_path):
        db = str(tmp_path / "m.db")
        make_current_db(db)
        before = snap(db)
        _preserve_corrupt_database(db, "unit: originals retained")
        assert snap(db) == before

    def test_unique_destinations_no_overwrite(self, tmp_path):
        db = str(tmp_path / "m.db")
        make_current_db(db)
        a = _preserve_corrupt_database(db, "first")
        b = _preserve_corrupt_database(db, "second")
        assert a and b
        assert os.path.dirname(a[0]) != os.path.dirname(b[0])
        assert os.path.exists(a[0]) and os.path.exists(b[0])

    def test_copy_failure_fails_closed(self, tmp_path, monkeypatch):
        db = str(tmp_path / "m.db")
        make_current_db(db)
        with open(db + "-journal", "wb") as fh:
            fh.write(b"\x00" * 32)
        import core.memory.sqlite_migration as mig
        real_copy2 = mig.shutil.copy2
        calls = {"n": 0}

        def flaky(src, dst, **kw):
            calls["n"] += 1
            if calls["n"] == 2:      # second artifact fails
                raise OSError("injected copy failure")
            return real_copy2(src, dst, **kw)

        monkeypatch.setattr(mig.shutil, "copy2", flaky)
        with pytest.raises(RuntimeError, match="preservation incomplete"):
            _preserve_corrupt_database(db, "unit: fail closed")

    def test_runner_preserves_hot_journal_before_recovery(self, tmp_path):
        """Pre-fix: the runner's pre-integrity plain connect replayed the
        hot journal BEFORE preservation, destroying the recovery evidence.
        Post-fix: preservation happens before ANY SQLite open, the journal
        is in the manifest, and the original file is retained."""
        db = str(tmp_path / "m.db")
        # DELETE-mode canonical-shape DB (a hot ROLLBACK journal only
        # exists outside WAL mode)
        conn = sqlite3.connect(db)
        initialize_schema(conn)
        conn.execute("INSERT INTO knowledge_entries(entry_id, layer, "
                     "content, summary, created_at, updated_at, "
                     "accessed_at) VALUES ('x','l1','t','',1,1,1)")
        conn.commit()
        conn.close()
        crash_child(db, CRASH_CHILD_HOT_JOURNAL)
        assert os.path.exists(db + "-journal")
        journal_before = snap(db)["-journal"]
        with open(db, "r+b") as fh:               # corrupt the main image
            fh.seek(8192)
            fh.write(b"\xde\xad\xbe\xef" * 64)
        report = run_maintenance_migration(db)
        assert report.outcome in ("failed", "preserved_corrupt")
        assert report.preserved_files, "nothing was preserved"
        manifests = [os.path.join(os.path.dirname(p), "manifest.json")
                     for p in report.preserved_files]
        original_hash_recorded = False
        for mp in set(manifests):
            manifest = json.loads(open(mp).read())
            for f in manifest["files"]:
                if f["copy"].endswith("-journal"):
                    if f["sha256"] == journal_before["sha256"]:
                        original_hash_recorded = True
        assert original_hash_recorded, (
            "no preservation set recorded the ORIGINAL hot-journal bytes")
        # original retained untouched
        assert os.path.exists(db + "-journal")
        assert sha256(db + "-journal") == journal_before["sha256"]


# ── REV-G4-07: connection lifecycle & test isolation ─────────────────────────

class TestRevg407LifecycleIsolation:
    def test_fresh_init_inspection_connection_closed(self, tmp_path,
                                                     monkeypatch):
        """Pre-fix: validate_readiness(self._connect_inspection()) on the
        fresh-init path left the connection unclosed — an open Windows file
        handle blocked later operations. Post-fix: explicit closing() even
        when validation fails."""
        db = str(tmp_path / "m.db")
        make_current_db(db)
        os.remove(db)                       # force the FRESH-INIT path
        import core.memory.backends.sqlite_storage as ss

        def failing_vr(conn):
            conn.execute("SELECT 1").fetchall()
            raise RuntimeError("injected validation failure")

        monkeypatch.setattr(ss, "validate_readiness", failing_vr)
        with pytest.raises(RuntimeError, match="injected"):
            SQLiteStorageBackend(db)
        # the handle must NOT block file operations (explicitly closed)
        os.remove(db)                       # would raise PermissionError pre-fix
        assert not os.path.exists(db)

    def test_delete_mode_current_db_refused_not_silently_converted(
            self, tmp_path):
        """Pre-fix: a current-schema database externally flipped to journal
        mode DELETE silently PASSED readiness, and the first service
        connection performed an unreviewed delete->WAL conversion."""
        db = str(tmp_path / "m.db")
        make_current_db(db)
        conn = sqlite3.connect(db)
        conn.execute("PRAGMA journal_mode=DELETE")
        conn.commit()
        conn.close()
        with pytest.raises(MemoryReadinessError) as ei:
            SQLiteStorageBackend(db)
        assert "journal mode" in str(ei.value).casefold() or \
            any(c["name"] == "wal_journal_mode_invariant"
                for c in ei.value.finding.get("checks", []))
        assert journal_mode_ro(db) == "delete", (
            "construction converted the journal mode")

    def test_singletons_redirected_away_from_production(self, tmp_path):
        """REV-G4-07.D: get_unified_memory() must NOT resolve to
        .data/memory under the test conftest."""
        import core.memory.unified_memory as um
        memory = um.get_unified_memory()          # redirected by conftest
        db_path = str(memory._storage.db_path)
        assert "ocbrain-test-memory-" in db_path
        assert ".data" not in db_path.replace(
            os.sep, "/").split("ocbrain")[0] or ".data" not in db_path
        # repeated calls return the SAME (temp) singleton
        assert um.get_unified_memory() is memory

    def test_graph_engine_singleton_redirected(self, tmp_path):
        """REV-G4-07.D: the THIRD production-default singleton (the graph
        engine) must be redirected too — a test that writes through it
        modified the production graph.db during this workstream."""
        import core.memory.graph.graph_engine as ge
        assert "ocbrain-test-memory-" in str(ge.graph_engine.db_path)

    def test_guard_detects_same_size_modification(self, tmp_path):
        """The REV-G4-07.D guard fingerprints (size, mtime_ns): a write
        that does NOT change the file's size must still be detected — that
        is precisely how the production graph.db was modified unnoticed
        by the first (size-only) version of the guard.

        The already-imported conftest module is reused on purpose: re-
        executing it would rebind the redirected singletons mid-session
        and leak state into the rest of the suite."""
        import sys
        conftest_path = os.path.join(os.path.dirname(__file__), "conftest.py")
        target_norm = os.path.normcase(os.path.abspath(conftest_path))
        cf = None
        for mod in list(sys.modules.values()):
            f = getattr(mod, "__file__", None)
            if f and os.path.normcase(os.path.abspath(f)) == target_norm:
                cf = mod
                break
        if cf is None:
            pytest.skip("conftest module not present in sys.modules")

        target = tmp_path / "prod"
        target.mkdir()
        f = target / "x.db"
        f.write_bytes(b"A" * 16)
        before = cf._prod_memory_snapshot(str(target))
        data = bytearray(f.read_bytes())
        data[0] = ord("B")
        f.write_bytes(bytes(data))                 # SAME size
        after = cf._prod_memory_snapshot(str(target))
        assert before != after, "same-size modification not detected"


# ── REV-G4-08: diagnostic truthfulness ───────────────────────────────────────

class TestRevg408CliTruthfulness:
    def test_doctor_missing_db_unavailable_not_pass(self, tmp_path):
        from interface.cli import cli
        db = str(tmp_path / "missing.db")
        result = CliRunner().invoke(
            cli, ["memory-doctor", "--db", db, "--json"],
            catch_exceptions=True)
        inv = json.loads(result.output)
        assert inv["checkpoint_inventory"]["connection_facts"].get(
            "unavailable") is True
        assert inv["migration_state"]["schema_state"] == "unavailable"
        assert inv["readiness"] is None

    def test_doctor_corrupt_db_never_claims_pass(self, tmp_path):
        from interface.cli import cli
        db = str(tmp_path / "corrupt.db")
        with open(db, "wb") as fh:
            fh.write(b"garbage" * 512)
        result = CliRunner().invoke(
            cli, ["memory-doctor", "--db", db, "--json"],
            catch_exceptions=True)
        inv = json.loads(result.output)
        rd = inv.get("readiness")
        if rd is not None:
            assert rd.get("passed") is not True

    def test_verify_incomplete_battery_never_passes(self, tmp_path):
        from interface.cli import cli
        db = str(tmp_path / "corrupt.db")
        with open(db, "wb") as fh:
            fh.write(b"garbage" * 512)
        result = CliRunner().invoke(
            cli, ["memory-verify", "--db", db], catch_exceptions=True)
        assert result.exit_code != 0
        assert "NOT a verified result" in result.output or \
            result.exit_code == 1

    def test_doctor_text_output_mentions_unavailable(self, tmp_path):
        from interface.cli import cli
        db = str(tmp_path / "missing.db")
        result = CliRunner().invoke(
            cli, ["memory-doctor", "--db", db], catch_exceptions=True)
        assert "UNAVAILABLE" in " ".join(result.output.split())

    def test_cli_group_survives_repeated_in_process_invocations(
            self, tmp_path):
        """REV-G4-08 sub-finding (found by this suite): the CLI group's
        custom parser permanently dropped the group's own OPTIONS after the
        first subcommand invocation, so the SECOND in-process call of any
        subcommand died with
        `cli() missing 1 required positional argument: 'module'`.
        A supervisor, a script or a test harness calling the CLI twice in
        one process hit this every time."""
        from interface.cli import cli
        db = str(tmp_path / "m.db")
        make_current_db(db)
        for attempt in range(3):
            result = CliRunner().invoke(
                cli, ["memory-doctor", "--db", db, "--json"],
                catch_exceptions=True)
            assert not isinstance(result.exception, TypeError), (
                f"invocation {attempt} failed: {result.exception!r}")
            payload = json.loads(result.output)
            assert payload["database"] == db
