"""
tests/test_g4_indep_trigger_contract.py — Independent Rev 3 remediation tests,
checklist A (FTS5 external-content DELETE trigger contract) and the V2
migration identity.

Self-named independent tests (not copies of the candidate's suites). Every
expectation is anchored in a primary source or a measured probe artifact:

  * fts5.html §4.4.3 — the documented external-content trigger pattern uses
    the special 'delete' command with old.* values.
  * fts5.html §4.4.4/§4.4.4.1 — plain writes to an external-content FTS table
    query the content table at execution time, so the content row must still
    exist when the FTS index is updated ("the FTS5 table must be updated
    first").
  * fts5.html §6.7 — the rank=1 integrity-check fails SQLITE_CORRUPT_VTAB
    when the FTS b-trees disagree with the content table.
  * Probe artifacts: docs/reports/independent-g4-fts/evidence/
    (probe_fts_sync on 3.50.4/3.51.3/3.54.1 — the candidate plain-DELETE
    trigger fails identically on the fixed runtimes).
"""
import asyncio
import sqlite3
import time
import uuid

import pytest

from core.memory.backends.sqlite_storage import SQLiteStorageBackend
from core.memory.knowledge_entry import KnowledgeEntry
from core.memory.sqlite_contract import (
    CANONICAL_SCHEMA_STATEMENTS,
    CANONICAL_TRIGGER_DDL,
    KNOWN_LEGACY_TRIGGER_KE_AD,
    META_SCHEMA_STATE,
    MIGRATION_ID_V1,
    MIGRATION_ID_V2,
    SCHEMA_STATE_MIGRATED,
    normalize_sql,
    trigger_audit_classification,
)
from core.memory.sqlite_integrity import (
    audit_trigger_contract,
    validate_readiness,
)
from core.memory.sqlite_migration import (
    inspect_migration_state,
    run_maintenance_migration,
)


# ── helpers ──────────────────────────────────────────────────────────────────

def _open(path):
    conn = sqlite3.connect(str(path))
    conn.isolation_level = None
    return conn


def _apply_canonical_schema(path) -> None:
    """Create the canonical CURRENT database — WAL mode included.

    REV-G4-07.B: the canonical contract includes the WAL journal mode
    (the application's own initialization path always produces a WAL
    database). The fixture used to build a DELETE-mode database, which the
    corrected readiness contract legitimately refuses: a current-schema
    database whose journal mode was changed externally must not silently
    pass readiness. The fixture now builds the canonical shape.
    """
    conn = _open(path)
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        for statement in CANONICAL_SCHEMA_STATEMENTS:
            conn.execute(statement)
        conn.execute(
            "INSERT INTO _ocbrain_memory_meta(key, value) VALUES (?, ?)",
            (META_SCHEMA_STATE, "initialized_fresh_current"))
        conn.execute(
            "INSERT INTO _ocbrain_memory_migrations("
            "migration_id, name, status, started_at, completed_at, "
            "applied_by, host_os, pre_checks_json, post_checks_json) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            (MIGRATION_ID_V2, "verify corrected trigger contract", "applied",
             time.time(), time.time(), "test", "test", "{}", "{}"))
    finally:
        conn.close()


def _candidate_schema_snapshot(path) -> None:
    """
    Recreate the state a database lands in when the CANDIDATE Rev 3 code
    migrates/fresh-initializes it: the shipped V1 ledger row plus the
    plain-DELETE ke_ad trigger (the probe-failing form).
    """
    conn = _open(path)
    try:
        for statement in CANONICAL_SCHEMA_STATEMENTS:
            if "ke_ad" in statement:
                conn.execute(KNOWN_LEGACY_TRIGGER_KE_AD)
                continue
            conn.execute(statement)
        conn.execute(
            "INSERT INTO _ocbrain_memory_meta(key, value) VALUES (?, ?)",
            (META_SCHEMA_STATE, SCHEMA_STATE_MIGRATED))
        conn.execute(
            "INSERT INTO _ocbrain_memory_migrations("
            "migration_id, name, status, started_at, completed_at, "
            "applied_by, host_os, pre_checks_json, post_checks_json) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            (MIGRATION_ID_V1, "candidate v1 contract", "applied",
             time.time(), time.time(), "test", "test", "{}", "{}"))
    finally:
        conn.close()


def _insert_content_row(conn, entry_id: str, content: str,
                        layer: str = "l1") -> None:
    conn.execute(
        "INSERT INTO knowledge_entries (entry_id, layer, content, summary,"
        " importance, confidence, truth_status, trust_score, source,"
        " created_at, updated_at, accessed_at) "
        "VALUES (?, ?, ?, '', 0.5, 1.0, 'unknown', 1.0, '', ?, ?, ?)",
        (entry_id, layer, content, time.time(), time.time(), time.time()))


def _match_rowids(conn, token: str):
    rows = conn.execute(
        "SELECT rowid FROM knowledge_entries_fts "
        "WHERE knowledge_entries_fts MATCH ?", (token,)).fetchall()
    return sorted(r[0] for r in rows)


def _rank1(conn) -> str:
    try:
        conn.execute(
            "INSERT INTO knowledge_entries_fts(knowledge_entries_fts, rank) "
            "VALUES ('integrity-check', 1)")
        return "passed"
    except sqlite3.Error as exc:
        return f"ERROR: {type(exc).__name__}: {exc}"


def _entry(content: str, layer: str = "l1") -> KnowledgeEntry:
    return KnowledgeEntry(entry_id=f"test-{uuid.uuid4().hex[:12]}.{uuid.uuid4().hex[:8]}",
                          layer=layer, content=content)


# ── 1. the canonical contract text itself ────────────────────────────────────

class TestCanonicalTriggerText:
    def test_ke_ad_is_the_documented_delete_command(self):
        """fts5.html §4.4.3: the delete trigger must be a 'delete'

        command INSERT with old.* values, not a plain DELETE (which queries
        the already-deleted content row — §4.4.4.1)."""
        ddl = normalize_sql(CANONICAL_TRIGGER_DDL["ke_ad"])
        assert "'delete'" in ddl
        assert "old.rowid" in ddl
        assert "old.content" in ddl
        assert "old.summary" in ddl
        assert "old.tags" in ddl
        # the probe-failing plain-DELETE form must NOT be canonical anymore
        assert "delete from knowledge_entries_fts" not in ddl

    def test_candidate_plain_delete_ke_ad_is_recognized_legacy(self):
        classification = trigger_audit_classification(
            KNOWN_LEGACY_TRIGGER_KE_AD, "ke_ad")
        assert classification == "known_legacy_unsafe"

    def test_audit_classification_of_candidate_db_is_legacy_compatible(
            self, tmp_path):
        db = tmp_path / "candidate.db"
        _candidate_schema_snapshot(db)
        conn = _open(db)
        try:
            audit = audit_trigger_contract(conn)
            assert audit["classification"] == "legacy_compatible", audit
            assert audit["triggers"]["ke_ad"] == "known_legacy_unsafe"
        finally:
            conn.close()


# ── 2. engine-level behavior of the corrected contract ──────────────────────

class TestDeletedTokensLeaveTheIndex:
    def test_delete_removes_tokens_and_rank1_passes(self, tmp_path):
        """The probe's core RF-2 assertion, against the corrected canonical

        contract. On the 3.50.4 runtime of this machine (acknowledged), with
        the corrected trigger the deleted row's tokens are NOT MATCH-findable
        and rank=1 passes — the correction, not the runtime, fixes it."""
        db = tmp_path / "fresh.db"
        _apply_canonical_schema(db)
        conn = _open(db)
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            _insert_content_row(conn, "e1", "kwAlpha kwBravo original")
            _insert_content_row(conn, "e2", "kwDelta kwEcho doomed")
            r1 = _match_rowids(conn, "kwDelta")
            assert len(r1) == 1, r1
            conn.execute("DELETE FROM knowledge_entries WHERE entry_id='e2'")
            assert _match_rowids(conn, "kwDelta") == []
            assert _match_rowids(conn, "kwEcho") == []
            # survivor untouched
            assert len(_match_rowids(conn, "kwAlpha")) == 1
            assert _rank1(conn) == "passed"
            docsize = conn.execute(
                "SELECT count(*) FROM knowledge_entries_fts_docsize"
            ).fetchone()[0]
            assert docsize == 1, docsize
        finally:
            conn.close()


# ── 3. storage-backend construction on the corrected contract ───────────────

class TestBackendReadinessOnCorrectedContract:
    @pytest.mark.asyncio
    async def test_fresh_backend_v2_ready_and_delete_is_clean(self, tmp_path):
        db = tmp_path / "fresh.db"
        _apply_canonical_schema(db)
        backend = SQLiteStorageBackend(str(db))
        assert backend.readiness_state["migration_state"] == "current"
        assert backend.readiness_state["memory_ready"] is False  # acknowledged: honest
        keep = _entry("kwPersist kwRemains forever")
        gone = _entry("kwVanish kwGhost deleted")
        assert await backend.write(keep) == keep.entry_id
        assert await backend.write(gone) == gone.entry_id
        hits_keep = await backend.search_text("kwPersist")
        assert [e.entry_id for e in hits_keep] == [keep.entry_id]
        hits_wrong = await backend.search_text("kwVanish")
        assert [e.entry_id for e in hits_wrong] == [gone.entry_id]
        assert await backend.delete(gone.entry_id) is True
        # corrected contract: the deleted entry is GONE from MATCH, and the
        # index integrity survives
        assert await backend.search_text("kwVanish") == []
        conn = _open(db)
        try:
            assert _match_rowids(conn, "kwGhost") == []
            assert _rank1(conn) == "passed"
        finally:
            conn.close()


# ── 4. the V2 migration identity (candidate-era databases) ──────────────────

class TestV2MigrationIdentity:
    def test_candidate_v1_db_is_pending_until_v2_migration_and_then_current(
            self, tmp_path):
        db = tmp_path / "candidate.db"
        _candidate_schema_snapshot(db)

        # Refuse readiness while only the V1 contract is on the ledger.
        probe = _open(db)
        try:
            state = inspect_migration_state(probe)
            assert state.state == "legacy_pending_migration", state.finding
            validation = validate_readiness(probe)
            assert not validation["passed"], [
                c["name"] + ": " + c.get("detail", "")
                for c in validation["checks"] if c["status"] == "fail"]
        finally:
            probe.close()

        report = run_maintenance_migration(str(db))
        assert report.outcome == "migrated", (report.outcome, report.failure)
        conn = _open(db)
        try:
            rows = {row[0] for row in conn.execute(
                "SELECT migration_id FROM _ocbrain_memory_migrations "
                "WHERE status='applied'").fetchall()}
            # both identities survive in the ledger: V1 as the historical
            # record, V2 as the current requirement
            assert MIGRATION_ID_V1 in rows
            assert MIGRATION_ID_V2 in rows
            after = inspect_migration_state(conn)
            assert after.state == "current", after.finding
            validation = validate_readiness(conn)
            assert validation["passed"], [
                c["name"] + ": " + c.get("detail", "")
                for c in validation["checks"] if c["status"] == "fail"]
        finally:
            conn.close()

    def test_rerun_on_current_db_reports_already_applied(self, tmp_path):
        db = tmp_path / "candidate.db"
        _candidate_schema_snapshot(db)
        first = run_maintenance_migration(str(db))
        assert first.outcome == "migrated", first.failure
        second = run_maintenance_migration(str(db))
        assert second.outcome == "already_applied", second.outcome

    def test_current_state_requires_actually_canonical_schema(self, tmp_path):
        """Checklist C guard: 'current' cannot come from marker+ledger alone.

        F-state-machine (Nov 2026): the tampered-but-recognized state is now
        reported as the EXPLICIT `repairable_drift` state (the documented
        state machine distinguishes 'repairable_drift' from 'invalid'); the
        guard's substance — the verdict is NOT 'current' — is unchanged.
        """
        db = tmp_path / "fresh.db"
        _apply_canonical_schema(db)
        # tamper: swap the corrected trigger back to the probe-failing form
        conn = _open(db)
        try:
            conn.execute("DROP TRIGGER ke_ad")
            conn.execute(KNOWN_LEGACY_TRIGGER_KE_AD)
        finally:
            conn.close()
        conn = _open(db)
        try:
            state = inspect_migration_state(conn)
            assert state.state == "repairable_drift", (state.state, state.finding)
            assert state.state != "current"
            assert state.repairable is True
            # the repair scope is explicit and narrow (F17)
            scope = state.finding["repair_scope"]
            assert scope["triggers"] is True
            assert scope["fts_rebuild"] is True
            assert scope["journal_mode"] is None
        finally:
            conn.close()
        # ... and the idempotent maintenance migration restores the contract
        report = run_maintenance_migration(str(db))
        assert report.outcome == "migrated", (report.outcome, report.failure)
        conn = _open(db)
        try:
            assert inspect_migration_state(conn).state == "current"
            assert _rank1(conn) == "passed"
        finally:
            conn.close()
