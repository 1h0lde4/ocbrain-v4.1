"""
tests/conftest.py — test-environment setup and the F24 production boundary.

Two things happen here, and the ORDER matters:

  1. **A temporary memory path is established BEFORE any OCBrain module is
     imported** (`OCBRAIN_MEMORY_DIR`). The memory, cognitive-vault and
     graph-engine singletons construct their backing store at IMPORT time
     with a production default; replacing the singleton afterwards is too
     late. With the variable set, those imports build their stores under a
     temporary directory instead.

  2. **The production-access boundary is installed** — it PREVENTS access to
     the production memory directory and the production configuration files
     (it raises before the access happens) and is inherited by child
     processes through a generated `sitecustomize.py` on PYTHONPATH.

Both are installed at conftest IMPORT time, i.e. BEFORE pytest collects
(and therefore before it imports) any test module and before the
orchestrator/worker import chains run. A failed boundary installation
aborts the test run instead of degrading to "detection afterwards".

The Rev 3 runtime gate still defaults to "enforce", which refuses
memory-backend construction on an affected runtime (the one bundled with
this interpreter is affected — see
docs/reports/G4_FTS_REV3_REMEDIATION_REPORT.md). The whole test suite must
still run: it acknowledges the runtime EXPLICITLY. Under "acknowledge" the
gate never lies: every readiness report stays
`ready_degraded_runtime_not_supported` with memory_ready=False, and the
dedicated runtime-gate tests below remove the variable to prove the
refusal itself.

THIS IS A TEST-ENV-ONLY setting. It is NOT a production recommendation:
production must either upgrade the runtime, install a documented backport,
or register verified vendor-build provenance (Amendment 1 §D / report §R1).
"""
import os
import pathlib
import sys
import tempfile

import pytest

# Ensure the root directory is in the python path for absolute imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Rev 3 (G4-FTS remediation) — Amendment 1 §E: the SQLite WAL runtime gate
# defaults to "enforce" ... (unchanged; see the module docstring above).
os.environ.setdefault("OCBRAIN_MEMORY_RUNTIME_ACK", "acknowledge")

# ── F24 step 1: a temporary memory path BEFORE any OCBrain import ────────────
#
# The production-default singletons (memory, cognitive vault, graph engine)
# construct their backing store at import time. Establishing the temporary
# path here — before pytest imports a single test module — is what keeps
# the production directory untouched.
_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
_TEST_MEMORY_DIR = tempfile.mkdtemp(prefix="ocbrain-test-memory-")
os.environ["OCBRAIN_MEMORY_DIR"] = _TEST_MEMORY_DIR

# ── F24 step 2: the production-access PREVENTION boundary ────────────────────
import importlib.util  # noqa: E402

_PROTECTION_PATH = os.path.join(os.path.dirname(__file__), "_g4_protection.py")
_spec = importlib.util.spec_from_file_location("g4_protection", _PROTECTION_PATH)
_g4_protection = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_g4_protection)

_PROTECTED_PATHS = _g4_protection.protected_paths_for(_REPO_ROOT)
_g4_protection.export_for_children(_PROTECTED_PATHS)

# Child processes inherit the boundary through a generated sitecustomize.py
# on PYTHONPATH (sitecustomize is imported by the interpreter at startup,
# before the child's own imports).
_SITECUSTOMIZE_DIR = tempfile.mkdtemp(prefix="ocbrain-test-sitecustomize-")
with open(os.path.join(_SITECUSTOMIZE_DIR, "sitecustomize.py"), "w",
          encoding="utf-8") as fh:
    fh.write(
        "import sys\n"
        "try:\n"
        "    import _g4_protection\n"
        "except Exception:\n"
        "    pass\n"
        "else:\n"
        "    _g4_protection.install_from_env()\n")
_PYTHONPATH = os.environ.get("PYTHONPATH", "")
os.environ["PYTHONPATH"] = (
    os.pathsep.join([_SITECUSTOMIZE_DIR,
                     os.path.join(_REPO_ROOT, "tests"),
                     _PYTHONPATH]) if _PYTHONPATH
    else os.pathsep.join([_SITECUSTOMIZE_DIR,
                           os.path.join(_REPO_ROOT, "tests")]))

# Install the boundary in THIS process. A failure here MUST block the run.
_g4_protection.install(_PROTECTED_PATHS)


# ── F24 secondary net: the detection harness (defence in depth) ─────────────
#
# The prevention boundary is the primary control; this harness is the
# backstop for anything that bypasses the patched entry points (a C-level
# write, a library that opens the file through another API). It compares
# (size, mtime_ns) — a same-size write is invisible to a size-only check.
_PROD_MEMORY_DIR = os.path.join(_REPO_ROOT, ".data", "memory")


def _prod_memory_snapshot(directory=None):
    """(path -> (size, mtime_ns)) of every file under the given directory
    (default: .data/memory) — stat only, NEVER opened.

    The directory is a parameter so the fingerprint can be exercised against
    a temporary directory (a test must never write under .data/memory to
    prove the guard works)."""
    snap = {}
    root = os.path.abspath(directory or _PROD_MEMORY_DIR)
    for dirpath, _dirnames, filenames in os.walk(root):
        for name in filenames:
            p = os.path.join(dirpath, name)
            try:
                st = os.stat(p)
                snap[p] = (st.st_size, st.st_mtime_ns)
            except OSError:
                snap[p] = None
    return snap


@pytest.fixture(autouse=True)
def _no_production_memory_access():
    """
    REV-G4-07.D detection harness: fails ANY test that creates, deletes,
    resizes OR MODIFIES a file under <repo>/.data/memory. Files are only
    stat-ed — never opened.
    """
    before = _prod_memory_snapshot()
    yield
    after = _prod_memory_snapshot()
    changed = {p: (before.get(p), after.get(p))
               for p in set(before) | set(after)
               if before.get(p) != after.get(p)}
    if changed:
        raise AssertionError(
            "REV-G4-07.D violation: the test session modified the "
            f"production memory directory .data/memory: {changed!r}. "
            "Tests must use isolated temporary databases (explicit "
            "tmp_path / --db), never the configured production paths.")


@pytest.fixture(autouse=True)
def _isolated_config_dir(tmp_path, monkeypatch):
    """
    The configuration a test exercises is a COPY in a temporary directory.

    `core.config.set()` / `set_module_state()` persist the settings they
    change straight back to `config/settings.toml` (and `models.toml`) — so
    a test that flips a setting rewrote the PRODUCTION configuration file.
    With the copy in place the write lands in the temporary directory and
    the repository's configuration is never modified by a test run
    (F24 / section 10, "protect production TOML files").

    The in-memory settings the config object already loaded are unchanged,
    so tests keep asserting against the real values.
    """
    import core.config as core_config

    # The copy lives in its OWN directory (not under tmp_path): a test that
    # asserts "nothing else was written under tmp_path" must not see it.
    target = pathlib.Path(tempfile.mkdtemp(prefix="ocbrain-test-config-"))
    target.mkdir(exist_ok=True)
    for name in ("settings.toml", "models.toml", "sources.toml",
                 "settings.yaml", "user_prefs.yaml"):
        src = os.path.join(_REPO_ROOT, "config", name)
        if os.path.exists(src):
            try:
                with open(src, "rb") as fh:
                    (target / name).write_bytes(fh.read())
            except OSError:
                pass
    monkeypatch.setattr(core_config, "CONFIG_DIR", target)
    return target


@pytest.fixture
def temp_data_dir(tmp_path):
    """
    Provides a temporary directory for tests that need to write to disk.
    """
    return str(tmp_path)


@pytest.fixture
def enforce_runtime_gate(monkeypatch):
    """
    Remove the suite-wide acknowledgement so a test can observe the default
    fail-closed behavior (constructor raises
    MemoryRuntimeCompatibilityError on an affected runtime).
    """
    monkeypatch.delenv("OCBRAIN_MEMORY_RUNTIME_ACK", raising=False)
    return monkeypatch
