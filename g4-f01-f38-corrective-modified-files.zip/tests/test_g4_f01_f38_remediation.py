"""
tests/test_g4_f01_f38_remediation.py — regression evidence for the
definitive G4 corrective remediation (findings F01–F38).

Every test here reproduces a defect that was demonstrated against the
pre-remediation code and proves the corrected behaviour. Findings whose
correction is exercised by an existing suite reference that suite in the
class docstring instead of duplicating it.

Isolation: every database is a `tmp_path` fixture. The production
boundary installed by `tests/conftest.py` (F24) makes any production
access raise before it happens, so these tests cannot touch production
data even by accident.
"""
from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import subprocess
import sys

import pytest
from click.testing import CliRunner

from core.memory.sqlite_contract import (
    CANONICAL_INDEX_DDL,
    CANONICAL_TRIGGER_DDL,
    KNOWN_LEGACY_DEFINITIONS,
    LEGACY_TRIGGER_CONFIGURATIONS,
    MIGRATIONS_TABLE,
    META_TABLE,
    normalize_sql,
    parse_create_index,
    parse_create_virtual_table,
    sqlite_file_uri,
)
from core.memory.sqlite_integrity import (
    audit_housekeeping_contract,
    audit_index_contract,
    audit_trigger_contract,
    check_foreign_key_integrity,
    logical_content_digest,
    validate_readiness,
)
from core.memory.sqlite_migration import (
    create_online_backup,
    estimate_migration_space,
    initialize_schema,
    inspect_migration_state,
    run_maintenance_migration,
)


# ── helpers ──────────────────────────────────────────────────────────────────

def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def make_current_db(path: str, rows: int = 2) -> str:
    """A CURRENT canonical database (fresh init, WAL mode)."""
    from core.memory.backends.sqlite_storage import SQLiteStorageBackend
    backend = SQLiteStorageBackend(str(path))
    conn = sqlite3.connect(str(path))
    try:
        conn.executemany(
            "INSERT INTO knowledge_entries(entry_id, layer, content, summary,"
            " created_at, updated_at, accessed_at) VALUES (?,?,?,?,?,?,?)",
            [(f"e{i}", "l1", f"content token{i} alpha", "", 1.0, 1.0, 1.0)
             for i in range(rows)])
        conn.commit()
    finally:
        conn.close()
    return str(path)


def make_legacy_v1_db(path: str) -> str:
    """The documented Session-4C V1 shape: the canonical content table and
    FTS table, canonical ke_ai/ke_au, the plain-DELETE ke_ad, and NO
    housekeeping tables."""
    from core.memory.sqlite_contract import (
        CANONICAL_FTS_DDL, CANONICAL_KNOWLEDGE_ENTRIES_DDL)
    conn = sqlite3.connect(str(path))
    try:
        conn.execute(CANONICAL_KNOWLEDGE_ENTRIES_DDL)
        conn.execute(CANONICAL_FTS_DDL)
        conn.execute(CANONICAL_TRIGGER_DDL["ke_ai"])
        conn.execute(CANONICAL_TRIGGER_DDL["ke_au"])
        conn.execute(KNOWN_LEGACY_DEFINITIONS["ke_ad_plain_delete"])
        conn.execute(
            "INSERT INTO knowledge_entries(entry_id, layer, content, summary,"
            " created_at, updated_at, accessed_at)"
            " VALUES ('v1','l1','legacy body','',1,1,1)")
        conn.commit()
    finally:
        conn.close()
    return str(path)


def journal_mode(path: str) -> str:
    conn = sqlite3.connect(sqlite_file_uri(path, "ro"), uri=True)
    try:
        return str(conn.execute("PRAGMA journal_mode").fetchone()[0]).lower()
    finally:
        conn.close()


# ── F01: the doctor must never silently open a writable database ───────────

class TestF01DoctorNeverWrites:
    def test_inspection_connection_has_no_write_capable_fallback(self, tmp_path):
        from interface.cli import _open_inspection_connection
        db = make_current_db(str(tmp_path / "m.db"))
        real_connect = sqlite3.connect

        def failing_ro(target, *a, **kw):
            if isinstance(target, str) and "mode=ro" in target:
                raise sqlite3.OperationalError("simulated ro failure")
            return real_connect(target, *a, **kw)

        sqlite3.connect = failing_ro
        try:
            with pytest.raises(sqlite3.OperationalError):
                _open_inspection_connection(db)
        finally:
            sqlite3.connect = real_connect

    def test_doctor_leaves_main_wal_and_journal_untouched(self, tmp_path):
        from interface.cli import cli
        db = make_current_db(str(tmp_path / "m.db"))
        before = {s: (sha256_file(db + s) if os.path.exists(db + s) else None)
                  for s in ("", "-wal", "-shm", "-journal")}
        sizes_before = {s: (os.path.getsize(db + s)
                             if os.path.exists(db + s) else None)
                        for s in ("", "-wal", "-shm", "-journal")}
        result = CliRunner().invoke(cli, ["memory-doctor", "--db", db, "--json"],
                                    catch_exceptions=True)
        assert result.exception is None
        after = {s: (sha256_file(db + s) if os.path.exists(db + s) else None)
                 for s in ("", "-wal", "-shm", "-journal")}
        sizes_after = {s: (os.path.getsize(db + s)
                            if os.path.exists(db + s) else None)
                       for s in ("", "-wal", "-shm", "-journal")}
        assert before[""] == after[""], "the doctor rewrote the database"
        assert before["-journal"] == after["-journal"]
        # an EMPTY -wal created by the read-only open is coordination
        # scaffolding; an EXISTING -wal must keep its exact bytes
        if before["-wal"] is not None:
            assert before["-wal"] == after["-wal"], \
                "the doctor consumed WAL frames"
        else:
            # an EMPTY -wal created by the read-only open is coordination
            # scaffolding (never a checkpointed frame)
            assert sizes_before["-wal"] is None and (
                sizes_after["-wal"] is None or sizes_after["-wal"] == 0)

    def test_doctor_never_removes_sidecars(self, tmp_path):
        from interface.cli import cli
        db = make_current_db(str(tmp_path / "m.db"))
        with open(db + "-journal", "wb") as fh:
            fh.write(b"\x00" * 32)
        CliRunner().invoke(cli, ["memory-doctor", "--db", db, "--json"],
                           catch_exceptions=True)
        assert os.path.exists(db + "-journal"), "the doctor removed a sidecar"

    def test_doctor_reports_zero_byte_database_without_claiming_pass(
            self, tmp_path):
        from interface.cli import cli
        db = str(tmp_path / "zero.db")
        open(db, "wb").close()
        result = CliRunner().invoke(cli, ["memory-doctor", "--db", db, "--json"],
                                    catch_exceptions=True)
        payload = json.loads(result.output)
        assert payload["migration_state"]["schema_state"] in (
            "unavailable", "invalid", "absent")
        assert payload.get("readiness") is None or \
            payload["readiness"].get("passed") is not True

    def test_doctor_reports_corrupt_database_without_claiming_pass(
            self, tmp_path):
        from interface.cli import cli
        db = str(tmp_path / "corrupt.db")
        with open(db, "wb") as fh:
            fh.write(b"garbage" * 512)
        result = CliRunner().invoke(cli, ["memory-doctor", "--db", db, "--json"],
                                    catch_exceptions=True)
        payload = json.loads(result.output)
        readiness = payload.get("readiness")
        assert readiness is None or readiness.get("passed") is not True


# ── F03: a failed post-lock re-inspection never yields false success ───────

class TestF03PostLockReinspectionFailsClosed:
    def test_post_lock_reread_unavailable_refuses(self, tmp_path, monkeypatch):
        import core.memory.sqlite_migration as mig
        db = make_current_db(str(tmp_path / "m.db"))
        monkeypatch.setattr(mig, "_restate_readonly", lambda p: None)
        report = run_maintenance_migration(db)
        assert report.outcome == "failed"
        assert "re-inspection" in (report.failure or "")
        assert report.committed is not True


# ── F05: a DELETE-mode current database has an authorized recovery route ────

class TestF05JournalModeRecoveryRoute:
    def test_delete_mode_current_db_is_refused_by_startup(self, tmp_path):
        from core.memory.backends.sqlite_storage import SQLiteStorageBackend
        from core.memory.sqlite_contract import MemoryReadinessError
        db = make_current_db(str(tmp_path / "m.db"))
        conn = sqlite3.connect(db)
        conn.execute("PRAGMA journal_mode=DELETE")
        conn.commit()
        conn.close()
        with pytest.raises(MemoryReadinessError):
            SQLiteStorageBackend(db)

    def test_migration_restores_wal_without_rebuilding_fts(self, tmp_path):
        db = make_current_db(str(tmp_path / "m.db"))
        conn = sqlite3.connect(db)
        conn.execute("PRAGMA journal_mode=DELETE")
        conn.commit()
        conn.close()
        assert journal_mode(db) == "delete"

        report = run_maintenance_migration(db)
        assert report.outcome == "repaired", report.failure
        assert journal_mode(db) == "wal"
        steps = {s["step"]: s for s in report.steps}
        assert steps["fts_rebuild"]["status"] == "skipped"
        assert steps["replace_triggers"]["detail"].count("already canonical") == 1
        # readiness holds after the authorized transition
        conn = sqlite3.connect(sqlite_file_uri(db, "ro"), uri=True)
        try:
            assert validate_readiness(conn)["passed"]
        finally:
            conn.close()

    def test_second_invocation_is_idempotent(self, tmp_path):
        db = make_current_db(str(tmp_path / "m.db"))
        conn = sqlite3.connect(db)
        conn.execute("PRAGMA journal_mode=DELETE")
        conn.commit()
        conn.close()
        assert run_maintenance_migration(db).outcome == "repaired"
        second = run_maintenance_migration(db)
        assert second.outcome == "already_applied", second.outcome

    def test_unsupported_delete_db_stays_unmodified(self, tmp_path):
        db = str(tmp_path / "other.db")
        conn = sqlite3.connect(db)
        conn.execute("CREATE TABLE unrelated(x TEXT)")
        conn.commit()
        conn.close()
        before = sha256_file(db)
        report = run_maintenance_migration(db)
        assert report.outcome == "failed"
        assert journal_mode(db) == "delete"
        assert sha256_file(db) == before


# ── F06 / F07 / F08: backup publication, ownership and snapshot ─────────────

class TestF06F07F08Backup:
    def test_backup_publication_never_overwrites(self, tmp_path):
        src = make_current_db(str(tmp_path / "src.db"))
        dest = str(tmp_path / "dest.db")
        with open(dest, "wb") as fh:
            fh.write(b"PRE-EXISTING")
        result = create_online_backup(src, dest)
        assert result["ok"] is False
        with open(dest, "rb") as fh:
            assert fh.read() == b"PRE-EXISTING"

    def test_destination_appearing_before_publication_is_not_overwritten(
            self, tmp_path, monkeypatch):
        import core.memory.sqlite_migration as mig
        src = make_current_db(str(tmp_path / "src.db"))
        dest = str(tmp_path / "dest.db")
        real_link = os.link

        def racing_link(a, b, **kw):
            # a competing process creates the destination first
            with open(b, "wb") as fh:
                fh.write(b"RACER")
            return real_link(a, b, **kw)

        monkeypatch.setattr(mig.os, "link", racing_link)
        result = create_online_backup(src, dest)
        assert result["ok"] is False
        with open(dest, "rb") as fh:
            assert fh.read() == b"RACER", "the racer was overwritten"

    def test_temporary_artifact_is_exclusively_owned(self, tmp_path):
        src = make_current_db(str(tmp_path / "src.db"))
        dest = str(tmp_path / "dest.db")
        result = create_online_backup(src, dest)
        assert result["ok"] is True, result
        leftovers = [f for f in os.listdir(str(tmp_path))
                     if ".dest.db.tmp-" in f]
        assert not leftovers, leftovers

    def test_backup_verifies_a_complete_logical_snapshot(self, tmp_path):
        src = make_current_db(str(tmp_path / "src.db"), rows=3)
        dest = str(tmp_path / "dest.db")
        result = create_online_backup(src, dest)
        assert result["ok"] is True, result
        checks = result["checks"]
        assert checks["structural_integrity"] == "pass"
        assert checks["fts_rank1"] == "pass"
        assert checks["content_digest_preserved"] is True
        assert checks["identity_mapping_preserved"] is True
        assert checks["schema_equal_canonical_shape"] is True
        assert checks["trigger_contract_equal_source"] is True
        assert checks["index_contract_equal_source"] is True
        assert checks["content_rows"] == 3
        conn = sqlite3.connect(dest)
        try:
            digest = logical_content_digest(conn)
        finally:
            conn.close()
        assert digest["sha256"] == checks["content_sha256"]

    def test_backup_of_missing_source_creates_nothing(self, tmp_path):
        src = str(tmp_path / "missing.db")
        dest = str(tmp_path / "dest.db")
        result = create_online_backup(src, dest)
        assert result["ok"] is False
        assert not os.path.exists(src)
        assert not os.path.exists(dest)

    def test_backup_of_non_current_source_is_refused(self, tmp_path):
        src = str(tmp_path / "other.db")
        conn = sqlite3.connect(src)
        conn.execute("CREATE TABLE unrelated(x TEXT)")
        conn.commit()
        conn.close()
        result = create_online_backup(src, str(tmp_path / "dest.db"))
        assert result["ok"] is False
        assert not os.path.exists(str(tmp_path / "dest.db"))


# ── F12: structural ERROR is not corruption ──────────────────────────────────

class TestF12StructuralErrorVersusFail:
    def test_structural_error_does_not_claim_corruption(self, tmp_path,
                                                        monkeypatch):
        import core.memory.sqlite_migration as mig
        from core.memory.sqlite_integrity import IntegrityFinding
        db = make_current_db(str(tmp_path / "m.db"))

        def unavailable(conn):
            return IntegrityFinding("sqlite_structural_integrity",
                                     "PRAGMA integrity_check", "error",
                                     "simulated inspection failure", 0.0, 0.0)

        monkeypatch.setattr(mig, "check_structural_integrity", unavailable)
        report = run_maintenance_migration(db)
        assert report.outcome == "failed"
        assert report.outcome != "preserved_corrupt"
        assert "NOT a corruption verdict" in (report.failure or "")


# ── F13 / F34: quote-aware SQL normalization and strict parsers ────────────

class TestF13F34SqlSemantics:
    @pytest.mark.parametrize("left,right,equal", [
        ("SELECT 'unknown'", "SELECT 'UNKNOWN'", False),
        ("SELECT 'a -- b'", "SELECT 'a -- b'", True),
        ("SELECT 'a /* x */ b'", "SELECT 'a /* x */ b'", True),
        ("SELECT 'it''s'", "SELECT 'it''s'", True),
        ("SELECT 'it''s'", "SELECT 'its'", False),
        ("SELECT 'x'", 'SELECT "x"', False),
        ("SELECT 'Ünïcode'", "SELECT 'ünïcode'", False),
        ("SELECT  a  ,  b", "SELECT a,b", True),
        ("SELECT a -- c\nFROM t", "SELECT a FROM t", True),
    ])
    def test_normalization_preserves_literal_semantics(self, left, right,
                                                        equal):
        assert (normalize_sql(left) == normalize_sql(right)) is equal

    def test_identifiers_are_ascii_case_insensitive(self):
        assert normalize_sql('SELECT "Foo" FROM "Bar"') == \
            normalize_sql("select foo from bar")

    @pytest.mark.parametrize("bad", [
        "CREATE INDEX x ON t(a) TRAILING JUNK",
        "CREATE TABLE x(a)",
        "CREATE INDEX x ON t(",
        "CREATE INDEX x ON t(a) WHERE 'unterminated",
    ])
    def test_index_parser_rejects_unknown_grammar(self, bad):
        with pytest.raises(Exception):
            parse_create_index(bad)

    @pytest.mark.parametrize("bad", [
        "CREATE VIRTUAL TABLE t USING fts4(a)",
        "CREATE VIRTUAL TABLE t USING fts5(a) EXTRA",
        "CREATE TABLE t(a)",
    ])
    def test_fts_parser_rejects_unknown_grammar(self, bad):
        with pytest.raises(Exception):
            parse_create_virtual_table(bad)

    def test_expression_index_is_never_canonical(self, tmp_path):
        db = make_current_db(str(tmp_path / "m.db"))
        conn = sqlite3.connect(db)
        conn.execute("DROP INDEX idx_ke_layer")
        conn.execute("CREATE INDEX idx_ke_layer ON knowledge_entries(lower(content))")
        conn.commit()
        conn.close()
        conn = sqlite3.connect(sqlite_file_uri(db, "ro"), uri=True)
        try:
            audit = audit_index_contract(conn)
        finally:
            conn.close()
        # a same-name index with a different (expression) definition is
        # a RECOGNIZED wrong definition -> repairable, not unknown
        assert audit["classification"] == "repairable_drift"
        assert "idx_ke_layer" in audit["wrong_definition"]


# ── F14 / F33: index classification fails closed on unknown metadata ─────────

class TestF14F33IndexAudit:
    def test_missing_index_plus_unknown_extra_is_unknown_drift(self, tmp_path):
        db = make_current_db(str(tmp_path / "m.db"))
        conn = sqlite3.connect(db)
        conn.execute("DROP INDEX idx_ke_layer")
        conn.execute("CREATE INDEX idx_operator_custom ON knowledge_entries(summary)")
        conn.commit()
        conn.close()
        conn = sqlite3.connect(sqlite_file_uri(db, "ro"), uri=True)
        try:
            audit = audit_index_contract(conn)
        finally:
            conn.close()
        assert audit["classification"] == "unknown_drift"
        assert "idx_ke_layer" in audit["missing"]
        assert "idx_operator_custom" in audit["unknown_extra"]

    def test_pragma_failure_prevents_pass(self, tmp_path, monkeypatch):
        db = make_current_db(str(tmp_path / "m.db"))
        class _FailingPragma:
            """Delegates to the real connection but fails index_xinfo."""

            def __init__(self, inner):
                self._inner = inner

            def execute(self, sql, *a, **kw):
                if "index_xinfo" in str(sql):
                    raise sqlite3.OperationalError("simulated pragma failure")
                return self._inner.execute(sql, *a, **kw)

            def __getattr__(self, name):
                return getattr(self._inner, name)

        conn = sqlite3.connect(sqlite_file_uri(db, "ro"), uri=True)
        try:
            audit = audit_index_contract(_FailingPragma(conn))
        finally:
            conn.close()
        assert audit["classification"] == "unknown_drift"
        assert audit["unknown"], "a PRAGMA failure must prevent a PASS verdict"


# ── F15: global name collisions are refused, never dropped ──────────────────

class TestF15ObjectOwnership:
    def test_index_name_owned_by_another_table_is_refused(self, tmp_path):
        db = make_current_db(str(tmp_path / "m.db"))
        conn = sqlite3.connect(db)
        conn.execute("DROP INDEX idx_ke_layer")
        conn.execute("CREATE TABLE operator_table(x TEXT)")
        conn.execute("CREATE INDEX idx_ke_layer ON operator_table(x)")
        conn.commit()
        conn.close()
        conn = sqlite3.connect(sqlite_file_uri(db, "ro"), uri=True)
        try:
            audit = audit_index_contract(conn)
            state = inspect_migration_state(conn)
        finally:
            conn.close()
        assert audit["classification"] == "unknown_drift"
        assert "idx_ke_layer" in audit["foreign_owned"]
        assert state.state == "invalid"
        assert state.repairable is False

    def test_trigger_name_owned_by_another_table_is_refused(self, tmp_path):
        db = make_current_db(str(tmp_path / "m.db"))
        conn = sqlite3.connect(db)
        conn.execute("DROP TRIGGER ke_ad")
        conn.execute("CREATE TABLE operator_table(x TEXT)")
        conn.execute(
            "CREATE TRIGGER ke_ad AFTER INSERT ON operator_table"
            " BEGIN SELECT 1; END")
        conn.commit()
        conn.close()
        conn = sqlite3.connect(sqlite_file_uri(db, "ro"), uri=True)
        try:
            audit = audit_trigger_contract(conn)
        finally:
            conn.close()
        assert audit["classification"] == "unknown"
        assert "ke_ad" in audit["foreign_owned_triggers"]

    def test_unrelated_object_survives_a_refused_migration(self, tmp_path):
        db = make_current_db(str(tmp_path / "m.db"))
        conn = sqlite3.connect(db)
        conn.execute("DROP INDEX idx_ke_layer")
        conn.execute("CREATE TABLE operator_table(x TEXT)")
        conn.execute("CREATE INDEX idx_ke_layer ON operator_table(x)")
        conn.execute("INSERT INTO operator_table VALUES ('keep me')")
        conn.commit()
        conn.close()
        report = run_maintenance_migration(db)
        assert report.outcome == "failed"
        conn = sqlite3.connect(db)
        try:
            rows = conn.execute("SELECT x FROM operator_table").fetchall()
        finally:
            conn.close()
        assert rows == [("keep me",)], "the unrelated object was destroyed"


# ── F16 / F32: only explicitly documented legacy trigger SETS ───────────────

class TestF16F32LegacyTriggerSets:
    def test_documented_v1_set_is_recognized(self, tmp_path):
        db = make_legacy_v1_db(str(tmp_path / "v1.db"))
        conn = sqlite3.connect(db)
        try:
            audit = audit_trigger_contract(conn)
        finally:
            conn.close()
        assert audit["classification"] == "legacy_compatible"
        assert audit["triggers"]["ke_ad"] == "known_legacy_unsafe"

    def test_arbitrary_missing_trigger_set_is_not_legacy(self, tmp_path):
        db = make_current_db(str(tmp_path / "m.db"))
        conn = sqlite3.connect(db)
        conn.execute("DROP TRIGGER ke_ad")
        conn.commit()
        conn.close()
        conn = sqlite3.connect(sqlite_file_uri(db, "ro"), uri=True)
        try:
            audit = audit_trigger_contract(conn)
        finally:
            conn.close()
        assert audit["triggers"]["ke_ad"] == "missing"
        assert audit["classification"] == "unknown"

    def test_legacy_configurations_are_enumerated(self):
        assert ("canonical", "canonical", "known_legacy_unsafe") in \
            LEGACY_TRIGGER_CONFIGURATIONS
        for classes in LEGACY_TRIGGER_CONFIGURATIONS:
            assert "missing" not in classes


# ── F18 / F19: foreign-key detection and preflight enforcement ─────────────

class TestF18F19ForeignKeys:
    def test_prefix_similar_user_table_is_inspected(self, tmp_path):
        db = make_current_db(str(tmp_path / "m.db"))
        conn = sqlite3.connect(db)
        conn.execute("CREATE TABLE knowledge_entries_fts_custom("
                     " id INTEGER PRIMARY KEY, parent INTEGER REFERENCES "
                     "knowledge_entries(entry_id))")
        conn.commit()
        conn.close()
        conn = sqlite3.connect(sqlite_file_uri(db, "ro"), uri=True)
        try:
            finding = check_foreign_key_integrity(conn)
        finally:
            conn.close()
        assert finding.status == "pass"

    def test_fk_preflight_failure_refuses_before_journal_mode_change(
            self, tmp_path, monkeypatch):
        import core.memory.sqlite_migration as mig
        from core.memory.sqlite_integrity import IntegrityFinding
        db = make_current_db(str(tmp_path / "m.db"))

        def failing_fk(conn):
            return IntegrityFinding("foreign_key_consistency",
                                     "PRAGMA foreign_key_check", "fail",
                                     "simulated pre-existing violation",
                                     0.0, 0.0)

        monkeypatch.setattr(mig, "check_foreign_key_integrity", failing_fk)
        report = run_maintenance_migration(db)
        assert report.outcome == "failed"
        assert "foreign-key preflight" in (report.failure or "")


# ── F20 / F35: housekeeping contract and fresh-database classification ─────

class TestF20F35HousekeepingAndFreshness:
    def test_malformed_housekeeping_table_is_not_current(self, tmp_path):
        db = make_current_db(str(tmp_path / "m.db"))
        conn = sqlite3.connect(db)
        conn.execute(f"DROP TABLE {MIGRATIONS_TABLE}")
        conn.execute(f"CREATE TABLE {MIGRATIONS_TABLE} (migration_id TEXT)")
        conn.commit()
        conn.close()
        conn = sqlite3.connect(sqlite_file_uri(db, "ro"), uri=True)
        try:
            audit = audit_housekeeping_contract(conn)
            state = inspect_migration_state(conn)
        finally:
            conn.close()
        assert audit["classification"] in ("malformed", "unreadable")
        assert state.state == "invalid"

    def test_ledger_cardinality_is_enforced(self, tmp_path):
        """The ledger's primary key makes duplicate current rows
        impossible; the audit verifies that exactly one applied row for the
        current migration exists (a nonzero count is not enough)."""
        db = make_current_db(str(tmp_path / "m.db"))
        conn = sqlite3.connect(sqlite_file_uri(db, "ro"), uri=True)
        try:
            audit = audit_housekeeping_contract(conn)
        finally:
            conn.close()
        assert audit["classification"] == "canonical"
        assert audit["ledger"]["applied_current"] == 1
        assert audit["ledger"]["duplicate_current_rows"] == 0
        assert audit["ledger"]["current_row_statuses"] == ["applied"]
        assert audit["marker"]["current"] is True

    def test_database_with_only_a_view_is_not_absent(self, tmp_path):
        db = str(tmp_path / "view.db")
        conn = sqlite3.connect(db)
        conn.execute("CREATE TABLE t(x)")
        conn.execute("CREATE VIEW v AS SELECT x FROM t")
        conn.execute("DROP TABLE t")
        conn.commit()
        conn.close()
        conn = sqlite3.connect(sqlite_file_uri(db, "ro"), uri=True)
        try:
            state = inspect_migration_state(conn)
        finally:
            conn.close()
        assert state.state != "absent"


# ── F21: SQLite file URIs are safely encoded ────────────────────────────────

class TestF21UriEncoding:
    @pytest.mark.parametrize("name,encoded", [
        ("a#b.db", "%23"), ("a%b.db", "%25"), ("a b.db", "%20"),
        ("ü.db", "%C3%BC"),
    ])
    def test_uri_encodes_special_characters(self, tmp_path, name, encoded):
        target = tmp_path / name
        target.write_bytes(b"")
        uri = sqlite_file_uri(str(target), "ro")
        path_part = uri.split("?mode=")[0]
        assert encoded in path_part, path_part
        assert path_part.endswith(name.split(".")[0] + encoded + ".db") or \
            encoded in path_part
        assert uri.endswith("?mode=ro")

    def test_uri_encodes_a_question_mark(self, tmp_path):
        # '?' is not a legal Windows file name, so the encoding is checked
        # without creating the file
        uri = sqlite_file_uri(str(tmp_path / "a?b.db"), "ro")
        assert "%3F" in uri.split("?mode=")[0]

    def test_uri_is_absolute(self, tmp_path):
        uri = sqlite_file_uri("relative.db", "ro")
        assert uri.startswith("file:")
        assert "relative.db" in uri


# ── F22 / F23: service connections and initialization ───────────────────────

class TestF22F23ServiceLifecycle:
    def test_service_connection_does_not_change_the_journal_mode(self, tmp_path):
        from core.memory.backends.sqlite_storage import SQLiteStorageBackend
        db = make_current_db(str(tmp_path / "m.db"))
        backend = SQLiteStorageBackend(db)
        conn = sqlite3.connect(db)
        conn.execute("PRAGMA journal_mode=DELETE")
        conn.commit()
        conn.close()
        with pytest.raises(Exception):
            backend._connect()
        assert journal_mode(db) == "delete", "the service converted the mode"

    def test_missing_database_is_not_recreated_by_a_service_connection(
            self, tmp_path):
        from core.memory.backends.sqlite_storage import SQLiteStorageBackend
        db = make_current_db(str(tmp_path / "m.db"))
        backend = SQLiteStorageBackend(db)
        os.remove(db)
        with pytest.raises(sqlite3.Error):
            backend._connect()
        assert not os.path.exists(db), "the service silently recreated it"


# ── F24: the production boundary prevents access ───────────────────────────

class TestF24ProductionBoundary:
    def test_production_database_access_is_blocked(self):
        import importlib.util
        path = os.path.join(os.path.dirname(__file__), "_g4_protection.py")
        spec = importlib.util.spec_from_file_location("g4_protection_probe",
                                                      path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        repo = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
        protected = mod.protected_paths_for(repo)
        hit = mod._is_protected(
            os.path.join(repo, ".data", "memory", "unified.db"), protected)
        assert hit is not None, "a production database path must be protected"
        # a temporary path is NOT protected
        assert mod._is_protected(os.path.join(repo, "core", "main.py"),
                                 protected) is None

    def test_the_boundary_is_installed_in_this_process(self):
        import importlib.util
        path = os.path.join(os.path.dirname(__file__), "_g4_protection.py")
        spec = importlib.util.spec_from_file_location("g4_protection_probe2",
                                                      path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        repo = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
        protected = mod.protected_paths_for(repo)
        # the INSTALLED boundary raises its own class instance, so the
        # assertion uses the shared base class
        with pytest.raises(PermissionError):
            with open(os.path.join(repo, ".data", "memory",
                                   "unified.db"), "rb"):
                pass

    def test_memory_singleton_uses_the_temporary_path(self):
        import core.memory.unified_memory as um
        memory = um.get_unified_memory()
        assert "ocbrain-test-memory-" in str(memory._storage.db_path)


# ── F27 / F29 / F38: digests, transaction outcome and checkpoint honesty ───

class TestF27F29F38HonestReporting:
    def test_digest_detects_a_changed_value(self, tmp_path):
        db = make_current_db(str(tmp_path / "m.db"))
        conn = sqlite3.connect(db)
        try:
            before = logical_content_digest(conn)["sha256"]
            conn.execute("UPDATE knowledge_entries SET content='changed'")
            conn.commit()
            after = logical_content_digest(conn)["sha256"]
        finally:
            conn.close()
        assert before != after, "a changed value was not detected"

    def test_digest_is_stable_for_equal_content(self, tmp_path):
        db = make_current_db(str(tmp_path / "m.db"))
        conn = sqlite3.connect(db)
        try:
            first = logical_content_digest(conn)["sha256"]
            second = logical_content_digest(conn)["sha256"]
        finally:
            conn.close()
        assert first == second

    def test_pre_commit_fault_reports_a_verified_rollback(self, tmp_path):
        db = make_legacy_v1_db(str(tmp_path / "v1.db"))

        def boom(step):
            if step == "apply":
                raise RuntimeError("injected fault")

        report = run_maintenance_migration(db, fault_injection=boom)
        assert report.outcome == "failed"
        assert report.committed is False
        assert "rolled back" in (report.remediation or "").lower()
        assert report.verification["transaction_outcome_evidence"]

    def test_checkpoint_status_is_not_done_when_busy(self, tmp_path):
        db = make_legacy_v1_db(str(tmp_path / "v1.db"))
        report = run_maintenance_migration(db)
        assert report.outcome == "migrated", report.failure
        ck = report.checkpoint
        assert ck["status"] in ("completed", "blocked")
        if ck["busy"]:
            assert ck["status"] == "blocked"
            assert ck["truncated"] is False
        steps = {s["step"]: s for s in report.steps}
        assert steps["final_checkpoint"]["status"] == ck["status"]


# ── F35 / F36 / F37: classification, snapshot stability and lock ownership ──

class TestF35F36F37ClassificationAndLocks:
    def test_repair_scope_is_never_defaulted(self, tmp_path):
        from core.memory.sqlite_migration import _repair_scope_for_state
        from core.memory.sqlite_migration import MigrationStateResult
        broken = MigrationStateResult("repairable_drift", {"reason": "x"},
                                      "repair", repairable=True)
        assert _repair_scope_for_state(broken) is None, \
            "a scope-less repairable state must not authorize a broad repair"

    def test_lock_release_does_not_remove_a_foreign_lock(self, tmp_path):
        """F37: the release removes the pathname ONLY when it still refers
        to the lock object this process created."""
        from core.memory.sqlite_migration import _acquire_lock_file
        from core.memory.sqlite_migration import _release_lock_file
        lock = str(tmp_path / "x.lock")
        other = str(tmp_path / "other.lock")
        fd = _acquire_lock_file(lock)
        try:
            with open(other, "w", encoding="ascii") as fh:
                fh.write("someone else")
            # releasing with a DIFFERENT pathname must not remove that file
            _release_lock_file(other, fd)
            assert os.path.exists(other), "a foreign lock was removed"
        finally:
            if os.path.exists(other):
                os.remove(other)
            if os.path.exists(lock):
                os.remove(lock)
