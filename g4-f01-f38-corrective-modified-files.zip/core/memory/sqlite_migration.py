"""
core/memory/sqlite_migration.py — Memory-database migration lifecycle (Rev 3)

Rev 3 Amendment 2 separates three things that Rev 2 (Session 4C) had fused
inside `SQLiteStorageBackend._init_sync()`:

  1. Migration execution — ONLY here, via `run_maintenance_migration()`
     (exposed as the `ocbrain memory-migrate` CLI command), in a maintenance
     window.
  2. Migration-state verification — `inspect_migration_state()` /
     `read_migration_ledger()`, validation-only, no schema mutation.
  3. Memory-service readiness — the storage-backend constructor refuses
     readiness when migration is missing, incomplete, incompatible or
     unsupported; normal startup never mutates an existing database and never
     runs a rebuild (Amendment 2 §B).

Why the separation (Amendment 2 §C): a successful migration does not stop an
*old* application process from resuming writes with the defective write path
afterwards. The deployment contract in the report (and in the CLI command's
own help) therefore requires stopping/draining all processes, running the
maintenance migration, verifying its committed result, and only then starting
the new application version. Process fencing is NOT claimed here (Amendment
2 §D: otherwise explicitly out of scope until a real, tested protocol ships).

Concurrency protection for two independent migrators (Amendment 2 §E): an
advisory lock file plus `BEGIN IMMEDIATE`; the winner must RE-READ the
ledger after acquiring the write lock and must not repeat an already
committed migration.

A large rebuild can grow the WAL and need substantial free space: the runner
estimates and reports requirements from representative measurements
(Amendment 11), never deleting database/WAL/SHM files, and reports success
only after the commit succeeds (Amendment 2 §B.9).
"""

from __future__ import annotations

import getpass
import hashlib
import json
import logging
import os
import platform
import shutil
import sqlite3
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from core.memory.sqlite_contract import (
    CANONICAL_INDEX_DDL,
    CANONICAL_KNOWLEDGE_ENTRIES_DDL,
    CANONICAL_SCHEMA_STATEMENTS,
    CANONICAL_TRIGGER_DDL,
    CONTENT_TABLE,
    FTS_TABLE,
    META_SCHEMA_STATE,
    META_TABLE,
    MIGRATION_ID_CURRENT,
    MIGRATION_ID_V1,
    MIGRATION_NAME_V1,
    MIGRATION_NAME_V2,
    MIGRATIONS_TABLE,
    SCHEMA_STATE_FRESH_CURRENT,
    SCHEMA_STATE_MIGRATED,
    SCHEMA_STATES_CURRENT,
    normalize_sql,
    parse_create_index,
    sqlite_file_uri,
    trigger_audit_classification,
)
from core.memory.sqlite_integrity import (
    audit_housekeeping_contract,
    audit_index_contract,
    check_foreign_key_integrity,
    check_fts_integrity,
    check_structural_integrity,
    logical_content_digest,
    read_fts_configuration,
    run_full_integrity_validation,
    validate_readiness,
    verify_content_row_identity,
    audit_trigger_contract,
)
from core.memory.sqlite_runtime import (
    collect_connection_inventory,
    collect_runtime_inventory,
)

logger = logging.getLogger("ocbrain.memory.sqlite_migration")

# Representative disk-space factor for the maintenance window (Amendment 11).
# Measured in tests/test_g4_rev3_failure_recovery.py against representative
# synthetic content: WAL growth + FTS rebuild can worst-case approach ~2x the
# content table's bytes. This is an ESTIMATE for pre-flight reporting only —
# never a guarantee of required space.
REPRESENTATIVE_SPACE_FACTOR = 2.0

# Explicit checkpoint operations in the codebase (Amendment 10 inventory).
# Static table audited against the source: `grep wal_checkpoint core/`.
EXPLICIT_CHECKPOINT_SITES = [
    {
        "location": "core/runtime/state.py",
        "database": ".data/runtime_state.sqlite (runtime state store)",
        "operation": "PRAGMA wal_checkpoint(TRUNCATE)",
        "purpose": ("fold the small state DB's WAL back after "
                    "read-modify-write repair paths"),
        "owns_memory_db": False,
    },
    {
        "location": "core/memory/sqlite_migration.py",
        "database": "the memory DB under migration",
        "operation": "PRAGMA wal_checkpoint(TRUNCATE) after the maintenance commit",
        "purpose": ("close out the migration's WAL growth inside the "
                    "maintenance window (single-writer, verified quiescence)"),
        "owns_memory_db": True,
    },
]
# The memory backends (sqlite_storage / sqlite_archive / graph_engine) do NOT
# run explicit checkpoints; automatic checkpointing (default
# wal_autocheckpoint=1000 pages per connection) is left untouched — no global
# policy change is authorized by this remediation (Amendment 10).

MIGRATION_LOCK_SUFFIX = ".ocbrain_migrate.lock"


# ── Read-only inspection (lifecycle phase 2) ────────────────────────────────

@dataclass
class MigrationStateResult:
    state: str            # absent | current | legacy_pending_migration | invalid
    finding: Dict[str, Any] = field(default_factory=dict)
    remediation: str = ""
    # True ONLY for the fail-closed "invalid" drift case: the marker/ledger
    # say current but the ACTUAL schema is not canonical. Refuses readiness,
    # but the idempotent maintenance window may repair it.
    repairable: bool = False

    @property
    def is_ready_modal(self) -> bool:
        return self.state == "current"


def inspect_migration_state(conn: sqlite3.Connection) -> MigrationStateResult:
    """
    Read-only migration-state inspection of ONE database (Amendment 2 §B.2;
    Amendment 7: every database is judged by its own tables — no process
    global flag).

    F35: the "absent" verdict requires a database with NO schema objects at
    all — not merely no application TABLES. A file that already holds a
    view, index or trigger is never classified as absent (and therefore
    never silently initialized over).

    F20: the housekeeping tables and the migration ledger are verified
    against their exact documented contract and cardinality; a nonzero
    ledger count is never sufficient evidence of a current migration.

    F05: a database whose schema verifies current but whose journal mode
    was changed externally is a RECOGNIZED repairable drift with an
    explicit, narrow repair scope (restore WAL mode only).
    """
    try:
        objects = conn.execute(
            "SELECT type, name, tbl_name FROM sqlite_schema").fetchall()
    except sqlite3.DatabaseError as exc:
        return MigrationStateResult(
            "inspection_unavailable",
            {"reason": f"sqlite_schema unreadable: {exc}"},
            "database file may be corrupt: preserve it and investigate before "
            "running any migration")

    tables = {str(r[1]) for r in objects if str(r[0]) == "table"}
    non_table_objects = sorted(
        f"{str(r[0])}:{str(r[1])}" for r in objects if str(r[0]) != "table")

    if not objects:
        return MigrationStateResult(
            "absent",
            {"reason": "no schema objects at all — database creation and "
                       "initialization is the APPLICATION's startup path "
                       "(initialize_schema), never a function of the "
                       "migration runner (REV-G4-04)"},
            "")

    has_content = CONTENT_TABLE in tables
    has_meta = META_TABLE in tables
    has_ledger = MIGRATIONS_TABLE in tables

    if not has_content and not has_meta and not has_ledger:
        # Unknown non-application content already occupies this file (F35:
        # views/indexes/triggers count as content too).
        return MigrationStateResult(
            "invalid",
            {"reason": f"file contains unrelated schema objects "
                       f"(tables={sorted(tables)}, other={non_table_objects}); "
                       "initializing into it is not authorized"},
            "use a different database path after inspecting this file")

    if has_content and not has_meta:
        # Recognize legacy shapes only; anything unknown also fails closed.
        trig = audit_trigger_contract(conn)
        fts_cfg = read_fts_configuration(conn)
        if (trig["classification"] in ("canonical", "legacy_compatible")
                and fts_cfg.get("classification") == "canonical"):
            return MigrationStateResult(
                "legacy_pending_migration",
                {"reason": (
                    "pre-Rev3 database: recognized legacy/canonical trigger "
                    "state, but this database has no Rev 3 migration ledger "
                    "record; no validated rebuild/integrity run exists"),
                 "trigger_contract": trig["classification"]},
                ("stop all processes using this database, then run: "
                 "ocbrain memory-migrate --db <path>"))
        return MigrationStateResult(
            "invalid",
            {"reason": "unrecognized pre-Rev3 schema (trigger contract: "
                       f"{trig['classification']}, FTS configuration: "
                       f"{fts_cfg.get('classification')})"},
            "do not auto-migrate an unrecognized schema: inspect manually, "
            "then apply the maintenance migration explicitly")

    if has_meta and has_ledger:
        # Rev 3 independent fix (checklist C, part A): a "current" verdict is
        # granted ONLY when the ACTUAL schema verifies — trigger contract,
        # FTS configuration and content-table definition — not from the
        # marker+ledger rows alone (the candidate trusted those rows and
        # consequently served databases whose stored ke_ad was never even
        # canonical).
        # F20: the bookkeeping tables and the ledger are verified against
        # their exact documented contract and cardinality FIRST.
        housekeeping = audit_housekeeping_contract(conn)
        if housekeeping["classification"] != "canonical":
            return MigrationStateResult(
                "invalid",
                {"reason": ("housekeeping/ledger contract not satisfied: "
                            f"{housekeeping['reason']}"),
                 "housekeeping": housekeeping},
                "fail closed: the per-database bookkeeping is not in the "
                "documented shape; inspect it manually before any migration",
                repairable=False)

        mark = conn.execute(
            f"SELECT value FROM {META_TABLE} WHERE key=?", (META_SCHEMA_STATE,)
        ).fetchone()
        applied_v1 = housekeeping["ledger"]["applied_v1"]
        applied_current = housekeeping["ledger"]["applied_current"]
        marker_current = bool(mark) and str(mark[0]) in SCHEMA_STATES_CURRENT

        if marker_current and applied_current:
            trig = audit_trigger_contract(conn)
            fts_cfg = read_fts_configuration(conn)
            content_row = conn.execute(
                "SELECT sql FROM sqlite_schema WHERE type='table' AND name=?",
                (CONTENT_TABLE,)).fetchone()
            content_canonical = bool(content_row and str(content_row[0] or "")) \
                and normalize_sql(str(content_row[0])) == \
                normalize_sql(CANONICAL_KNOWLEDGE_ENTRIES_DDL)
            # REV-G4-03: 'current' requires the SEMANTIC index contract too —
            # a missing or wrong-definition canonical index means the marker/
            # ledger rows alone do not make this database ready.
            idx = audit_index_contract(conn)
            schema_verifies = (
                trig.get("classification") == "canonical"
                and fts_cfg.get("classification") == "canonical"
                and content_canonical
                and idx["classification"] == "canonical")
            # F05: the journal mode is part of the CURRENT contract. A
            # current-schema database whose journal mode was changed
            # externally is a RECOGNIZED repairable drift: the maintenance
            # command restores WAL mode (authorized transition) without
            # rebuilding the FTS index or replacing the triggers.
            journal_mode = "unknown"
            try:
                journal_mode = str(
                    conn.execute("PRAGMA journal_mode").fetchone()[0]).lower()
            except sqlite3.Error:
                journal_mode = "unknown"
            if schema_verifies and journal_mode == "delete":
                return MigrationStateResult(
                    "repairable_drift",
                    {"reason": (
                        "schema verifies canonical but the journal mode is "
                        "'delete' (changed externally); the authorized "
                        "recovery is to restore WAL mode only — no trigger "
                        "replacement, no FTS rebuild, no data change"),
                     "repair_scope": {
                         "journal_mode": "wal",
                         "triggers": False,
                         "indexes": ([], []),
                         "fts_rebuild": False,
                     },
                     "journal_mode": journal_mode},
                    "run ocbrain memory-migrate --db <path> (all processes "
                    "stopped) to restore the authorized WAL mode",
                    repairable=True)
            if schema_verifies:
                return MigrationStateResult(
                    "current",
                    {"reason": (
                        f"schema_state={mark[0]!r}, migration "
                        f"{MIGRATION_ID_CURRENT} applied, actual schema "
                        "verified canonical (triggers, FTS, content table "
                        f"AND index definitions), journal_mode="
                        f"{journal_mode!r}")})
            # REV-G4-03 repair policy — narrow, explicitly recognized states
            # ONLY; everything unknown stays fail-closed (never repaired).
            index_only_repairable = (
                trig.get("classification") == "canonical"
                and fts_cfg.get("classification") == "canonical"
                and content_canonical
                and idx["classification"] == "repairable_drift")
            legacy_repairable = (
                trig.get("classification") == "legacy_compatible"
                and fts_cfg.get("classification") == "canonical"
                and content_canonical
                and idx["classification"] in ("canonical", "repairable_drift"))
            if index_only_repairable or legacy_repairable:
                return MigrationStateResult(
                    "repairable_drift",
                    {"reason": (
                        "meta marker and ledger record the current migration, "
                        "but the actual schema does NOT verify (triggers: "
                        f"{trig.get('classification')}, FTS: "
                        f"{fts_cfg.get('classification')}, content table: "
                        f"{'canonical' if content_canonical else 'differs'}, "
                        f"indexes: {idx['classification']} — missing="
                        f"{idx['missing']}, wrong_definition="
                        f"{idx['wrong_definition']})"),
                     "repair_scope": {
                         "journal_mode": None,
                         "triggers": not index_only_repairable,
                         "indexes": (list(idx["missing"]),
                                      list(idx["wrong_definition"])),
                         "fts_rebuild": not index_only_repairable,
                     }},
                    "fail closed: inspect manually; the maintenance migration "
                    "is idempotent and can re-establish the verified "
                    "canonical contract: ocbrain memory-migrate --db <path>",
                    repairable=True)
            return MigrationStateResult(
                "invalid",
                {"reason": (
                    "meta marker and ledger record the current migration, "
                    "but the actual schema is NOT canonical and NOT a "
                    "recognized repairable state (triggers: "
                    f"{trig.get('classification')}, FTS: "
                    f"{fts_cfg.get('classification')}, content table: "
                    f"{'canonical' if content_canonical else 'differs'}, "
                    f"indexes: {idx['classification']}, unknown_extra="
                    f"{idx['unknown_extra']}) — unknown schema drift is "
                    "never automatically replaced")},
                "fail closed: inspect manually; unknown schema definitions "
                "require human review before any repair",
                repairable=False)

        if marker_current and applied_v1 and not applied_current:
            return MigrationStateResult(
                "legacy_pending_migration",
                {"reason": (
                    f"Rev 3 v1 migration ({MIGRATION_ID_V1}) applied, but "
                    "the corrected V2 contract (ke_ad 'delete'-command form, "
                    f"migration {MIGRATION_ID_CURRENT}) is NOT applied — the "
                    "V1-era stored ke_ad leaves deleted tokens MATCH-findable "
                    "and fails rank=1 (EVIDENCE_NOTE.md §3.1)")},
                "run ocbrain memory-migrate --db <path>")

        if marker_current and not applied_v1 and not applied_current:
            return MigrationStateResult(
                "invalid",
                {"reason": ("meta marker says current but the migration "
                            "ledger has no applied record — inconsistent "
                            "per-database state")},
                "run ocbrain memory-migrate --db <path> to re-establish a "
                "consistent ledger (idempotent)")

        return MigrationStateResult(
            "legacy_pending_migration",
            {"reason": f"meta marker present but not current: {mark!r}"},
            "run ocbrain memory-migrate --db <path>")

    return MigrationStateResult(
        "invalid",
        {"reason": f"unexpected table set: {sorted(tables)}"},
        "inspect manually before running the maintenance migration")


def read_migration_ledger(conn: sqlite3.Connection) -> List[Dict[str, Any]]:
    """Per-database ledger rows (Amendment 7 §4)."""
    out: List[Dict[str, Any]] = []
    try:
        rows = conn.execute(
            "SELECT migration_id, name, status, started_at, completed_at, "
            "applied_by, host_os, wal_bytes_before, wal_bytes_after "
            f"FROM {MIGRATIONS_TABLE} ORDER BY completed_at").fetchall()
    except sqlite3.Error:
        return out
    for row in rows:
        out.append({
            "migration_id": row[0], "name": row[1], "status": row[2],
            "started_at": row[3], "completed_at": row[4],
            "applied_by": row[5], "host_os": row[6],
            "wal_bytes_before": row[7], "wal_bytes_after": row[8],
        })
    return out


# ── Initialization (fresh databases only — never a legacy mutation) ─────────

def initialize_schema(conn: sqlite3.Connection) -> Dict[str, Any]:
    """
    Create the canonical schema on an *absent* database and record the fresh
    initialization in this database's own ledger.

    Scope guard (Amendment 2 §F): construction may call this ONLY when
    inspection returned state == "absent". Any pre-existing database (even an
    empty file with junk tables) is refused to validation instead — or handed
    to the maintenance command through an explicit, reviewed path.

    Transaction safety: the connection is switched to autocommit mode
    (isolation_level=None) and wrapped in an explicit BEGIN IMMEDIATE, so
    schema creation + ledger row commit as ONE unit (executescript would
    otherwise commit any implicit transaction mid-script).
    """
    started = time.time()
    applied_by = _applied_by()
    pre = {"state": "absent",
           "runtime": collect_runtime_inventory()["sqlite3_sqlite_version"]}

    isolation = conn.isolation_level
    conn.isolation_level = None
    try:
        conn.execute("BEGIN IMMEDIATE")
        for statement in CANONICAL_SCHEMA_STATEMENTS:
            conn.execute(statement)
        conn.execute(
            f"INSERT INTO {META_TABLE}(key, value) VALUES (?, ?)",
            (META_SCHEMA_STATE, SCHEMA_STATE_FRESH_CURRENT))
        conn.execute(
            f"INSERT INTO {MIGRATIONS_TABLE}("
            "migration_id, name, status, started_at, completed_at, applied_by, "
            "host_os, pre_checks_json, post_checks_json) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            (MIGRATION_ID_CURRENT, MIGRATION_NAME_V2, "applied", started, time.time(),
             applied_by, platform.platform(),
             json.dumps(pre), json.dumps({"initialized": "fresh"})))
        conn.execute("COMMIT")
    except Exception:
        try:
            conn.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        raise
    finally:
        conn.isolation_level = isolation
    return {"initialized": True, "applied_by": applied_by}


def _applied_by() -> str:
    try:
        user = getpass.getuser()
    except Exception:  # pragma: no cover
        user = "unknown"
    return f"{user}@{platform.node()} pid={os.getpid()}"


# ── Path precheck (REV-G4-02/04 — non-creating filesystem validation) ───────

SQLITE_HEADER_MAGIC = b"SQLite format 3\x00"


def _path_precheck(db_path: str) -> Optional[str]:
    """
    REV-G4-02/04: validate the requested migration target using ONLY
    non-creating filesystem operations, BEFORE any SQLite connection exists.

    Returns None when the path is an existing, readable, regular, non-empty
    SQLite database file; otherwise a short refusal reason. A missing path,
    a directory, an unreadable file, a zero-byte file and an invalid header
    are all refused here so nothing can be manufactured by accident.
    """
    if not os.path.exists(str(db_path)):
        return ("missing: the target database does not exist — a migration "
                "NEVER creates a database; fresh initialization is the "
                "application's own startup path (initialize_schema), and "
                "running the app once creates and initializes it")
    if not os.path.isfile(str(db_path)):
        return "not a regular file: the target path is not a database file"
    try:
        size = os.path.getsize(str(db_path))
    except OSError as exc:
        return f"unreadable: cannot stat the target file: {exc}"
    if size == 0:
        return ("zero-byte: an existing zero-byte file is NOT a fresh "
                "initialization target for the migration runner; the "
                "application's initialization path owns database creation")
    try:
        with open(str(db_path), "rb") as fh:
            header = fh.read(16)
    except OSError as exc:
        return f"unreadable: cannot read the target file: {exc}"
    if header != SQLITE_HEADER_MAGIC:
        return ("invalid header: the target file is not a SQLite database "
                "(magic header mismatch) — inspect it manually before any "
                "migration attempt")


# ── Amendment 11 — free-space estimate (report, never a guarantee) ──────────

def estimate_migration_space(db_path: str) -> Dict[str, Any]:
    """
    Representative-measurement based estimate of the extra space the
    maintenance window can require, and the free space actually visible.

    Content table bytes are measured; the FTS rebuild + WAL growth envelope
    uses REPRESENTATIVE_SPACE_FACTOR measured on synthetic datasets. This is
    an estimate, never a guarantee; the resulting report is written into the
    ledger row's pre-checks.

    REV-G4-02/04: the measurement connects READ-ONLY (mode=ro URI) and never
    creates a missing file; an unusable target is reported as an "error"
    result, not by manufacturing a database.
    """
    page_size = page_count = freelist = None
    content_bytes = None
    if not os.path.exists(str(db_path)):
        return {"error": (
            f"database file does not exist: {db_path} — refusing to create "
            "it for a space estimate (no connection was attempted that "
            "could create anything)")}
    try:
        conn = sqlite3.connect(sqlite_file_uri(db_path, "ro"), uri=True,
                               timeout=20.0)
        try:
            page_size = conn.execute("PRAGMA page_size").fetchone()[0]
            page_count = conn.execute("PRAGMA page_count").fetchone()[0]
            freelist = conn.execute("PRAGMA freelist_count").fetchone()[0]
            res = conn.execute(
                f"SELECT COALESCE(SUM(LENGTH(content) + LENGTH(COALESCE(summary, ''))), 0) "
                f"FROM {CONTENT_TABLE}").fetchone()
            content_bytes = int(res[0])
        finally:
            conn.close()
    except sqlite3.Error as exc:
        return {"error": (
            f"read-only space estimate unavailable ({exc}); no write-capable "
            "connection was used and nothing was created or modified")}
    db_bytes = (page_count * page_size) if page_size and page_count else None
    est_extra = (content_bytes * REPRESENTATIVE_SPACE_FACTOR
                 if content_bytes is not None else None)
    free_bytes = None
    try:
        free_bytes = shutil.disk_usage(os.path.dirname(os.path.abspath(db_path))).free
    except OSError:
        pass
    return {
        "db_bytes": db_bytes,
        "page_size": page_size,
        "page_count": page_count,
        "freelist_pages": freelist,
        "content_bytes_measured": content_bytes,
        "estimate_extra_bytes": est_extra,
        "estimate_basis": (
            f"content-table bytes x {REPRESENTATIVE_SPACE_FACTOR} "
            "representative measurement (WAL growth + FTS index rebuild); "
            "an estimate, NOT a guarantee (Amendment 11)"),
        "free_bytes": free_bytes,
        "sufficient_free_estimate": (
            bool(free_bytes and est_extra is not None
                 and free_bytes >= est_extra)),
    }


# ── Amendment 4 §D — snapshot-preserving backup (SQLite Online Backup API) ──

def create_online_backup(db_path: str, dest_path: str) -> Dict[str, Any]:
    """
    Consistent, verified logical snapshot via the SQLite Online Backup API.

    F06 — publication is ATOMIC and NON-OVERWRITING on every supported
    operating system: the temporary file is published with an exclusive
    link (`os.link`), which fails with EEXIST if the destination already
    exists (no overwrite, no TOCTOU window). `os.rename()` is deliberately
    NOT used — on POSIX it silently REPLACES an existing destination. If no
    atomic no-replace primitive is available, the operation FAILS CLOSED.

    F07 — the temporary artifact is allocated EXCLUSIVELY (O_CREAT|O_EXCL)
    by this invocation, its identity (device/inode) is recorded, and only
    that identity is ever removed. A pre-existing file is never deleted.

    F08 — ONE consistent snapshot: the source is opened READ-ONLY, a single
    read transaction is held across the source reads AND the backup call,
    and the source digest is compared with the digest of the produced
    copy. The verification battery (structural integrity, foreign keys,
    FTS rank=1, canonical schema/trigger/index contract, and a full
    type-aware logical content digest over EVERY stored value) runs against
    the TEMPORARY COPY.

    Source and destination protections:
      * a missing source is never created; the source must verify as a
        CURRENT memory database;
      * the destination must not exist (a dangling symlink counts as
        existing), must not alias the source (realpath AND device/inode
        identity), and must not be a directory;
      * on ANY failure only this operation's temporary artifact is removed.
    """
    import os
    import uuid

    # ── source precheck (non-creating) ──────────────────────────────────
    reason = _path_precheck(db_path)
    if reason:
        return {"ok": False, "error": f"source {reason}"}

    # REV-G4-01/05: a WAL source whose -shm scaffolding is missing cannot
    # be read without SQLite creating that -shm — fail closed instead.
    if os.path.exists(str(db_path) + "-wal") and \
            not os.path.exists(str(db_path) + "-shm"):
        return {"ok": False, "error": (
            "source WAL state cannot be snapshotted safely (a -wal exists "
            "but the -shm scaffolding is missing; opening the source would "
            "create the missing artifact) — fail closed")}

    src_abs = os.path.abspath(str(db_path))
    dest_abs = os.path.abspath(str(dest_path))
    if dest_abs == src_abs or os.path.realpath(dest_abs) == \
            os.path.realpath(src_abs):
        return {"ok": False, "error": (
            "source and destination resolve to the same file — refusing "
            "(alias/same-file case)")}
    # F06: a dangling symlink is an EXISTING name — os.path.exists() would
    # report False for it.
    if os.path.lexists(dest_path):
        return {"ok": False, "error": f"destination already exists: {dest_path}"}
    if os.path.isdir(dest_path):
        return {"ok": False, "error": f"destination is a directory: {dest_path}"}
    # F06: a hard link to the source is the same file under another name.
    try:
        src_stat = os.stat(src_abs)
        dest_stat = os.stat(dest_abs)
        if (src_stat.st_dev, src_stat.st_ino) == (dest_stat.st_dev,
                                                   dest_stat.st_ino):
            return {"ok": False, "error": (
                "destination is a hard link to the source — refusing")}
    except OSError:
        pass
    dest_dir = os.path.dirname(dest_abs) or "."
    if not os.path.isdir(dest_dir):
        return {"ok": False, "error": (
            f"destination directory does not exist: {dest_dir}")}

    # ── F07: exclusive temporary allocation ──────────────────────────────
    tmp_path = os.path.join(dest_dir, f".{os.path.basename(dest_abs)}.tmp-"
                             f"{uuid.uuid4().hex}")
    tmp_identity: Optional[Tuple[int, int]] = None
    try:
        fd = os.open(tmp_path, os.O_CREAT | os.O_EXCL | os.O_RDWR, 0o600)
        os.close(fd)
        st = os.stat(tmp_path)
        tmp_identity = (st.st_dev, st.st_ino)
    except OSError as exc:
        return {"ok": False, "error": (
            f"could not allocate an exclusive temporary file next to the "
            f"destination: {exc}")}

    published = False
    try:
        # ── ONE consistent source snapshot ───────────────────────────────
        src = sqlite3.connect(sqlite_file_uri(db_path, "ro"), uri=True,
                              timeout=20.0)
        try:
            state = inspect_migration_state(src)
            if state.state != "current":
                return {"ok": False, "error": (
                    f"source is not a verified current memory database "
                    f"(state={state.state!r}: {state.finding.get('reason', '')}) "
                    "— refusing to label it a backup source")}
            src.execute("BEGIN")          # deferred read transaction
            try:
                src_digest = logical_content_digest(src)
                src_schema = src.execute(
                    "SELECT name, sql FROM sqlite_schema WHERE sql IS NOT NULL "
                    "ORDER BY name").fetchall()
                src_schema_hash = hashlib.sha256(
                    repr(src_schema).encode("utf-8")).hexdigest()
                src_triggers = src.execute(
                    "SELECT name, sql FROM sqlite_schema WHERE type='trigger' "
                    "ORDER BY name").fetchall()
                src_triggers_hash = hashlib.sha256(
                    repr(src_triggers).encode("utf-8")).hexdigest()
                src_indexes = src.execute(
                    "SELECT name, sql FROM sqlite_schema WHERE type='index' "
                    "AND sql IS NOT NULL ORDER BY name").fetchall()
                src_indexes_hash = hashlib.sha256(
                    repr(src_indexes).encode("utf-8")).hexdigest()

                # ── the backup itself, on the SAME snapshot ──────────────
                dst = sqlite3.connect(tmp_path, timeout=20.0)
                try:
                    src.backup(dst)
                finally:
                    dst.close()
            finally:
                try:
                    src.execute("COMMIT")
                except sqlite3.Error:
                    pass
        finally:
            src.close()

        # ── verification of the produced copy ─────────────────────────────
        dst = sqlite3.connect(tmp_path, timeout=20.0)
        try:
            structural = check_structural_integrity(dst)
            fk = check_foreign_key_integrity(dst)
            fts1 = check_fts_integrity(dst)
            copy_digest = logical_content_digest(dst)
            copy_schema = dst.execute(
                "SELECT name, sql FROM sqlite_schema WHERE sql IS NOT NULL "
                "ORDER BY name").fetchall()
            copy_schema_hash = hashlib.sha256(
                repr(copy_schema).encode("utf-8")).hexdigest()
            copy_triggers = dst.execute(
                "SELECT name, sql FROM sqlite_schema WHERE type='trigger' "
                "ORDER BY name").fetchall()
            copy_triggers_hash = hashlib.sha256(
                repr(copy_triggers).encode("utf-8")).hexdigest()
            copy_indexes = dst.execute(
                "SELECT name, sql FROM sqlite_schema WHERE type='index' "
                "AND sql IS NOT NULL ORDER BY name").fetchall()
            copy_indexes_hash = hashlib.sha256(
                repr(copy_indexes).encode("utf-8")).hexdigest()
            identity_ok = copy_digest["rowid_mapping"] == \
                src_digest["rowid_mapping"]
            content_ok = copy_digest["sha256"] == src_digest["sha256"]
        finally:
            dst.close()

        checks = {
            "structural_integrity": structural.status,
            "foreign_keys": fk.status,
            "fts_rank1": fts1.status,
            # the established key name is preserved (schema shape equality
            # against the verified source snapshot)
            "schema_equal_canonical_shape": copy_schema_hash == src_schema_hash,
            "schema_equal_source": copy_schema_hash == src_schema_hash,
            "trigger_contract_equal_source":
                copy_triggers_hash == src_triggers_hash,
            "index_contract_equal_source":
                copy_indexes_hash == src_indexes_hash,
            "identity_mapping_preserved": identity_ok,
            "content_digest_preserved": content_ok,
            "content_rows": copy_digest["rows"],
            "content_sha256": copy_digest["sha256"],
        }
        verified_ok = (
            structural.status == "pass"
            and fk.status in ("pass", "not_applicable")
            and fts1.status == "pass"
            and copy_schema_hash == src_schema_hash
            and copy_triggers_hash == src_triggers_hash
            and copy_indexes_hash == src_indexes_hash
            and identity_ok
            and content_ok
        )
        if not verified_ok:
            return {"ok": False, "error": (
                "the temporary backup failed verification; only the "
                "temporary artifact was removed — the destination was never "
                "created"),
                "checks": checks}

        # ── F06: atomic, non-overwriting publication ─────────────────────
        # os.link() is an atomic no-replace primitive: it fails with EEXIST
        # when the destination name exists, and it never replaces it.
        try:
            os.link(tmp_path, dest_path)
        except FileExistsError:
            return {"ok": False, "error": (
                f"destination appeared before publication: {dest_path} — "
                "refusing to overwrite it; its original content is "
                "untouched")}
        except OSError as exc:
            return {"ok": False, "error": (
                f"atomic no-replace publication failed ({exc}); refusing to "
                "publish (a non-atomic rename could overwrite a concurrent "
                "destination)")}
        published = True
        # The temporary file has been published under its final name; the
        # link is removed, the published file stays.
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        return {
            "ok": True,
            "method": "sqlite3.Connection.backup (Online Backup API)",
            "destination": dest_path,
            "identities_compared": len(copy_digest["rowid_mapping"]),
            "identity_preserved": bool(identity_ok and content_ok),
            "checks": checks,
            "note": ("VACUUM INTO is not used for backups: with hidden-rowid "
                     "documents, only an explicit identity verification like "
                     "this one — or the Online Backup API — may be relied "
                     "on (DEBT-045 remains OPEN)"),
        }
    except sqlite3.Error as exc:
        return {"ok": False, "error": f"backup failed: {exc}"}
    finally:
        if not published:
            # F07: remove ONLY the artifact this operation created, and only
            # if it is still the file we created.
            try:
                st = os.stat(tmp_path)
                if tmp_identity is None or (st.st_dev, st.st_ino) == tmp_identity:
                    os.remove(tmp_path)
            except OSError:
                pass


# ── Amendment 10 — checkpoint & WAL operational inventory ───────────────────

def collect_checkpoint_inventory(db_path: str) -> Dict[str, Any]:
    """
    Amendment 10: the explicit operational checkpoint/WAL report.

    REV-G4-01: this is a READ-ONLY diagnostic. Filesystem facts (existence,
    size) of the main database and ALL sidecars (-wal, -shm, -journal) are
    collected WITHOUT opening any SQLite connection. Where connection-level
    facts are needed, a strictly read-only connection is used; if SQLite
    cannot safely inspect the current WAL state read-only (e.g. a -wal that
    would require recovery, or a missing -shm), the inspection is reported
    as explicitly UNAVAILABLE — it never falls back to a write-capable
    connection, which could checkpoint, recover or otherwise change the
    database it claims to merely observe.
    """
    inv: Dict[str, Any] = {
        "explicit_checkpoint_sites": EXPLICIT_CHECKPOINT_SITES,
        "automatic_checkpointing": (
            "enabled; every memory-backend connection keeps SQLite's default "
            "wal_autocheckpoint=1000 pages — no global change is authorized "
            "by the FTS remediation"),
        "checkpoint_scheduling_owner": (
            "automatic: per-connection SQLite autocheckpoint; explicit: the "
            "maintenance runner's post-commit TRUNCATE checkpoint (and the "
            "unrelated runtime-state repair paths in core/runtime/state.py)"),
        "multiple_processes_can_initiate": (
            "yes for automatic checkpoints (any writer connection); the "
            "maintenance TRUNCATE checkpoint runs only in the maintenance "
            "window after the quiescence gate"),
        "readers_preventing_completion": (
            "a TRUNCATE/PASSIVE checkpoint fails to free the WAL (busy) when "
            "readers/writers hold it; SQLite then retries automatically on "
            "later checkpoints; the runner records busy=1 honestly and never "
            "forces readers out"),
        "wal_monitoring": (
            "WAL file sizes are reported here and in maintenance results; no "
            "continuous -wal wake-up polling exists by design"),
        "inspection_read_only": True,
    }
    for suffix, key in (("", "db_bytes"), ("-wal", "wal_bytes"),
                        ("-shm", "shm_bytes"), ("-journal", "journal_bytes")):
        path = str(db_path) + suffix
        try:
            inv[key] = os.path.getsize(path)
        except OSError:
            inv[key] = None
    if not os.path.exists(str(db_path)):
        # Independent Rev 3 fix (checklist E): a read-only diagnostic must
        # not create the database it was pointed at. The pre-fix
        # `sqlite3.connect(str(db_path))` below silently created a 0-byte
        # file for a missing path (probe artifact:
        # docs/reports/independent-g4-fts/evidence/affected-3_50_4/
        # probe_cli_diagnostics.txt). Refuse honestly instead.
        inv["connection_facts"] = {
            "error": (
                f"database file does not exist: {db_path} — refusing to "
                "create it from a read-only inventory (no connection "
                "attempted, nothing was written)"),
            "unavailable": True,
        }
        return inv
    # REV-G4-01: a WAL database whose -shm scaffolding is missing cannot be
    # opened read-only WITHOUT letting SQLite create that -shm — an artifact
    # creation a read-only diagnostic must not perform. Report the
    # inspection as unavailable WITHOUT attempting any connection.
    if inv["wal_bytes"] is not None and inv["shm_bytes"] is None:
        inv["connection_facts"] = {
            "unavailable": True,
            "error": (
                "read-only inspection unavailable: the database has a -wal "
                "but its -shm scaffolding is missing; opening it (even "
                "read-only) would let SQLite create the missing -shm — an "
                "artifact a read-only inspection must not create. No "
                "connection was attempted and nothing was modified."),
        }
        return inv
    # REV-G4-01: strictly read-only connection facts; failure is reported as
    # UNAVAILABLE (fail closed), never replaced by a writable connection.
    try:
        conn = sqlite3.connect(sqlite_file_uri(db_path, "ro"), uri=True,
                               timeout=20.0)
        try:
            inv["connection_facts"] = collect_connection_inventory(conn)
            inv["connection_facts"]["read_only_connection"] = True
        finally:
            conn.close()
    except sqlite3.Error as exc:
        inv["connection_facts"] = {
            "unavailable": True,
            "error": (
                f"read-only inspection unavailable: {exc} — the current WAL "
                "state cannot be inspected without opening the database "
                "write-capable (which could trigger recovery/checkpointing); "
                "no fallback connection was used and nothing was modified"),
        }
    return inv


# ── Amendment 2 §B — the maintenance runner ─────────────────────────────────

@dataclass
class MaintenanceReport:
    db_path: str
    outcome: str                       # migrated | migrated_post_commit_fault |
                                       # already_applied | failed | preserved_corrupt
    steps: List[Dict[str, Any]] = field(default_factory=list)
    verification: Dict[str, Any] = field(default_factory=dict)
    ledger_row: Dict[str, Any] = field(default_factory=dict)
    space_estimate: Dict[str, Any] = field(default_factory=dict)
    wal_bytes_before: Optional[int] = None
    wal_bytes_after: Optional[int] = None
    checkpoint: Dict[str, Any] = field(default_factory=dict)
    failure: Optional[str] = None
    remediation: str = ""
    preserved_files: List[str] = field(default_factory=list)
    # Independent Rev 3 fix (reporting honesty): True iff the migration
    # transaction actually COMMITTED. A fault after this point must never be
    # described as "the transaction rolled back; nothing was recorded".
    committed: Optional[bool] = None

    def as_dict(self) -> Dict[str, Any]:
        return {k: getattr(self, k) for k in self.__dataclass_fields__}


def _repair_scope_for_state(state: MigrationStateResult) -> Optional[Dict[str, Any]]:
    """
    REV-G4-03 / F17: translate an inspection result into the EXPLICIT repair
    scope the maintenance runner may execute.

    None means "not a repair" (an ordinary legacy migration with the full
    trigger+rebuild sequence, or a non-repairable refusal).

    F17: there is NO broad fallback any more. A repairable state must carry a
    COMPLETE, VALIDATED scope; a missing, malformed or contradictory scope
    fails closed (None) instead of authorizing trigger replacement, index
    recreation or an FTS rebuild by default.
    """
    if state.state != "repairable_drift" or not state.repairable:
        return None
    scope = state.finding.get("repair_scope")
    if not isinstance(scope, dict):
        return None
    # Required keys and their permitted types.
    allowed = {"journal_mode", "triggers", "indexes", "fts_rebuild"}
    if set(scope) - allowed:
        return None
    if "triggers" not in scope or not isinstance(scope["triggers"], bool):
        return None
    if "fts_rebuild" not in scope or not isinstance(scope["fts_rebuild"], bool):
        return None
    idx = scope.get("indexes")
    if not (isinstance(idx, (tuple, list)) and len(idx) == 2
            and all(isinstance(x, (tuple, list)) for x in idx)):
        return None
    jm = scope.get("journal_mode", None)
    if jm is not None and jm not in ("wal", None):
        return None
    # Contradiction check: an FTS rebuild without trigger replacement, or an
    # index list naming indexes that the scope does not otherwise allow, is
    # not a coherent scope.
    if scope["fts_rebuild"] and not scope["triggers"]:
        return None
    normalized = {
        "journal_mode": jm,
        "triggers": scope["triggers"],
        "indexes": (list(idx[0]), list(idx[1])),
        "fts_rebuild": scope["fts_rebuild"],
    }
    return normalized


def _repair_journal_mode_only(db_path: str, report: MaintenanceReport,
                               step, fault) -> MaintenanceReport:
    """
    F05: restore the authorized WAL journal mode on a database whose schema
    verifies canonical but whose journal mode was changed externally.

    Scope is deliberately narrow: NO migration transaction, NO trigger
    replacement, NO index work, NO FTS rebuild, NO ledger write. The
    transition is verified (the mode actually returned by SQLite) and the
    full readiness contract is re-checked afterwards.
    """
    fault("journal_mode")
    conn: Optional[sqlite3.Connection] = None
    try:
        conn = sqlite3.connect(str(db_path), timeout=20.0)
        conn.isolation_level = None
        before = str(conn.execute("PRAGMA journal_mode").fetchone()[0])
        conn.execute("PRAGMA journal_mode=WAL")
        after = str(conn.execute("PRAGMA journal_mode").fetchone()[0])
        step("journal_mode", "restored", f"{before} -> {after}")
        if after.lower() != "wal":
            report.outcome = "failed"
            report.failure = (
                f"the authorized WAL transition did not take effect "
                f"(SQLite reports {after!r})")
            report.remediation = (
                "the database was not otherwise modified: no trigger, index "
                "or FTS change was made and no ledger row was written.")
            report.committed = None
            return report
        readiness = validate_readiness(conn)
        report.verification["final_readiness"] = {
            "passed": readiness["passed"],
            "checks": readiness["checks"],
        }
        if not readiness["passed"]:
            report.outcome = "failed"
            report.failure = (
                "readiness failed after the journal-mode repair: " +
                "; ".join(
                    f"{c['name']}: {c['detail']}"
                    for c in readiness["checks"]
                    if c["status"] in ("fail", "error")))
            report.remediation = (
                "the journal mode was restored, but the canonical readiness "
                "contract does not hold; inspect the database manually.")
            report.committed = None
            return report
        report.outcome = "repaired"
        report.committed = None      # no migration transaction was opened
        report.remediation = (
            "the journal mode was restored to WAL; no schema, trigger, index, "
            "FTS or ledger change was made by this run.")
        step("replace_triggers", "skipped",
             "journal-mode-only repair: the triggers were not "
             "replaced (they were already canonical)")
        step("fts_rebuild", "skipped",
             "journal-mode-only repair: the FTS index was not "
             "rebuilt (no trigger or index change was needed)")
        step("migration", "repaired",
             "journal mode restored (no migration transaction opened)")
        return report
    except sqlite3.Error as exc:
        report.outcome = "failed"
        report.failure = f"journal-mode repair failed: {exc}"
        report.remediation = ("the database was not otherwise modified.")
        report.committed = None
        return report
    finally:
        if conn is not None:
            try:
                conn.close()
            except sqlite3.Error:
                pass


def _restate_readonly(db_path: str) -> Optional[MigrationStateResult]:
    """
    Amendment 2 §E post-lock re-read of the migration state, STRICTLY
    READ-ONLY (REV-G4-01/02: a read-only connection cannot checkpoint,
    recover, convert a journal mode or mutate content).

    Used for the "there is nothing to do" decision, where opening a write
    transaction would itself be a persistent side effect. Returns None
    when the database cannot be inspected read-only — the caller then
    keeps the earlier state and reports honestly.
    """
    try:
        ro = sqlite3.connect(sqlite_file_uri(db_path, "ro"), uri=True, timeout=20.0)
    except sqlite3.Error:
        return None
    try:
        return inspect_migration_state(ro)
    except sqlite3.Error:
        return None
    finally:
        ro.close()


def run_maintenance_migration(
    db_path: str,
    *,
    fault_injection: Optional[Callable[[str], None]] = None,
    run_final_checkpoint: bool = True,
    busy_timeout_ms: int = 20000,
) -> MaintenanceReport:
    """
    The dedicated maintenance migration (Amendment 2 §B) for ONE database.

    Sequence (Amendment 2 §B + Amendment 3 §B):
      1. quiescence: the caller must have stopped/drained all processes using
         this database; an advisory lock file is taken on top of SQLite's own
         write lock,
      2. whole-database structural integrity BEFORE touching a legacy
         database — corruption stops everything and the database is
         preserved for recovery (nothing is "repaired" by an FTS rebuild),
      3. acquire migration serialization (advisory lock + BEGIN IMMEDIATE),
      4. RE-read the migration state after acquiring the lock (Am. §E),
      5. apply the migration (canonical triggers; FTS external-content
         rebuild),
      6. verify: content-row identity, FTS integrity, retrieval, whole-
         database structural check, FK re-check (Amendment 3 §B.5–7),
      7. record the migration in THIS database's ledger,
      8. commit — success is reported only after the commit succeeds
         (Amendment 2 §B.9),
      9. optional post-commit TRUNCATE checkpoint (recorded honestly).

    `fault_injection` is a TEST hook: if provided, it is called with the step
    name before critical steps so tests can raise controlled faults (e.g. a
    SQLITE_FULL equivalent). Production callers never set it.
    """
    report = MaintenanceReport(db_path=db_path, outcome="failed")
    lock_path = str(db_path) + MIGRATION_LOCK_SUFFIX
    lock_fd: Optional[int] = None
    _prepared_already_applied = False
    # F29: the durable ledger row as it is BEFORE this run's transaction
    pre_ledger_row: Optional[Tuple[Any, ...]] = None
    committed = False

    def _step(name: str, status: str, detail: str = "") -> None:
        report.steps.append({"step": name, "status": status, "detail": detail})
        logger.info("[memory-migrate] %s (%s)%s", name, status,
                    f" {detail}" if detail else "")

    def _fault(step_name: str) -> None:
        if fault_injection is not None:
            _step("fault_injection", "invoked", f"step={step_name}")
            fault_injection(step_name)

    conn: Optional[sqlite3.Connection] = None
    try:
        _fault("pre_flight")

        # ── REV-G4-02 preflight redesign ────────────────────────────────────
        # Ordering (each boundary refuses BEFORE any persistent change):
        #   1. non-creating path validation (missing / directory / zero-byte
        #      / invalid header refused with NO SQLite connection at all),
        #   2. advisory maintenance lock (serialization before any
        #      connection operation that could alter state),
        #   3. raw recovery-evidence preservation BEFORE any SQLite open
        #      (a hot -journal or dirty -wal can be replayed/recovered by
        #      the first SQLite open; the evidence is captured first),
        #   4. read-only space estimate (never creates a file),
        #   5. STRICTLY read-only inspection + classification
        #      (supported / recognized legacy / repairable drift /
        #      unsupported) — an inspection the database will not permit
        #      read-only is reported unavailable and the run FAILS CLOSED,
        #   6. unsupported / absent targets are refused BEFORE any
        #      persistent database change (no journal-mode conversion,
        #      no -wal/-shm creation),
        #   7. only an ELIGIBLE target reaches journal_mode=WAL +
        #      BEGIN IMMEDIATE (see the TOCTOU note below),
        #   8. state is re-read inside the transaction after the
        #        serialization is held (Amendment 2 §E).
        precheck = _path_precheck(db_path)
        if precheck is not None:
            report.outcome = "failed"
            report.failure = f"target refused before any connection: {precheck}"
            report.remediation = (
                "nothing was opened, created or modified (no database, WAL, "
                "SHM or rollback-journal artifact exists because of this "
                "run). Create databases only through the application's own "
                "initialization path; point the migration at an existing, "
                "recognized memory database.")
            _step("target_precheck", "refused", precheck)
            return report
        _step("target_precheck", "ok", "existing regular SQLite file")

        # Advisory maintenance lock BEFORE any SQLite open (REV-G4-02 #3):
        # independent migrators serialize before any state-touching
        # connection exists.
        lock_fd = _acquire_lock_file(lock_path)
        _step("maintenance_lock", "acquired", os.path.basename(lock_path))
        _fault("lock")

        # Raw recovery-evidence preservation BEFORE any SQLite open
        # (REV-G4-06): if -wal/-shm/-journal artifacts exist, the first
        # SQLite open could trigger recovery and destroy the original
        # evidence. Copy first (byte-verified), never move, never delete.
        recovery_artifacts = [sfx for sfx in ("-wal", "-shm", "-journal")
                              if os.path.exists(str(db_path) + sfx)]
        if recovery_artifacts:
            _fault("recovery_preservation")
            report.preserved_files = _preserve_recoverable_state(
                db_path, reason=(
                    "pre-migration recovery evidence preserved BEFORE any "
                    "SQLite open (hot journal / WAL state); originals "
                    "retained untouched"))
            _step("recovery_evidence_preserved", "ok",
                  f"artifacts={recovery_artifacts}")

        # Read-only space estimate (REV-G4-02/04: mode=ro, never creates).
        report.space_estimate = estimate_migration_space(db_path)
        _step("space_estimate", "measured",
              json.dumps({k: report.space_estimate.get(k)
                          for k in ("estimate_extra_bytes", "free_bytes",
                                    "estimate_basis", "error")},
                         default=str))

        report.wal_bytes_before = _wal_size(db_path)

        # Strictly read-only inspection + pre-integrity (REV-G4-02 #5). A
        # mode=ro connection can neither checkpoint, recover, convert, nor
        # create anything; if the current WAL state cannot be inspected
        # read-only the run fails closed (report honestly) instead of
        # opening the database write-capable.
        _fault("inspection")
        structural = foreign_pre = None
        state: Optional[MigrationStateResult] = None
        inspection_error: Optional[str] = None
        try:
            ro = sqlite3.connect(sqlite_file_uri(db_path, "ro"), uri=True,
                                 timeout=busy_timeout_ms / 1000.0)
            try:
                structural = check_structural_integrity(ro)
                foreign_pre = check_foreign_key_integrity(ro)
                if structural.status == "pass":
                    state = inspect_migration_state(ro)
            finally:
                ro.close()
        except sqlite3.Error as exc:
            inspection_error = str(exc)
        report.verification["pre_foreign_keys"] = (
            foreign_pre.as_dict() if foreign_pre
            else {"status": "error", "detail": "not run (inspection "
                  "unavailable)"})
        # The established runner step contract (Amendment 2 §B) is
        # preserved: the pre-integrity and pre-foreign-key checks are
        # reported as steps even though they now run READ-ONLY (REV-G4-02).
        _step("pre_integrity_check",
              structural.status if structural else "unavailable",
              structural.detail if structural else
              "inspection unavailable (read-only open refused)")
        _step("pre_foreign_key_check",
              foreign_pre.status if foreign_pre else "unavailable",
              foreign_pre.detail if foreign_pre else
              "inspection unavailable (read-only open refused)")

        if inspection_error is not None:
            report.outcome = "failed"
            report.failure = (
                f"cannot safely inspect the database read-only: "
                f"{inspection_error}")
            report.remediation = (
                "the current WAL/journal state resists read-only "
                "inspection; recovery evidence (if any) was preserved raw "
                "before any SQLite open. Do NOT delete or trim files; "
                "investigate with the database stopped and drained.")
            report.verification["inspection"] = {"unavailable": True}
            return report

        # F19: the foreign-key PREFLIGHT is ENFORCED — a pre-existing
        # violation or an unavailable FK inspection must stop the run BEFORE
        # any persistent journal-mode change. The previous behaviour recorded
        # the finding and continued, letting the violation survive until
        # post-migration verification (after the database had already been
        # converted to WAL).
        if foreign_pre is not None and foreign_pre.status in ("fail", "error"):
            report.outcome = "failed"
            report.failure = (
                "refusing migration: the foreign-key preflight did not pass "
                f"({foreign_pre.status}): {foreign_pre.detail}")
            report.remediation = (
                "the pre-existing foreign-key state must be resolved (or the "
                "inspection made available) before any migration; nothing was "
                "opened write-capable and the journal mode was NOT changed.")
            _step("migration", "refused",
                  f"foreign-key preflight {foreign_pre.status}")
            return report

        if structural.status != "pass":
            # F12: a structural ERROR (the check could not complete) is NOT
            # proof of corruption. Only an actual integrity FAIL is treated
            # as confirmed corruption (preserve and refuse); an ERROR is an
            # unavailable inspection (refuse WITHOUT claiming corruption).
            if structural.status == "error":
                report.outcome = "failed"
                report.failure = (
                    "the structural integrity inspection could not complete "
                    f"({structural.detail}); this is NOT a corruption verdict")
                report.remediation = (
                    "the database was not modified: no journal-mode change, "
                    "no schema change and no ledger row. The recovery "
                    "evidence (if any) was preserved raw before any SQLite "
                    "open. Investigate the I/O or locking condition with all "
                    "processes stopped.")
                report.verification["pre_integrity"] = structural.as_dict()
                _step("pre_integrity_check", "unavailable",
                      structural.detail)
                return report
            # Amendment 3 §B.2: stop, preserve, do NOT conceal via rebuild.
            report.outcome = "preserved_corrupt"
            report.failure = (
                f"whole-database structural corruption detected before "
                f"migration: {structural.detail}")
            report.remediation = (
                "database preserved untouched; do not delete or repair "
                "files in place; investigate recovery from the preserved "
                "copy before any migration attempt")
            report.verification["pre_integrity"] = structural.as_dict()
            # extend (not overwrite): the pre-open recovery-evidence set
            # stays listed alongside this preservation set (REV-G4-06).
            report.preserved_files = report.preserved_files + \
                _preserve_corrupt_database(db_path, structural.detail)
            return report
        report.verification["pre_integrity"] = structural.as_dict()

        # Classification BEFORE any persistent change (REV-G4-02 #6): state
        # is still None only if the structural check failed above.
        assert state is not None
        repair_scope = _repair_scope_for_state(state)
        if state.state == "absent":
            conn = None
            _prepared_already_applied = True  # nothing to roll back
            report.outcome = "failed"
            report.failure = (
                "refusing migration in state='absent': a migration NEVER "
                "creates or initializes a database (REV-G4-04)")
            report.remediation = (
                "database creation is the application's own initialization "
                "path: start the application once on this (configured) "
                "database path and it will initialize the canonical schema "
                "with its own ledger; then no migration is needed. Nothing "
                "was created or modified by this run.")
            _step("migration", "refused",
                  "absent targets are not migration targets")
            return report
        if state.state == "current" and not repair_scope:
            # Amendment 2 §E: re-read the migration state AFTER acquiring
            # the serialization lock — the pre-lock inspection is not
            # trusted. The advisory lock is held, so a READ-ONLY re-read
            # is authoritative for this "nothing to do" decision and cannot
            # mutate the database (no write transaction is opened for a
            # database that is already current).
            state_after_lock = _restate_readonly(db_path)
            if state_after_lock is None:
                # F03: a FAILED post-lock re-inspection must never reuse the
                # pre-lock state for a success verdict. The authoritative
                # second inspection did not complete -> fail closed.
                conn = None
                _prepared_already_applied = True
                report.outcome = "failed"
                report.failure = (
                    "the post-lock re-inspection could not be completed; "
                    "the pre-lock state was NOT reused for a success verdict")
                report.remediation = (
                    "nothing was opened write-capable and no persistent "
                    "database setting was changed. Investigate the database "
                    "with all processes stopped and re-run the maintenance "
                    "command.")
                _step("re_read_migration_state", "unavailable",
                      "post-lock re-inspection failed")
                return report
            report.steps.append({
                "step": "re_read_migration_state",
                "status": state_after_lock.state,
                "detail": state_after_lock.finding.get("reason", "")})
            state = state_after_lock
            repair_scope = _repair_scope_for_state(state)
            if state.state == "current" and not repair_scope:
                conn = None
                _prepared_already_applied = True
                report.outcome = "already_applied"
                _step("migration", "skipped",
                      "migration already applied and the actual schema "
                      "verifies canonical")
                return report
        if state.state not in ("legacy_pending_migration",) \
                and not repair_scope:
            conn = None
            _prepared_already_applied = True
            report.outcome = "failed"
            report.failure = (
                f"refusing migration in state={state.state!r}: "
                f"{state.finding.get('reason', '')}"
            )
            report.remediation = state.remediation + (
                " — nothing was opened write-capable and no persistent "
                "database setting was changed (journal mode and all "
                "sidecars are untouched).")
            _step("migration", "refused", state.state)
            return report

        # F05: a JOURNAL-MODE-ONLY repair is an authorized PERSISTENT
        # TRANSITION, not a schema migration. It opens no migration
        # transaction, replaces no trigger, recreates no index, rebuilds no
        # FTS index and writes no ledger row: it restores the WAL mode and
        # verifies the result.
        if (repair_scope is not None
                and repair_scope.get("journal_mode") == "wal"
                and not repair_scope["triggers"]
                and not repair_scope["fts_rebuild"]
                and not repair_scope["indexes"][0]
                and not repair_scope["indexes"][1]):
            conn = None
            _prepared_already_applied = True
            return _repair_journal_mode_only(db_path, report, _step, _fault)

        # ELIGIBLE target only past this point (supported legacy migration,
        # or explicitly recognized repairable drift).
        _fault("journal_mode")
        conn = sqlite3.connect(str(db_path), timeout=busy_timeout_ms / 1000.0)
        conn.isolation_level = None          # manual txn control (see below)
        # TOCTOU note (documented, deliberate): PRAGMA journal_mode=WAL is
        # persistent and CANNOT run inside a transaction, so there is a
        # window between the read-only classification and this statement.
        # Under the deployment contract ALL application processes are
        # stopped and drained for the maintenance window (Amendment 2 §C) —
        # no other process can mutate the database in that window. The
        # advisory lock serializes independent migrators. Process fencing is
        # NOT claimed (Amendment 2 §D).
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute(f"PRAGMA busy_timeout={busy_timeout_ms}")
        conn.row_factory = sqlite3.Row

        # Amendment 2 §B.2: acquire migration serialization.
        conn.execute("BEGIN IMMEDIATE")
        _step("migration_lock", "acquired", "BEGIN IMMEDIATE")
        # F29: capture the durable ledger row as it is BEFORE this
        # transaction writes anything — it is the baseline against which a
        # post-failure reconciliation decides whether THIS run committed (a
        # fresh-initialized database already carries a ledger row, so the
        # mere presence of a row proves nothing).
        try:
            pre_ledger_row = conn.execute(
                f"SELECT status, completed_at FROM {MIGRATIONS_TABLE} "
                "WHERE migration_id=?", (MIGRATION_ID_CURRENT,)).fetchone()
        except sqlite3.Error:
            # A legacy database has no ledger table yet (this very migration
            # creates it): there is no pre-transaction row to compare with.
            pre_ledger_row = None

        # Amendment 2 §B.3/§E: re-read the migration state AFTER acquiring
        # the write lock (in-transaction) — a pre-lock state inspection is
        # not trusted.
        state = inspect_migration_state(conn)
        report.steps.append({"step": "re_read_migration_state",
                             "status": state.state,
                             "detail": state.finding.get("reason", "")})
        repair_scope = _repair_scope_for_state(state)
        if state.state == "current":
            # An independent migrator already committed this migration while
            # we were waiting — do NOT repeat it.
            conn.execute("ROLLBACK")
            _step("migration", "skipped",
                  "ledger shows this migration already applied (re-read "
                  "after lock)")
            report.outcome = "already_applied"
            _prepared_already_applied = True
            return report
        if state.state == "absent":
            # Lost a race against an initialized-then-refused state? Refuse
            # honestly (REV-G4-04): absent is never a migration target.
            conn.execute("ROLLBACK")
            report.outcome = "failed"
            report.failure = (
                "re-read after lock reports state='absent': a migration "
                "NEVER initializes a database (REV-G4-04)")
            report.remediation = (
                "the application's initialization path owns database "
                "creation; the transaction was rolled back.")
            return report
        if repair_scope:
            _step("repair_drift", "accepted",
                  "recognized repairable state: " + json.dumps(repair_scope))
        elif state.state != "legacy_pending_migration":
            conn.execute("ROLLBACK")
            report.outcome = "failed"
            report.failure = (
                f"refusing migration in state={state.state!r}: "
                f"{state.finding.get('reason', '')}"
            )
            report.remediation = state.remediation
            return report

        _fault("apply")

        # Apply: canonical trigger set — but ONLY known definitions are ever
        # replaced (REV-G4-03 repair policy): unknown trigger definitions
        # abort the migration fail-closed instead of being dropped.
        trig_live = audit_trigger_contract(conn)
        if trig_live.get("unknown_triggers") or any(
                t not in ("canonical", "known_legacy_unsafe", "missing")
                for t in trig_live["triggers"].values()):
            raise RuntimeError(
                "unknown trigger definitions present "
                f"(classification={trig_live.get('classification')}, "
                f"triggers={trig_live['triggers']}, unknown="
                f"{trig_live.get('unknown_triggers')}) — fail closed: "
                "unknown schema is never automatically replaced; inspect "
                "manually and decide explicitly")
        replaced: List[str] = []
        if repair_scope is None or repair_scope.get("triggers"):
            for name in ("ke_ai", "ke_au", "ke_ad"):
                row = conn.execute(
                    "SELECT sql FROM sqlite_schema WHERE type='trigger' "
                    "AND name=?", (name,)).fetchone()
                current_sql = str(row[0]) if row is not None else ""
                if current_sql and trigger_audit_classification(
                        current_sql, name) == "canonical":
                    continue
                conn.execute(f"DROP TRIGGER IF EXISTS {name}")
                conn.execute(CANONICAL_TRIGGER_DDL[name])
                replaced.append(name)
        _step("replace_triggers", "ok",
              f"replaced={replaced or 'none (already canonical)'}")

        # Indexes: create missing canonical indexes AND repair same-name
        # wrong-definition ones (REV-G4-03). Unknown EXTRA indexes and
        # unparseable definitions are never dropped — the final readiness
        # gate fails closed on them instead.
        idx_live = audit_index_contract(conn)
        if idx_live["unparseable"] or idx_live["unknown_extra"]:
            raise RuntimeError(
                "unknown index drift on the content table "
                f"(unparseable={idx_live['unparseable']}, unknown_extra="
                f"{idx_live['unknown_extra']}) — fail closed: unknown index "
                "schema is never automatically dropped or replaced")
        created_idx: List[str] = []
        repaired_idx: List[str] = []
        for name in CANONICAL_INDEX_DDL:
            cls = idx_live["indexes"][name]["classification"]
            if cls == "canonical":
                continue
            conn.execute(f"DROP INDEX IF EXISTS {name}")
            conn.execute(CANONICAL_INDEX_DDL[name])
            (created_idx if cls == "missing" else repaired_idx).append(name)
        _step("ensure_indexes", "ok",
              f"created={created_idx or 'none (already canonical)'} "
              f"repaired={repaired_idx or 'none'}")

        # FTS external-content rebuild from the content table — ONLY when
        # the repair actually touched triggers (or a legacy migration).
        # An index-only repair must NOT unnecessarily rebuild the FTS index
        # (REV-G4-03 safe-repair policy).
        if repair_scope is None or repair_scope.get("fts_rebuild"):
            _fault("rebuild")
            conn.execute(f"INSERT INTO {FTS_TABLE}({FTS_TABLE}) VALUES ('rebuild')")
            _step("fts_rebuild", "ok")
        else:
            _step("fts_rebuild", "skipped",
                  "index-only repair: FTS index left untouched")

        _fault("verify")

        # Verify: content-row identity + FTS + whole-database integrity + FK.
        identity = verify_content_row_identity(conn)
        report.verification["content_row_identity"] = {
            "passed": identity["passed"],
            "checks": [f.as_dict() for f in identity["checks"]],
        }
        if not identity["passed"]:
            raise RuntimeError(
                "content-row identity verification failed: "
                + "; ".join(f"{f.name}: {f.detail}"
                            for f in identity["checks"]
                            if f.status in ("fail", "error")))

        full = run_full_integrity_validation(conn)
        report.verification["post_integrity"] = full
        if not full["passed"]:
            raise RuntimeError(
                "post-migration integrity validation failed: "
                + "; ".join(
                    f"{f.scope}/{f.name}: {f.detail}"
                    for f in full["finding_objects"]
                    if f.status in ("fail", "error")))
        _step("verification", "ok", f"total_cost_s={full['total_cost_s']}")

        # Record the migration in THIS database's ledger.
        _fault("record")
        if not _table_exists(conn, META_TABLE):
            # Legacy state normally lacks the housekeeping tables; they are
            # part of the canonical contract (per-database ledger, Am. 7).
            for statement in CANONICAL_SCHEMA_STATEMENTS:
                if statement.startswith("CREATE TABLE IF NOT EXISTS _ocbrain_"):
                    conn.execute(statement)
        mark = conn.execute(
            f"SELECT value FROM {META_TABLE} WHERE key=?",
            (META_SCHEMA_STATE,)).fetchone()
        if mark is None:
            conn.execute(
                f"INSERT INTO {META_TABLE}(key, value) VALUES (?, ?)",
                (META_SCHEMA_STATE, SCHEMA_STATE_MIGRATED))
        else:
            conn.execute(
                f"UPDATE {META_TABLE} SET value=? WHERE key=?",
                (SCHEMA_STATE_MIGRATED, META_SCHEMA_STATE))
        wal_at_record = _wal_size(db_path)
        conn.execute(
            f"INSERT INTO {MIGRATIONS_TABLE}(migration_id, name, status, "
            "started_at, completed_at, applied_by, host_os, pre_checks_json, "
            "post_checks_json, wal_bytes_before, wal_bytes_after) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?) "
            # drift-repair re-application: refresh the same ledger row
            "ON CONFLICT(migration_id) DO UPDATE SET "
            "name=excluded.name, status=excluded.status, "
            "started_at=excluded.started_at, completed_at=excluded.completed_at, "
            "applied_by=excluded.applied_by, host_os=excluded.host_os, "
            "pre_checks_json=excluded.pre_checks_json, "
            "post_checks_json=excluded.post_checks_json, "
            "wal_bytes_before=excluded.wal_bytes_before, "
            "wal_bytes_after=excluded.wal_bytes_after",
            (MIGRATION_ID_CURRENT, MIGRATION_NAME_V2, "applied",
             time.time(), time.time(), _applied_by(), platform.platform(),
             json.dumps({"space": report.space_estimate,
                         "pre_integrity": report.verification.get("pre_integrity"),
                         "pre_foreign_keys": report.verification.get("pre_foreign_keys")},
                        default=str),
             json.dumps(report.verification, default=str),
             report.wal_bytes_before, wal_at_record))
        _step("record_migration", "ok")

        # REV-G4-03 / §6 invariant 18: the migration must not commit its
        # ledger entry merely because the data-integrity checks passed — the
        # complete canonical READINESS contract must pass on the
        # in-transaction state (marker + ledger included) BEFORE the commit.
        _fault("final_readiness")
        final_readiness = validate_readiness(conn)
        report.verification["final_readiness"] = {
            "passed": final_readiness["passed"],
            "checks": final_readiness["checks"],
        }
        if not final_readiness["passed"]:
            raise RuntimeError(
                "final readiness contract FAILED after the repair: "
                + "; ".join(
                    f"{c['name']}: {c['detail']}"
                    for c in final_readiness["checks"]
                    if c["status"] in ("fail", "error")))
        _step("final_readiness", "ok",
              "canonical readiness contract verified pre-commit")

        # Commit. Success is reported only after the commit succeeds.
        _fault("commit")
        conn.execute("COMMIT")
        committed = True
        report.committed = True
        _step("commit", "ok")
        report.outcome = "migrated"

        if run_final_checkpoint:
            _fault("checkpoint")
            busy, log_pages, ck_pages = conn.execute(
                "PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
            busy = int(busy)
            log_pages = int(log_pages)
            ck_pages = int(ck_pages)
            # F38: a busy checkpoint is NOT a completed checkpoint. The
            # migration transaction itself stays committed and successful —
            # the checkpoint status is reported separately and honestly
            # (blocked / incomplete), with the frame counts that show what
            # was (and was not) checkpointed.
            ck_status = "completed" if busy == 0 else "blocked"
            report.checkpoint = {
                "operation": "PRAGMA wal_checkpoint(TRUNCATE)",
                "status": ck_status,
                "busy": busy,
                "wal_frames": log_pages,
                "checkpointed_frames": ck_pages,
                "truncated": bool(busy == 0),
                "note": (
                    "busy=0: the WAL was checkpointed and truncated; "
                    "readers were never forced"
                    if busy == 0 else
                    "busy=1: the checkpoint was BLOCKED by a concurrent "
                    "reader/writer — the WAL was NOT truncated and NOT fully "
                    "checkpointed. The migration transaction itself remains "
                    "committed and successful; only the checkpoint is "
                    "incomplete. Retry with all OCBrain processes stopped "
                    "and drained; readers are never forced out."),
            }
            _step("final_checkpoint", ck_status,
                  f"busy={busy} wal_frames={log_pages} "
                  f"checkpointed={ck_pages}")
        # WAL growth measurement taken while the connection is still open (a
        # closed WAL connection legitimately removes the -wal file).
        report.wal_bytes_after = _wal_size(db_path)
        _step("wal_measurement", "measured",
              f"before={report.wal_bytes_before} after={report.wal_bytes_after}")
        row = conn.execute(
            f"SELECT migration_id, name, status, completed_at FROM "
            f"{MIGRATIONS_TABLE} WHERE migration_id=?", (MIGRATION_ID_CURRENT,)
        ).fetchone()
        if row is not None:
            report.ledger_row = {
                "migration_id": row[0], "name": row[1],
                "status": row[2], "completed_at": row[3],
            }
    except sqlite3.OperationalError as exc:
        if committed:
            # Independent Rev 3 fix (checklist C): a fault AFTER the commit
            # (e.g. the TRUNCATE checkpoint or the WAL measurement) did NOT
            # roll anything back - say so, instead of the rollback text.
            report.outcome = "migrated_post_commit_fault"
            report.failure = (
                f"{type(exc).__name__} AFTER the migration commit: {exc}")
            report.remediation = (
                "The migration transaction was COMMITTED before this fault "
                "occurred: the canonical schema, the verification results "
                "and the ledger record are durable. NEVER delete or manually "
                "trim database/WAL/SHM files to recover (Amendment 11). Only "
                "the post-commit epilogue (TRUNCATE checkpoint / WAL "
                "measurement) was interrupted. Remedy: re-run "
                "`ocbrain memory-migrate --db <path>` - it re-reads the state "
                "after locking and reports already_applied with no side "
                "effects - or pass --skip-checkpoint to skip the epilogue "
                "checkpoint step.")
            report.verification["failure_classified"] = \
                _classify_migration_failure(str(exc))
            report.verification["post_commit_fault"] = True
            report.steps.append({"step": "post_commit_fault", "status":
                                 "recorded", "detail": (
                                     "migration committed before this "
                                     "fault; durable state real")})
        else:
            # F29: a failure BEFORE the commit does not prove that nothing
            # was written. The durable state is re-read to establish the
            # outcome (committed / confirmed rollback / uncertain).
            _reconcile_transaction_outcome(report, conn, db_path, exc,
                                            pre_ledger_row)
    except Exception as exc:
        if committed:
            report.outcome = "migrated_post_commit_fault"
            report.failure = (
                f"{type(exc).__name__} AFTER the migration commit: {exc}")
            report.remediation = (
                "The migration transaction was COMMITTED before this fault "
                "occurred: the canonical schema, the verification results "
                "and the ledger record are durable. NEVER delete or manually "
                "trim database/WAL/SHM files to recover (Amendment 11). Only "
                "the post-commit epilogue (TRUNCATE checkpoint / WAL "
                "measurement) was interrupted. Remedy: re-run "
                "`ocbrain memory-migrate --db <path>` - it re-reads the state "
                "after locking and reports already_applied with no side "
                "effects - or pass --skip-checkpoint to skip the epilogue "
                "checkpoint step.")
            report.verification["failure_classified"] = \
                _classify_migration_failure(str(exc))
            report.verification["post_commit_fault"] = True
            report.steps.append({"step": "post_commit_fault", "status":
                                 "recorded", "detail": (
                                     "migration committed before this "
                                     "fault; durable state real")})
        else:
            # F29: a failure BEFORE the commit does not prove that nothing
            # was written. The durable state is re-read to establish the
            # outcome (committed / confirmed rollback / uncertain).
            _reconcile_transaction_outcome(report, conn, db_path, exc,
                                            pre_ledger_row)
    finally:
        if conn is not None:
            if not _prepared_already_applied:
                try:
                    # Only an OPEN transaction is rolled back here; the
                    # F29 reconciliation may already have rolled it back
                    # (a "no transaction is active" error is not a failure).
                    if conn.in_transaction:
                        conn.execute("ROLLBACK")
                except sqlite3.Error as rollback_exc:
                    # F29: a swallowed ROLLBACK exception does NOT prove
                    # that the transaction rolled back. If the outcome was
                    # not already established, it becomes UNCERTAIN.
                    report.verification["rollback_error"] = str(rollback_exc)
                    if report.outcome == "failed" and report.committed is False:
                        report.outcome = "outcome_uncertain"
                        report.committed = None
                        report.failure = (
                            f"{report.failure} (the ROLLBACK could not be "
                            f"confirmed: {rollback_exc})")
                        report.remediation = (
                            "the transaction outcome could NOT be "
                            "established: the rollback failed. Inspect the "
                            "database's ledger row before re-running the "
                            "maintenance command.")
            try:
                conn.close()
            except sqlite3.Error:
                pass
        if lock_fd is not None:
            _release_lock_file(lock_path, lock_fd)

    if report.outcome in ("migrated", "migrated_post_commit_fault") \
            and report.wal_bytes_after is None:
        # Fallback when the checkpoint step was disabled: measure before the
        # last connection closed (post-close the WAL file may not exist on
        # all platforms).
        report.wal_bytes_after = _wal_size(db_path)
    return report


def _durable_migration_state(db_path: str) -> Dict[str, Any]:
    """
    Re-open the database READ-ONLY and inspect the durable migration ledger
    (F29). Never writes; never converts a journal mode.

    Returns {"inspectable": bool, "ledger_row": tuple | None,
    "error": str | None} where ledger_row is (status, completed_at).
    """
    try:
        conn = sqlite3.connect(sqlite_file_uri(db_path, "ro"), uri=True,
                                timeout=10.0)
    except sqlite3.Error as exc:
        return {"inspectable": False, "ledger_row": None, "error": str(exc)}
    try:
        row = conn.execute(
            f"SELECT status, completed_at FROM {MIGRATIONS_TABLE} "
            "WHERE migration_id=?", (MIGRATION_ID_CURRENT,)).fetchone()
        return {"inspectable": True,
                "ledger_row": None if row is None else (str(row[0]), row[1]),
                "error": None}
    except sqlite3.OperationalError as exc:
        # A legacy database has no ledger table yet: that is "no row", not
        # "the inspection failed".
        if "no such table" in str(exc).lower():
            return {"inspectable": True, "ledger_row": None, "error": None}
        return {"inspectable": False, "ledger_row": None, "error": str(exc)}
    except sqlite3.Error as exc:
        return {"inspectable": False, "ledger_row": None, "error": str(exc)}
    finally:
        try:
            conn.close()
        except sqlite3.Error:
            pass


def _reconcile_transaction_outcome(report: "MaintenanceReport",
                                    conn: Optional[sqlite3.Connection],
                                    db_path: str, exc: BaseException,
                                    pre_ledger_row: Optional[Tuple[Any, ...]]
                                    ) -> None:
    """
    F29: establish the durable transaction outcome instead of ASSUMING a
    rollback.

    The evidence is the durable ledger row COMPARED WITH the row that
    existed before this transaction started (a fresh-initialized database
    already carries a ledger row — its mere presence proves nothing about
    THIS run):

    * the durable row differs from the pre-transaction row -> this run
      COMMITTED;
    * the durable row is unchanged (or absent, as before) -> the transaction
      ROLLED BACK — reported only with this evidence;
    * the durable state could not be read, or the connection state is
      ambiguous -> UNCERTAIN (`outcome_uncertain`). A confirmed rollback is
      never claimed without evidence.
    """
    durable: Dict[str, Any] = {}
    in_txn: Optional[bool] = None
    # F29: a transaction that is still open is rolled back FIRST (safely),
    # so the outcome can be classified from evidence instead of assumption.
    rollback_error: Optional[str] = None
    try:
        if conn is not None and conn.in_transaction:
            try:
                conn.execute("ROLLBACK")
            except sqlite3.Error as rollback_exc:
                rollback_error = str(rollback_exc)
    except sqlite3.Error as exc:
        rollback_error = str(exc)
    try:
        in_txn = bool(conn.in_transaction) if conn is not None else None
    except sqlite3.Error:
        in_txn = None
    durable = _durable_migration_state(db_path)
    pre = tuple(pre_ledger_row) if pre_ledger_row is not None else None
    durable_row = durable.get("ledger_row")
    committed_now = bool(
        durable.get("inspectable") and durable_row is not None
        and (pre is None or durable_row != pre))
    report.verification["transaction_outcome_evidence"] = {
        "durable_ledger_row": durable_row,
        "pre_transaction_ledger_row": pre,
        "durable_inspectable": durable.get("inspectable"),
        "durable_error": durable.get("error"),
        "connection_in_transaction": in_txn,
        "connection_opened": conn is not None,
        "rollback_error": rollback_error,
    }
    if committed_now:
        report.outcome = "migrated_post_commit_fault"
        report.committed = True
        report.failure = (
            f"{type(exc).__name__} during maintenance, but the durable ledger "
            f"shows the migration WAS committed: {exc}")
        report.remediation = (
            "the migration transaction WAS committed (verified through the "
            "durable ledger): the canonical schema, the verification results "
            "and the ledger record are durable. NEVER delete or manually trim "
            "database/WAL/SHM files to recover (Amendment 11). Re-run "
            "`ocbrain memory-migrate --db <path>` to confirm already_applied.")
        report.verification["post_commit_fault"] = True
    elif durable.get("inspectable") and durable_row == pre \
            and (in_txn is False or conn is None):
        report.outcome = "failed"
        report.committed = False
        report.failure = f"{type(exc).__name__} during maintenance: {exc}"
        report.remediation = (
            "the transaction rolled back (verified: the durable ledger is "
            "unchanged from the pre-transaction state); fix the underlying "
            "cause, then re-run `ocbrain memory-migrate --db <path>`. NEVER "
            "delete or manually trim database/WAL/SHM files to recover "
            "(Amendment 11).")
    else:
        report.outcome = "outcome_uncertain"
        report.committed = None
        report.failure = (
            f"{type(exc).__name__} during maintenance and the transaction "
            f"outcome could NOT be established: {exc}")
        report.remediation = (
            "the durable state of this database is UNKNOWN: the ledger row "
            "could not be re-read or the connection state is ambiguous. "
            "Inspect the database's ledger row and schema manually (with all "
            "processes stopped) before re-running the maintenance command; "
            "do NOT delete or trim any file (Amendment 11).")
    report.verification["failure_classified"] = \
        _classify_migration_failure(str(exc))


def _table_exists(conn: sqlite3.Connection, name: str) -> bool:
    """
    Re-open the database READ-ONLY and inspect the durable migration ledger
    (F29). Never writes; never converts a journal mode.

    Returns {"inspectable": bool, "ledger_row": bool | None,
    "error": str | None}.
    """
    try:
        conn = sqlite3.connect(sqlite_file_uri(db_path, "ro"), uri=True,
                                timeout=10.0)
    except sqlite3.Error as exc:
        return {"inspectable": False, "ledger_row": None, "error": str(exc)}
    try:
        row = conn.execute(
            f"SELECT status FROM {MIGRATIONS_TABLE} WHERE migration_id=?",
            (MIGRATION_ID_CURRENT,)).fetchone()
        return {"inspectable": True, "ledger_row": row is not None,
                "error": None}
    except sqlite3.Error as exc:
        return {"inspectable": False, "ledger_row": None, "error": str(exc)}
    finally:
        try:
            conn.close()
        except sqlite3.Error:
            pass




def _table_exists(conn: sqlite3.Connection, name: str) -> bool:
    row = conn.execute(
        "SELECT 1 FROM sqlite_schema WHERE type='table' AND name=?", (name,)
    ).fetchone()
    return row is not None


def _wal_size(db_path: str) -> Optional[int]:
    try:
        return os.path.getsize(str(db_path) + "-wal")
    except OSError:
        return None


def _acquire_lock_file(lock_path: str):
    """
    Advisory lock: O_CREAT|O_EXCL is atomic on POSIX and Windows NTFS, so two
    independent migrators serialize on file creation; the crash of a migrator
    leaves a stale lock only if the process itself is killed mid-run (lock
    removal is in the finally path). Advisory by design — NOT a fencing
    protocol; the deployment contract delivers process quiescence.

    F30/F37: the lock's IDENTITY is established here — the PID is written
    and flushed while the descriptor is still open, and a failure to write
    it removes the lock again instead of leaving an UNOWNED lock behind.
    A descriptor failure closes the descriptor.
    """
    fd = None
    deadline = time.time() + 20.0
    while True:
        try:
            fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            break
        except FileExistsError:
            if time.time() > deadline:
                raise RuntimeError(
                    f"migration lock busy: {lock_path} exists — another "
                    "maintenance run may be active; if you are certain no "
                    "run is active, remove the advisory lock file manually "
                    f"{lock_path!r} after verifying first")
            time.sleep(0.2)
    try:
        os.write(fd, str(os.getpid()).encode())
        os.fsync(fd)
    except OSError as exc:
        # F30: a lock whose identity could not be written is an unowned
        # lock — remove it again rather than blocking every later run.
        try:
            os.close(fd)
        except OSError:
            pass
        try:
            os.remove(lock_path)
        except OSError:
            pass
        raise RuntimeError(
            f"could not establish the maintenance lock identity at "
            f"{lock_path!r}: {exc}")
    return fd


def _release_lock_file(lock_path: str, fd) -> None:
    """
    Release the advisory lock (F30/F37).

    The pathname is removed ONLY when it still refers to the lock object
    THIS process created (same device/inode). A lock file that was replaced
    by another process is never removed, and a release failure is reported
    honestly instead of being swallowed.
    """
    try:
        owned = os.fstat(fd)
    except OSError:
        owned = None
    try:
        current = os.stat(lock_path)
    except OSError:
        current = None
    try:
        os.close(fd)
    except OSError:
        pass
    if owned is None or current is None:
        return
    if (current.st_dev, current.st_ino) != (owned.st_dev, owned.st_ino):
        logger.warning(
            "[memory-migrate] the lock path %s now refers to a different "
            "object; it was NOT removed (another process owns it)",
            lock_path)
        return
    try:
        os.remove(lock_path)
    except OSError as exc:
        logger.warning(
            "[memory-migrate] the maintenance lock %s could not be removed: "
            "%s (a stale lock must be removed manually after verifying that "
            "no maintenance run is active)", lock_path, exc)


def _preserve_recoverable_state(db_path: str, reason: str) -> List[str]:
    """
    REV-G4-06: raw forensic preservation of the database file set — main,
    -wal, -shm AND -journal — BEFORE any SQLite open that could trigger
    rollback-journal or WAL recovery.

    Contract:
      * unique, non-overwriting destination (timestamp + random suffix,
        created with mkdir-exists-guard — never replaces a previous
        preservation set);
      * originals are retained untouched (copy, never move/rename/trim);
      * every copy is byte-verified (SHA-256 source == copy) and its size
        and hash are recorded in a manifest.json next to the copies,
        together with the reason;
      * preservation never claims success unless EVERY existing artifact
        was accounted for — a failed copy raises and the caller must fail
        closed;
      * this is RAW file preservation, deliberately NOT the Online Backup
        API (a logical backup of a potentially corrupt database with
        pending recovery artifacts is NOT forensically valid — it reads
        through SQLite and could itself trigger recovery).
    """
    existing = [sfx for sfx in ("", "-wal", "-shm", "-journal")
                if os.path.exists(str(db_path) + sfx)]
    if not existing:
        return []
    ts = time.strftime("%Y%m%d_%H%M%S", time.localtime())
    while True:
        dest_dir = (f"{db_path}.ocbrain_preserved_{ts}_"
                    f"{uuid.uuid4().hex[:8]}")
        try:
            os.mkdir(dest_dir)          # never overwrites an existing set
            break
        except FileExistsError:         # pragma: no cover - uuid collision
            continue
    saved: List[Dict[str, Any]] = []
    saved_paths: List[str] = []
    for suffix in existing:
        src = str(db_path) + suffix
        dest = os.path.join(dest_dir, os.path.basename(src))
        try:
            shutil.copy2(src, dest)
        except OSError as exc:
            # fail closed: never report (or continue from) a partial
            # preservation
            raise RuntimeError(
                f"preservation incomplete: copying {src} failed: {exc} — "
                "do not proceed with any recovery or migration action") from exc
        src_hash, dst_hash = sha256_file(src), sha256_file(dest)
        if src_hash != dst_hash:
            raise RuntimeError(
                f"preservation incomplete: copy verification FAILED for "
                f"{src} (source sha256 {src_hash} != copy sha256 "
                f"{dst_hash}) — fail closed, do not proceed")
        saved.append({
            "source": src, "copy": dest,
            "bytes": os.path.getsize(src), "sha256": src_hash,
            "verified": True,
        })
        saved_paths.append(dest)
    manifest = {
        "preserved_at": time.time(),
        "db_path": db_path,
        "reason": reason,
        "originals_retained": True,
        "files": saved,
        "warning": ("preserved recovery artifacts; do not 'repair' or "
                    "rebuild on the original (Amendment 3 §B.2)"),
    }
    (Path(dest_dir) / "manifest.json").write_text(
        json.dumps(manifest, indent=2))
    logger.warning("[memory-migrate] recovery artifacts preserved: %s",
                   dest_dir)
    return saved_paths


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _preserve_corrupt_database(db_path: str, reason: str) -> List[str]:
    """
    Amendment 3 §B.2: preserve the corrupt database for recovery before any
    further action; nothing about the original file is repaired or deleted.

    REV-G4-06: delegated to the raw preservation routine so the rollback
    journal (-journal) is included alongside the main database, -wal and
    -shm.
    """
    return _preserve_recoverable_state(db_path, reason)


def _classify_migration_failure(message: str) -> str:
    m = message.casefold()
    if "disk is full" in m or "database is full" in m or "out of memory" in m \
            or "disk i/o error" in m:
        return "sqlite_full_equivalent"
    if "integrity validation failed" in m:
        return "integrity_check_failure"
    if "identity verification failed" in m:
        return "content_identity_failure"
    if "locked" in m or "busy" in m:
        return "serialization_conflict"
    return "other"
