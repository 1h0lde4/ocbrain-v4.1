"""
core/memory/sqlite_integrity.py — Independent integrity validation (Rev 3)

Implements Rev 3 Amendment 3 (whole-database integrity validation) and the
verification parts of Amendments 4 and 8.

Four independent verification layers, each with its own scope, status and
verification time (Amendment 3 §C — the FTS `rank=1` integrity-check does NOT
stand in for whole-database integrity):

  1. SQLite structural integrity          — PRAGMA integrity_check
  2. Foreign-key consistency              — PRAGMA foreign_key_check
     (run whenever the database has foreign-key relationships, including
     relationships introduced through migrations)
  3. FTS5 internal/external-content integrity — the documented
     `INSERT INTO fts(fts, rank) VALUES ('integrity-check', 1)` command
  4. Actual retrieval health               — real FTS5 MATCH queries against
     controlled test tokens

Cost accounting: every finding carries its measured duration; callers must
not run full validation on ordinary health heartbeats (Amendment 3 §C) —
`validate_readiness()` is the cheap, schema-only startup path.
"""

from __future__ import annotations

import logging
import sqlite3
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence

from core.memory.sqlite_contract import (
    CANONICAL_FTS_DDL,
    CANONICAL_INDEX_DDL,
    CANONICAL_KNOWLEDGE_ENTRIES_DDL,
    CANONICAL_TRIGGER_DDL,
    CANONICAL_TRIGGER_NAMES,
    CONTENT_TABLE,
    FTS_CONFIG_RECOGNIZED_KEYS,
    FTS_TABLE,
    HOUSEKEEPING_TABLE_CONTRACTS,
    LEDGER_STATUS_APPLIED,
    LEGACY_TRIGGER_CONFIGURATIONS,
    MIGRATION_ID_CURRENT,
    MIGRATION_ID_V1,
    SCHEMA_STATES_CURRENT,
    META_SCHEMA_STATE,
    META_TABLE,
    MIGRATIONS_TABLE,
    SqlParseError,
    normalize_sql,
    canonical_columns,
    canonical_fts_options,
    parse_create_index,
    parse_create_virtual_table,
    trigger_audit_classification,
    _ascii_lower,
)

logger = logging.getLogger("ocbrain.memory.sqlite_integrity")

# Controlled retrieval tokens mandated by Amendment 9 §1: simple alphabetic
# tokens that need no special FTS5 query syntax.
RETRIEVAL_PROBE_TOKEN_PREFIX = "xqzIntegrityProbe"

SCOPE_STRUCTURAL = "sqlite_structural_integrity"
SCOPE_FOREIGN_KEYS = "foreign_key_consistency"
SCOPE_FTS_INTERNAL = "fts_internal_external_content_integrity"
SCOPE_RETRIEVAL = "fts_retrieval_health"
SCOPE_SCHEMA_CONTRACT = "schema_contract_validation"
SCOPE_CONTENT_IDENTITY = "fts_content_row_identity"

PASS = "pass"
FAIL = "fail"
ERROR = "error"
NOT_APPLICABLE = "not_applicable"
FAILED_STATUSES = (FAIL, ERROR)


@dataclass
class IntegrityFinding:
    """One verification result: scope + status + verification time (+ cost)."""
    scope: str
    name: str
    status: str          # "pass" | "fail" | "not_applicable" | "error"
    detail: str
    verified_at: float = field(default_factory=time.time)
    duration_s: float = 0.0

    def as_dict(self) -> Dict[str, Any]:
        return {
            "scope": self.scope,
            "name": self.name,
            "status": self.status,
            "detail": self.detail,
            "verified_at": self.verified_at,
            "duration_s": round(self.duration_s, 6),
        }


def _sql_error_finding(scope: str, name: str, exc: Exception,
                       start: float = 0.0) -> IntegrityFinding:
    finding = IntegrityFinding(
        scope=scope, name=name, status=ERROR,
        detail=f"{type(exc).__name__}: {exc}",
        duration_s=time.time() - start,
    )
    return finding


# ── Amendment 3 §A — whole-database checks ──────────────────────────────────

def check_structural_integrity(conn: sqlite3.Connection) -> IntegrityFinding:
    """
    `PRAGMA integrity_check`. A corrupted database can either return error
    rows or raise mid-pragma (Session 4C observed the raised form against
    real corruption) — both are failures.
    """
    start = time.time()
    try:
        rows = [r[0] for r in conn.execute("PRAGMA integrity_check").fetchall()]
    except sqlite3.DatabaseError as exc:
        return _sql_error_finding(SCOPE_STRUCTURAL, "PRAGMA integrity_check",
                                  exc, start)
    dur = time.time() - start
    if rows == ["ok"]:
        return IntegrityFinding(SCOPE_STRUCTURAL, "PRAGMA integrity_check",
                                PASS, "database image reports ok", duration_s=dur)
    return IntegrityFinding(
        SCOPE_STRUCTURAL, "PRAGMA integrity_check", FAIL,
        f"{len(rows)} integrity problem row(s); first: {rows[:3]!r}",
        duration_s=dur,
    )


def _user_tables(conn: sqlite3.Connection) -> List[str]:
    """
    Application tables: every `type='table'` object that is not a SQLite
    internal table (`sqlite_%`).

    F18: the FTS5 shadow tables and the housekeeping tables are excluded by
    an EXACT name allowlist further down — never by a prefix match, because
    a user table named `knowledge_entries_fts_custom` or `_ocbrain_custom`
    is a real user table whose foreign keys must be inspected.
    """
    names: List[str] = []
    for (name,) in conn.execute(
        "SELECT name FROM sqlite_schema WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    ).fetchall():
        names.append(str(name))
    return names


#: Exact names of the tables that are NOT user tables for foreign-key
#: relationship DETECTION (F18). A prefix exclusion is wrong: it silently
#: ignored user tables whose names merely start with the same prefix.
FTS5_SHADOW_TABLE_NAMES = frozenset({
    f"{FTS_TABLE}_data",
    f"{FTS_TABLE}_idx",
    f"{FTS_TABLE}_content",
    f"{FTS_TABLE}_docsize",
    f"{FTS_TABLE}_config",
})
HOUSEKEEPING_TABLE_NAMES = frozenset({META_TABLE, MIGRATIONS_TABLE})
INTERNAL_TABLE_NAMES = FTS5_SHADOW_TABLE_NAMES | HOUSEKEEPING_TABLE_NAMES

#: Foreign-key relationship detection outcomes.
FK_FOUND = "found"
FK_NONE = "none"
FK_UNAVAILABLE = "unavailable"


def _foreign_key_relationship_status(
        conn: sqlite3.Connection) -> Dict[str, Any]:
    """
    Determine whether the database declares foreign-key relationships (F18).

    Returns {"status": "found" | "none" | "unavailable", "tables": [...],
    "error": str | None}.

    An inspection error is reported as `unavailable` — it is NEVER collapsed
    into "no foreign keys" (the previous implementation swallowed
    `PRAGMA foreign_key_list` errors and reported NOT_APPLICABLE).
    """
    tables_with_fks: List[str] = []
    for name in _user_tables(conn):
        if name in INTERNAL_TABLE_NAMES:
            continue
        try:
            fks = conn.execute(
                f"PRAGMA foreign_key_list({_quote_ident(name)})").fetchall()
        except sqlite3.Error as exc:
            return {"status": FK_UNAVAILABLE, "tables": tables_with_fks,
                    "error": f"{type(exc).__name__}: {exc}"}
        if fks:
            tables_with_fks.append(name)
    return {"status": (FK_FOUND if tables_with_fks else FK_NONE),
            "tables": tables_with_fks, "error": None}


def _has_foreign_key_relationships(conn: sqlite3.Connection) -> bool:
    """
    Detect FOREIGN KEY relationships on real user tables.

    Kept for compatibility; the authoritative result is the three-valued
    `_foreign_key_relationship_status()` — a bool cannot express
    "inspection unavailable".
    """
    return _foreign_key_relationship_status(conn)["status"] == FK_FOUND


def classify_foreign_key_violations(rows: Sequence[Any]) -> List[Dict[str, Any]]:
    """
    Amendment 3 §B.3 / F18: classify existing violations explicitly instead
    of ignoring them. `PRAGMA foreign_key_check` rows are
    (child_table, rowid, parent_table, fk_index).

    EVERY violation row is preserved as its own record (a mapping keyed by
    a composite string could collapse distinct violations); the relation
    classification tells the operator WHERE the inconsistency is.
    """
    classified: List[Dict[str, Any]] = []
    for row in rows:
        table = str(row[0])
        rowid = row[1]
        parent = str(row[2])
        try:
            fk_index = int(row[3])
        except (TypeError, ValueError, IndexError):
            fk_index = -1
        if parent in FTS5_SHADOW_TABLE_NAMES:
            relation = "fts_shadow_parent_fk_violation"
        elif table in FTS5_SHADOW_TABLE_NAMES:
            relation = "fts_shadow_child_fk_violation"
        else:
            relation = "content_fk_violation"
        classified.append({
            "child_table": table,
            "rowid": rowid,
            "parent_table": parent,
            "fk_index": fk_index,
            "relation": relation,
            "key": f"{table}(rowid={rowid}) -> {parent}(fk #{fk_index})",
        })
    return classified


def check_foreign_key_integrity(conn: sqlite3.Connection) -> IntegrityFinding:
    """
    Amendment 3 §A/§B: run `PRAGMA foreign_key_check` whenever the database
    has foreign-key relationships — including relationships introduced
    through migrations. With none defined, the result is `not_applicable`,
    recorded explicitly so absence is never mistaken for a pass (F18: an
    inspection ERROR is reported as error, never as not_applicable).
    """
    start = time.time()
    status = _foreign_key_relationship_status(conn)
    if status["status"] == FK_UNAVAILABLE:
        return IntegrityFinding(
            SCOPE_FOREIGN_KEYS, "PRAGMA foreign_key_check", ERROR,
            f"foreign-key relationship inspection unavailable: "
            f"{status['error']}",
            duration_s=time.time() - start,
        )
    if status["status"] == FK_NONE:
        return IntegrityFinding(
            SCOPE_FOREIGN_KEYS, "PRAGMA foreign_key_check", NOT_APPLICABLE,
            "no foreign-key relationships defined in this database",
            duration_s=time.time() - start,
        )
    try:
        rows = conn.execute("PRAGMA foreign_key_check").fetchall()
    except sqlite3.DatabaseError as exc:
        return _sql_error_finding(SCOPE_FOREIGN_KEYS, "PRAGMA foreign_key_check",
                                  exc, start)
    dur = time.time() - start
    if not rows:
        return IntegrityFinding(SCOPE_FOREIGN_KEYS, "PRAGMA foreign_key_check",
                                PASS, "no foreign-key violations", duration_s=dur)
    classified = classify_foreign_key_violations(rows)
    counts: Dict[str, int] = {}
    for record in classified:
        counts[record["relation"]] = counts.get(record["relation"], 0) + 1
    detail = (
        f"{len(rows)} foreign-key violation row(s); " +
        "; ".join(f"{rel}={n}" for rel, n in sorted(counts.items()))
    )
    return IntegrityFinding(SCOPE_FOREIGN_KEYS, "PRAGMA foreign_key_check",
                            FAIL, detail, duration_s=dur)


def check_fts_integrity(conn: sqlite3.Connection) -> IntegrityFinding:
    """
    Amendment 3 §A: the FTS5 external-content integrity command. Detects the
    exact drift the legacy ke_au trigger used to produce (index vs content
    table). This is the FTS-layer check ONLY — Amendment 3 §C forbids
    presenting it as whole-database integrity.
    """
    start = time.time()
    try:
        conn.execute(
            f"INSERT INTO {FTS_TABLE}({FTS_TABLE}, rank) VALUES ('integrity-check', 1)"
        )
    except sqlite3.Error as exc:
        return _sql_error_finding(SCOPE_FTS_INTERNAL,
                                  "fts5 integrity-check(rank=1)", exc, start)
    return IntegrityFinding(
        SCOPE_FTS_INTERNAL, "fts5 integrity-check(rank=1)", PASS,
        "external-content index is internally consistent with the content table",
        duration_s=time.time() - start,
    )


def check_fts_retrieval(
    conn: sqlite3.Connection,
    tokens: Sequence[tuple] = (),
) -> IntegrityFinding:
    """
    Amendment 3 §A / Amendment 9: execute real FTS5 MATCH queries. `tokens`
    is a list of (token, must_match) pairs; with no pairs a trivial probe
    verifies the MATCH machinery runs.
    """
    start = time.time()
    details: List[str] = []
    ok = True
    try:
        if not tokens:
            probe = f"{RETRIEVAL_PROBE_TOKEN_PREFIX}{time.time_ns()}"
            conn.execute(
                f"SELECT rowid FROM {FTS_TABLE} WHERE {FTS_TABLE} MATCH ?",
                (probe,),
            ).fetchall()
        for token, must_match in tokens:
            rows = conn.execute(
                f"SELECT rowid FROM {FTS_TABLE} WHERE {FTS_TABLE} MATCH ?",
                (token,),
            ).fetchall()
            if must_match and not rows:
                ok = False
                details.append(f"missing expected token {token!r}")
            if not must_match and rows:
                ok = False
                details.append(
                    f"unexpected token {token!r} still matches (rowids: "
                    f"{[r[0] for r in rows][:5]})")
    except sqlite3.Error as exc:
        return _sql_error_finding(SCOPE_RETRIEVAL, "MATCH probes", exc, start)
    dur = time.time() - start
    detail = "; ".join(details) if details else "MATCH executed"
    return IntegrityFinding(SCOPE_RETRIEVAL, "MATCH probes",
                            PASS if ok else FAIL, detail, duration_s=dur)


def run_full_integrity_validation(
    conn: sqlite3.Connection,
    retrieval_tokens: Sequence[tuple] = (),
) -> Dict[str, Any]:
    """
    All four Amendment 3 checks as independent findings, plus total cost.

    Returns: {"findings": [IntegrityFinding...], "passed": bool,
              "total_cost_s": float, "verified_at": float}
    """
    findings = [
        check_structural_integrity(conn),
        check_foreign_key_integrity(conn),
        check_fts_integrity(conn),
        check_fts_retrieval(conn, tokens=retrieval_tokens),
    ]
    return {
        "findings": [f.as_dict() for f in findings],
        "finding_objects": findings,
        "passed": all(f.status in (PASS, NOT_APPLICABLE) for f in findings),
        "total_cost_s": round(sum(f.duration_s for f in findings), 6),
        "verified_at": time.time(),
    }


# ── Amendment 4 — FTS content-row identity invariants ───────────────────────

_ROWID_ALIAS_COLUMNS = {"rowid", "oid", "_rowid_"}


def verify_content_row_identity(conn: sqlite3.Connection) -> Dict[str, Any]:
    """
    Amendment 4 §A: prove against the LIVE database that the FTS
    `content_rowid='rowid'` configuration is valid for the actual content
    table:

      * the table is not WITHOUT ROWID (sqlite_schema + live behavior);
      * no declared column shadows/aliases the hidden rowid
        (rowid/oid/_rowid_);
      * the `rowid` identifier resolves on this table;
      * the identity is unique for every content row.

    The OPEN architectural classification of hidden-rowid persistence
    (Amendment 4 §B) is carried in the result: SQLite's documentation notes
    VACUUM may change rowids of tables without an INTEGER PRIMARY KEY. The
    application-level TEXT primary key is not the FTS identity and is never
    inferred to be one.
    """
    checks: List[IntegrityFinding] = []
    audit: Dict[str, Any] = {
        "content_rowid": "rowid",
        "checks": checks,
        "passed": True,
    }

    try:
        schema_row = conn.execute(
            "SELECT sql FROM sqlite_schema WHERE type='table' AND name=?",
            (CONTENT_TABLE,),
        ).fetchone()
    except sqlite3.Error as exc:
        audit["passed"] = False
        audit["error"] = str(exc)
        return audit

    if schema_row is None or not schema_row[0]:
        audit["passed"] = False
        audit["reason"] = f"{CONTENT_TABLE} table is missing"
        return audit
    norm_schema = normalize_sql(schema_row[0])

    start = time.time()
    if "without rowid" in norm_schema:
        audit["passed"] = False
        checks.append(IntegrityFinding(
            SCOPE_CONTENT_IDENTITY, "without_rowid", FAIL,
            "content table is declared WITHOUT ROWID — the hidden rowid "
            "identity is invalid for FTS external content",
            duration_s=time.time() - start))
        return audit

    declared = [str(r[1]) for r in conn.execute(
        f"PRAGMA table_info({CONTENT_TABLE})")]
    shadowing = [c for c in declared if c.casefold() in _ROWID_ALIAS_COLUMNS]
    if shadowing:
        audit["passed"] = False
        checks.append(IntegrityFinding(
            SCOPE_CONTENT_IDENTITY, "rowid_alias_columns", FAIL,
            f"declared column(s) shadow the hidden rowid: {shadowing} — "
            "ambiguity invalidates the FTS content-row identity",
            duration_s=time.time() - start))
        return audit
    checks.append(IntegrityFinding(
        SCOPE_CONTENT_IDENTITY, "rowid_alias_columns", PASS,
        "no declared rowid/oid/_rowid_ columns observed",
        duration_s=time.time() - start))

    start = time.time()
    try:
        row = conn.execute(
            f"SELECT COUNT(*), COUNT(DISTINCT rowid) FROM {CONTENT_TABLE}"
        ).fetchone()
    except sqlite3.DatabaseError as exc:
        audit["passed"] = False
        checks.append(IntegrityFinding(
            SCOPE_CONTENT_IDENTITY, "rowid_resolution_uniqueness", FAIL,
            f"hidden rowid does not resolve on the live table: {exc}",
            duration_s=time.time() - start))
        return audit
    total, distinct = int(row[0]), int(row[1])
    if total != distinct:
        audit["passed"] = False
        checks.append(IntegrityFinding(
            SCOPE_CONTENT_IDENTITY, "rowid_resolution_uniqueness", FAIL,
            f"duplicate FTS document identifiers possible: {total} content "
            f"rows vs {distinct} distinct rowid values",
            duration_s=time.time() - start))
        return audit
    checks.append(IntegrityFinding(
        SCOPE_CONTENT_IDENTITY, "rowid_resolution_uniqueness", PASS,
        f"hidden rowid resolves and is unique across {total} row(s)",
        duration_s=time.time() - start))

    audit["content_rows"] = total
    audit["open_risk_classified"] = (
        "OPEN: hidden-rowid persistence relies on SQLite rowid stability "
        "for a table without an INTEGER PRIMARY KEY; VACUUM and table "
        "rebuilds can change it (Amendment 4 §C). The stable-integer-identity "
        "decision (DBT-R3-IDENTITY) is a separately tracked OPEN item — not "
        "resolved by this remediation."
    )
    return audit


# ── Amendment 8 — complete FTS configuration audit ──────────────────────────

def read_fts_configuration(conn: sqlite3.Connection) -> Dict[str, Any]:
    """
    Read the FTS5 virtual-table configuration from the live schema. FTS5
    persists only limited runtime values in the shadow `config` table
    (version; runtime secure-delete when set); the declared definition comes
    from the sqlite_schema SQL. Unknown option keys or value/column
    mismatches are classified `unknown` (fail closed).
    """
    out: Dict[str, Any] = {"classification": "unknown", "details": {}}
    row = conn.execute(
        "SELECT sql FROM sqlite_schema WHERE type='table' AND name=?",
        (FTS_TABLE,)).fetchone()
    if row is None or not row[0]:
        out["reason"] = f"{FTS_TABLE} virtual table missing"
        return out
    ddl = str(row[0])
    try:
        columns, options = parse_create_virtual_table(ddl)
    except ValueError as exc:
        out["reason"] = f"virtual table definition not parseable: {exc}"
        return out
    out["details"]["declared_columns"] = columns
    out["details"]["declared_options"] = options
    canonical_cols = canonical_columns()
    canonical_opts = canonical_fts_options()
    out["details"]["expected_columns"] = canonical_cols
    out["details"]["expected_options"] = canonical_opts

    try:
        config_rows = conn.execute(
            f"SELECT k, v FROM {FTS_TABLE}_config").fetchall()
    except sqlite3.Error as exc:
        out["reason"] = f"shadow config table unreadable: {exc}"
        return out
    out["details"]["shadow_config_rows"] = {str(k): v for (k, v) in config_rows}
    unrecognized = [str(k) for (k, _v) in config_rows
                    if str(k) not in FTS_CONFIG_RECOGNIZED_KEYS]
    out["details"]["unrecognized_config_keys"] = unrecognized

    if columns != canonical_cols or options != canonical_opts or unrecognized:
        out["classification"] = "unknown"
        out["reason"] = (
            f"FTS definition differs from the canonical contract "
            f"(columns={columns!r}, options={options!r}, "
            f"unrecognized_config_keys={unrecognized!r})"
        )
        return out
    out["classification"] = "canonical"
    return out


def audit_trigger_contract(conn: sqlite3.Connection) -> Dict[str, Any]:
    """
    Amendment 8 / F15 / F16 / F32: classify each of the three
    synchronization triggers against the canonical definitions (normalized
    semantic comparison — not substring checks).

    * A trigger NAME is a DATABASE-WIDE identifier: if `ke_ad` (or any other
      canonical trigger name) exists on a DIFFERENT table, that is a
      COLLISION — the migration must refuse, and the unrelated trigger must
      never be dropped (F15).
    * Only the explicitly enumerated historical trigger SETS are recognized
      as repairable legacy states (LEGACY_TRIGGER_CONFIGURATIONS): an
      arbitrary partial set (a missing trigger, a legacy ke_au combined with
      a canonical ke_ad, …) is NOT a historical state and fails closed
      (F16 / F32).
    """
    result: Dict[str, Any] = {"triggers": {}, "classification": "unknown"}
    # GLOBAL lookup: name -> owning table (a trigger name is unique
    # database-wide, so a second object with the same name cannot exist).
    owner_rows = conn.execute(
        "SELECT name, tbl_name, sql FROM sqlite_schema WHERE type='trigger'"
    ).fetchall()
    # W01: trigger names are database-wide and compared ASCII-case-
    # insensitively by SQLite: "KE_AD" is the SAME name as "ke_ad".
    owner_by_name: Dict[str, str] = {}
    sql_by_name: Dict[str, Optional[str]] = {}
    content_triggers = set()
    for name, tbl_name, sql in owner_rows:
        n = str(name)
        key = _ascii_lower(n)
        owner_by_name[key] = str(tbl_name)
        sql_by_name[key] = sql
        if str(tbl_name) == CONTENT_TABLE:
            content_triggers.add(key)

    foreign_owned: List[str] = []
    for name in CANONICAL_TRIGGER_NAMES:
        key = _ascii_lower(name)
        owner = owner_by_name.get(key)
        if owner is None:
            result["triggers"][name] = "missing"
            continue
        if owner != CONTENT_TABLE:
            foreign_owned.append(name)
            result["triggers"][name] = "foreign_owned"
            continue
        result["triggers"][name] = trigger_audit_classification(
            sql_by_name.get(key), name)

    unknown_triggers = [str(n) for n in content_triggers
                        if str(n) not in {_ascii_lower(x)
                                         for x in CANONICAL_TRIGGER_DDL}]
    result["unknown_triggers"] = unknown_triggers
    result["foreign_owned_triggers"] = foreign_owned

    classes = tuple(result["triggers"][n] for n in CANONICAL_TRIGGER_NAMES)
    if classes == ("canonical", "canonical", "canonical") and \
            not unknown_triggers and not foreign_owned:
        result["classification"] = "canonical"
    elif classes in LEGACY_TRIGGER_CONFIGURATIONS and not unknown_triggers \
            and not foreign_owned:
        result["classification"] = "legacy_compatible"
        result["legacy_configuration"] = LEGACY_TRIGGER_CONFIGURATIONS[classes]
        result["reason"] = (
            "trigger set matches a documented historical configuration "
            f"({LEGACY_TRIGGER_CONFIGURATIONS[classes]}); the dedicated "
            "maintenance migration must restore the canonical set and verify "
            "the index"
        )
    else:
        result["classification"] = "unknown"
        result["reason"] = (
            f"unrecognized trigger configuration "
            f"(classes={result['triggers']}, unknown={unknown_triggers}, "
            f"foreign_owned={foreign_owned}) — only the explicitly "
            "documented historical trigger sets are recognized"
        )
    return result


def read_secure_delete_policy(conn: sqlite3.Connection) -> Dict[str, Any]:
    """
    Amendment 6 §A: report the actual FTS5 `secure-delete` configuration and
    the SQLite core `PRAGMA secure_delete` value. Read-only by contract —
    this module never changes either setting (scope boundary, §B).
    """
    out: Dict[str, Any] = {}
    try:
        out["core_pragma_secure_delete"] = conn.execute(
            "PRAGMA secure_delete").fetchone()[0]
    except sqlite3.Error as exc:
        out["core_pragma_secure_delete"] = f"error: {exc}"
    try:
        rows = conn.execute(f"SELECT k, v FROM {FTS_TABLE}_config").fetchall()
        cfg = {str(k): v for (k, v) in rows}
        out["fts5_secure_delete"] = cfg.get("secure-delete", "default (disabled)")
        out["fts5_config_keys"] = sorted(cfg.keys())
    except sqlite3.Error as exc:
        out["fts5_secure_delete"] = f"error: {exc}"
    out["interpretation"] = (
        "FTS5 secure-delete governs the FTS5 inverted index only; the SQLite "
        "core PRAGMA secure_delete (0=off) governs regular database pages. "
        "OFF is the FTS5 default: deleted or updated terms may remain in FTS5 "
        "structures until merge operations remove them, so content-table "
        "deletion, MATCH invisibility, and a passing integrity-check each "
        "prove different things — none proves physical erasure."
    )
    return out


# ── REV-G4-03 / F14 / F15 / F33 — semantic index-contract audit ──────────────

#: Index classifications.
IDX_CANONICAL = "canonical"
IDX_MISSING = "missing"
IDX_WRONG = "wrong_definition"
IDX_UNPARSEABLE = "unparseable"
IDX_FOREIGN = "foreign_owned"      # same name, different owning table (F15)
IDX_UNKNOWN = "unknown"            # cannot be established (fail closed)


def _quote_ident(name: str) -> str:
    """Quote an SQL identifier, escaping embedded double quotes (F18)."""
    return '"' + str(name).replace('"', '""') + '"'


def _index_physical_facts(conn: sqlite3.Connection, table: str,
                          index_name: str) -> Dict[str, Any]:
    """
    Physical index facts from `PRAGMA index_list` + `PRAGMA index_xinfo` (F14
    requirement 7 / F33).

    `index_xinfo` reports the REAL column order, the DESC flag, the
    collation, the expression terms and the key/auxiliary distinction — the
    stored SQL text alone is never accepted as proof.

    Raises sqlite3.Error when the metadata cannot be read: the caller must
    classify the index contract as unavailable, never as canonical.
    """
    facts: Dict[str, Any] = {}
    listing = conn.execute(
        f"PRAGMA index_list({_quote_ident(table)})").fetchall()
    for row in listing:
        if str(row[1]) == index_name:
            facts["unique"] = bool(row[2])
            facts["origin"] = str(row[3]) if len(row) > 3 else ""
            facts["partial"] = bool(row[4]) if len(row) > 4 else False
            break
    else:
        raise sqlite3.OperationalError(
            f"index {index_name!r} is not listed by "
            f"PRAGMA index_list({table!r})")
    xinfo = conn.execute(
        f"PRAGMA index_xinfo({_quote_ident(index_name)})").fetchall()
    terms = []
    for row in xinfo:
        terms.append({
            "seqno": row[0],
            "cid": row[1],
            "name": None if row[2] is None else str(row[2]),
            "desc": bool(row[3]),
            "coll": str(row[4]) if row[4] is not None else "",
            "key": bool(row[5]) if len(row) > 5 else True,
        })
    facts["terms"] = terms
    facts["key_columns"] = [t for t in terms if t["key"]]
    return facts


def _index_terms_match(parsed: Dict[str, Any],
                       physical: Dict[str, Any]) -> bool:
    """
    Compare the PARSED definition with the PHYSICAL facts.

    Both must agree; a disagreement means the stored SQL does not describe
    the index that actually exists (and the index cannot be established as
    canonical).
    """
    parsed_terms = parsed.get("terms") or []
    key_terms = physical.get("key_columns") or []
    if len(parsed_terms) != len(key_terms):
        return False
    for pt, xt in zip(parsed_terms, key_terms):
        if pt.get("expression"):
            return False                     # an expression is never canonical
        if xt.get("name") is None:
            return False                     # expression index
        if _ascii_lower(xt["name"]) != pt.get("column"):
            return False
        if bool(xt.get("desc")) != bool(pt.get("desc")):
            return False
        want_coll = (pt.get("collation") or "binary").lower()
        if str(xt.get("coll") or "").lower() != want_coll:
            return False
    return True


def audit_index_contract(conn: sqlite3.Connection) -> Dict[str, Any]:
    """
    Verify every canonical index SEMANTICALLY against CANONICAL_INDEX_DDL
    (REV-G4-03) and PHYSICALLY against the live SQLite metadata
    (F14/F33): presence of a same-name index is NOT proof, and neither is
    parseable SQL text.

    Per-index classification:
      "canonical"        — parsed definition AND physical metadata both
                           match the canonical contract.
      "missing"          — no object with that name exists (repairable).
      "wrong_definition" — a same-name index on the content table exists but
                           does not match (repairable by drop+recreate).
      "unparseable"      — the stored definition cannot be parsed (unknown).
      "foreign_owned"    — an object with that name belongs to ANOTHER table
                           (F15: never dropped, never repaired).
      "unknown"          — the contract could not be established (metadata
                           unavailable / inconsistent) — fail closed.

    Aggregate result: {"classification": "canonical" | "repairable_drift" |
    "unknown_drift", "missing", "wrong_definition", "unparseable",
    "foreign_owned", "unknown", "unknown_extra", "indexes": {...}}.

    UNKNOWN drift always takes precedence over repairable drift (F14.1), so a
    missing index plus an unknown extra index classifies as `unknown_drift`
    (F14.2) and is never auto-repaired.
    """
    rows = conn.execute(
        "SELECT name, tbl_name, sql FROM sqlite_schema WHERE type='index'"
    ).fetchall()
    # W01: SQLite object names are compared ASCII-case-INsensitively, so the
    # ownership lookup must be too: a case variant ("IDX_KE_LAYER") is the
    # SAME name as the canonical one — it is a collision, not an unrelated
    # extra index, and it must never be treated as "the canonical index is
    # simply missing".
    owner_by_name: Dict[str, str] = {}
    sql_by_name: Dict[str, Optional[str]] = {}
    content_indexes = set()
    for name, tbl_name, sql in rows:
        n = str(name)
        key = _ascii_lower(n)
        owner_by_name[key] = str(tbl_name)
        sql_by_name[key] = sql
        if str(tbl_name) == CONTENT_TABLE:
            content_indexes.add(key)

    out: Dict[str, Any] = {
        "classification": "canonical",
        "missing": [],
        "wrong_definition": [],
        "unparseable": [],
        "foreign_owned": [],
        "unknown": [],
        "unknown_extra": [],
        "indexes": {},
    }

    for name, ddl in CANONICAL_INDEX_DDL.items():
        want = parse_create_index(ddl)
        key = _ascii_lower(name)
        if key not in owner_by_name:
            out["missing"].append(name)
            out["indexes"][name] = {"classification": IDX_MISSING}
            continue
        owner = owner_by_name[key]
        if owner != CONTENT_TABLE:
            # F15/W01: a canonical index name owned by another table is a
            # COLLISION — refuse; never drop the unrelated object.
            out["foreign_owned"].append(name)
            out["indexes"][name] = {
                "classification": IDX_FOREIGN,
                "owner_table": owner,
                "actual_sql": sql_by_name.get(key),
            }
            continue
        got_sql = sql_by_name.get(key)
        try:
            got = parse_create_index(got_sql)
        except (ValueError, SqlParseError) as exc:
            out["unparseable"].append(name)
            out["indexes"][name] = {
                "classification": IDX_UNPARSEABLE, "error": str(exc),
                "actual_sql": got_sql}
            continue

        # Physical metadata — a PRAGMA failure is an ERROR, never a verdict.
        try:
            physical = _index_physical_facts(conn, CONTENT_TABLE, name)
        except sqlite3.Error as exc:
            out["unknown"].append(name)
            out["indexes"][name] = {
                "classification": IDX_UNKNOWN,
                "error": f"index metadata unavailable: {exc}",
                "actual_sql": got_sql}
            continue

        sql_matches = (
            got["table"] == want["table"]
            and got["columns"] == want["columns"]
            and got["unique"] == want["unique"]
            and got["where"] == want["where"]
        )
        physical_matches = (
            physical.get("unique") == want["unique"]
            and bool(physical.get("partial")) == bool(want["where"])
            and _index_terms_match(got, physical)
            and _index_terms_match(want, physical)
        )
        if sql_matches and physical_matches:
            out["indexes"][name] = {
                "classification": IDX_CANONICAL,
                "unique": physical.get("unique"),
                "partial": physical.get("partial"),
                "key_columns": [t.get("name") for t in
                                physical.get("key_columns", [])],
            }
        elif sql_matches and not physical_matches:
            # The stored SQL claims the canonical shape but the live index
            # metadata disagrees — equivalence CANNOT be established.
            out["unknown"].append(name)
            out["indexes"][name] = {
                "classification": IDX_UNKNOWN,
                "error": "stored definition and live index metadata disagree",
                "actual_sql": got_sql,
                "physical": physical,
            }
        else:
            out["wrong_definition"].append(name)
            out["indexes"][name] = {
                "classification": IDX_WRONG,
                "actual_sql": got_sql, "canonical_sql": ddl,
                "physical": physical,
            }

    canonical_keys = {_ascii_lower(n) for n in CANONICAL_INDEX_DDL}
    extra = sorted(
        n for n in content_indexes
        if n not in canonical_keys and not n.startswith("sqlite_autoindex"))
    out["unknown_extra"] = extra

    # UNKNOWN drift takes precedence over repairable drift (F14.1).
    if out["foreign_owned"] or out["unparseable"] or out["unknown"] or extra:
        out["classification"] = "unknown_drift"
    elif out["missing"] or out["wrong_definition"]:
        out["classification"] = "repairable_drift"
    return out


# ── F20 — housekeeping table + migration-ledger contract ────────────────────

def audit_housekeeping_contract(conn: sqlite3.Connection) -> Dict[str, Any]:
    """
    Verify the EXACT structural contract of the per-database bookkeeping
    tables and the consistency of the migration ledger (F20).

    Returns:
      {"classification": "canonical" | "malformed" | "unreadable",
       "tables": {name: {"classification": ..., "detail": ...}},
       "marker": {...} | None,
       "ledger": {"applied_current": n, "applied_v1": n, "rows": n,
                  "duplicate_current_rows": n,
                  "current_row_statuses": [...], "unreadable": bool},
       "reason": str}

    A current migration requires EXACTLY ONE applied ledger row for the
    current migration identity, exactly one schema-state marker with a
    current value, and both tables shaped exactly as documented. A nonzero
    row count is never sufficient.
    """
    out: Dict[str, Any] = {
        "classification": "canonical",
        "tables": {},
        "marker": None,
        "ledger": {"applied_current": 0, "applied_v1": 0, "rows": 0,
                   "duplicate_current_rows": 0, "current_row_statuses": [],
                   "unreadable": False},
        "reason": "",
    }

    for table, contract in HOUSEKEEPING_TABLE_CONTRACTS.items():
        try:
            rows = conn.execute(
                f"PRAGMA table_info({_quote_ident(table)})").fetchall()
        except sqlite3.Error as exc:
            out["tables"][table] = {"classification": "unreadable",
                                    "detail": str(exc)}
            out["classification"] = "unreadable"
            out["reason"] = f"{table} metadata unreadable: {exc}"
            return out
        if not rows:
            out["tables"][table] = {"classification": "missing", "detail": ""}
            out["classification"] = "malformed"
            out["reason"] = f"housekeeping table {table} is missing"
            continue
        actual_cols = tuple((str(r[1]), str(r[2]).upper()) for r in rows)
        actual_pk = tuple(str(r[1]) for r in sorted(rows, key=lambda x: x[5])
                          if r[5])
        actual_notnull = tuple(str(r[1]) for r in rows if r[3])
        want_cols = tuple((n, t.upper()) for n, t in contract["columns"])
        problems: List[str] = []
        if actual_cols != want_cols:
            problems.append(
                f"columns differ: actual={actual_cols} expected={want_cols}")
        if tuple(actual_pk) != tuple(contract["primary_key"]):
            problems.append(
                f"primary key differs: actual={actual_pk} "
                f"expected={tuple(contract['primary_key'])}")
        missing_notnull = [c for c in contract["not_null"]
                           if c not in actual_notnull]
        if missing_notnull:
            problems.append(f"columns not NOT NULL: {missing_notnull}")
        if problems:
            out["tables"][table] = {"classification": "malformed",
                                    "detail": "; ".join(problems)}
            out["classification"] = "malformed"
            out["reason"] = f"{table}: " + "; ".join(problems)
        else:
            out["tables"][table] = {"classification": "canonical",
                                    "detail": ""}

    # marker (exactly one row for the schema-state key)
    try:
        marker_rows = conn.execute(
            f"SELECT value FROM {META_TABLE} WHERE key=?",
            (META_SCHEMA_STATE,)).fetchall()
    except sqlite3.Error as exc:
        out["marker"] = {"error": str(exc)}
        out["classification"] = "unreadable"
        out["reason"] = f"schema-state marker unreadable: {exc}"
        return out
    if len(marker_rows) != 1:
        out["marker"] = {"rows": len(marker_rows)}
        out["classification"] = "malformed"
        out["reason"] = (
            f"schema-state marker cardinality is {len(marker_rows)} "
            "(exactly one required)")
    else:
        out["marker"] = {"value": str(marker_rows[0][0]),
                         "current": str(marker_rows[0][0]) in SCHEMA_STATES_CURRENT}

    # ledger rows
    try:
        ledger_rows = conn.execute(
            f"SELECT migration_id, status FROM {MIGRATIONS_TABLE}").fetchall()
    except sqlite3.Error as exc:
        out["ledger"]["unreadable"] = True
        out["ledger"]["error"] = str(exc)
        out["classification"] = "unreadable"
        out["reason"] = f"migration ledger unreadable: {exc}"
        return out
    out["ledger"]["rows"] = len(ledger_rows)
    current_rows = [r for r in ledger_rows if str(r[0]) == MIGRATION_ID_CURRENT]
    out["ledger"]["duplicate_current_rows"] = len(current_rows) - 1
    out["ledger"]["current_row_statuses"] = sorted({str(r[1]) for r in current_rows})
    out["ledger"]["applied_current"] = sum(
        1 for r in current_rows if str(r[1]) == LEDGER_STATUS_APPLIED)
    out["ledger"]["applied_v1"] = sum(
        1 for r in ledger_rows
        if str(r[0]) == MIGRATION_ID_V1 and str(r[1]) == LEDGER_STATUS_APPLIED)
    if out["ledger"]["duplicate_current_rows"] > 0:
        out["classification"] = "malformed"
        out["reason"] = (
            f"migration ledger carries "
            f"{out['ledger']['duplicate_current_rows']} duplicate rows for "
            f"{MIGRATION_ID_CURRENT}")
    return out


# ── F08 / F27 — deterministic logical content digest ─────────────────────────

def logical_content_digest(conn: sqlite3.Connection,
                            table: str = CONTENT_TABLE
                            ) -> Dict[str, Any]:
    """
    Deterministic, type-aware, length-delimited digest over EVERY stored
    value of the memory content table (F08/F27).

    Equal row counts and an equal schema hash prove NOTHING about content:
    a changed value keeps both identical. This digest covers every column
    value plus the hidden-rowid mapping, with an explicit type tag and an
    explicit length for every field, so no two different contents can
    produce the same digest.

    Returns {"rows": n, "sha256": hex, "columns": [...], "rowid_mapping":
             [(rowid, entry_id), ...]}.
    """
    import hashlib
    import struct

    columns = [str(c[1]) for c in conn.execute(
        f"PRAGMA table_info({_quote_ident(table)})").fetchall()]
    rows = conn.execute(
        f"SELECT rowid, * FROM {_quote_ident(table)} ORDER BY rowid"
    ).fetchall()
    digest = hashlib.sha256()
    mapping: List[Any] = []
    for row in rows:
        digest.update(struct.pack("<q", int(row[0])))
        for value in row[1:]:
            if value is None:
                digest.update(b"\x00")
            elif isinstance(value, (bytes, bytearray, memoryview)):
                raw = bytes(value)
                digest.update(b"\x01" + struct.pack("<I", len(raw)) + raw)
            elif isinstance(value, bool):
                digest.update(b"\x02" + struct.pack("<B", 1 if value else 0))
            elif isinstance(value, int):
                digest.update(b"\x03" + struct.pack("<q", value))
            elif isinstance(value, float):
                digest.update(b"\x04" + struct.pack("<d", value))
            else:
                raw = str(value).encode("utf-8")
                digest.update(b"\x05" + struct.pack("<I", len(raw)) + raw)
        digest.update(b"\x1e")
        mapping.append((int(row[0]), str(row[1]) if len(row) > 1 else None))
    return {"rows": len(rows), "sha256": digest.hexdigest(),
            "columns": columns, "rowid_mapping": mapping}

# ── Startup readiness validation (Amendment 2B.3 — cheap, read-only) ────────

def validate_readiness(conn: sqlite3.Connection) -> Dict[str, Any]:
    """
    Validation-only readiness check for normal application startup.

    Verifies the schema contract (content table, FTS definition, trigger
    set, indexes), the per-database migration marker + ledger row, and the
    content-row identity — without running integrity_check /
    foreign_key_check / FTS rebuilds (those belong to the maintenance and
    explicit-verification paths; Amendment 3 §C).
    """
    checks: List[IntegrityFinding] = []
    summary: Dict[str, Any] = {}
    t0 = time.time()

    # 0. Journal-mode invariant (REV-G4-07.B): a CURRENT database must be in
    #    WAL mode — fresh initialization or the maintenance migration
    #    established it. A current-schema database externally flipped to a
    #    different journal mode must FAIL readiness (fail closed) instead of
    #    silently triggering an unreviewed delete->WAL conversion through the
    #    first service connection. The authorized transition is the
    #    maintenance path only (run_maintenance_migration). Reading the
    #    pragma is a read-only operation and never changes the mode.
    try:
        mode = str(conn.execute("PRAGMA journal_mode").fetchone()[0])
    except sqlite3.Error as exc:
        mode = f"unreadable: {exc}"
    if mode.casefold() == "wal":
        checks.append(IntegrityFinding(
            SCOPE_SCHEMA_CONTRACT, "wal_journal_mode_invariant", PASS,
            "journal mode is WAL as the current contract requires",
            duration_s=time.time() - t0))
    else:
        checks.append(IntegrityFinding(
            SCOPE_SCHEMA_CONTRACT, "wal_journal_mode_invariant", FAIL,
            f"journal mode is {mode!r}, not WAL — a current database must "
            "not have its journal mode changed externally; run the "
            "maintenance migration (with all processes stopped) for the "
            "authorized transition",
            duration_s=time.time() - t0))
    summary["journal_mode"] = mode

    # 1. Migration marker + per-database ledger row
    mark = None
    try:
        mark = conn.execute(
            f"SELECT value FROM {META_TABLE} WHERE key=?", (META_SCHEMA_STATE,)
        ).fetchone()
    except sqlite3.Error as exc:
        checks.append(IntegrityFinding(
            SCOPE_SCHEMA_CONTRACT, "migration_marker", FAIL,
            f"meta table unreadable: {exc}", duration_s=time.time() - t0))
    applied = None
    try:
        applied = conn.execute(
            f"SELECT COUNT(*) FROM {MIGRATIONS_TABLE} WHERE migration_id=? "
            "AND status='applied'", (MIGRATION_ID_CURRENT,)
        ).fetchone()[0]
    except sqlite3.Error as exc:
        checks.append(IntegrityFinding(
            SCOPE_SCHEMA_CONTRACT, "migration_ledger", FAIL,
            f"ledger table unreadable: {exc}", duration_s=time.time() - t0))
    marked = bool(mark) and str(mark[0]) in SCHEMA_STATES_CURRENT
    if bool(applied) and marked:
        checks.append(IntegrityFinding(
            SCOPE_SCHEMA_CONTRACT, "migration_marker", PASS,
            f"schema_state={mark[0]!r}, migration {MIGRATION_ID_CURRENT} "
            "applied"))
    else:
        checks.append(IntegrityFinding(
            SCOPE_SCHEMA_CONTRACT, "migration_marker", FAIL,
            f"marker={mark!r}, applied_count={applied!r} — migration pending, "
            "incomplete or unknown state"))
    summary["schema_marked"] = bool(marked)
    summary["migration_applied"] = bool(applied)

    # 2. Content table definition
    row = conn.execute(
        "SELECT sql FROM sqlite_schema WHERE type='table' AND name=?",
        (CONTENT_TABLE,)).fetchone()
    if row and normalize_sql(row[0]) == normalize_sql(CANONICAL_KNOWLEDGE_ENTRIES_DDL):
        checks.append(IntegrityFinding(
            SCOPE_SCHEMA_CONTRACT, "content_table_definition", PASS,
            "canonical content table definition"))
    else:
        checks.append(IntegrityFinding(
            SCOPE_SCHEMA_CONTRACT, "content_table_definition", FAIL,
            "content table missing or differs from the canonical definition"))
    summary["content_table_present"] = bool(row)

    # 3. FTS virtual table configuration (complete definition, Am. 8)
    fts_cfg = read_fts_configuration(conn)
    checks.append(IntegrityFinding(
        SCOPE_SCHEMA_CONTRACT, "fts_virtual_table_definition",
        PASS if fts_cfg.get("classification") == "canonical" else FAIL,
        fts_cfg.get("reason", "canonical FTS5 external-content definition")))
    summary["fts_configuration"] = fts_cfg.get("classification")

    # 4. Trigger contract
    trig = audit_trigger_contract(conn)
    checks.append(IntegrityFinding(
        SCOPE_SCHEMA_CONTRACT, "fts_trigger_contract",
        PASS if trig["classification"] == "canonical" else FAIL,
        trig.get("reason", "canonical trigger set"),
        duration_s=time.time() - t0))
    summary["trigger_contract"] = trig["classification"]

    # 5. Supporting indexes — SEMANTIC verification (REV-G4-03): a same-name
    #    index with a wrong definition must not pass readiness, and a missing
    #    canonical index must never be mistaken for fully current.
    idx = audit_index_contract(conn)
    if idx["classification"] == "canonical":
        checks.append(IntegrityFinding(
            SCOPE_SCHEMA_CONTRACT, "supporting_indexes", PASS,
            "all canonical indexes present with semantically canonical "
            "definitions"))
    else:
        detail = []
        if idx["missing"]:
            detail.append(f"missing indexes: {idx['missing']}")
        if idx["wrong_definition"]:
            detail.append(
                f"indexes with wrong definitions: {idx['wrong_definition']}")
        if idx["unparseable"]:
            detail.append(f"unparseable index definitions: {idx['unparseable']}")
        if idx["unknown_extra"]:
            detail.append(
                f"unknown extra indexes on {CONTENT_TABLE}: "
                f"{idx['unknown_extra']} (fail closed; not auto-repaired)")
        checks.append(IntegrityFinding(
            SCOPE_SCHEMA_CONTRACT, "supporting_indexes", FAIL,
            "; ".join(detail)))
    summary["index_contract"] = idx["classification"]

    # 6. Content-row identity (Amendment 4 §A)
    identity = verify_content_row_identity(conn)
    checks.extend(identity["checks"])
    summary["content_row_identity"] = PASS if identity["passed"] else FAIL
    if identity["passed"]:
        summary["open_identity_risk"] = identity.get("open_risk_classified")

    return {
        "passed": all(f.status not in FAILED_STATUSES for f in checks),
        "checks": [f.as_dict() for f in checks],
        "summary": summary,
        "total_cost_s": round(sum(f.duration_s for f in checks), 6),
        "verified_at": time.time(),
    }
