"""
core/memory/sqlite_contract.py — The canonical SQLite memory-DB contract (Rev 3)

Rev 3 (OCBrain G4-FTS remediation) makes every storage-backend constructor a
*validation-only* consumer of this contract. Mutation of an existing schema is
reserved for the dedicated maintenance migration
(`core/memory/sqlite_migration.py`, exposed as the `ocbrain memory-migrate`
CLI command — following the repository's existing click-command architecture
in `interface/cli.py`).

This module owns:

  * the canonical DDL (content table, FTS5 external-content virtual table,
    the three synchronization triggers, supporting indexes) — a single
    source of truth used by initialization, auditing and the migration
    runner so text cannot drift between sites (Amendment 8);
  * the known historical definitions (pre-Session 4C unsafe `ke_au`), so a
    legacy database is *recognized* rather than guessed at (Amendment 8:
    "Use the canonical migration definition and known historical definitions
    to identify supported states");
  * the per-database migration bookkeeping tables (ledger + meta) and their
    DDL — part of the database's own schema so each database file carries
    its own independent migration state (Amendment 7);
  * SQL normalization and CREATE VIRTUAL TABLE parsing used for semantic
    comparison — substring checks are NOT accepted as proof of equivalence
    (Amendment 8);
  * the `MemoryReadinessError` fail-closed refusal type (Amendment 2B.3–5).

The FTS content-row identity is intentionally `content_rowid='rowid'`
(Amendment 4). The identity is only safe because the canonical content table
has no declared rowid/oid/_rowid_ column and is not WITHOUT ROWID;
`sqlite_integrity.verify_content_row_identity()` enforces that against the
live database, and hidden-rowid persistence remains an OPEN architectural
risk (stable-integer-identity decision pending — explicitly disclosed).
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional, Tuple

# ── Canonical DDL (single source of truth) ───────────────────────────────────

CANONICAL_KNOWLEDGE_ENTRIES_DDL = """
CREATE TABLE knowledge_entries (
    entry_id       TEXT PRIMARY KEY,
    layer          TEXT NOT NULL,
    content        TEXT NOT NULL,
    summary        TEXT NOT NULL DEFAULT '',
    importance     REAL NOT NULL DEFAULT 0.5,
    confidence     REAL NOT NULL DEFAULT 1.0,
    truth_status   TEXT NOT NULL DEFAULT 'unknown',
    trust_score    REAL NOT NULL DEFAULT 1.0,
    source         TEXT NOT NULL DEFAULT '',
    worker_id      TEXT NOT NULL DEFAULT '',
    workflow_id    TEXT NOT NULL DEFAULT '',
    derived_from   TEXT NOT NULL DEFAULT '[]',
    supports       TEXT NOT NULL DEFAULT '[]',
    contradicts    TEXT NOT NULL DEFAULT '[]',
    supersedes     TEXT NOT NULL DEFAULT '[]',
    graph_node_id  TEXT,
    tags           TEXT NOT NULL DEFAULT '[]',
    metadata       TEXT NOT NULL DEFAULT '{}',
    procedure_name TEXT,
    created_at     REAL NOT NULL,
    updated_at     REAL NOT NULL,
    accessed_at    REAL NOT NULL,
    access_count   INTEGER NOT NULL DEFAULT 0
)"""

CANONICAL_FTS_DDL = """
CREATE VIRTUAL TABLE knowledge_entries_fts USING fts5(
    content,
    summary,
    tags,
    content='knowledge_entries',
    content_rowid='rowid'
)"""

CANONICAL_TRIGGER_DDL = {
    "ke_ai": """
CREATE TRIGGER ke_ai AFTER INSERT ON knowledge_entries BEGIN
    INSERT INTO knowledge_entries_fts(rowid, content, summary, tags)
    VALUES (new.rowid, new.content, new.summary, new.tags);
END""",
    "ke_au": """
CREATE TRIGGER ke_au AFTER UPDATE ON knowledge_entries BEGIN
    INSERT INTO knowledge_entries_fts(knowledge_entries_fts, rowid, content, summary, tags)
    VALUES ('delete', old.rowid, old.content, old.summary, old.tags);
    INSERT INTO knowledge_entries_fts(rowid, content, summary, tags)
    VALUES (new.rowid, new.content, new.summary, new.tags);
END""",
    # Rev 3 independent fix (checklist A): the delete trigger MUST use the
    # FTS5 special 'delete' command with old.* values (fts5.html §4.4.3). A
    # plain `DELETE FROM <fts>` in an AFTER DELETE trigger makes FTS5 query
    # the content table for the deleted row's tokens only AFTER the outer
    # statement already removed that row (fts5.html §4.4.4/§4.4.4.1 — "the
    # FTS5 table must be updated first (so that the content table row is
    # still available to it)"): deleted tokens stay MATCH-findable and the
    # rank=1 integrity-check fails SQLITE_CORRUPT_VTAB from the first delete
    # onward. Measured identically on SQLite 3.50.4, 3.51.3 and 3.54.1 — an
    # in-repo trigger-pattern defect, not a build defect
    # (docs/reports/independent-g4-fts/EVIDENCE_NOTE.md §3.1).
    "ke_ad": """
CREATE TRIGGER ke_ad AFTER DELETE ON knowledge_entries BEGIN
    INSERT INTO knowledge_entries_fts(knowledge_entries_fts, rowid, content, summary, tags)
    VALUES ('delete', old.rowid, old.content, old.summary, old.tags);
END""",
}

CANONICAL_INDEX_DDL = {
    "idx_ke_layer": "CREATE INDEX idx_ke_layer ON knowledge_entries(layer)",
    "idx_ke_importance": "CREATE INDEX idx_ke_importance ON knowledge_entries(importance DESC)",
    "idx_ke_truth": "CREATE INDEX idx_ke_truth ON knowledge_entries(truth_status)",
    "idx_ke_created": "CREATE INDEX idx_ke_created ON knowledge_entries(created_at DESC)",
    "idx_ke_source": "CREATE INDEX idx_ke_source ON knowledge_entries(source)",
    "idx_ke_procedure": (
        "CREATE INDEX idx_ke_procedure ON knowledge_entries(procedure_name) "
        "WHERE procedure_name IS NOT NULL"
    ),
}

# Housekeeping tables: each database file carries its own migration state so
# a process-global flag can never stand in for per-database truth (Am. 7).
HOUSEKEEPING_DDL = """
CREATE TABLE IF NOT EXISTS _ocbrain_memory_meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS _ocbrain_memory_migrations (
    migration_id     TEXT PRIMARY KEY,
    name             TEXT NOT NULL,
    status           TEXT NOT NULL,
    started_at       REAL NOT NULL,
    completed_at     REAL NOT NULL,
    applied_by       TEXT NOT NULL,
    host_os          TEXT NOT NULL,
    pre_checks_json  TEXT NOT NULL DEFAULT '{}',
    post_checks_json TEXT NOT NULL DEFAULT '{}',
    wal_bytes_before INTEGER,
    wal_bytes_after  INTEGER
)"""

CANONICAL_SCHEMA_STATEMENTS: tuple = (
    CANONICAL_KNOWLEDGE_ENTRIES_DDL,
    CANONICAL_FTS_DDL,
    CANONICAL_TRIGGER_DDL["ke_ai"],
    CANONICAL_TRIGGER_DDL["ke_au"],
    CANONICAL_TRIGGER_DDL["ke_ad"],
    *CANONICAL_INDEX_DDL.values(),
    "CREATE TABLE IF NOT EXISTS _ocbrain_memory_meta ("
    "key TEXT PRIMARY KEY, value TEXT NOT NULL)",
    "CREATE TABLE IF NOT EXISTS _ocbrain_memory_migrations ("
    "migration_id TEXT PRIMARY KEY, name TEXT NOT NULL, status TEXT NOT NULL, "
    "started_at REAL NOT NULL, completed_at REAL NOT NULL, "
    "applied_by TEXT NOT NULL, host_os TEXT NOT NULL, "
    "pre_checks_json TEXT NOT NULL DEFAULT '{}', "
    "post_checks_json TEXT NOT NULL DEFAULT '{}', "
    "wal_bytes_before INTEGER, wal_bytes_after INTEGER)",
)

# Documentation/schema-text form (NOT used for execution — see
# CANONICAL_SCHEMA_STATEMENTS; trigger bodies contain semicolons).
CANONICAL_SCHEMA_SCRIPT = ";\n".join(CANONICAL_SCHEMA_STATEMENTS) + ";"

CONTENT_TABLE = "knowledge_entries"
FTS_TABLE = "knowledge_entries_fts"
META_TABLE = "_ocbrain_memory_meta"
MIGRATIONS_TABLE = "_ocbrain_memory_migrations"
CONTENT_COLUMNS: Tuple[str, ...] = ("content", "summary", "tags")

# ── Housekeeping table structural contract (F20) ─────────────────────────────
#
# The per-database bookkeeping tables are part of the memory contract: a
# database is "current" only when these tables have EXACTLY the documented
# shape. A nonzero ledger row count, or a marker whose value merely looks
# right, is NOT sufficient evidence.
#
# "columns" is the exact (name, declared type) sequence in declaration
# order; "primary_key" lists the primary-key columns in order;
# "not_null" lists the columns that must be NOT NULL.
HOUSEKEEPING_TABLE_CONTRACTS: Dict[str, Dict[str, Any]] = {
    META_TABLE: {
        "columns": (("key", "TEXT"), ("value", "TEXT")),
        "primary_key": ("key",),
        "not_null": ("value",),
    },
    MIGRATIONS_TABLE: {
        "columns": (
            ("migration_id", "TEXT"),
            ("name", "TEXT"),
            ("status", "TEXT"),
            ("started_at", "REAL"),
            ("completed_at", "REAL"),
            ("applied_by", "TEXT"),
            ("host_os", "TEXT"),
            ("pre_checks_json", "TEXT"),
            ("post_checks_json", "TEXT"),
            ("wal_bytes_before", "INTEGER"),
            ("wal_bytes_after", "INTEGER"),
        ),
        "primary_key": ("migration_id",),
        "not_null": ("name", "status", "started_at", "completed_at",
                      "applied_by", "host_os", "pre_checks_json",
                      "post_checks_json"),
    },
}

#: The ledger status value that means "this migration is applied".
LEDGER_STATUS_APPLIED = "applied"

def split_sql_statements(script: str) -> List[str]:
    """
    DEPRECATED text splitter — kept only for reference; the canonical schema
    is executed statement-by-statement via CANONICAL_SCHEMA_STATEMENTS
    instead (trigger bodies contain semicolons; safe textual splitting is
    not possible without an SQL lexer).
    """
    statements: List[str] = []
    buf: List[str] = []
    depth = 0
    in_quote = False
    for ch in script:
        if ch == "'":
            in_quote = not in_quote
        if not in_quote:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
        if ch == ";" and depth == 0 and not in_quote:
            text = "".join(buf).strip()
            if text:
                statements.append(text)
            buf = []
            continue
        buf.append(ch)
    text = "".join(buf).strip()
    if text:
        statements.append(text)
    return statements


# ── Known historical definitions (Amendment 8: recognized legacy state) ──────

# Pre-Session 4C `ke_au`: a raw UPDATE against the FTS5 shadow table — unsafe
# for external-content tables (see docs/reports/SESSION4C_REPORT.md).
KNOWN_LEGACY_TRIGGER_KE_AU = """
CREATE TRIGGER ke_au AFTER UPDATE ON knowledge_entries BEGIN
    UPDATE knowledge_entries_fts
    SET content=new.content, summary=new.summary, tags=new.tags
    WHERE rowid=old.rowid;
END"""

# The candidate Rev 3 `ke_ad` (the plain-DELETE delete trigger): recognized
# as a historical definition from now on so databases the candidate
# implementation migrated are a KNOWN state, not an unrecognized one.
# Unsafe for external-content FTS5 tables (EVIDENCE_NOTE.md §3.1 — the
# documented trigger contract, fts5.html §4.4.3, uses the 'delete' command).
KNOWN_LEGACY_TRIGGER_KE_AD = """
CREATE TRIGGER ke_ad AFTER DELETE ON knowledge_entries BEGIN
    DELETE FROM knowledge_entries_fts WHERE rowid=old.rowid;
END"""

KNOWN_LEGACY_DEFINITIONS = {
    "ke_au_raw_update": KNOWN_LEGACY_TRIGGER_KE_AU,
    "ke_ad_plain_delete": KNOWN_LEGACY_TRIGGER_KE_AD,
}

# ── Explicitly supported historical trigger configurations (F16 / F32) ───────
#
# The classification of a trigger set must never be "each missing trigger
# individually appears in an allowed tuple" — that accepted arbitrary partial
# or entirely missing trigger sets as a repairable legacy state. The
# repository history documents exactly THREE trigger sets:
#
#   * 42818a7 (original upload) — ke_ai canonical, ke_au = raw UPDATE against
#     the FTS shadow (unsafe for external-content FTS5), ke_ad = plain DELETE
#     against the FTS shadow (the V1 deletion defect).
#   * da99c12 (Session 4C) — ke_ai canonical, ke_au = the 'delete'-command +
#     INSERT pair (canonical), ke_ad = plain DELETE (still the V1 defect).
#     This is the "V1" state the Rev 3 migration is defined for.
#   * the current canonical contract — all three canonical.
#
# ONLY the two historical configurations below are recognized as repairable
# legacy states. Every other combination (a missing trigger, a legacy ke_au
# combined with a canonical ke_ad, an unknown body, a trigger of the same
# name owned by ANOTHER table) is unsupported and fails closed.
LEGACY_TRIGGER_CONFIGURATIONS: Dict[Tuple[str, str, str], str] = {
    ("canonical", "known_legacy_unsafe", "known_legacy_unsafe"):
        "pre-Session-4C trigger set (raw-UPDATE ke_au, plain-DELETE ke_ad)",
    ("canonical", "canonical", "known_legacy_unsafe"):
        "Session-4C V1 trigger set (the documented V1 migration target)",
}

#: The canonical trigger names, in the order used by the configuration keys.
CANONICAL_TRIGGER_NAMES: Tuple[str, str, str] = ("ke_ai", "ke_au", "ke_ad")

# ── Migration identity ──────────────────────────────────────────────────────

MIGRATION_ID_V1 = "mlc_v1_fts_external_content_trigger_contract"
MIGRATION_NAME_V1 = ("verify external-content FTS trigger contract; rebuild "
                     "and verify FTS; whole-database integrity checks")

# Rev 3 independent fix (checklist A): the V1 contract shipped a plain-DELETE
# ke_ad that corrupts the FTS index on deletes (EVIDENCE_NOTE.md §3.1). The
# corrected contract is a NEW migration identity so databases migrated under
# V1 are re-migrated (idempotent, additive) rather than silently trusted.
MIGRATION_ID_V2 = "mlc_v2_fts_delete_command_contract"
MIGRATION_NAME_V2 = ("replace plain-DELETE ke_ad with the fts5.html-documented "
                     "'delete' command form; rebuild and verify FTS; "
                     "whole-database integrity checks")
# The ledger row every CURRENT database must carry (validation requires it).
MIGRATION_ID_CURRENT = MIGRATION_ID_V2

META_SCHEMA_STATE = "memory_schema_state"
SCHEMA_STATE_FRESH_CURRENT = "initialized_fresh_current"
SCHEMA_STATE_MIGRATED = "migrated_to_current"
SCHEMA_STATES_CURRENT = (SCHEMA_STATE_FRESH_CURRENT, SCHEMA_STATE_MIGRATED)

# FTS5 option values that would be recorded in the shadow config table by
# runtime commands (e.g. secure-delete). Recognized so an audit can report
# rather than fail on legitimate runtime state (Amendment 6/8).
FTS_CONFIG_RECOGNIZED_KEYS = {"version", "secure-delete"}


class MemoryReadinessError(RuntimeError):
    """
    Fail-closed refusal of memory readiness (Amendment 2B.3–5).

    Raised by storage-backend construction when the database's own migration
    state or schema contract does not currently qualify for ordinary memory
    service. The constructor never mutates the database in response; the
    operator runs the dedicated maintenance command instead.
    """

    def __init__(self, finding: Dict[str, Any], remediation: str):
        self.finding = finding
        self.remediation = remediation
        reason = finding.get("reason", "unspecified")
        super().__init__(f"Memory readiness refused: {reason}")
        self.remediation_plan = remediation


# ── Normalization & parsing (NOT substring checks — Amendment 8) ─────────────
#
# REV-G4 / F13: the previous implementation removed comments with a
# whole-statement regular expression and compared the result with
# `str.casefold()`. Both are unsound for SQL:
#   * a string literal containing "--" or "/* ... */" was destroyed (the
#     comment regex matched INSIDE the literal);
#   * `str.casefold()` is Unicode-aware, so it changes identifier semantics
#     (e.g. 'İ'.casefold() is two code points) and it also lowercased STRING
#     LITERAL VALUES, so 'unknown' and 'UNKNOWN' compared EQUAL.
#
# The tokenizer below is quote-aware: comments are recognized only OUTSIDE
# quoted content, string literal values are preserved byte-for-byte, and
# identifiers are compared with ASCII-only case folding (SQLite identifier
# comparison is ASCII case-insensitive, not Unicode case folding).

class SqlParseError(ValueError):
    """Raised when SQL cannot be tokenized or parsed unambiguously."""


# Token kinds
TOK_WORD = "word"           # bare identifier / keyword
TOK_STRING = "string"       # 'literal'
TOK_QUOTED_IDENT = "ident"  # "ident" | `ident` | [ident]
TOK_NUMBER = "number"
TOK_PUNCT = "punct"
TOK_COMMENT = "comment"


class SqlToken:
    """One token: kind, raw text and semantic value."""

    __slots__ = ("kind", "text", "value")

    def __init__(self, kind: str, text: str, value: str):
        self.kind = kind
        self.text = text
        self.value = value

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return f"SqlToken({self.kind!r}, {self.text!r})"


def _ascii_lower(text: str) -> str:
    """
    ASCII-only lower-casing.

    SQLite identifier comparison is ASCII case-insensitive; Python's
    `str.lower()`/`str.casefold()` are Unicode-aware and would map e.g.
    'İ' (U+0130) to 'i̇' (two code points) — changing identifier
    semantics. Only A-Z is folded here.
    """
    return "".join(chr(ord(c) + 32) if "A" <= c <= "Z" else c for c in text)


_IDENT_START = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_")
_IDENT_CONT = _IDENT_START | set("0123456789$")
_DIGITS = set("0123456789")


def tokenize_sql(sql: str) -> List[SqlToken]:
    """
    Tokenize SQL into a quote-aware token list.

    Handles: `--` line comments, `/* */` block comments (unterminated → error),
    `'...'` string literals with `''` escapes, `"..."` / `` `...` `` / `[...]`
    quoted identifiers, numbers, bare words and single-character punctuation.

    Raises SqlParseError on unterminated quotes or comments — an ambiguous
    statement is never "parsed optimistically".
    """
    if sql is None:
        return []
    text = str(sql)
    tokens: List[SqlToken] = []
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        if ch in " \t\r\n\f\v":
            i += 1
            continue
        if ch == "-" and i + 1 < n and text[i + 1] == "-":
            j = text.find("\n", i)
            if j == -1:
                j = n
            tokens.append(SqlToken(TOK_COMMENT, text[i:j], ""))
            i = j
            continue
        if ch == "/" and i + 1 < n and text[i + 1] == "*":
            j = text.find("*/", i + 2)
            if j == -1:
                raise SqlParseError(
                    f"unterminated block comment in SQL: {sql!r}")
            tokens.append(SqlToken(TOK_COMMENT, text[i:j + 2], ""))
            i = j + 2
            continue
        if ch == "'":
            j = i + 1
            buf: List[str] = []
            while True:
                if j >= n:
                    raise SqlParseError(
                        f"unterminated string literal in SQL: {sql!r}")
                c = text[j]
                if c == "'":
                    if j + 1 < n and text[j + 1] == "'":
                        buf.append("'")
                        j += 2
                        continue
                    j += 1
                    break
                buf.append(c)
                j += 1
            tokens.append(SqlToken(TOK_STRING, text[i:j], "".join(buf)))
            i = j
            continue
        if ch in '"`':
            closing = ch
            j = i + 1
            buf = []
            while True:
                if j >= n:
                    raise SqlParseError(
                        f"unterminated quoted identifier in SQL: {sql!r}")
                c = text[j]
                if c == closing:
                    if j + 1 < n and text[j + 1] == closing:
                        buf.append(closing)
                        j += 2
                        continue
                    j += 1
                    break
                buf.append(c)
                j += 1
            tokens.append(SqlToken(TOK_QUOTED_IDENT, text[i:j], "".join(buf)))
            i = j
            continue
        if ch == "[":
            j = text.find("]", i + 1)
            if j == -1:
                raise SqlParseError(
                    f"unterminated bracketed identifier in SQL: {sql!r}")
            tokens.append(SqlToken(TOK_QUOTED_IDENT, text[i:j + 1],
                                   text[i + 1:j]))
            i = j + 1
            continue
        if ch in _IDENT_START:
            j = i + 1
            while j < n and text[j] in _IDENT_CONT:
                j += 1
            raw = text[i:j]
            tokens.append(SqlToken(TOK_WORD, raw, _ascii_lower(raw)))
            i = j
            continue
        if ch in _DIGITS or (ch == "." and i + 1 < n and text[i + 1] in _DIGITS):
            j = i
            while j < n and (text[j] in _DIGITS or text[j] == "." or
                             text[j] in "eE" or
                             (text[j] in "+-" and j > i and
                              text[j - 1] in "eE")):
                j += 1
            raw = text[i:j]
            tokens.append(SqlToken(TOK_NUMBER, raw, raw))
            i = j
            continue
        tokens.append(SqlToken(TOK_PUNCT, ch, ch))
        i += 1
    return tokens


def _escape_literal(value: str) -> str:
    return value.replace("'", "''")


def _join_tokens(parts: List[str]) -> str:
    """
    Join canonical token renderings with a single space, except around the
    `.` qualifier operator: a dotted identifier stays intact ("old.rowid"),
    which keeps qualified-name comparisons faithful while remaining
    deterministic and whitespace-insensitive.
    """
    out: List[str] = []
    for part in parts:
        if not out:
            out.append(part)
            continue
        if part == "." or out[-1].endswith("."):
            out.append(part)
        else:
            out.append(" ")
            out.append(part)
    return "".join(out)


def normalize_sql(sql: str) -> str:
    """
    Semantic comparison basis (F13): a quote-aware canonical form.

    * comments are removed — but ONLY outside quoted content;
    * string literal VALUES are preserved exactly (case-sensitive): 'unknown'
      and 'UNKNOWN' are NOT the same statement;
    * identifiers (bare or quoted) are ASCII-lowercased, matching SQLite's
      ASCII case-insensitive identifier comparison;
    * whitespace is collapsed to a single separator between tokens.

    A statement that cannot be tokenized unambiguously raises
    SqlParseError instead of being compared optimistically.
    """
    if sql is None:
        return ""
    parts: List[str] = []
    for tok in tokenize_sql(sql):
        if tok.kind == TOK_COMMENT:
            continue
        if tok.kind == TOK_STRING:
            parts.append("'" + _escape_literal(tok.value) + "'")
        elif tok.kind in (TOK_WORD, TOK_QUOTED_IDENT):
            parts.append(_ascii_lower(tok.value))
        else:
            parts.append(tok.text)
    text = _join_tokens(parts).strip()
    return text.rstrip(";").strip()


def _split_top_level(tokens: List[SqlToken], sep: str = ",") -> List[List[SqlToken]]:
    """Split a token list on a top-level separator (respecting nesting)."""
    groups: List[List[SqlToken]] = []
    current: List[SqlToken] = []
    depth = 0
    for tok in tokens:
        if tok.kind == TOK_PUNCT:
            if tok.text in "([":
                depth += 1
            elif tok.text in ")]":
                depth -= 1
                if depth < 0:
                    raise SqlParseError("unbalanced parentheses in SQL")
            elif tok.text == sep and depth == 0:
                groups.append(current)
                current = []
                continue
        current.append(tok)
    groups.append(current)
    if depth != 0:
        raise SqlParseError("unbalanced parentheses in SQL")
    return groups


def _tokens_text(tokens: List[SqlToken]) -> str:
    """Render tokens back to canonical text (for predicate comparison)."""
    parts: List[str] = []
    for tok in tokens:
        if tok.kind == TOK_STRING:
            parts.append("'" + _escape_literal(tok.value) + "'")
        elif tok.kind in (TOK_WORD, TOK_QUOTED_IDENT):
            parts.append(_ascii_lower(tok.value))
        else:
            parts.append(tok.text)
    return _join_tokens(parts).strip()


def parse_create_virtual_table(sql: str) -> Tuple[List[str], Dict[str, str]]:
    """
    Parse `CREATE VIRTUAL TABLE name USING fts5(a, b, c, option='value')`
    into (declared columns, options) — F34: strict, quote-aware parsing.

    Every clause is validated and NO trailing SQL is tolerated: a definition
    that cannot be fully accounted for raises SqlParseError (never silently
    treated as canonical).
    """
    tokens = [t for t in tokenize_sql(sql) if t.kind != TOK_COMMENT]
    if not tokens:
        raise SqlParseError("empty CREATE VIRTUAL TABLE definition")
    i = 0

    def word() -> str:
        nonlocal i
        if i >= len(tokens) or tokens[i].kind != TOK_WORD:
            raise SqlParseError(
                f"expected a keyword in CREATE VIRTUAL TABLE: {sql!r}")
        val = tokens[i].value
        i += 1
        return val

    def punct(expected: str) -> None:
        nonlocal i
        if i >= len(tokens) or tokens[i].kind != TOK_PUNCT or \
                tokens[i].text != expected:
            raise SqlParseError(
                f"expected {expected!r} in CREATE VIRTUAL TABLE: {sql!r}")
        i += 1

    if word() != "create":
        raise SqlParseError(f"not a CREATE VIRTUAL TABLE statement: {sql!r}")
    if word() != "virtual":
        raise SqlParseError(f"not a CREATE VIRTUAL TABLE statement: {sql!r}")
    if word() != "table":
        raise SqlParseError(f"not a CREATE VIRTUAL TABLE statement: {sql!r}")
    if i < len(tokens) and tokens[i].kind == TOK_WORD and \
            tokens[i].value == "if":
        i += 1
        if i < len(tokens) and tokens[i].value == "not":
            i += 1
            if i < len(tokens) and tokens[i].value == "exists":
                i += 1
    if i >= len(tokens) or tokens[i].kind not in (TOK_WORD, TOK_QUOTED_IDENT):
        raise SqlParseError(
            f"CREATE VIRTUAL TABLE without a table name: {sql!r}")
    i += 1                                   # the table name
    if word() != "using":
        raise SqlParseError(
            f"CREATE VIRTUAL TABLE without a USING clause: {sql!r}")
    if i >= len(tokens) or tokens[i].kind != TOK_WORD:
        raise SqlParseError(
            f"CREATE VIRTUAL TABLE without a module name: {sql!r}")
    module = tokens[i].value
    i += 1
    if module != "fts5":
        raise SqlParseError(
            f"unsupported virtual table module {module!r}: {sql!r}")
    punct("(")
    depth = 1
    body: List[SqlToken] = []
    while i < len(tokens):
        tok = tokens[i]
        if tok.kind == TOK_PUNCT and tok.text == "(":
            depth += 1
        elif tok.kind == TOK_PUNCT and tok.text == ")":
            depth -= 1
            if depth == 0:
                i += 1
                break
        body.append(tok)
        i += 1
    else:
        raise SqlParseError(
            f"unterminated CREATE VIRTUAL TABLE argument list: {sql!r}")
    if i != len(tokens):
        raise SqlParseError(
            f"unparsed trailing SQL after CREATE VIRTUAL TABLE: {sql!r}")

    columns: List[str] = []
    options: Dict[str, str] = {}
    for group in _split_top_level(body, ","):
        if not group:
            continue
        # option: name = 'value'
        if len(group) >= 3 and group[0].kind in (TOK_WORD, TOK_QUOTED_IDENT) \
                and group[1].kind == TOK_PUNCT and group[1].text == "=" \
                and group[2].kind == TOK_STRING:
            options[_ascii_lower(group[0].value)] = group[2].value
            continue
        # a plain column name
        if len(group) == 1 and group[0].kind in (TOK_WORD, TOK_QUOTED_IDENT):
            columns.append(_ascii_lower(group[0].value))
            continue
        # Anything else cannot be proven semantically equivalent to the
        # canonical definition — signal fail-closed classification (Am. 8).
        raise SqlParseError(
            f"unrecognized FTS5 definition token: {_tokens_text(group)!r}")
    return columns, options


def sqlite_file_uri(db_path: str, mode: str = "ro") -> str:
    """
    Correctly encoded ABSOLUTE SQLite file URI (F21).

    A raw filesystem path must never be concatenated into
    `file:<path>?mode=...`: a path containing '#', '?' or '%' changes the
    URI's meaning (SQLite parses the fragment and the query), a Windows
    drive path needs a leading slash, and a UNC path needs the authority
    form. This helper percent-encodes the path, normalizes the separators
    and appends the requested open mode.

    `mode="ro"` opens an existing file read-only and NEVER creates it;
    `mode="rw"` opens an existing file read-write and NEVER creates it
    either (it removes the check-then-create TOCTOU window); `mode="rwc"`
    is the only mode that may create a file.
    """
    from urllib.parse import quote

    absolute = os.path.abspath(str(db_path))
    normalized = absolute.replace("\\", "/")
    if normalized.startswith("//"):
        # UNC path: file://server/share/... (authority form)
        return "file:" + quote(normalized, safe="/:") + f"?mode={mode}"
    if len(normalized) > 1 and normalized[1] == ":":
        # Windows drive path: file:/C:/...
        normalized = "/" + normalized
    return "file:" + quote(normalized, safe="/:") + f"?mode={mode}"


def canonical_columns() -> List[str]:
    cols, _ = parse_create_virtual_table(CANONICAL_FTS_DDL)
    return cols


def canonical_fts_options() -> Dict[str, str]:
    _, opts = parse_create_virtual_table(CANONICAL_FTS_DDL)
    return opts


def parse_create_index(sql: str) -> Dict[str, Any]:
    """
    Parse `CREATE [UNIQUE] INDEX name ON table (term, ...) [WHERE predicate]`
    into its semantic parts — F34: strict, quote-aware parsing.

    Returns {"name", "table", "unique", "columns": [(col, collation, desc)],
    "where", "terms": [...]} where each term records whether it is a plain
    column or an EXPRESSION (an expression can never be equivalent to a
    canonical column term) — REV-G4-03.

    Every clause is validated and no trailing SQL is tolerated: an
    unrecognized grammar raises SqlParseError (never "canonical").
    """
    tokens = [t for t in tokenize_sql(sql) if t.kind != TOK_COMMENT]
    if not tokens:
        raise SqlParseError("empty CREATE INDEX definition")
    i = 0

    def word() -> str:
        nonlocal i
        if i >= len(tokens) or tokens[i].kind != TOK_WORD:
            raise SqlParseError(
                f"expected a keyword in CREATE INDEX: {sql!r}")
        val = tokens[i].value
        i += 1
        return val

    def punct(expected: str) -> None:
        nonlocal i
        if i >= len(tokens) or tokens[i].kind != TOK_PUNCT or \
                tokens[i].text != expected:
            raise SqlParseError(
                f"expected {expected!r} in CREATE INDEX: {sql!r}")
        i += 1

    if word() != "create":
        raise SqlParseError(f"not a CREATE INDEX statement: {sql!r}")
    unique = False
    if i < len(tokens) and tokens[i].kind == TOK_WORD:
        if tokens[i].value == "unique":
            unique = True
            i += 1
        elif tokens[i].value == "if":
            i += 1
            if i < len(tokens) and tokens[i].value == "not":
                i += 1
                if i < len(tokens) and tokens[i].value == "exists":
                    i += 1
    if word() != "index":
        raise SqlParseError(f"not a CREATE INDEX statement: {sql!r}")
    if i >= len(tokens) or tokens[i].kind not in (TOK_WORD, TOK_QUOTED_IDENT):
        raise SqlParseError(f"CREATE INDEX without an index name: {sql!r}")
    raw_name = tokens[i].value
    i += 1
    if word() != "on":
        raise SqlParseError(f"CREATE INDEX without an ON clause: {sql!r}")
    if i >= len(tokens) or tokens[i].kind not in (TOK_WORD, TOK_QUOTED_IDENT):
        raise SqlParseError(f"CREATE INDEX without a table name: {sql!r}")
    table = tokens[i].value
    i += 1
    punct("(")
    depth = 1
    body: List[SqlToken] = []
    while i < len(tokens):
        tok = tokens[i]
        if tok.kind == TOK_PUNCT and tok.text == "(":
            depth += 1
        elif tok.kind == TOK_PUNCT and tok.text == ")":
            depth -= 1
            if depth == 0:
                i += 1
                break
        body.append(tok)
        i += 1
    else:
        raise SqlParseError(
            f"unterminated CREATE INDEX column list: {sql!r}")

    where = ""
    if i < len(tokens) and tokens[i].kind == TOK_WORD and \
            tokens[i].value == "where":
        i += 1
        where_tokens: List[SqlToken] = []
        while i < len(tokens):
            where_tokens.append(tokens[i])
            i += 1
        where = _tokens_text(where_tokens)
    if i != len(tokens):
        raise SqlParseError(
            f"unparsed trailing SQL after CREATE INDEX: {sql!r}")

    columns: List[Tuple[str, str, bool]] = []
    terms: List[Dict[str, Any]] = []
    for group in _split_top_level(body, ","):
        if not group:
            continue
        # col [COLLATE name] [ASC|DESC]
        coll = ""
        desc = False
        rest = list(group)
        if len(rest) >= 2 and rest[-2].kind == TOK_WORD and \
                rest[-2].value == "collate":
            coll = _ascii_lower(rest[-1].value)
            rest = rest[:-2]
        if rest and rest[-1].kind == TOK_WORD and rest[-1].value in ("asc", "desc"):
            desc = rest[-1].value == "desc"
            rest = rest[:-1]
        if len(rest) == 1 and rest[0].kind in (TOK_WORD, TOK_QUOTED_IDENT):
            col = _ascii_lower(rest[0].value)
            is_expression = False
        elif rest:
            # an expression (function call, literal, arithmetic) — parseable
            # but NEVER equivalent to a canonical column term
            col = _tokens_text(rest)
            is_expression = True
        else:
            raise SqlParseError(f"empty index column term in: {sql!r}")
        columns.append((col, coll, desc))
        terms.append({"column": col, "collation": coll, "desc": desc,
                      "expression": is_expression})

    return {
        "name": _ascii_lower(raw_name),
        "table": _ascii_lower(table),
        "unique": unique,
        "columns": columns,
        "where": where,
        "terms": terms,
    }


def trigger_audit_classification(trigger_sql: Optional[str], name: str) -> str:
    """
    Classify a stored trigger definition against the contract.

    Returns one of:
      "canonical"            — semantically equal to the canonical definition.
      "known_legacy_unsafe"  — exactly a recognized historical (unsafe) body.
      "unknown"              — anything else: fail closed (Amendment 8).
    """
    if trigger_sql is None:
        return "missing"
    norm = normalize_sql(trigger_sql)
    if name in CANONICAL_TRIGGER_DDL and norm == normalize_sql(CANONICAL_TRIGGER_DDL[name]):
        return "canonical"
    if name == "ke_au" and norm == normalize_sql(KNOWN_LEGACY_TRIGGER_KE_AU):
        return "known_legacy_unsafe"
    if name == "ke_au" and norm == normalize_sql(_LEGACY_KE_AU_INLINE):
        return "known_legacy_unsafe"
    if name == "ke_ad" and norm == normalize_sql(KNOWN_LEGACY_TRIGGER_KE_AD):
        return "known_legacy_unsafe"
    return "unknown"


# The historical ke_au body as written inline in the original repository
# schema (single-line formatted). Recognized so the migration can name it.
_LEGACY_KE_AU_INLINE = (
    "CREATE TRIGGER ke_au AFTER UPDATE ON knowledge_entries BEGIN\n"
    "    UPDATE knowledge_entries_fts SET content=new.content, "
    "summary=new.summary, tags=new.tags WHERE rowid=old.rowid;\n"
    "END"
)
