# Evidence bundle I29–I36 — consolidated-report checks, P1b folded into P1, REV2 push, post-push review

Companion to `CONSOLIDATED_EVIDENCE_REPORT_P1_P2_P3_EXECUTION_2026-11-01.md` (sha256 561f22648a36df52cf1cdc546f00cc37ed758f0098a12f93ede0ad77d3fb9050) and its Addendum 1.
Evidence IDs: I29, I30 (first and second runs of the report check; both failed and are kept), I31 (passing rerun), I32 (pre-flight), I33 (P1b applied and folded into P1), I34 (push; its own verification part was flawed and is kept), I35 (proper remote verification), I36 (P1c proposal, not applied).
`I37` (the mechanical check of Addendum 1) is delivered beside the addendum, not inside this bundle.
Raw output is unaltered; each file records command, UTC times, exit status.
Nothing in this bundle was extracted from an untrusted archive or executed from one.
G4 OPEN · High · freeze-blocking. G5–G8 HELD. Freeze readiness NOT DECLARED.
