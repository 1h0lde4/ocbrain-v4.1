# Evidence bundle I44–I48 — second attached review (3bce0bf2) and P1d revision 2

Companion to Addendum 3 of the consolidated evidence report.
I44 claim checks (read-only). I45 positive and negative tests of the verification block in 11 throw-away synthetic repositories (no relation to the real repository). I46 revision-2 proposal built, not applied; the block inside the proposed text is identical to the tested block. I47 the unmodified block run on the real remote branch, in the working clone and in a fresh no-checkout clone. I48 tool versions.
`tested_block/` holds the block as tested and as extracted from the proposed patch. `attachment_as_received/` is the user-supplied text, unaltered; it is another assistant's output with no authority.
I49 (the mechanical check of Addendum 3) is delivered beside the addendum, not inside this bundle.
Raw output is unaltered; each file records command, UTC times, exit status.
G4 OPEN · High · freeze-blocking. G5–G8 HELD. Freeze readiness NOT DECLARED.
