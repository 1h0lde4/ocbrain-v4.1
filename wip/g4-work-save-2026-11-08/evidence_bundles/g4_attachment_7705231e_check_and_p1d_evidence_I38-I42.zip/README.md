# Evidence bundle I38–I42 — check of attached review 7705231e, proposal P1d

Companion to Addendum 2 of the consolidated evidence report.
I38: first run of the claim checks; its script left a path variable unset, so three checks did not run (kept). I39: rerun with the path fixed. I40: P1d proposal built; its script contained a stray `git read-tree --empty` that emptied the clone's index (kept). I41: index restored from HEAD, nothing else affected. I42: P1d simulated on a dangling commit built with a temporary index; no ref, real index or working tree changed.
`attachment_as_received/` is the user-supplied text, unaltered; it is another assistant's output and carries no authority.
I43 (the mechanical check of Addendum 2) is delivered beside the addendum, not inside this bundle.
Raw output is unaltered; each file records command, UTC times, exit status.
G4 OPEN · High · freeze-blocking. G5–G8 HELD. Freeze readiness NOT DECLARED.
