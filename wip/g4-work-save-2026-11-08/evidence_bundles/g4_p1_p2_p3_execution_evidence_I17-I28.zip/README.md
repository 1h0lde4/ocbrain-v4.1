# Evidence bundle I17–I28 — execution of P1, P2 and P3 (2026-10-31 / 2026-11-01)

Accompanies `CONSOLIDATED_EVIDENCE_REPORT_P1_P2_P3_EXECUTION_2026-11-01.md`. Governing statuses, unchanged: G4 OPEN · High · freeze-blocking. G5–G8 HELD. Freeze readiness NOT DECLARED. No implementation authorized.

Verify the bundle: `sha256sum -c MANIFEST.sha256` (run from this directory).

| Folder | Content |
|---|---|
| `evidence/` | I17–I18 (check of the attached review), I19–I20 (read-only state inventory), I21 (pre-flight), I22 (P1 local commit), I23 (P2 first local commit), I24 (P3 conditional apply), I25 (wording fixes, chain rebuilt), I26 (REV3 push), I27 (P1 message amended, P1b built), I28 (final state). Each records command, UTC start and finish, exit status and unaltered output. |
| `scripts/` | the read-only scripts used (`preflight.sh`, `final_state.sh`, `inventory.sh`, `inventory2.sh`) and the recorder `ev.sh` |
| `commit_messages/` | the final messages of the three commits, and the first P1 message (superseded: it said that handoff.md §7 records the handoff commit hash, which is not true) |
| `commits_format_patch/` | `git format-patch` of the three final commits. The P1 commit exists only in the working clone (it is not pushed); this file preserves it. |
| `proposals/` | P1 (as executed), P1b (proposed, NOT applied), P3 (as executed, with its condition note) |
| `final_files/` | the erratum as pushed |

Not in this bundle: the REV3 ZIP; evidence I01–I16 (delivered with Addenda 2 and 3 and their bundle `g4_rev3_zip_authentication_evidence_I01-I14.zip`); the report itself (it cites this bundle's hash). I29 (the author's mechanical check of the report text) is delivered beside the report for the same reason.

Secret scan over this bundle (GitHub token shapes, API-key shapes, private-key headers, auth headers, e-mail address): no match.
