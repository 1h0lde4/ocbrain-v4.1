#!/usr/bin/env python3
"""Final mechanical consistency check of the report (read-only).
usage: python3 -I check_final.py REPORT EVIDENCE_DIR REPO WT_AUDIT
Checks: placeholders, section headings 1..13, final status line, evidence IDs exist,
40-hex ids resolvable in the repo or audit worktree, 64-hex digests present in evidence text.
"""
import re, sys, os, subprocess

report, evdir, repo, wt = sys.argv[1:5]
txt = open(report, encoding="utf-8").read()
lines = txt.splitlines()
ok = True


def fail(msg):
    global ok
    ok = False
    print("FAIL:", msg)


# 1 placeholders
for tok in ("PLACEHOLDER", "REVIEW_STATUS", "<FILL"):
    if tok in txt:
        fail(f"token present: {tok}")
print("placeholders: checked")

# 2 headings
heads = [l for l in lines if l.startswith("## ")]
print("level-2 headings:", len(heads))
for h in heads:
    print("  ", h[:90])
nums = [int(m.group(1)) for h in heads if (m := re.match(r"## (\d+)\. ", h))]
if nums != list(range(1, 14)):
    fail(f"section numbers not 1..13: {nums}")

# 3 final line
nonempty = [l for l in lines if l.strip()]
want = "G4 OPEN · High · freeze-blocking. G5–G8 HELD. Freeze readiness NOT DECLARED."
print("last non-empty line:", nonempty[-1])
if nonempty[-1] != want:
    fail("final status line mismatch")

# 4 gate statuses
gate_lines = [l for l in lines if l.startswith("| ") and "**" in l.split("|")[2:3][0:1][0] if len(l.split("|")) > 3] if False else []
in_gate = False
statuses = []
for l in lines:
    if l.startswith("| Gate | Status"):
        in_gate = True
        continue
    if in_gate:
        if not l.startswith("|"):
            break
        cells = [c.strip() for c in l.strip("|").split("|")]
        if cells and not set(cells[0]) <= set("-"):
            statuses.append((cells[0].strip("*"), cells[1].strip("*")))
print("gate rows:", len(statuses))
allowed = {"PASS", "FAIL", "BLOCKED", "NOT RUN"}
for g, s in statuses:
    print(f"   {s:8s} {g}")
    if s not in allowed:
        fail(f"gate status not allowed: {g} -> {s}")
mand_bad = [g for g, s in statuses if g != "Overall result" and s != "PASS"]
overall = [s for g, s in statuses if g == "Overall result"]
print("non-PASS gates:", mand_bad, "| overall:", overall)
if overall != ["BLOCKED"] or sorted(mand_bad) != ["Archive integrity and contents", "Original ZIP authentication"]:
    fail("gate set inconsistent with the stated overall result")

# 5 evidence IDs
have = {f.split("_")[0] for f in os.listdir(evdir) if re.match(r"^[A-G]\d\d_", f)}
cited = set(re.findall(r"\b([A-G]\d\d)\b", txt))
print("evidence files:", len(have), "| ids cited in report:", len(cited))
missing = sorted(cited - have)
unused = sorted(have - cited)
print("cited but no file:", missing)
print("file but not cited:", unused)
if missing:
    fail(f"evidence ids cited without a file: {missing}")

# 6 40-hex
def objtype(d, sha):
    r = subprocess.run(["git", "-C", d, "cat-file", "-t", sha], capture_output=True, text=True)
    return r.stdout.strip() if r.returncode == 0 else None

full40 = sorted(set(re.findall(r"\b[0-9a-f]{40}\b", txt)))
print("40-hex ids:", len(full40))
unres = []
for s in full40:
    t = objtype(repo, s) or objtype(wt, s)
    if not t:
        unres.append(s)
print("unresolved in repo/audit worktree:", unres)

# 7 64-hex
evtext = ""
for f in os.listdir(evdir):
    p = os.path.join(evdir, f)
    if os.path.isfile(p):
        evtext += open(p, encoding="utf-8", errors="replace").read()
full64 = sorted(set(re.findall(r"\b[0-9a-f]{64}\b", txt)))
print("64-hex digests:", len(full64))
nf = [s for s in full64 if s not in evtext]
print("64-hex not found in any evidence file text:", nf)
if nf:
    fail("digest in report not backed by evidence text")

print("RESULT:", "ALL MECHANICAL CHECKS PASSED" if ok else "FAILURES PRESENT (see above)")
sys.exit(0 if ok else 1)
