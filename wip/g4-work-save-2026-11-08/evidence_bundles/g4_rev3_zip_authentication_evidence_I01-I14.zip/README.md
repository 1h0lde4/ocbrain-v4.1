# Evidence bundle I01–I14 — REV3 ZIP authentication (Addendum 2, 2026-10-29)

Accompanies `ADDENDUM_2_2026-10-29_REV3_ZIP_authentication.md`. Governing statuses, unchanged: G4 OPEN · High · freeze-blocking. G5–G8 HELD. Freeze readiness NOT DECLARED. No implementation authorized. Nothing in this bundle changes a repository.

Verify the bundle: `sha256sum -c MANIFEST.sha256` (run from this directory).

## Not in this bundle
- The REV3 ZIP itself (the user's file, 254,581 bytes) and its extraction. Its measured digest and the inspection output are recorded in I01–I05.
- Evidence A01–G03 of the earlier report and H01–H04 of Addendum 1; they are in the earlier bundles delivered with those documents.
- The revision-1 bundle that supplied two protocol-run JSONs to the checker (see Addendum 2 §1 item 5, §9).

## Evidence index (each file records command, UTC start and finish, exit status and unaltered output)
| ID | What it records |
|---|---|
| I01 | identity of the supplied file: path, size, type, time, SHA-256 |
| I02 | exact comparison with Value A and Value B (offset 23); safe inspection of the archive listing before extraction |
| I03 | extraction into a new empty directory; `sha256sum -c MANIFEST.sha256` (86/86); unlisted/missing check |
| I04 | inventory against my REV2 bundle (three files differ); inner-file digests |
| I05 | inner files against the in-repo copies (one final newline difference) |
| I06 | 83/83 transcription check re-run, with the inputs named in Addendum 2 §1 item 5 |
| I07 | first raw-docs passage check, 9/11 (flawed tag stripping; kept, not deleted) |
| I08 | corrected passage check, 11/11 |
| I09 | P3 patch build and apply-check in a scratch directory |
| I10 | final repository state, remote tips, PR #90, `main` tip (2026-10-30) |
| I11 | `main` re-measured: FTS source blobs, paths changed since `f13bfde`, open PRs, DEBT-042 row |
| I12 | path scan of the new PRs #100 and #101 |
| I13 | condition note added to P3; apply-check repeated (hash before and after) |
| I14 | the four `main` tips named in the addendum (`f13bfde`, `6e41187`, `7bb0ce2`, `16d663a`): commit, date, title, parents; each is an ancestor of the current tip |

I15 and I16 (the author's mechanical checks of the addendum text; I15 is the first run, which failed on two points and is kept) are delivered beside the addendum, not in this bundle, because they check the text that cites this bundle's hash.

`derived/` holds the check outputs the addendum cites (manifest check, F-in-extraction/manifest lists, 83/83 result JSON `ae12c539…`). `scripts/` holds my own scripts; `rev2_numbers_check.py` (`730ae766…`) is my pre-packaging copy, not the one from the archive. `proposed_diffs/` holds P2 (completed) and P3, proposals only; `P3_before_condition_note.patch` is the version checked by I09 and by the independent reviewer.

Secret scan over this bundle (patterns for GitHub tokens, API-key shapes, private-key headers, auth headers): no match.
