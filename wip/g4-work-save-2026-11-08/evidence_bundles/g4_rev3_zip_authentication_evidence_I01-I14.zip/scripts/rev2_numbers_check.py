"""rev2_numbers_check.py -- transcription check for the figures quoted in packet REV 2.

For every new figure in `g4_fts_correctness_batch_decision_packet_1d813bd_REV2_PROPOSED.md` this script (1) derives the quantity from the raw probe
JSON (or from git for history facts) and compares it with the literal value expected by the author, and (2) checks that the literal string
used in the packet text is present.  It is a transcription check (the expectations are hard-coded, like packet_numbers_check.py); the
independence comes from deriving the left-hand side from the raw outputs and from git, and from scanning the packet text for the string.

Usage: python3.12 -I rev2_numbers_check.py <out.json> --out DIR --packet PACKET_REV2.md --worktree WT --preserved DIR
       --derivation derivation.json --contract-compare compare.json
Read-only.  Exclusive-create output.  Exit status 1 if any check fails.
"""
import argparse
import json
import os
import re
import subprocess
import sys

sys.dont_write_bytecode = True
ap = argparse.ArgumentParser()
ap.add_argument("outfile")
ap.add_argument("--out", required=True)
ap.add_argument("--packet", required=True)
ap.add_argument("--worktree", required=True)
ap.add_argument("--preserved", required=True)
ap.add_argument("--derivation", required=True)
ap.add_argument("--contract-compare", required=True)
A = ap.parse_args()

TEXT = re.sub(r"\s+", " ", open(A.packet, encoding="utf-8").read())
J = lambda n: json.load(open(os.path.join(A.out, n)))  # noqa: E731
checks = []


def chk(cid, derived, expected, pat=None):
    ok_v = derived == expected
    ok_t = True if pat is None else (re.sub(r"\s+", " ", pat) in TEXT)
    checks.append({"id": cid, "derived": derived, "expected": expected, "value_ok": ok_v, "text_pattern": pat, "text_ok": ok_t, "ok": ok_v and ok_t})


def git(*args):
    p = subprocess.run(["git", "-C", A.worktree, *args], capture_output=True, text=True,
                       env={"PATH": os.environ.get("PATH", ""), "GIT_TERMINAL_PROMPT": "0", "HOME": "/nonexistent"})
    return p.stdout.strip()


# ---------------------------------------------------------------- R1 product path
pp = J("fts_baseline_product_path_run1.json")["fixtures"]
order = ["F1_ghost_nonexistent", "F2_reused_disjoint", "F3_reused_overlap", "F4_pre4c_then_4c_migration", "F5a_random_20261013", "F5b_random_7", "F5c_random_99"]
chk("R1/product-path/startup-repairs-nothing", [pp[f]["historical_product_startup"]["ghost_state_repaired_by_startup"] for f in order], [False] * 7, "repairs nothing (fingerprint unchanged, 7/7)")
chk("R1/product-path/fingerprint-unchanged", [pp[f]["historical_product_startup"]["fingerprint_unchanged_by_reopen"]["all"] for f in order], [True] * 7)
ops = [pp[f]["historical_product_api_workload"]["workload"]["ops"] for f in order]
chk("R1/product-path/ops", ops, [13, 15, 15, 9, 13, 9, 45], "13/15/15/9/13/9/45 = 119")
chk("R1/product-path/ops-sum", sum(ops), 119)
chk("R1/product-path/op-errors", [pp[f]["historical_product_api_workload"]["workload"]["op_errors"] for f in order], [0] * 7, "throws 0 exceptions")
cmpk = ("ops_equal", "op_errors_equal", "ops_with_discrepancy_equal", "false_positive_total_equal", "false_negative_total_equal", "max_raw_ghost_rowids_equal", "after_workload_raw_ghost_equal", "after_workload_rank1_equal")
chk("R1/product-path/equals-raw-sql-N", all(pp[f]["comparison_with_preserved_raw_sql_N_run"][k] for f in order for k in cmpk), True, "(raw ghost rowids 13/8/9/2/53/94/181, `rank=1` failing; 7/7)")
chk("R1/product-path/raw-ghost-after", [pp[f]["historical_product_api_workload"]["after_workload"]["raw_ghost_rowids"] for f in order], [13, 8, 9, 2, 53, 94, 181])
chk("R1/product-path/rank1-failing-after", all(pp[f]["historical_product_api_workload"]["after_workload"]["fts_integrity"]["rank1"] != "ok" for f in order), True)

# ---------------------------------------------------------------- R1 fresh API histories
fa = J("fts_baseline_fresh_api_history_run1.json")["runs"]
seeds = [20261013, 7, 99]
sh = [fa[f"shipped/{s}"] for s in seeds]
cc = [fa[f"control_canonical_ke_ad/{s}"] for s in seeds]
chk("R1/fresh/first-discrepancy-op", [r["history_summary"]["first_discrepancy"]["op_index"] for r in sh], [3, 14, 2], "(operations 3, 14, 2)")
chk("R1/fresh/first-discrepancy-is-delete", [r["history_summary"]["first_discrepancy"]["op"][0] for r in sh], ["delete"] * 3, "first discrepancy at the first delete")
chk("R1/fresh/ops-with-discrepancy", [r["history_summary"]["ops_with_discrepancy"] for r in sh], [148, 137, 149], "148 / 137 / 149 of 150")
chk("R1/fresh/op-errors", [r["history_summary"]["op_errors"] for r in sh], [0, 0, 0])
chk("R1/fresh/fp-totals", [r["history_summary"]["false_positive_total"] for r in sh], [387, 620, 893], "(387 / 620 / 893)")
chk("R1/fresh/fn-totals", [r["history_summary"]["false_negative_total"] for r in sh], [0, 0, 0])
chk("R1/fresh/end-raw-ghost", [r["end_state"]["raw_ghost_rowids"] for r in sh], [113, 93, 68], "113 / 93 / 68 raw ghost rowids")
chk("R1/fresh/live-rows", [r["live_rows_at_end"] for r in sh], [10, 20, 12], "10 / 20 / 12 live rows")
chk("R1/fresh/plain-ok-rank1-failing", [(r["end_state"]["fts_integrity"]["plain"], r["end_state"]["fts_integrity"]["rank1"] != "ok") for r in sh], [("ok", True)] * 3)
chk("R1/fresh/ke_ad-never-delete-command", [r["ke_ad_uses_delete_command"] for r in sh], [False] * 3)
chk("R1/fresh/control-zero-discrepancy", [(r["history_summary"]["ops_with_discrepancy"], r["history_summary"]["op_errors"], r["end_state"]["raw_ghost_rowids"], r["end_state"]["fts_integrity"]["rank1"]) for r in cc], [(0, 0, 0, "ok")] * 3, "0 discrepancies, 0 ghost rowids, `rank=1` ok, 3/3")
chk("R1/fresh/ops-per-history", J("fts_baseline_fresh_api_history_run1.json")["ops_per_history"], 150)

# ---------------------------------------------------------------- R2 commit boundary
cb = J("fts_commit_boundary_run1.json")
pa = cb["part_a"]
pre_pts = ["F0_after_begin_and_detect", "F1_after_trigger_swap", "F2_after_rebuild", "F3_before_commit"]
chk("R2/A/pre-commit-exception-pre", [pa[p]["exception"]["state_class"] for p in pre_pts], ["pre"] * 4)
chk("R2/A/pre-commit-hard-exit-pre", [pa[p]["hard_exit"]["state_class"] for p in pre_pts], ["pre"] * 4)
chk("R2/A/pre-commit-all-clean", all(pa[p][m]["retry_final_clean_post"] and (pa[p][m].get("third_noop_unchanged") or pa[p][m].get("third_invocation", {}).get("performed") is False) for p in pre_pts for m in ("exception", "hard_exit")), True, "state **exactly pre**")
chk("R2/A/pre-commit-no-txn-left", all(pa[p]["exception"]["connection_in_transaction_after"] is False for p in pre_pts), True)
chk("R2/A/hard-exit-code-9", [pa[p]["hard_exit"]["worker_exit_code"] for p in pre_pts + ["F4_after_commit"]], [9] * 5)
chk("R2/A/hard-exit-integrity-ok", all(pa[p]["hard_exit"]["sqlite_integrity_check_after_crash"] == ["ok"] for p in pre_pts + ["F4_after_commit"]), True)
chk("R2/A/F4-post", [pa["F4_after_commit"][m]["state_class"] for m in ("exception", "hard_exit")], ["post", "post"], "state exactly post, retry = no-op, third run no-op — 2/2")
chk("R2/A/F4-retry-noop", [pa["F4_after_commit"][m]["retry"]["performed"] for m in ("exception", "hard_exit")], [False, False])
chk("R2/A/8-of-8", len(pre_pts) * 2, 8, "— 8/8.")
chk("R2/A/seed", (cb["seed_small_state"]["raw_ghost_rowids"], cb["seed_small_state"]["false_positive"], cb["seed_small_state"]["trigger"], cb["seed_small_state"]["marker"]), (34, 21, "legacy", "absent"), "34 ghost rowids, 21 false positives")
pb = cb["part_b_simulated_torn_commit"]
chk("R2/B/wal-bytes-frames", (pb["raw_wal_bytes"], pb["raw_frames"], pb["page_size_from_db_header"]), (444992, 108, 4096), "444,992 bytes")
chk("R2/B/frame-arithmetic", (pb["raw_wal_bytes"] - 32) / pb["raw_frames"], 4120.0, "108 frames of 4,120 bytes")
chk("R2/B/commit-frame-is-last", (pb["commit_frame_indexes"], pb["last_frame_is_commit_frame"]), ([107], True), "index 107")
chk("R2/B/variants", (len(pb["variants"]), pb["distribution_by_class"]), (40, {"pre": 39, "post": 1, "mixed": 0}), "40 variants")
chk("R2/B/intact-is-post", [v["state_class"] for v in pb["variants"] if v["kind"] == "intact"], ["post"], "39 truncated variants → **pre**; the intact WAL → **post**")
chk("R2/B/all-integrity-ok", all(v["integrity_check"] == ["ok"] for v in pb["variants"]), True)
tr = cb["part_c_trials"]
cnt = {c: sum(1 for t in tr if t["state_class"] == c) for c in ("pre", "post", "mixed")}
chk("R2/C/trials-and-classes", (len(tr), cnt), (250, {"pre": 237, "post": 13, "mixed": 0}), "pre 237, post 13, mixed 0")
chk("R2/C/series-sizes", (sum(1 for t in tr if t["series"] == "uniform"), sum(1 for t in tr if t["series"] == "targeted_around_commit")), (100, 150), "100 uniformly timed + 150")
amb = [t for t in tr if t["last_stage"] == "commit_statement_issued"]
chk("R2/C/ambiguous-window", (len(amb), sorted(t["state_class"] for t in amb), sorted({t["series"] for t in amb})), (2, ["post", "pre"], ["uniform"]), "Only **2 of 250** kills")
tg = [t for t in tr if t["series"] == "targeted_around_commit"]
chk("R2/C/targeted-none-in-window", sorted({t["last_stage"] for t in tg}), ["F1_after_trigger_swap", "F2_after_rebuild"], "**None of the 150")
chk("R2/C/all-ok", (all(t["integrity_check"] == ["ok"] for t in tr), all(t["retry_final_clean_post"] for t in tr), all(t["third_noop"] for t in tr)), (True, True, True))
chk("R2/C/seed-rows", (cb["seed_big"]["bulk_rows"], cb["seed_big"]["live_rows_at_end"]), (20000, 4), "20,004-row seed")
chk("R2/C/dry-timings", round(cb["part_c_dry_runs"]["median_total_s"], 3), 0.132, "≈0.13 s")

# ---------------------------------------------------------------- R3 classifier
cl = J("fts_state_classifier_run1.json")
exp = {"S1": "MIGRATE_SWAP_REBUILD_VERIFY_RECORD", "S2": "NOOP", "S3a": "COMPLETE_REBUILD_VERIFY_RECORD", "S3b": "COMPLETE_REBUILD_VERIFY_RECORD", "S3c": "COMPLETE_REBUILD_VERIFY_RECORD",
       "S4a": "RECREATE_REBUILD_VERIFY_RECORD", "S4b": "REFUSE_UNRECOGNIZED_TRIGGER", "S4c": "REFUSE_MALFORMED_MARKER", "S4d": "REFUSE_NEWER_MARKER", "S5": "NOOP"}
got = {}
for k, v in cl["cases"].items():
    sid, be = k.split("__")
    if v.get("applicable"):
        got.setdefault(sid, set()).add(v["evidence"]["disposition"])
chk("R3/dispositions", {k: sorted(v) for k, v in got.items()}, {k: [e] for k, e in exp.items()}, "S4b, S4c, S4d: REFUSE (fail closed), state untouched")
chk("R3/not-applicable", sorted(k for k, v in cl["cases"].items() if not v.get("applicable")), ["S3c__user_version", "S4c__user_version"])
s3b = cl["cases"]["S3b__table"]["pre_state"]
chk("R3/S3b-stranded", (s3b["trigger"], s3b["raw_ghost_rowids"], s3b["false_positive"]), ("canonical", 48, 7), "48 raw ghost rowids, 7 false positives")
s5 = cl["cases"]["S5__table"]
chk("R3/S5-drift", (s5["evidence"]["disposition"], s5.get("explicit_verify_detects_drift"), s5.get("clean_after_explicit_repair")), ("NOOP", True, True), "classifier says **no-op**")
chk("R3/all-end-clean-where-migrated", all(v["post_state"]["rank1"] == "ok" for k, v in cl["cases"].items() if v.get("applicable") and v.get("result") and v["result"].get("performed")), True)
chk("R3/costs", (cl["cost"]["10000"]["rank1_verify_s_mean_of_3"], cl["cost"]["50000"]["rank1_verify_s_mean_of_3"], cl["cost"]["10000"]["classification_s_mean_of_50"]), (0.0477, 0.2428, 2.7e-05), "0.048 s at 10k rows, 0.243 s at 50k rows")

# ---------------------------------------------------------------- R4 transaction boundary
tx = J("fts_txn_boundary_run1.json")
pc = tx["product_connection"]
chk("R4/product-connection", (pc["isolation_level"], pc["is_legacy_transaction_control"], pc["journal_mode"], pc["synchronous"], pc["busy_timeout_ms"], pc["foreign_keys"]), ("", True, "wal", 1, 20000, 1), "busy timeout 20,000 ms")
t2 = tx["T2_executescript_after_begin_immediate"]
chk("R4/T2-executescript-commits", (t2["in_txn_after_executescript"], t2["trigger_after_rollback_new_connection"]), (False, "canonical"), "**`executescript()` after `BEGIN IMMEDIATE` commits the pending transaction first**")
chk("R4/T2b-trigger-absent", tx["T2b_executescript_failure_after_drop"]["trigger_after_rollback_new_connection"], "absent", "left the trigger **absent**")
t8 = tx["T8_deferred_upgrade_snapshot_busy"]
chk("R4/T8-immediate-lock-error", ("locked" in t8["error"], t8["elapsed_s"] < 0.01, t8["returned_before_timeout"]), (True, True, True), "(0.0 s, **not** after the timeout)")
chk("R4/T6-user-version-transactional", (tx["T6_user_version_is_transactional"]["inside_txn"], tx["T6_user_version_is_transactional"]["after_rollback"], tx["T6_user_version_is_transactional"]["after_commit"]), (1, 0, 1), "(inside 1, rollback 0, commit 1)")
t7 = tx["T7_alternative_autocommit_false"]
chk("R4/T7", (t7["in_txn_after_executescript"], t7["trigger_after_rollback_new_connection"]), (True, "legacy"))
t9 = tx["T9_new_database_initialisation_and_rolling_compat"]
chk("R4/T9", (t9["statements_from_product_source"], sorted(t9["schema_objects_differing_from_product_created_db"]), t9["historical_constructor_on_new_state"]["fingerprint_unchanged"], t9["historical_api_workload_on_new_state"]["ops"], t9["historical_api_workload_on_new_state"]["ops_with_discrepancy"]),
    (11, ["table:ocbrain_schema_migrations", "trigger:ke_ad"], True, 17, 0), "the 11 product DDL statements")
t10 = tx["T10_migrate_with_marker_on_product_connection"]
chk("R4/T10", {k: v["state_class_after_first_attempt"] for k, v in t10.items()}, {"t10_ok": "post", "t10_f0": "pre", "t10_f2": "pre", "t10_f3": "pre", "t10_f4": "post"}, "faults at F0, F2, F3 → pre; F4 → post")

# ---------------------------------------------------------------- R5 concurrency
co = J("fts_concurrency_run1.json")
c1 = co["c1_multiprocess_open_race"]
chk("R5/C1", ([len(c1[n]["trials"]) for n in ("2", "4", "6")], all(c1[n]["all_exactly_one_performed"] and c1[n]["all_error_free"] and c1[n]["all_final_clean"] for n in ("2", "4", "6")), max(t["max_elapsed_s"] for n in ("2", "4", "6") for t in c1[n]["trials"])), ([5, 5, 5], True, 0.3339), "**15/15** trials")
c2a = co["c2a_wait_within_timeout"]
chk("R5/C2a", (round(c2a["contender"]["elapsed_s"], 2), c2a["contender_waited_for_holder"], c2a["contender_noop_no_error"]), (3.14, True, True), "waited 3.14 s")
c2b = co["c2b_wait_beyond_timeout"]
chk("R5/C2b", ("locked" in c2b["contender"]["error"], round(c2b["contender"]["elapsed_s"], 2), c2b["retry_after_failure"]["performed"], c2b["final_clean_post"]), (True, 20.05, False, True), "after **20.05 s**")
c3 = co["c3_holder_killed_while_contender_waits"]
chk("R5/C3", (c3["contender_was_blocked_when_holder_killed"], c3["contender_saw_exact_pre_state"], c3["contender_performed_migration"], c3["final_clean_post"]), (True, True, True, True))
c4 = co["c4_older_snapshot_reader"]
ck = "wal_checkpoint_passive_while_reader_open_(busy,log_frames,checkpointed_frames)"
ck2 = "wal_checkpoint_passive_after_reader_ended_(busy,log,checkpointed)"
chk("R5/C4", (c4["reader_sees_pre_state_until_it_ends"], c4[ck], "locked" in c4["stale_snapshot_write_error"], c4["stale_snapshot_write_elapsed_s"] < 0.001, c4[ck2], c4["reader_view_after_new_transaction"]["trigger"]),
    (True, [0, 590, 0], True, True, [0, 601, 601], "canonical"), "busy 0, 590 frames, 0 checkpointed (blocked)")
chk("R5/C4-restated", c4[ck2], [0, 601, 601], "the checkpoint completes 601/601")
c5 = co["c5_writer_traffic_during_migration"]
chk("R5/C5", (len(c5["trials"]), sorted({t["writer_start_delay_s"] for t in c5["trials"]}), c5["all_error_free"], c5["all_final_clean"], c5["all_row_counts_match"], c5["trials_where_writer_ran_in_migration_window"], c5["max_writer_op_latency_s"]),
    (8, [0.0, 0.2, 0.5, 1.0], True, True, True, 3, 0.1807), "8/8 error-free")
c6 = co["c6_lock_hold_and_wal_growth"]
by = c6["by_rows"]
rng = lambda n: (min(r["total_s"] for r in by[n]["reps"]), max(r["total_s"] for r in by[n]["reps"]))  # noqa: E731
chk("R5/C6-ranges", (rng("5004"), rng("20004"), rng("50004")), ((0.0446, 0.0697), (0.1743, 0.2318), (0.4908, 0.5645)), "0.045–0.070 s (WAL 0.68 MB)")
chk("R5/C6-text-20k-50k", True, True, "20k rows 0.174–0.232 s (2.43 MB); 50k rows 0.491–0.565 s (7.2 MB)")
chk("R5/C6-wal-mb", (by["5004"]["median_wal_mb"], by["20004"]["median_wal_mb"], by["50004"]["median_wal_mb"]), (0.68, 2.43, 7.2))
chk("R5/C6-extrapolation", (c6["extrapolated_rows_at_which_hold_reaches_20s_busy_timeout"], c6["extrapolation_status"].startswith("EXTRAPOLATED")), (1890756, True), "near 1.9 million rows")

# ---------------------------------------------------------------- VACUUM controls
vc = J("fts_vacuum_rowid_control_run1.json")["cases"]
chk("VAC/plain-no-index", (vc["plain_no_index"]["rowids_before_vacuum"], vc["plain_no_index"]["rowids_after_vacuum"]), ([[1, "a"], [4, "d"]], [[1, "a"], [2, "d"]]), "(1,4 → 1,2)")
chk("VAC/preserved-cases", [vc[k]["rowids_changed"] for k in ("text_pk_auto_index", "explicit_integer_pk", "plain_with_explicit_index", "product_shape_clean")], [False] * 4)
fs = vc["fts_no_index_shape"]
chk("VAC/fts-no-index", (fs["rowids_changed"], fs["rank1_after"] != "ok", fs["retrieval_correct_before"], fs["retrieval_correct_after"]), (True, True, True, False), "**rowids renumbered; `rank=1` fails (malformed); retrieval wrong**")
chk("VAC/product-shape-rank1", (vc["product_shape_clean"]["rank1_before"], vc["product_shape_clean"]["rank1_after"]), ("ok", "ok"))
chk("VAC/vacuum-into-preserves", (vc["vacuum_into_plain"]["rowids_changed"], vc["vacuum_into_indexed"]["rowids_changed"]), (False, False), "preserved in both on 3.45.1")

# ---------------------------------------------------------------- durations
pr = {r: json.load(open(os.path.join(A.preserved, f"fts_migration_protocol_run{r}.json")))["part5_rebuild_duration"] for r in (1, 2)}
chk("DUR/50k-original-runs", sorted(round(pr[r]["50000"]["protocol_migrate_s"], 3) for r in (1, 2)), [0.41, 0.501], "**0.410 s and 0.501 s**")
chk("DUR/50k-range-text", True, True, "**0.41–0.50 s**")
rp = json.load(open(os.path.join(A.out, "repro", "fts_migration_protocol_repro.json")))["part5_rebuild_duration"]
chk("DUR/50k-repro", round(rp["50000"]["protocol_migrate_s"], 3), 0.425, "0.425 s")
chk("DUR/1k-10k-inside-range", [(0.008 <= round(pr[r]["1000"]["protocol_migrate_s"], 3) <= 0.009, 0.07 <= round(pr[r]["10000"]["protocol_migrate_s"], 2) <= 0.08) for r in (1, 2)], [(True, True)] * 2, "0.008–0.009 s / 0.07–0.08 s")

# ---------------------------------------------------------------- history, digests, derivation, contract
f = "core/memory/backends/sqlite_storage.py"
full = git("log", "--full-history", "--format=%h", "1d813bd", "--", f).split()
plain = git("log", "--format=%h", "1d813bd", "--", f).split()
chk("GIT/full-history-five", sorted(full), sorted(["da99c12", "984e640", "6b8b0af", "42818a7", "81d3069"]), "all five commits")
chk("GIT/plain-log-three", sorted(plain), sorted(["da99c12", "42818a7", "81d3069"]), "shows only three of them")
td = json.load(open(os.path.join(A.out, "tree_digest_compare_run1.json")))
chk("DIGEST", (td["digest_excluding_dotgit_equal"], td["harness_digests_equal"], td["worktrees"]["A"]["harness_digest_fts_lab_tree_digest"][:8], td["worktrees"]["B"]["harness_digest_fts_lab_tree_digest"][:8],
               td["worktrees"]["A"]["digest_excluding_dotgit_file_recomputed_by_this_script"][:8]), (True, False, "624b0e3f", "46cacae3", "bbb5f945"), "`624b0e3f…` original worktree, `46cacae3…` audit worktree")
dv = json.load(open(A.derivation))
chk("DERIV/387-385-2", (dv["total"], dv["total"] - len(dv["failed"]), len(dv["failed"])), (387, 385, 2), "(385/387;")
chk("DERIV/failures-are-duration", sorted({x["id"] for x in dv["failed"]}), ["3.3/duration-50000-rows"])
cc_ = json.load(open(A.contract_compare))
chk("CONTRACT/identical", (cc_["result_matrix_identical"], cc_["rc07_counters_identical"]), (True, True), "identical to the two preserved runs")

bad = [c for c in checks if not c["ok"]]
with open(A.outfile, "x") as fh:
    json.dump({"tool": "rev2_numbers_check.py", "packet": os.path.basename(A.packet), "total": len(checks), "failed": bad, "checks": checks}, fh, indent=2)
print(f"{len(checks) - len(bad)}/{len(checks)} checks passed")
for c in bad:
    print("FAILED:", c["id"], "| value_ok:", c["value_ok"], "| text_ok:", c["text_ok"], "| derived:", c["derived"], "| expected:", c["expected"], "| pattern:", c["text_pattern"])
sys.exit(1 if bad else 0)
