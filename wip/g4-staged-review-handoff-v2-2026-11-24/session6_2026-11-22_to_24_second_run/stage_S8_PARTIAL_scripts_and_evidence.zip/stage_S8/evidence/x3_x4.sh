#!/bin/bash
. /tmp/claude-0/-home-claude/d441201d-0373-573d-8f64-186072f858d3/scratchpad/a9/stage_S8/exp/lib.sh
W=$S8/exp/w34; rm -rf $W; mkdir -p $W; cd $W
# ---- X3: credential sent to a non-canonical host after the identity FAIL (real CANON line kept; only T,H changed)
python3 -I $S8/exp/srv401.py 18951 $W/srv.log & SP=$!; sleep 0.7
git init -q r; cd r
mkblock $W/blk_X3.sh https://github.com/1h0lde4/ocbrain-v4.1 1111111111111111111111111111111111111111 2222222222222222222222222222222222222222 >/dev/null
diff $BLOCK $W/blk_X3.sh | grep '^[<>]' | cut -c1-12
git remote add origin 'http://user:DUMMYTOKEN-xyz@127.0.0.1:18951/o/r.git'
env -u HTTPS_PROXY -u https_proxy -u HTTP_PROXY -u http_proxy -u ALL_PROXY -u all_proxy NO_PROXY=127.0.0.1 bash $W/blk_X3.sh >$W/X3.out 2>$W/X3.err; echo "X3 rc=$?"
echo "-- stdout"; cat $W/X3.out; echo "-- stderr"; cat $W/X3.err
echo "-- server log (presence of Authorization only):"; cat $W/srv.log
echo "token occurrences in stdout/stderr: $(cat $W/X3.out $W/X3.err | grep -c DUMMYTOKEN-xyz) lines"
kill $SP 2>/dev/null; wait $SP 2>/dev/null
