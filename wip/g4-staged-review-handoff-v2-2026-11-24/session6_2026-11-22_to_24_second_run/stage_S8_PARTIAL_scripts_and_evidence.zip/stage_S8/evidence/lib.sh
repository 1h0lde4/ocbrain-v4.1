# S8 experiment helpers (synthetic repos, local paths only)
S8=/tmp/claude-0/-home-claude/d441201d-0373-573d-8f64-186072f858d3/scratchpad/a9/stage_S8
BLOCK=$S8/pkg/review_package/rev3/verify_block_rev3.sh
BR=docs/g4-fts-errata-handoff-oct2026
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null GIT_TERMINAL_PROMPT=0
export GIT_AUTHOR_NAME=a GIT_AUTHOR_EMAIL=a@example.invalid GIT_COMMITTER_NAME=a GIT_COMMITTER_EMAIL=a@example.invalid
export GIT_AUTHOR_DATE=2026-01-01T00:00:00Z GIT_COMMITTER_DATE=2026-01-01T00:00:00Z
unset HTTPS_PROXY https_proxy HTTP_PROXY http_proxy ALL_PROXY all_proxy; export NO_PROXY=127.0.0.1
mkblock() { # $1 out $2 CANON $3 T $4 H  (substitute only CANON=, T=, H= lines)
  sed -e "s|^CANON=[^ ]*|CANON=$2|" -e "s|^T=[0-9a-f]*|T=$3|" -e "s|^H=[0-9a-f]*|H=$4|" "$BLOCK" > "$1"
  diff "$BLOCK" "$1" | grep -c '^>' ; }
