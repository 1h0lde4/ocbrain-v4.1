import http.server, sys
log = open(sys.argv[2], 'a')
class H(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        a = self.headers.get('Authorization')
        log.write("GET %s Host=%s Authorization_present=%s\n" % (self.path, self.headers.get('Host'), a is not None)); log.flush()
        self.send_response(401); self.send_header('WWW-Authenticate', 'Basic realm="x"'); self.send_header('Content-Length','0'); self.end_headers()
    do_POST = do_GET
    def log_message(self, *a): pass
http.server.HTTPServer(('127.0.0.1', int(sys.argv[1])), H).serve_forever()
