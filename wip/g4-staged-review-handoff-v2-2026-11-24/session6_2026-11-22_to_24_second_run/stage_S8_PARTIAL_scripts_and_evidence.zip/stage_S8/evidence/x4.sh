#!/bin/bash
# X4: line 15 string decision, and which host libcurl names, inside a no-network namespace (nothing leaves the machine)
. /tmp/claude-0/-home-claude/d441201d-0373-573d-8f64-186072f858d3/scratchpad/a9/stage_S8/exp/lib.sh
CANON=https://github.com/1h0lde4/ocbrain-v4.1
L15=$(sed -n 15p $BLOCK)
R=/ocbrain-v4.1; G=github.com/1h0lde4/ocbrain-v4.1
forms=("https://$G" "https://127.0.0.1:1?@$G" "https://127.0.0.1:1#@$G" "https://127.0.0.1:1/@$G" "https://127.0.0.1:1/x?@$G" 'https://127.0.0.1:1\@'"$G" "https://127.0.0.1:1%2f@$G" "https://127.0.0.1:1:?@$G" "https://2130706433?@$G" "https://127.0.0.1:1?token=DUMMYTOKEN-xyz@$G")
cd $S8/exp; rm -rf w4; mkdir w4; cd w4; git init -q r; cd r
for f in "${forms[@]}"; do
  URL=$f; eval "$L15"; norm=${URL%.git}; [ "$norm" = "$CANON" ] && dec=ACCEPT || dec=REJECT
  git remote remove origin 2>/dev/null; git remote add origin "$f"
  net=$(unshare -rn env GIT_CURL_VERBOSE=1 GIT_TERMINAL_PROMPT=0 git ls-remote origin 2>&1 | grep -m2 -E "Could not resolve host|Failed to connect|Trying|Network is unreachable|Connection refused|Immediate connect" | tr '\n' ' ' | cut -c1-150)
  printf '%s\t%s\t%s\n' "$f" "$dec" "$net"
done
