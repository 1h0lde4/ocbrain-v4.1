#!/bin/bash
# X1 graft/replace, X2 cwd dependence.  Usage: bash x1_x2.sh
. /tmp/claude-0/-home-claude/d441201d-0373-573d-8f64-186072f858d3/scratchpad/a9/stage_S8/exp/lib.sh
W=$S8/exp/w12; rm -rf $W; mkdir -p $W; cd $W
git init -q --bare -b main origin.git 2>/dev/null || git init -q --bare origin.git
git clone -q origin.git seed 2>/dev/null; cd seed
git checkout -q -b $BR
echo r > README.md; git add .; git commit -qm c0
echo t > other.txt; git add .; git commit -qm T; T=$(git rev-parse HEAD)
echo x > x.txt; git add .; git commit -qm X; X=$(git rev-parse HEAD)
echo h > handoff.md; git add .; git commit -qm H; H=$(git rev-parse HEAD)
echo h2 >> handoff.md; git add .; git commit -qm c1
git push -q origin $BR 2>&1 | tail -1
echo "T=$T X=$X H=$H"
cd $W
run() { # $1 label $2 clone dir $3 cwd-subdir $4 T $5 H
  mkblock $W/blk_$1.sh $W/origin $4 $5 >/dev/null
  ( cd "$2/$3" && bash $W/blk_$1.sh >$W/$1.out 2>$W/$1.err; echo "rc=$?" >$W/$1.rc )
  echo "== $1: $(cat $W/$1.rc)"; echo "-- stdout"; cat $W/$1.out; echo "-- stderr (head)"; head -3 $W/$1.err; }
# X1: control (no replace), remote chain T->X->H->c1
git clone -q origin.git c_ctl 2>/dev/null; (cd c_ctl; git remote set-url origin $W/origin.git)
run X1_control $W/c_ctl . $T $H
# X1a: replace --graft H T (makes H's parent T locally)
git clone -q origin.git c_rep 2>/dev/null; (cd c_rep; git remote set-url origin $W/origin.git; git replace --graft $H $T; git replace -l)
run X1a_replace_graft $W/c_rep . $T $H
# X1b: legacy grafts file
git clone -q origin.git c_gr 2>/dev/null; (cd c_gr; git remote set-url origin $W/origin.git; echo "$H $T" > .git/info/grafts)
run X1b_grafts_file $W/c_gr . $T $H
# X2: tip has root handoff.md as symlink; docs/handoff.md regular added by H; run from docs/
cd $W; git init -q --bare origin2.git; git clone -q origin2.git seed2 2>/dev/null; cd seed2
git checkout -q -b $BR; mkdir docs
echo r > README.md; git add .; git commit -qm c0
echo t > other.txt; git add .; git commit -qm T; T2=$(git rev-parse HEAD)
echo h > docs/handoff.md; git add .; git commit -qm H; H2=$(git rev-parse HEAD)
ln -s docs/handoff.md handoff.md; git add .; git commit -qm c1-root-symlink
git push -q origin $BR 2>&1|tail -1
cd $W; git clone -q origin2.git c2 2>/dev/null; (cd c2; git remote set-url origin $W/origin2.git; mkdir -p docs; git ls-tree HEAD)
mkblock $W/blk_X2.sh $W/origin2 $T2 $H2 >/dev/null
for d in . docs; do ( cd c2/$d && bash $W/blk_X2.sh >$W/X2_$(echo $d|tr . r).out 2>$W/X2_$(echo $d|tr . r).err; echo "rc=$?" > $W/X2_$(echo $d|tr . r).rc ); echo "== X2 cwd=$d $(cat $W/X2_$(echo $d|tr . r).rc)"; cat $W/X2_$(echo $d|tr . r).out; done
