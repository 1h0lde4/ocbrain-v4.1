#!/bin/bash
# usage: bash run_all.sh <stage dir>   (re-runs everything: setup, all cases in a netns, summary)
D=${1:-/tmp/claude-0/-home-claude/d441201d-0373-573d-8f64-186072f858d3/scratchpad/a9/stage_S3}
cd $D; find evidence -mindepth 1 -maxdepth 1 -type d -exec rm -rf {} +; rm -f server.stdout server.stderr
bash $D/setup.sh $D >/dev/null
env -u HTTPS_PROXY -u https_proxy -u HTTP_PROXY -u http_proxy -u ALL_PROXY -u all_proxy unshare -rn bash $D/inner.sh $D
python3 -I $D/summarize.py $D
