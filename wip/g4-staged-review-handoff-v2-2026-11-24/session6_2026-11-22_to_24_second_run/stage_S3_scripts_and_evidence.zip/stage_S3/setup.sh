#!/bin/bash
# builds cert, synthetic bare repo (T,H,c1), block copy with only T=/H= lines changed
D=$1; W=$D/work; BR=docs/g4-fts-errata-handoff-oct2026
set -e
cd $W
openssl req -x509 -newkey rsa:2048 -nodes -keyout key.pem -out cert.pem -days 3 -subj "/CN=loopback-test-ca" \
  -addext "subjectAltName=DNS:github.com,DNS:evil.test,IP:127.0.0.1" 2>/dev/null
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null GIT_AUTHOR_NAME=a GIT_AUTHOR_EMAIL=a@x.test GIT_COMMITTER_NAME=a GIT_COMMITTER_EMAIL=a@x.test
rm -rf w srv; mkdir srv
git init -q -b main w; cd w
git checkout -q -b $BR
export GIT_AUTHOR_DATE=2026-11-01T00:00:00Z GIT_COMMITTER_DATE=2026-11-01T00:00:00Z
echo base > f.txt; git add f.txt; git commit -q -m "T transfer commit"; T=$(git rev-parse HEAD)
export GIT_AUTHOR_DATE=2026-11-01T01:00:00Z GIT_COMMITTER_DATE=2026-11-01T01:00:00Z
echo "handoff v1" > handoff.md; git add handoff.md; git commit -q -m "H handoff commit"; H=$(git rev-parse HEAD)
export GIT_AUTHOR_DATE=2026-11-01T02:00:00Z GIT_COMMITTER_DATE=2026-11-01T02:00:00Z
echo "followup" >> handoff.md; git commit -q -am "c1 follow-up"; C1=$(git rev-parse HEAD)
cd ..; git clone -q --bare w srv/repo.git; git -C srv/repo.git symbolic-ref HEAD refs/heads/$BR
echo "T=$T H=$H C1=$C1" > hashes.txt
cp $D/pkg/review_package/rev3/verify_block_rev3.sh block_orig.sh
sed -e "s/^T=[0-9a-f]\{40\}/T=$T/" -e "s/^H=[0-9a-f]\{40\}/H=$H/" block_orig.sh > block_rev3_copy.sh
diff block_orig.sh block_rev3_copy.sh > $D/evidence/block_diff_vs_original.txt || true
cat $D/evidence/block_diff_vs_original.txt; cat hashes.txt
