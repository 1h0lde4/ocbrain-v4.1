#!/bin/bash
# runs INSIDE `unshare -rn`. args: D
D=$1; W=$D/work; EV=$D/evidence; BR=docs/g4-fts-errata-handoff-oct2026
python3 -I - <<'PY'
import socket, fcntl, struct
s=socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
r=fcntl.ioctl(s,0x8913,struct.pack('16sH14s',b'lo',0,b''))
fl=struct.unpack('16sH14s',r)[1]|1|0x40
fcntl.ioctl(s,0x8914,struct.pack('16sH14s',b'lo',fl,b''))
PY
python3 -I -c "import socket;s=socket.socket();s.connect_ex(('127.0.0.1',1));print('lo up check ok')"
unset HTTPS_PROXY https_proxy HTTP_PROXY http_proxy ALL_PROXY all_proxy SSL_CERT_FILE CURL_CA_BUNDLE REQUESTS_CA_BUNDLE
export NO_PROXY=127.0.0.1 no_proxy=127.0.0.1
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null GIT_TERMINAL_PROMPT=0 GIT_SSL_CAINFO=$W/cert.pem
export GIT_CONFIG_COUNT=2 GIT_CONFIG_KEY_0=http.curloptResolve GIT_CONFIG_VALUE_0=github.com:443:127.0.0.1 GIT_CONFIG_KEY_1=http.curloptResolve GIT_CONFIG_VALUE_1=evil.test:443:127.0.0.1
python3 -I $D/server.py $W $EV > $D/server.stdout 2>$D/server.stderr & SP=$!
sleep 1
CANONURL=https://github.com/1h0lde4/ocbrain-v4.1
cases=$(cat $D/cases.tsv)
while IFS=$'\t' read -r id mode url; do
  [ -z "$id" ] && continue
  ev=$EV/$id; mkdir -p $ev; cl=$W/clone_$id; rm -rf $cl
  printf '{"case":"%s_clone","mode":"normal"}' "$id" > $W/ctl.json
  git clone -q -b $BR $CANONURL $cl 2>$ev/clone.err || echo "CLONE FAILED $id" >> $ev/clone.err
  git -C $cl remote set-url origin "$url"
  # parsed identity: exactly line 15/16 of the block copy, applied to what `git remote get-url origin` returns
  got=$(git -C $cl remote get-url origin)
  parsed=$( URL="$got"; CANON=$CANONURL; eval "$(sed -n 15p $W/block_rev3_copy.sh)"; printf '%s' "$URL")
  idok=NO; [ "${parsed%.git}" = "$CANONURL" ] && idok=YES
  printf '{"case":"%s","mode":"%s"}' "$id" "$mode" > $W/ctl.json
  ( cd $cl && bash $W/block_rev3_copy.sh >$ev/block.stdout 2>$ev/block.stderr; echo $? >$ev/block.rc )
  printf '%s\n' "$url" > $ev/url.txt; printf '%s\n' "$got" > $ev/remote_get_url.txt; printf '%s\n' "$parsed" > $ev/parsed_identity.txt; echo $idok > $ev/identity_check_passes.txt
  # standalone attribution (F15): which git command prints what
  ( cd $cl; git fetch origin "+refs/heads/$BR:refs/remotes/origin/$BR" >$ev/solo_fetch.out 2>$ev/solo_fetch.err; echo $? >$ev/solo_fetch.rc
    git ls-remote origin "refs/heads/$BR" >$ev/solo_lsremote.out 2>$ev/solo_lsremote.err; echo $? >$ev/solo_lsremote.rc )
done <<< "$cases"
kill $SP 2>/dev/null; wait $SP 2>/dev/null
