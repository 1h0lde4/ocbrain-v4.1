import json,os,sys
EV=sys.argv[1]+'/evidence'; rows=[]
def rd(p,d=''):
    try: return open(p,errors='replace').read()
    except Exception: return d
for cid in [l.split('\t')[0] for l in open(sys.argv[1]+'/cases.tsv') if l.strip()]:
    d=f'{EV}/{cid}'
    so=rd(d+'/block.stdout'); se=rd(d+'/block.stderr'); rc=rd(d+'/block.rc').strip()
    logs=[json.loads(l) for l in rd(d+'/server.log').splitlines() if l.strip()]
    hosts=sorted({str(l['host_header']) for l in logs}); snis=sorted({str(l['sni']) for l in logs})
    auth=any(l['authorization_present'] for l in logs)
    tok=lambda s:s.count('DUMMYTOKEN-xyz')
    ct=f"out={tok(so)} err={tok(se)}"
    solo=sum(tok(rd(d+f'/{n}')) for n in ('solo_fetch.out','solo_fetch.err','solo_lsremote.out','solo_lsremote.err'))
    first=so.strip().splitlines()[-1][:4] if so.strip() else ''
    passed=so.startswith('PASS') or '\nPASS' in so
    fp = passed and rc=='0' and any(h!='github.com' for h in hosts)
    if cid.startswith('F14'):
        v='FALSE PASS (PASS/rc0 but server saw non-github.com Host)' if fp else ('PASS at canonical host' if passed and rc=='0' else 'FAIL (block rejected)')
    else:
        v='CREDENTIAL OUTPUT' if (tok(so)+tok(se)+solo)>0 else 'no token in this case'
    rows.append((cid,open(d+'/url.txt').read().strip(),rd(d+'/parsed_identity.txt').strip(),rd(d+'/identity_check_passes.txt').strip(),','.join(hosts),','.join(snis),str(len(logs)),'Y' if auth else 'N',rc,ct,f'solo={solo}',v))
hdr='case\turl\tparsed_identity\tidentity_ok\tserver_Host\tSNI\t#req\tAuthz_seen\tblock_rc\ttoken_count(block)\ttoken(solo git cmds)\tverdict'
open(sys.argv[1]+'/SUMMARY.tsv','w').write(hdr+'\n'+'\n'.join('\t'.join(r) for r in rows)+'\n')
print(hdr); [print('\t'.join(r)) for r in rows]
