import ssl, sys, json, os, subprocess, re, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
W=sys.argv[1]; EV=sys.argv[2]
class H(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    def log_message(self,*a): pass
    def ctl(self):
        try: return json.load(open(W+'/ctl.json'))
        except Exception: return {'case':'unknown','mode':'normal'}
    def reply(self,code,hdrs,body):
        self.send_response(code)
        for k,v in hdrs: self.send_header(k,v)
        self.send_header('Content-Length',str(len(body))); self.end_headers()
        if self.command!='HEAD': self.wfile.write(body)
    def handle_any(self):
        c=self.ctl(); case=c['case']; mode=c['mode']
        body=b''
        if 'chunked' in self.headers.get('Transfer-Encoding','').lower():
            while True:
                n=int(self.rfile.readline().strip().split(b';')[0] or b'0',16)
                if n==0:
                    while self.rfile.readline().strip(): pass
                    break
                body+=self.rfile.read(n); self.rfile.readline()
        else:
            n=int(self.headers.get('Content-Length') or 0)
            if n: body=self.rfile.read(n)
        t=self.path; m=self.command
        has_auth='Authorization' in self.headers
        pi=None; qs=''
        if '/info/refs' in t:
            pi='/repo.git/info/refs'; qs='service=git-upload-pack' if 'service=git-upload-pack' in t else ''
        elif '/git-upload-pack' in t and m=='POST':
            pi='/repo.git/git-upload-pack'
        elif mode=='lenient':
            if m=='GET': pi='/repo.git/info/refs'; qs='service=git-upload-pack'
            elif m=='POST': pi='/repo.git/git-upload-pack'
        status=None
        if mode=='401' or (mode=='auth' and not has_auth):
            status=401
        elif mode=='404' or pi is None:
            status=404
        rec={'t':round(time.time(),3),'case':case,'mode':mode,'client':'%s:%s'%self.client_address,
             'sni':getattr(self.connection,'_sni',None),'host_header':self.headers.get('Host'),
             'request_line':self.requestline,'authorization_present':has_auth,'body_len':len(body)}
        if status==401:
            rec['status']=401; self.log(rec)
            self.reply(401,[('WWW-Authenticate','Basic realm="loopback"'),('Content-Type','text/plain')],b'auth required\n'); return
        if status==404:
            rec['status']=404; self.log(rec)
            self.reply(404,[('Content-Type','text/plain')],b'not found\n'); return
        env={'PATH':os.environ.get('PATH',''),'GIT_PROJECT_ROOT':W+'/srv','GIT_HTTP_EXPORT_ALL':'1','PATH_INFO':pi,'QUERY_STRING':qs,
             'REQUEST_METHOD':m,'CONTENT_TYPE':self.headers.get('Content-Type',''),'CONTENT_LENGTH':str(len(body)),
             'REMOTE_ADDR':self.client_address[0],'GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_SYSTEM':'/dev/null'}
        if self.headers.get('Git-Protocol'): env['HTTP_GIT_PROTOCOL']=self.headers['Git-Protocol']
        if self.headers.get('Content-Encoding'): env['HTTP_CONTENT_ENCODING']=self.headers['Content-Encoding']
        p=subprocess.run(['/usr/lib/git-core/git-http-backend'],input=body,env=env,capture_output=True)
        out=p.stdout; hdr,_,b=out.partition(b'\r\n\r\n')
        if not _: hdr,_,b=out.partition(b'\n\n')
        code=200; hs=[]
        for ln in hdr.decode('latin1').splitlines():
            k,_,v=ln.partition(':'); v=v.strip()
            if k.lower()=='status': code=int(v.split()[0])
            elif k.lower() not in('content-length','connection'): hs.append((k,v))
        rec['status']=code; rec['cgi_pi']=pi; self.log(rec)
        self.reply(code,hs,b)
    def log(self,rec):
        d=os.path.join(EV,rec['case']); os.makedirs(d,exist_ok=True)
        with open(d+'/server.log','a') as f: f.write(json.dumps(rec)+'\n')
    do_GET=do_POST=do_HEAD=handle_any
ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); ctx.load_cert_chain(W+'/cert.pem',W+'/key.pem')
def sni(sock,name,c):
    sock._sni=name
ctx.sni_callback=sni
class S(ThreadingHTTPServer):
    daemon_threads=True
srv=S(('127.0.0.1',443),H); srv.socket=ctx.wrap_socket(srv.socket,server_side=True)
srv.serve_forever()
