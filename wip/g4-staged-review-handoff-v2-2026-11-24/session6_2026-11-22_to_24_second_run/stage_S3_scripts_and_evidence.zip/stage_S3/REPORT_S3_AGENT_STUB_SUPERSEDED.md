STAGE S3: COMPLETE
Package SHA-256 (computed on copy) = 391eb0a06784153af4591d6bbfdc0af87edce0f17dd2e2aae0a7593794ce2286 -> MATCHES authoritative value. SHA256SUMS.txt (inside package, 7 entries) all OK.
| Criterion | Status | Plan |
| F14 false PASS via crafted URL | NOT RUN | loopback TLS git server in netns, cases 1-7 |
| F15 credential output by git | NOT RUN | cases a-d over TLS |

F14 status FAIL (false PASS reproduced for ?@ forms; # form only vs hostile server). F15 status FAIL (credential output reproduced in git stderr). Details: SUMMARY.tsv, evidence/INDEX.txt; full report was returned as the final message of the stage.
