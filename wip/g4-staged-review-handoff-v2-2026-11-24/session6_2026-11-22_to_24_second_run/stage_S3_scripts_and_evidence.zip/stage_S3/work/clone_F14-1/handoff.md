handoff v1
followup
