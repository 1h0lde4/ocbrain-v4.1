STAGE S6: IN PROGRESS

# REPORT S6 (provisional)
Package integrity: zip SHA-256 = 391eb0a06784153af4591d6bbfdc0af87edce0f17dd2e2aae0a7593794ce2286 (matches authoritative value, full compare); inner SHA256SUMS.txt: all 7 files OK; extracted to pkg/review_package/ (copy of the zip, original untouched).

| Criterion | Status | Plan |
|---|---|---|
| F unavoidable race | NOT RUN | wrapper moves remote tip after final ls-remote / between calls |
| G(4) prose claims vs block | NOT RUN | claim table, test each claim |
| H shell/git pitfalls | NOT RUN | synthetic-repo row matrix |
