handoff v1
