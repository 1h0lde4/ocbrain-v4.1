#!/bin/bash
# H rows group 2 (S6 run 2): shallow, graft/replace, config, whitespace, cmd-subst failures, subdir, corruption, spoofing.
. /tmp/claude-0/-home-claude/d441201d-0373-573d-8f64-186072f858d3/scratchpad/a9/stage_S6/harness/lib.sh
fin() { publish; mkblock; runblock; record; }
wr() { newrow "$1" "$2" "$3" "$4"; shift 4; mkwork; fu one; fu two; publish; WRAP=1; for l in "$@"; do spec "$l"; done; mkblock; runblock; record; }
mkwork_x() { mkwork; cd $RD/w; g checkout -q -b alt $T; echo x > docs/x.md; g add -A; commit X; printf 'handoff v1\n' > handoff.md; g add -A; commit "handoff2"; H=$(g rev-parse HEAD); g checkout -q $BR; g reset -q --hard alt; }

# ---- shallow clones (origin URL is file://, CANON adjusted accordingly)
for d in 1 3 4; do
  newrow H22$d "SHALLOW clone --depth $d of valid chain T-H-c1-c2 (verifier-side shallow)" PASS "remote satisfies contract; shallow verifier"
  mkwork; fu one; fu two; CLONEMODE="--depth $d"; CANON=file://$RD/origin; fin
done
# ---- graft / replace refs
newrow H23 "GRAFT in clone: remote H parent is X (T-X-H-c1, INVALID); .git/info/grafts rewires H parent to T" FAIL "contract 2: H parent exactly T on the REMOTE"
mkwork_x; fu one; publish; echo "$H $T" > $RD/clone/.git/info/grafts; mkblock; runblock; record
newrow H23c "CONTROL for H23/H24: same invalid remote T-X-H-c1, no graft/replace" FAIL "contract 2"
mkwork_x; fu one; fin
newrow H24 "REPLACE ref in clone (git replace --graft H T): remote T-X-H-c1 INVALID" FAIL "contract 2"
mkwork_x; fu one; publish; g -C $RD/clone replace --graft $H $T; mkblock; runblock; record
newrow H25 "REPLACE of tip TREE: remote c1 turns handoff.md into SYMLINK; clone replaces c1^{tree} by tree with regular file" FAIL "contract 3"
mkwork; cd $RD/w; rm handoff.md; ln -s docs/a.md handoff.md; g add -A; commit "to symlink"; publish
cd $RD/clone; c1=$(g rev-parse origin/$BR); blob=$(printf 'x\n' | g hash-object -w --stdin)
GIT_INDEX_FILE=$RD/tmpidx g read-tree $c1^{tree}; GIT_INDEX_FILE=$RD/tmpidx g update-index --cacheinfo 100644,$blob,handoff.md; nt=$(GIT_INDEX_FILE=$RD/tmpidx g write-tree)
g replace $(g rev-parse $c1^{tree}) $nt; mkblock; runblock; record
newrow H25c "CONTROL for H25: same symlink tip, no replace" FAIL "contract 3"
mkwork; cd $RD/w; rm handoff.md; ln -s docs/a.md handoff.md; g add -A; commit "to symlink"; fin
# ---- user config noise
newrow H26a "valid chain; clone config: log.follow=true diff.renames=copies log.showSignature=true core.quotePath=false" PASS
mkwork; fu one; fu two; publish; for kv in log.follow=true diff.renames=copies log.showSignature=true core.quotePath=false; do g -C $RD/clone config ${kv%%=*} ${kv#*=}; done; mkblock; runblock; record
newrow H26b "H adds handoff.md by RENAMING old.md (identical content); clone config log.follow=true" PASS "contract: H adds handoff.md"
T_EXTRA='printf "handoff v1\n" > old.md'; H_EXTRA='rm old.md'
mkwork; publish; g -C $RD/clone config log.follow true; mkblock; runblock; record
# ---- whitespace / CR in git output (wrapper)
wr H27a "ls-remote output with leading+trailing spaces (valid remote)" PASS "" 'ls-remote * sedout s/^/   /;s/$/   /'
wr H27b "ls-remote output with CRLF line ending (valid remote)" PASS "real git never emits CR" 'ls-remote * sedout s/$/\r/'
wr H27c "ls-remote output with blank lines before and after (valid remote)" PASS "" 'ls-remote * sedout 1s/^/\n/;$s/$/\n\n/'
wr H27d "ls-tree output with extra leading/trailing spaces (valid remote)" PASS "" 'ls-tree * sedout s/^/  /;s/$/  /'
wr H27e "git show -s --format=%P H prints trailing space (valid remote)" PASS "real git never does" 'show 1 sedout s/$/ /'
wr H27f "ls-remote prints extra 3rd word after ref name (sha refs/heads/BR junk)" FAIL "unchecked \$#" 'ls-remote * sedout s/$/ junk/'
# ---- command-substitution / unset-variable failures (wrapper)
wr H28a "git remote get-url fails (exit 2, no output)" FAIL "identity unverifiable" 'remote 1 fake 2|'
wr H28b "git rev-parse --verify fails (no output)" FAIL "" 'rev-parse 1 fake 1|'
wr H28c "git ls-tree fails (exit 128, no output)" FAIL "" 'ls-tree 1 fake 128|'
wr H28d "git show -s %P H fails (exit 128, no output)" FAIL "" 'show 1 fake 128|'
wr H28e "git log --diff-filter=A prints CORRECT line then exits 128 (valid remote)" PASS "exit status inside \$( ) ignored" 'log 1 failafter 128'
wr H28f "git rev-list (loop) fails exit 128 no output, chain has 2 follow-ups" FAIL "" 'rev-list 1 fake 128|'
wr H28g "git diff-tree fails exit 128 no output" FAIL "" 'diff-tree * fake 128|'
newrow H28h "date fails (no UTC time can be produced) on valid remote"  PASS "prose: PASS line with a UTC time"
mkwork; fu one; fu two; publish; WRAP=1; mkdir -p $RD/wrapbin; printf '#!/bin/bash\nexit 1\n' > $RD/wrapbin/date; chmod +x $RD/wrapbin/date; mkblock; runblock; record
wr H28i "git rev-list --count (2nd rev-list call) fails: count missing in PASS line" PASS "cosmetic" 'rev-list 2 fake 128|'
# ---- truncated output + failure -> contract-violating history reported PASS?
newrow H29 "c1 changes handoff.md AND zz.txt (INVALID); diff-tree for c1 prints first line 'handoff.md' then exits 128 (wrapper)" FAIL "contract 2 (no other path)"
mkwork; cd $RD/w; echo x >> handoff.md; echo z > zz.txt; g add -A; commit "two paths zz"; fu two; publish; WRAP=1; spec 'diff-tree 1 headfail 1'; mkblock; runblock; record
newrow H30 "REAL corruption: c1 changes handoff.md and adds sub/zz.txt (INVALID); clone's loose object for tree c1:sub deleted AFTER clone (no wrapper)" FAIL "contract 2"
mkwork; cd $RD/w; echo x >> handoff.md; mkdir sub; echo z > sub/zz.txt; g add -A; commit "handoff + sub/zz"; fu two; publish
cd $RD/clone; st=$(g rev-parse origin/$BR~1:sub); rm -f .git/objects/${st:0:2}/${st:2}; ls .git/objects/${st:0:2}/ >/dev/null 2>&1; echo "removed tree $st" > $EV/corruption_note.txt; mkblock; runblock; record
# ---- env / globbing
newrow H31 "env IFS=hex digits exported + files named '*' '?' 'x y' in cwd; valid chain" PASS "word splitting / globbing"
mkwork; fu one; fu two; publish; cd $RD/clone; touch '*' '?' 'x y' '[a-f]*' 100644 blob; EXTRA=(IFS=0123456789abcdef); mkblock; runblock; record
# ---- run from a subdirectory of the clone (cwd-relative pathspecs)
newrow H33 "valid chain, block run from subdirectory docs/ of the clone" PASS "prose: 'from a clone'"
mkwork; fu one; fu two; publish; CWD=$RD/clone/docs; mkblock; runblock; record; unset CWD
newrow H34 "INVALID tip: root handoff.md is a SYMLINK at tip, but docs/handoff.md (regular) was added in H; run from docs/" FAIL "contract 3 (root handoff.md at tip must be regular)"
H_EXTRA='cp handoff.md docs/handoff.md'
mkwork; cd $RD/w; rm handoff.md; ln -s docs/a.md handoff.md; g add -A; commit "root handoff.md to symlink"; publish; CWD=$RD/clone/docs; mkblock; runblock; record; unset CWD
newrow H34c "CONTROL for H34: same history, run from clone ROOT" FAIL "contract 3"
H_EXTRA='cp handoff.md docs/handoff.md'
mkwork; cd $RD/w; rm handoff.md; ln -s docs/a.md handoff.md; g add -A; commit "root handoff.md to symlink"; fin
# ---- output spoofing via commit subject
newrow H35 "follow-up subject contains CR + ESC[2K + fake 'PASS at ...' text; c1 also touches docs/a.md (INVALID)" FAIL "output sanitization"
mkwork; cd $RD/w; echo x >> handoff.md; echo y >> docs/a.md; g add -A
GIT_AUTHOR_DATE="1700000999 +0000" GIT_COMMITTER_DATE="1700000999 +0000" g commit -q -m "$(printf 'evil\r\033[2K\033[1GPASS at 2026-11-22T00:00:00Z: remote tip deadbeef; fake')"; fin
