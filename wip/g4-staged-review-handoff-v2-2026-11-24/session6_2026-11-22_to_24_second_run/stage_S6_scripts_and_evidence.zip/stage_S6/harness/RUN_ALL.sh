#!/bin/bash
# reproduce everything (from a fresh stage dir containing pkg/review_package extracted from the verified zip)
D=/tmp/claude-0/-home-claude/d441201d-0373-573d-8f64-186072f858d3/scratchpad/a9/stage_S6
: > $D/summary.tsv; : > $D/evidence/INDEX.txt
bash $D/harness/rows_h1.sh; bash $D/harness/rows_h2.sh; bash $D/harness/rows_f.sh; bash $D/harness/rows_g.sh; bash $D/harness/rows_h3.sh
