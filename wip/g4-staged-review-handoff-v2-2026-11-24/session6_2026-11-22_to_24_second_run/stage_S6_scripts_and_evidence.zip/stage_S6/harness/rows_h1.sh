#!/bin/bash
# H rows group 1: history shape, diff-tree options, ordering, merges. Run: bash rows_h1.sh
. /tmp/claude-0/-home-claude/d441201d-0373-573d-8f64-186072f858d3/scratchpad/a9/stage_S6/harness/lib.sh
fin() { publish; mkblock; runblock; record; }

newrow H01 "valid chain T-H-c1-c2 (baseline)" PASS
mkwork; fu one; fu two; fin
newrow H02 "zero follow-ups (tip == H)" PASS
mkwork; fin
newrow H03 "valid linear chain, follow-up commit dates go BACKWARDS (older than parent)" PASS "rev-list ordering"
mkwork; tick=1600000000; fu one; tick=1500000000; fu two; fin
newrow H04 "valid linear chain, all commits identical timestamp" PASS "rev-list ordering"
mkwork; FIXTICK=1700000000; fu one; fu two; fu three; fin
newrow H05 "follow-up RENAMES handoff.md to other.md (tip has no handoff.md)" FAIL
mkwork; cd $RD/w; g mv handoff.md other.md; commit "rename away"; fin
newrow H06 "follow-up renames handoff.md to other.md, next follow-up renames it back" FAIL "contract: c1 touches other.md"
mkwork; cd $RD/w; g mv handoff.md other.md; commit "rename away"; g mv other.md handoff.md; commit "rename back"; fin
newrow H07 "follow-up edits handoff.md AND copies it to copy.md" FAIL
mkwork; cd $RD/w; cp handoff.md copy.md; echo x >> handoff.md; g add -A; commit "edit+copy"; fin
newrow H08 "follow-up only COPIES handoff.md to copy.md (handoff.md untouched)" FAIL "changes other path, not handoff.md"
mkwork; cd $RD/w; cp handoff.md copy.md; g add copy.md; commit "copy only"; fin
newrow H09 "follow-up changes ONLY the mode of handoff.md to 100755 (tip executable)" FAIL "contract 3"
mkwork; cd $RD/w; g update-index --chmod=+x handoff.md; commit "mode only"; fin
newrow H10 "mode flip 644->755 (c1) then 755->644 (c2); tip 100644" PASS "contract-literal; prose says each follow-up is 'documentation-only'"
mkwork; cd $RD/w; g update-index --chmod=+x handoff.md; commit "mode +x"; g update-index --chmod=-x handoff.md; commit "mode -x"; fin
newrow H11 "type flip: c1 handoff.md becomes SYMLINK, c2 back to regular file; tip regular" PASS "contract-literal"
mkwork; cd $RD/w; rm handoff.md; ln -s docs/a.md handoff.md; g add -A; commit "to symlink"; rm handoff.md; echo back > handoff.md; g add -A; commit "back to file"; fin
newrow H12 "follow-up is an EMPTY commit (no tree change)" FAIL "contract: must change handoff.md"
mkwork; cd $RD/w; commit "empty"; fin
newrow H13 "follow-up changes handoff.md and docs/a.md" FAIL
mkwork; cd $RD/w; echo x >> handoff.md; echo y >> docs/a.md; g add -A; commit "two paths"; fin
newrow H14 "follow-up wipes handoff.md content to empty file (still 100644)" PASS "contract-literal; prose: 'documentation-only change'"
mkwork; cd $RD/w; : > handoff.md; g add -A; commit "wipe"; fin
newrow H15 "c1 DELETES handoff.md, c2 re-adds it (tip regular)" FAIL "contract-ambiguous: 'the commit that adds handoff.md' no longer unique; log --diff-filter=A returns 2 lines"
mkwork; cd $RD/w; g rm -q handoff.md; commit "delete"; echo again > handoff.md; g add handoff.md; commit "re-add"; fin
newrow H16 "H adds handoff.md by RENAMING old.md (present in T) -> git log reports R not A" PASS "contract: H is the commit that adds handoff.md (path appears in H); tests dependence on path-filtered git log"
T_EXTRA='printf "handoff v1\n" > old.md'; H_EXTRA='rm old.md'
mkwork; fin
newrow H17 "H adds handoff.md as a COPY of old.md (old.md kept); default log does no copy detection" PASS
T_EXTRA='printf "handoff v1\n" > old.md'; H_EXTRA=''
mkwork; fin
newrow H18 "tip merge commit M(c1, s) where s is a side commit child of H changing handoff.md" FAIL
mkwork; fu one; cd $RD/w; g checkout -q -b side $H; echo side >> handoff.md; g add handoff.md; commit side; S=$(g rev-parse HEAD); g checkout -q $BR
g merge -q --no-ff -m merge -X theirs side >/dev/null 2>&1 || { echo conflict-resolve; g checkout --theirs handoff.md; g add handoff.md; commit merge; }; fin
newrow H19 "M(H, s): merge as FIRST follow-up, s child of T touching other file" FAIL
mkwork; cd $RD/w; g checkout -q -b side $T; echo s > side.txt; g add side.txt; commit side; g checkout -q $BR; g merge -q --no-ff -m merge side >/dev/null; fin
newrow H20 "tip M with parents (c1, T) built by commit-tree (second parent is an ancestor)" FAIL
mkwork; fu one; cd $RD/w; C1=$(tipw); M=$(printf 'm\n' | g commit-tree -p $C1 -p $T "$C1^{tree}"); g reset -q --hard $M; fin
newrow H21 "long chain of 40 valid follow-ups" PASS
mkwork; for i in $(seq 1 40); do fu "n$i"; done; fin
