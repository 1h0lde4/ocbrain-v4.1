#!/bin/bash
# git wrapper used ONLY by the S6 tests (placed first in PATH). Calls the real git by absolute path.
# Behaviour is driven by $WSTATE/spec: lines "<subcmd> <n|*> <kind> <arg...>"
REAL=/usr/bin/git
sub=$1
S=${WSTATE:?}
n=0; [ -f "$S/c.$sub" ] && n=$(<"$S/c.$sub"); n=$((n+1)); echo $n > "$S/c.$sub"
echo "$sub #$n $(date +%s.%N)" >> "$S/calls.log"
kind=""; arg=""
if [ -f "$S/spec" ]; then
  while read -r s k kd rest; do
    if [ "$s" = "$sub" ] && { [ "$k" = "$n" ] || [ "$k" = "*" ]; }; then kind=$kd; arg=$rest; break; fi
  done < "$S/spec"
fi
case $kind in
  before)  eval "$arg"; exec $REAL "$@";;                       # run hook, then the real command
  after)   out=$($REAL "$@" 2>"$S/err.$$"); rc=$?; cat "$S/err.$$" >&2; rm -f "$S/err.$$"   # real command observes first,
           eval "$arg"; [ -n "$out" ] && printf '%s\n' "$out"; exit $rc;;                  # then hook (e.g. move remote), then output is returned
  fake)    rc=${arg%%|*}; o=${arg#*|}; printf '%b' "$o"; exit $rc;;  # do not run git: print OUTPUT, exit RC
  failafter) $REAL "$@"; exit $arg;;                            # real output, then forced exit status
  sedout)  $REAL "$@" | sed "$arg"; exit ${PIPESTATUS[0]};;     # real command, output rewritten by sed
  headfail) $REAL "$@" 2>/dev/null | head -n ${arg%% *}; exit 128;;   # real output truncated to N lines then exit 128
  *)       exec $REAL "$@";;
esac
