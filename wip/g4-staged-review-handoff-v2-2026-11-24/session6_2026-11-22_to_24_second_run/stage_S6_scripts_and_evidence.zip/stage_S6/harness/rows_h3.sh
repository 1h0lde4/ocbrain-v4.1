#!/bin/bash
# extra H rows (empty ls-remote output / two lines) + pure-string identity normalisation check (block lines 4,15,16 evaluated verbatim, no network)
. /tmp/claude-0/-home-claude/d441201d-0373-573d-8f64-186072f858d3/scratchpad/a9/stage_S6/harness/lib.sh
wr() { newrow "$1" "$2" "$3" "$4"; shift 4; mkwork; fu one; fu two; publish; WRAP=1; for l in "$@"; do spec "$l"; done; mkblock; runblock; record; }
wr H36 "ls-remote #1 prints nothing, exit 0 (pipefail / empty-output path)" FAIL "" 'ls-remote 1 fake 0|'
wr H37 "ls-remote prints the correct line twice (2 refs same name)" FAIL "" 'ls-remote * sedout p'
wr H38 "final ls-remote (#2) prints nothing exit 0" FAIL "" 'ls-remote 2 fake 0|'
wr H39 "fetch prints junk and exits 0 but updates nothing (control for wrapper): valid remote" PASS "" 'fetch * sedout s/^/x/'
W2=$W/evidence/IDN; mkdir -p $W2
B=$PKG/rev3/verify_block_rev3.sh
L4=$(sed -n 4p $B); L15=$(sed -n 15p $B); L16=$(sed -n 16p $B)
bad() { :; }
for U in https://github.com/1h0lde4/ocbrain-v4.1 https://github.com/1h0lde4/ocbrain-v4.1.git git@github.com:1h0lde4/ocbrain-v4.1.git ssh://git@github.com/1h0lde4/ocbrain-v4.1.git \
  https://user:DUMMYTOKEN-xyz@github.com/1h0lde4/ocbrain-v4.1.git https://DUMMYTOKEN-xyz@github.com/1h0lde4/ocbrain-v4.1 https://github.com/1h0lde4/ocbrain-v4.1/ \
  https://github.com/1h0lde4/ocbrain-v4.1?token=DUMMYTOKEN-xyz https://github.com@evil.example/1h0lde4/ocbrain-v4.1 https://github.com/1h0lde4/ocbrain-v4.1.git.git \
  ssh://git:DUMMYTOKEN-xyz@github.com/1h0lde4/ocbrain-v4.1.git https://github.com:443/1h0lde4/ocbrain-v4.1 http://github.com/1h0lde4/ocbrain-v4.1; do
  r=$( URL=$U; eval "$L4"; eval "$L15" 2>&1; [ "${URL%.git}" = "$CANON" ] && echo ACCEPT || echo "REJECT(norm=${URL%.git})" )
  printf '%-75s %s\n' "$U" "$r" | tee -a $W2/identity_normalisation.txt
done
