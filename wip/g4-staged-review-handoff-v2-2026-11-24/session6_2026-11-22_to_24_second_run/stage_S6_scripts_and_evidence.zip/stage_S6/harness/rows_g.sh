#!/bin/bash
# G(4) execution checks of prose claims about URL credentials / identity forms. Loopback dead port only; SSH forms use GIT_SSH_COMMAND=/bin/false (no traffic).
. /tmp/claude-0/-home-claude/d441201d-0373-573d-8f64-186072f858d3/scratchpad/a9/stage_S6/harness/lib.sh 2>/dev/null || . /tmp/claude-0/-home-claude/d441201d-0373-573d-8f64-186072f858d3/scratchpad/a9/stage_S6/harness/lib.sh
GD=$W/evidence/G; rm -rf $GD $W/rows/G; mkdir -p $GD $W/rows/G
FT=1111111111111111111111111111111111111111
run() { # id url canon [ssh]
  local id=$1 url=$2 canon=$3; local d=$W/rows/G/$id; rm -rf $d; mkdir -p $d/home; g init -q -b main $d/c; g -C $d/c remote add origin "$url"
  sed -e "4s|^CANON=[^ ]*|CANON=$canon|" -e "6s|^T=[0-9a-f]*|T=$FT|" -e "7s|^H=[0-9a-f]*|H=$FT|" $PKG/rev3/verify_block_rev3.sh > $d/block.sh
  ( cd $d/c && env -i PATH=/usr/bin:/bin HOME=$d/home GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null GIT_TERMINAL_PROMPT=0 GIT_SSH_COMMAND=/bin/false NO_PROXY=127.0.0.1 bash $d/block.sh >$GD/$id.stdout 2>$GD/$id.stderr ); echo $? > $GD/$id.rc
  cat $GD/$id.stdout $GD/$id.stderr > $GD/$id.combined
  printf '%-6s rc=%s token_in_output=%s identity_FAIL_line=%s url=%s\n' $id $(cat $GD/$id.rc) "$(grep -c DUMMYTOKEN $GD/$id.combined)" "$(grep -c 'not the canonical' $GD/$id.stdout)" "$url" | tee -a $GD/summary.txt; }
C=https://127.0.0.1:1/o/r
run G01 "https://user:DUMMYTOKEN-xyz@127.0.0.1:1/o/r.git" $C
run G02 "https://DUMMYTOKEN-xyz@127.0.0.1:1/o/r" $C
run G03 "https://user:DUMMYTOKEN-xyz@127.0.0.1:1/o/r.git/" $C
run G04 "https://127.0.0.1:1/o/r?token=DUMMYTOKEN-xyz" $C
run G05 "http://user:DUMMYTOKEN-xyz@127.0.0.1:1/o/r.git" $C
run G06 "ssh://git:DUMMYTOKEN-xyz@127.0.0.1:1/o/r.git" $C
run G07 "https://127.0.0.1:1/o/r.git" $C
run G08 "git@github.com:1h0lde4/ocbrain-v4.1.git" https://github.com/1h0lde4/ocbrain-v4.1
run G09 "git@github.com:1h0lde4/ocbrain-v4.1" https://github.com/1h0lde4/ocbrain-v4.1
run G10 "ssh://git@github.com/1h0lde4/ocbrain-v4.1.git" https://github.com/1h0lde4/ocbrain-v4.1
run G11 "https://github.com/1h0lde4/other-repo.git" https://github.com/1h0lde4/ocbrain-v4.1
run G12 "git@github.com:1h0lde4/ocbrain-v4.1.git" https://github.com/1h0lde4/ocbrain-v4.1
