#!/bin/bash
# Criterion F rows: remote moves at chosen points relative to the block's git calls (wrapper hooks).
. /tmp/claude-0/-home-claude/d441201d-0373-573d-8f64-186072f858d3/scratchpad/a9/stage_S6/harness/lib.sh
fr() { # ROW DESC EXP NOTE spec...   (remote prepared: valid chain T-H-c1-c2 published; local c3 (valid ff) and 'bad' (invalid, touches other.md) unpublished)
  newrow "$1" "$2" "$3" "$4"; shift 4; mkwork; fu one; fu two; publish; fu three; C3=$(tipw)
  cd $RD/w; g checkout -q -b bad $H; echo q > other.md; g add other.md; commit bad; BAD=$(g rev-parse HEAD); g checkout -q $BR
  OLD=$(g ls-remote $RD/origin.git refs/heads/$BR | cut -f1); WRAP=1
  MV_VALID="/usr/bin/git -C $RD/w push -q $RD/origin.git $BR:refs/heads/$BR"
  MV_BAD="/usr/bin/git -C $RD/w push -q -f $RD/origin.git +bad:refs/heads/$BR"
  MV_BACK="/usr/bin/git -C $RD/w push -q -f $RD/origin.git +$OLD:refs/heads/$BR"
  for l in "$@"; do eval "l=\"$l\""; spec "$l"; done
  mkblock; runblock; g ls-remote $RD/origin.git refs/heads/$BR | cut -f1 > $EV/origin_tip_after_run.txt
  { echo "tip before run: $OLD"; echo "C3 (valid ff): $C3"; echo "BAD (invalid): $BAD"; echo "origin tip after run: $(cat $EV/origin_tip_after_run.txt)"; } > $EV/tips.txt; record; }
fr F01 "control: remote does not move" PASS "" 
fr F02 "remote moves to VALID ff commit c3 right AFTER the final ls-remote (#2) observed old tip" PASS "documented 'unavoidable' race" 'ls-remote 2 after $MV_VALID'
fr F03 "remote force-moved to INVALID commit (touches other.md) right AFTER the final ls-remote (#2)" PASS "documented 'unavoidable' race; PASS line text still says each follow-up changes handoff.md alone" 'ls-remote 2 after $MV_BAD'
fr F04 "remote moves (valid ff) right AFTER ls-remote #1 (between the two observations)" FAIL "block should detect motion at ls-remote #2" 'ls-remote 1 after $MV_VALID'
fr F05 "remote moves (valid ff) BEFORE the fetch" PASS "fetch sees the new tip; verified tip = c3" 'fetch 1 before $MV_VALID'
fr F06 "remote moves (valid ff) AFTER the fetch, before ls-remote #1" FAIL "fetched tip != live tip" 'fetch 1 after $MV_VALID'
fr F07 "ABA: remote moves to c3 after ls-remote #1, then back to the old tip before ls-remote #2" PASS "documented: PASS only about the final observation" 'ls-remote 1 after $MV_VALID' 'ls-remote 2 before $MV_BACK'
fr F08 "remote force-moved to INVALID commit AFTER ls-remote #1 and left there (before #2)" FAIL "must detect at #2" 'ls-remote 1 after $MV_BAD'
fr F09 "remote moves to INVALID commit AFTER the fetch (before ls-remote #1): block compares fetched vs live" FAIL "" 'fetch 1 after $MV_BAD'
