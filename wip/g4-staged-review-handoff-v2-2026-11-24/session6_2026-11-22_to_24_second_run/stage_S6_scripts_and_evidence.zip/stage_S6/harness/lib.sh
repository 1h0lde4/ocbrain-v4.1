# lib.sh (sourced). All paths absolute. Never touches anything outside $W.
W=/tmp/claude-0/-home-claude/d441201d-0373-573d-8f64-186072f858d3/scratchpad/a9/stage_S6
PKG=$W/pkg/review_package
RG=/usr/bin/git
BR=docs/g4-fts-errata-handoff-oct2026
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null GIT_TERMINAL_PROMPT=0
export GIT_AUTHOR_NAME=Rev GIT_AUTHOR_EMAIL=rev@example.invalid GIT_COMMITTER_NAME=Rev GIT_COMMITTER_EMAIL=rev@example.invalid
g() { $RG "$@"; }
tick=1700000000; FIXTICK=""
commit() { if [ -n "$FIXTICK" ]; then t=$FIXTICK; else tick=$((tick+60)); t=$tick; fi
  GIT_AUTHOR_DATE="$t +0000" GIT_COMMITTER_DATE="$t +0000" g commit -q --allow-empty -m "$1"; }
newrow() { unset T_EXTRA H_EXTRA; ROW=$1; DESC=$2; EXP=$3; NOTE=${4:-}; RD=$W/rows/$ROW; EV=$W/evidence/$ROW
  rm -rf "$RD" "$EV"; mkdir -p "$RD/home" "$EV"; WRAP=0; EXTRA=(); CWDREL=""; CANON=""; CLONEMODE=plain; tick=1700000000; FIXTICK=""
  echo "$DESC" > $EV/desc.txt; }
mkwork() { g init -q -b main "$RD/w"; cd "$RD/w"; g checkout -q -b $BR
  mkdir -p docs; echo a > docs/a.md; echo b > docs/b.md
  [ -n "${T_EXTRA:-}" ] && eval "$T_EXTRA"
  g add -A; commit "transfer"; T=$(g rev-parse HEAD)
  printf 'handoff v1\n' > handoff.md; [ -n "${H_EXTRA:-}" ] && eval "$H_EXTRA"; g add -A; commit "handoff"; H=$(g rev-parse HEAD); }
fu() { cd "$RD/w"; printf '%s\n' "${1:-edit}" >> handoff.md; g add handoff.md; commit "fu ${1:-edit}"; }
tipw() { g -C "$RD/w" rev-parse HEAD; }
publish() { g init -q --bare -b $BR "$RD/origin.git"; g -C "$RD/w" push -q "$RD/origin.git" "HEAD:refs/heads/$BR"
  if [ "$CLONEMODE" = plain ]; then g clone -q "$RD/origin.git" "$RD/clone" 2>/dev/null; else g clone -q $CLONEMODE "file://$RD/origin.git" "$RD/clone" 2>/dev/null; fi; }
mkblock() { [ -n "$CANON" ] || CANON=$RD/origin
  sed -e "4s|^CANON=[^ ]*|CANON=$CANON|" -e "6s|^T=[0-9a-f]*|T=$T|" -e "7s|^H=[0-9a-f]*|H=$H|" $PKG/rev3/verify_block_rev3.sh > $RD/block.sh
  diff <(cat $PKG/rev3/verify_block_rev3.sh) $RD/block.sh | grep '^[<>]' | cut -c1-40 > $EV/block_diff_lines.txt; }
runblock() { local cwd=${CWD:-$RD/clone}; local pathx=/usr/bin:/bin
  if [ "$WRAP" = 1 ]; then mkdir -p $RD/wrapbin $RD/wstate; cp $W/harness/wrapgit.sh $RD/wrapbin/git; pathx=$RD/wrapbin:/usr/bin:/bin; fi
  ( cd "$cwd" && env -i PATH=$pathx HOME=$RD/home GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null GIT_TERMINAL_PROMPT=0 \
      GIT_AUTHOR_NAME=Rev GIT_AUTHOR_EMAIL=rev@example.invalid GIT_COMMITTER_NAME=Rev GIT_COMMITTER_EMAIL=rev@example.invalid WSTATE=$RD/wstate "${EXTRA[@]}" \
      bash $RD/block.sh >$EV/stdout 2>$EV/stderr ); echo $? > $EV/rc
  cat $EV/stdout $EV/stderr > $EV/combined
  [ -d $RD/wstate ] && cp $RD/wstate/calls.log $EV/git_calls.log 2>/dev/null; true; }
record() { local rc act cls; rc=$(<$EV/rc)
  if grep -q '^PASS' $EV/stdout; then act=PASS; else act=FAIL; fi
  if [ "$act" = PASS ]; then [ "$EXP" = PASS ] && cls="correct PASS" || cls="FALSE PASS"; else [ "$EXP" = FAIL ] && cls="correct FAIL" || cls="false FAIL"; fi
  local anom=""; { [ $act = PASS ] && [ $rc != 0 ]; } && anom=" [ANOMALY: PASS with rc!=0]"; { [ $act = FAIL ] && [ $rc != 1 ]; } && anom=" [ANOMALY: no PASS and rc=$rc]"
  local fl; fl=$(grep -E '^(FAIL|PASS)' $EV/stdout | cut -c1-150 | tr '\n' '|')
  printf '%s\t%s\t%s\t%s\t%s%s\t%s\t%s\t%s\n' "$ROW" "$EXP" "$act" "$rc" "$cls" "$anom" "$DESC" "$NOTE" "$fl" >> $W/summary.tsv
  echo "$ROW/stdout, stderr, combined, rc, desc.txt, block_diff_lines.txt${RD:+}: $DESC" >> $W/evidence/INDEX.txt
  printf '%-8s exp=%-4s act=%-4s rc=%s  %s\n' "$ROW" "$EXP" "$act" "$rc" "$cls$anom"; }
spec() { mkdir -p $RD/wstate; printf '%s\n' "$@" >> $RD/wstate/spec; }
