STAGE S7: IN PROGRESS

Package integrity: full SHA-256 of copied zip = 391eb0a06784153af4591d6bbfdc0af87edce0f17dd2e2aae0a7593794ce2286 (matches preamble); inner SHA256SUMS.txt: all 7 entries OK.

| Criterion | Status | Plan |
|---|---|---|
| I (check_addendum4.py status-line handling) | NOT RUN | mutation harness run_mutations.py |
