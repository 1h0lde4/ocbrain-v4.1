#!/usr/bin/env python3
"""S7 mutation harness (reviewer-owned). Builds mutated COPIES of the addendum text and runs a COPY of
check_addendum4.py (fresh interpreter, python3 -I) on each. Evidence under evidence/. Usage: python3 -I run_mutations.py
"""
import os, re, subprocess, sys, json
BASE = "/tmp/claude-0/-home-claude/d441201d-0373-573d-8f64-186072f858d3/scratchpad/a9/stage_S7"
W = BASE + "/work"; MUT = W + "/mut"; EV = BASE + "/evidence"
os.makedirs(MUT, exist_ok=True); os.makedirs(EV, exist_ok=True)
T = open(W + "/addendum_orig.md", encoding="utf-8", newline="").read()
WANT = "G4 OPEN · High · freeze-blocking. G5–G8 HELD. Freeze readiness NOT DECLARED."
GOV = "**Governing statuses, unchanged:** "
BAD = "G4 CLOSED · High · freeze-blocking. G5–G8 RELEASED. Freeze readiness DECLARED."
assert T.count(GOV + WANT) == 1 and T.rstrip("\n").endswith("\n" + WANT)

def gov(f):            # transform only the governing-status line (line 5)
    return lambda t: t.replace(GOV + WANT, f(GOV + WANT), 1)
def last(f):           # transform only the final status line
    def g(t):
        i = t.rindex(WANT); return t[:i] + f(WANT) + t[i + len(WANT):]
    return g
def rep(a, b): return lambda s: s.replace(a, b, 1)
def after_gov(ins): return lambda t: t.replace(GOV + WANT, GOV + WANT, 1) if False else re.sub(r"(?m)^(\*\*Governing statuses, unchanged:\*\* .*\n)", lambda m: m.group(1) + ins, t, 1)
def before_last(ins): return lambda t: t[:t.rindex(WANT)] + ins + t[t.rindex(WANT):]
def row(start, f):
    def g(t):
        out = []
        for l in t.split("\n"):
            out.append(f(l) if l.startswith(start) else l)
        return "\n".join(out)
    return g
INV = "| G4/freeze invariants |"; OVR = "| **Overall result"
M = []  # (id, desc, expect, reason, fn)
def add(i, d, e, r, fn): M.append((i, d, e, r, fn))
R, A = "reject", "accept"
# --- wrong statuses on the governing line only
add("M01", "gov line: G4 OPEN -> G4 CLOSED", R, "wrong status", gov(rep("G4 OPEN", "G4 CLOSED")))
add("M02", "gov line: G4 OPEN -> G4 RESOLVED", R, "wrong status", gov(rep("G4 OPEN", "G4 RESOLVED")))
add("M03", "gov line: High -> Low", R, "wrong priority", gov(rep("High", "Low")))
add("M04", "gov line: G5-G8 HELD -> G5-G8 RELEASED", R, "wrong status", gov(rep("HELD", "RELEASED")))
add("M05", "gov line: NOT DECLARED -> DECLARED", R, "wrong status", gov(rep("NOT DECLARED", "DECLARED")))
add("M06", "gov line: freeze-blocking -> non-blocking", R, "wrong status", gov(rep("freeze-blocking", "non-blocking")))
# --- wrong statuses on the last line only
add("M07", "last line: G4 CLOSED", R, "wrong status", last(rep("G4 OPEN", "G4 CLOSED")))
add("M08", "last line: G4 RESOLVED", R, "wrong status", last(rep("G4 OPEN", "G4 RESOLVED")))
add("M09", "last line: High -> Low", R, "wrong priority", last(rep("High", "Low")))
add("M10", "last line: G5-G8 RELEASED", R, "wrong status", last(rep("HELD", "RELEASED")))
add("M11", "last line: Freeze readiness DECLARED", R, "wrong status", last(rep("NOT DECLARED", "DECLARED")))
# --- both consistently wrong
add("M12", "gov+last: G4 CLOSED", R, "wrong status", lambda t: last(rep("G4 OPEN", "G4 CLOSED"))(gov(rep("G4 OPEN", "G4 CLOSED"))(t)))
add("M13", "gov+last: Freeze readiness DECLARED", R, "wrong status", lambda t: last(rep("NOT DECLARED", "DECLARED"))(gov(rep("NOT DECLARED", "DECLARED"))(t)))
# --- ambiguous / near-miss on the LAST line
add("M14", "last line lower-case", R, "case differs", last(lambda s: s.lower()))
add("M15", "last line: en dash -> hyphen in G5-G8", R, "different dash", last(rep("–", "-")))
add("M16", "last line: middle dot -> bullet U+2022", R, "different separator", last(rep("·", "•")))
add("M17", "last line: double space after G4", R, "spacing", last(rep("G4 OPEN", "G4  OPEN")))
add("M18", "last line: trailing space", R, "trailing char", last(lambda s: s + " "))
add("M19", "last line: trailing U+200B", R, "zero-width trailing", last(lambda s: s + "​"))
add("M20", "last line: interior U+200B", R, "zero-width interior", last(rep("G4 OPEN", "G4​ OPEN")))
add("M21", "last line: NBSP instead of space", R, "spacing", last(rep("G4 OPEN", "G4 OPEN")))
add("M22", "last line: hedged suffix", R, "hedged", last(lambda s: s[:-1] + ", pending review."))
add("M23", "last line: negated prefix", R, "negated", last(lambda s: "It is not true that " + s))
add("M24", "last line: trailing U+2028", R, "invisible trailing char", last(lambda s: s + " "))
add("M25", "last line: 'wrong status' + U+2028 + correct text on one physical line", R, "hidden wrong status", last(lambda s: BAD + " " + s))
add("M26", "last line: 'wrong status' + U+0085 + correct text on one physical line", R, "hidden wrong status", last(lambda s: BAD + "\u0085" + s))
add("M27", "last line: 'wrong status' + FORM FEED + correct text", R, "hidden wrong status", last(lambda s: BAD + "\x0c" + s))
add("M61", "last line: 'wrong status' + lone CR + correct text on one physical line", R, "hidden wrong status", last(lambda s: BAD + "\r" + s))
add("M28", "extra NBSP-only line after the correct last line", A, "invisible; neutral", lambda t: t.rstrip("\n") + "\n \n")
# --- ambiguous on the GOVERNING line
add("M29", "gov line lower-case status", R, "case differs", gov(lambda s: s.replace(WANT, WANT.lower())))
add("M30", "gov line: hyphen dash", R, "different dash", gov(rep("–", "-")))
add("M31", "gov line: interior U+200B", R, "zero-width", gov(rep("G4 OPEN", "G4​ OPEN")))
add("M32", "gov line: hedged suffix after the status", R, "hedged", gov(lambda s: s + " Note: G4 was closed in a later review."))
add("M33", "gov line: negated prefix before the label", R, "negated", gov(lambda s: "It is not true that " + s))
add("M34", "gov line: contradiction appended on the same line", R, "conflicting", gov(lambda s: s + " G4 CLOSED. Freeze readiness DECLARED."))
add("M35", "gov line: trailing U+200B after the final period", R, "zero-width trailing", gov(lambda s: s + "​"))
# --- duplicate / conflicting statements elsewhere (gov line and last line intact)
add("M36", "body paragraph with wrong status", R, "conflicting statement", after_gov("\n" + BAD + "\n"))
add("M37", "wrong status in a table cell (claims table row)", R, "conflicting statement", row("| F11:", lambda l: l + "\n| Status check | G4 CLOSED; G5–G8 RELEASED; freeze readiness DECLARED | I60 |"))
add("M38", "wrong status in a code fence", R, "conflicting statement", after_gov("\n```\n" + BAD + "\n```\n"))
add("M39", "wrong status in a blockquote", R, "conflicting statement", after_gov("\n> " + BAD + "\n"))
add("M40", "line 17 (Statuses unchanged) says G4 CLOSED", R, "conflicting statement", rep("**Statuses unchanged:** G4 OPEN", "**Statuses unchanged:** G4 CLOSED"))
add("M41", "second Governing statuses line (wrong) BEFORE the correct one", R, "conflicting statement", after_gov("") if False else (lambda t: t.replace(GOV + WANT, GOV + BAD + "\n\n" + GOV + WANT, 1)))
add("M42", "wrong status line inserted BEFORE the correct last line", R, "conflicting statement", before_last(BAD + "\n\n"))
add("M43", "wrong status line appended AFTER the correct last line", R, "last line wrong", lambda t: t.rstrip("\n") + "\n\n" + BAD + "\n")
add("M44", "gov line moved into an HTML comment; visible paragraph says G4 CLOSED", R, "hidden/conflicting", lambda t: t.replace(GOV + WANT, "<!-- " + GOV + WANT + " -->\n\n" + BAD, 1))
add("M45", "unclosed <!-- inserted before correct last line (last line hidden when rendered)", R, "hidden status", before_last("<!--\n"))
add("M46", "gov line indented 4 spaces (code block)", R, "not a statement", lambda t: t.replace(GOV + WANT, "    " + GOV + WANT, 1))
add("M47", "gov line deleted", R, "missing", lambda t: t.replace(GOV + WANT, "No status line here.", 1))
add("M48", "last line deleted", R, "missing", lambda t: t[:t.rindex(WANT)].rstrip("\n") + "\n")
# --- gate table
add("M49", "gate row G4/freeze invariants: status FAIL, overall PASS", R, "inconsistent table", row(INV, rep("**PASS**", "**FAIL**")))
add("M50", "gate row G4/freeze invariants: status CLOSED", R, "word not allowed", row(INV, rep("**PASS**", "**CLOSED**")))
add("M51", "gate row G4/freeze invariants: reason says G4 CLOSED / freeze DECLARED, status PASS", R, "conflicting statement", row(INV, rep("statuses stated unchanged", "G4 CLOSED; freeze readiness DECLARED")))
add("M52", "gate row G4/freeze invariants deleted", R, "gate absent (weak expectation)", lambda t: "\n".join(l for l in t.split("\n") if not l.startswith(INV)))
add("M53", "overall FAIL with all gates PASS", R, "inconsistent", row(OVR, rep("**PASS**", "**FAIL**")))
add("M54", "gate status lower-case 'pass'", R, "word not allowed", row(INV, rep("**PASS**", "**pass**")))
add("M55", "extra gate row '| G4 CLOSED | PASS | x | y |'", R, "conflicting (weak expectation)", row(INV, lambda l: l + "\n| G4 CLOSED | **PASS** | x | y |"))
add("M56", "overall row without SELF-REVIEW ONLY", R, "label missing", row(OVR, rep("**SELF-REVIEW ONLY**", "reviewed")))
add("M57", "gate row G4/freeze invariants BLOCKED and overall BLOCKED", A, "consistent alternative", lambda t: row(OVR, rep("**PASS**", "**BLOCKED**"))(row(INV, rep("**PASS**", "**BLOCKED**"))(t)))
add("M58", "gate row with one cell only ('| G4 |') after the invariants row", R, "malformed (crash expected)", row(INV, lambda l: l + "\n| G4 |"))
# --- encoding / neutral
add("M59", "CRLF line endings throughout", A, "same text; neutral", lambda t: t.replace("\n", "\r\n"))
add("M60", "UTF-8 BOM at file start", A, "neutral", lambda t: "﻿" + t)
add("M00", "unmodified text (baseline)", A, "control", lambda t: t)

ENV = {"PATH": "/usr/bin:/bin:/usr/local/bin", "GIT_CONFIG_GLOBAL": "/dev/null", "GIT_CONFIG_SYSTEM": "/dev/null", "GIT_TERMINAL_PROMPT": "0", "HOME": "/nonexistent"}
S = W + "/stub"
rows = []; idx = []
for mid, desc, exp, why, fn in sorted(M, key=lambda x: x[0]):
    new = fn(T); assert new != T or mid in ("M00",), mid
    p = f"{MUT}/{mid}.md"
    with open(p, "w", encoding="utf-8", newline="") as f: f.write(new)
    cmd = ["python3", "-I", W + "/check_addendum4.py", p, W + "/ev", W + "/repo", S + "/bundle.zip", S + "/rev3.patch", S + "/rev2.patch", S + "/att.txt", S + "/add1.txt", S + "/add2.txt", S + "/add3.txt", S + "/report.txt"]
    r = subprocess.run(cmd, capture_output=True, text=True, env=ENV, cwd=W + "/ev", timeout=60)
    out = r.stdout; err = r.stderr
    open(f"{EV}/{mid}.stdout", "w").write(out); open(f"{EV}/{mid}.stderr", "w").write(err)
    pre = out.split("ids cited:")[0]            # every status-line / gate-table check runs before this marker
    fails = [l for l in pre.splitlines() if l.startswith("FAIL:")]
    crash = ("Traceback" in err) and ("ids cited:" not in out)
    lastok = re.search(r"last non-empty line ok: (\w+)", out);
    rejected = bool(fails) or crash
    if exp == R: cls = "correct reject" if rejected else "FALSE ACCEPT"
    else: cls = "false reject" if rejected else "correct accept"
    first = (fails[0] if fails else ("CRASH: " + err.strip().splitlines()[-1] if crash else "(no status-check FAIL)"))
    rows.append((mid, desc, exp, why, r.returncode, "; ".join(f[6:].strip() for f in fails) or ("CRASH" if crash else "-"), cls))
    idx.append(f"{mid}  exit={r.returncode}  status-check-fails={len(fails)}  crash={crash}  files: evidence/{mid}.stdout evidence/{mid}.stderr  input: work/mut/{mid}.md")
with open(BASE + "/SUMMARY_TABLE.tsv", "w") as f:
    f.write("id\tmutation\texpected\treason\toverall_exit(unrelated evidence checks fail in every run)\tstatus_check_FAIL_lines\tclassification\n")
    for r in rows: f.write("\t".join(map(str, r)) + "\n")
open(EV + "/INDEX.txt", "w").write("S7 evidence index (raw stdout/stderr per mutation; mutated inputs in work/mut/)\n" + "\n".join(idx) + "\n")
from collections import Counter
print(Counter(r[-1] for r in rows))
for r in rows:
    if r[-1] in ("FALSE ACCEPT", "false reject"): print(r[0], r[-1], "|", r[1], "|", r[5])
