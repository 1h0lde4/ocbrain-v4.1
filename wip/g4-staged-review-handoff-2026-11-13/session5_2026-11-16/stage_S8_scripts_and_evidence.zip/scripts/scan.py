#!/usr/bin/env python3
# S8 own: for each row, classify every output line as BLOCK-written (FAIL:/PASS/follow-up:/TRANSFER) or GIT/other, and report token / URL text per stream.
import os,sys,re
base=sys.argv[1]
BLK=("FAIL:","PASS at","follow-up:","TRANSFER INCOMPLETE")
for row in sys.argv[2:]:
    d=os.path.join(base,row)
    rd=lambda n: open(os.path.join(d,n),errors="replace").read() if os.path.exists(os.path.join(d,n)) else ""
    url=rd("url_as_given.txt").strip()
    A=rd("A_interleaved.txt").splitlines(); so=rd("B_stdout.txt").splitlines(); se=rd("B_stderr.txt").splitlines()
    def tok(ls): return [l for l in ls if "DUMMYTOKEN" in l]
    def urlish(ls): return [l for l in ls if re.search(r"https?://|127\.0\.0\.[12]|evil\.example",l)]
    blockA=[l for l in A if l.startswith(BLK)]
    gitA=[l for l in A if not l.startswith(BLK)]
    blk_tok=tok(blockA); blk_url=[l for l in urlish(blockA) if "https://github.com/1h0lde4/ocbrain-v4.1)" not in l]
    print("%-40s exit=%s | all-lines=%d block-lines=%d | token lines: total=%d block-written=%d stdout=%d stderr=%d | url-ish lines written by block (other than the constant CANON in the identity FAIL): %d | git url-ish lines=%d"%(
        row,rd("A_exit.txt").strip(),len(A),len(blockA),len(tok(A)),len(blk_tok),len(tok(so)),len(tok(se)),len(blk_url),len(urlish(gitA))))
    for l in tok(se)[:3]: print("      TOKEN(stderr)>",l[:200])
    for l in urlish(gitA)[:2]:
        if "DUMMYTOKEN" not in l: print("      URL(git)     >",l[:200])
