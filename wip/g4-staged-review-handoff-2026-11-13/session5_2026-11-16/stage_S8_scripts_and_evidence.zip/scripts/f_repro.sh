#!/bin/bash
# S8 own: equivalents of the author's R1, R2, R5. Run inside `unshare -rn` via env -i (see bottom of file for the call).
S=$(cd "$(dirname "$0")/.." && pwd); BLK=$S/pkg/review_package/rev3/verify_block_rev3.sh
python3 -I -c 'import fcntl,socket,struct; s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); f=struct.unpack("16sH14s",fcntl.ioctl(s,0x8913,struct.pack("16sH14s",b"lo",0,b"")))[1]; fcntl.ioctl(s,0x8914,struct.pack("16sH14s",b"lo",f|1,b""))'
python3 -I -c 'import socket;s=socket.socket();s.settimeout(2);s.connect(("1.1.1.1",443))' 2>/dev/null && { echo "LEAK abort"; exit 99; }
echo "block sha256: $(sha256sum $BLK | cut -d' ' -f1)"
echo; echo "== R1-equivalent: block line 15 (verbatim, sed -n 15p) + line 16 comparison, string level"
CANON=https://github.com/1h0lde4/ocbrain-v4.1
l15=$(sed -n 15p $BLK)
for u in 'https://127.0.0.1:18443?@github.com/1h0lde4/ocbrain-v4.1' 'https://evil.example#@github.com/1h0lde4/ocbrain-v4.1' 'https://evil.example/@github.com/1h0lde4/ocbrain-v4.1' 'https://evil.example/x?@github.com/1h0lde4/ocbrain-v4.1' 'https://github.com/1h0lde4/ocbrain-v4.1' 'https://evil.example\@github.com/1h0lde4/ocbrain-v4.1' 'https://evil.example%2f@github.com/1h0lde4/ocbrain-v4.1' 'https://evil.example?x=1#@github.com/1h0lde4/ocbrain-v4.1'; do
  URL=$u; eval "$l15"
  if [ "${URL%.git}" = "$CANON" ]; then r="ACCEPTED as canonical"; else r="rejected"; fi
  printf '%-62s -> %s (%s)\n' "$u" "$r" "$URL"
done
echo; echo "== R2-equivalent: which host does git/libcurl contact for the '?@' form (dead loopback port 1, github.com NOT mapped, no proxy)"
W=$(mktemp -d); cd $W
CL=(env -i PATH=/usr/bin:/bin HOME=$W LANG=C GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null GIT_TERMINAL_PROMPT=0 NO_PROXY=127.0.0.1 no_proxy=127.0.0.1)
"${CL[@]}" git init -q . ; "${CL[@]}" git remote add origin 'https://127.0.0.1:1?@github.com/1h0lde4/ocbrain-v4.1'
"${CL[@]}" git remote get-url origin
GIT_TRACE_CURL=1 "${CL[@]}" env GIT_TRACE_CURL=1 git ls-remote origin 2>&1 | grep -E "Info:|fatal" | cut -c1-220
echo; echo "== R5-equivalent: git alone (ls-remote), token as user name, plain-http 401 server on 127.0.0.1:18402"
python3 -I $S/scripts/http401.py 18402 $W/h401.jsonl & HP=$!; sleep 0.5
"${CL[@]}" git ls-remote 'http://DUMMYTOKENU@127.0.0.1:18402' 2>&1 | cut -c1-200
echo "-- control string absent from that output:"; "${CL[@]}" git ls-remote 'http://DUMMYTOKENU@127.0.0.1:18402' 2>&1 | grep -c 'NOTPRESENT-xyz'
echo "-- server log (authz presence only):"; cut -c1-200 $W/h401.jsonl | head -4
kill $HP 2>/dev/null; wait $HP 2>/dev/null; rm -rf $W
