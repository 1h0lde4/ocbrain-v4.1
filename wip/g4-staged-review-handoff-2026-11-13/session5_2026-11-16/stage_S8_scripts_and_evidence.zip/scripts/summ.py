#!/usr/bin/env python3
import json,os,sys,re
base=sys.argv[1]
for row in sys.argv[2:]:
    d=os.path.join(base,row)
    rd=lambda n: open(os.path.join(d,n),errors="replace").read() if os.path.exists(os.path.join(d,n)) else ""
    out=rd("B_stdout.txt"); err=rd("B_stderr.txt")
    reqs=[json.loads(l) for l in rd("server_requests.jsonl").splitlines() if l.strip()]
    # run A is first 'runA' requests
    m=re.search(r"runA=(\d+)",rd("request_counts.txt")); nA=int(m.group(1)) if m else len(reqs)
    ra=reqs[:nA]
    dest=sorted({(r["server"],r["host_header"],r["sni"]) for r in ra})
    passed=any(l.startswith("PASS") for l in out.splitlines())
    nfail=sum(l.startswith("FAIL") for l in out.splitlines())
    first=ra[0]["request_line"][:70] if ra else None
    print("%-44s exitB=%s PASS=%s nFAIL=%d reqsA=%d dest=%s first=%s authz=%s"%(row,rd("B_exit.txt").strip(),passed,nfail,nA,[(a,b,c) for a,b,c in dest],first,sorted({r['authorization'] for r in ra})))
