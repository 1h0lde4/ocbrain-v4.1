#!/bin/bash
S=$(cd "$(dirname "$0")/.." && pwd)
exec env -i PATH=/usr/bin:/bin:/usr/local/bin HOME=/nonexistent unshare -rn bash $S/scripts/s8_row.sh "$@"
