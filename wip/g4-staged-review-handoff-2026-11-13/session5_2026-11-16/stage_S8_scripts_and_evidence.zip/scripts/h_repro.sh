#!/bin/bash
# S8 own: minimal reproductions of S6-H-01 (refs/replace), S6-H-02 (grafts), S6-H-03 (run from a clone subdirectory). Local paths only; no network.
set -u
S=$(cd "$(dirname "$0")/.." && pwd); BLK=$S/pkg/review_package/rev3/verify_block_rev3.sh; BR=docs/g4-fts-errata-handoff-oct2026
W=$S/work/h; rm -rf "$W"; mkdir -p "$W"; cd "$W"
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null GIT_TERMINAL_PROMPT=0
export GIT_AUTHOR_NAME=a GIT_AUTHOR_EMAIL=a@example.invalid GIT_COMMITTER_NAME=a GIT_COMMITTER_EMAIL=a@example.invalid
d=1; tick() { d=$((d+1)); export GIT_AUTHOR_DATE="2026-10-23T10:0$d:00Z" GIT_COMMITTER_DATE="2026-10-23T10:0$d:00Z"; }
runblock() { # $1 = origin path (no .git), $2 = T, $3 = H, rest: env assignments ; runs in cwd
  local o=$1 t=$2 h=$3; shift 3
  sed -e "4s#^CANON=[^ ]*#CANON=$o#" -e "6s/^T=[0-9a-f]\{40\}/T=$t/" -e "7s/^H=[0-9a-f]\{40\}/H=$h/" $BLK > $W/blk_$$.sh
  env -i PATH=/usr/bin:/bin HOME=$W LANG=C GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null GIT_TERMINAL_PROMPT=0 "$@" bash $W/blk_$$.sh > $W/out_$$.txt 2> $W/err_$$.txt; local rc=$?
  echo "   exit=$rc"; sed 's/^/   stdout: /' $W/out_$$.txt | cut -c1-210; sed 's/^/   stderr: /' $W/err_$$.txt | cut -c1-160 | head -3
  { diff $BLK $W/blk_$$.sh | grep -c '^[<>]'; } | sed 's/^/   changed block lines (4=line4? see note): /'
}
# ---- world 1: remote chain T -> H -> P -> M (M is a MERGE commit with parents P and S, tree = P's tree with handoff.md changed)
git init -q -b $BR w1; cd w1; tick; echo t > src.txt; git add .; git commit -qm T; T=$(git rev-parse HEAD)
tick; echo h > handoff.md; git add .; git commit -qm H; H=$(git rev-parse HEAD)
tick; echo p >> handoff.md; git add .; git commit -qm P; P=$(git rev-parse HEAD)
git checkout -q -b side $H; tick; echo s > side.txt; git add .; git commit -qm S; SD=$(git rev-parse HEAD); git checkout -q $BR
echo m >> handoff.md; git add handoff.md; TREE=$(git write-tree); tick
M=$(git commit-tree $TREE -p $P -p $SD -m "M merge")      # two parents
git update-ref refs/heads/$BR $M; cd ..
git clone -q --bare w1 origin1.git
echo "world1: T=$T H=$H P=$P M(merge,2 parents)=$M ; remote tip parents: $(git -C origin1.git show -s --format=%P $BR)"
O1=$W/origin1
echo "== H-ctl0: clean clone, no replace/graft  (expect FAIL: M is not a single-parent child)"
git clone -q origin1.git c_ctl; ( cd c_ctl; runblock $O1 $T $H )
echo "== H-01 (refs/replace): same clone dir style, local replace ref M -> X (single-parent twin of M, same tree)"
git clone -q origin1.git c_rep; ( cd c_rep; X=$(git commit-tree $TREE -p $P -m "X twin"); git replace $M $X; echo "   replace refs: $(git for-each-ref refs/replace | wc -l)"; runblock $O1 $T $H )
echo "== H-01 control: same clone with replace ref present, GIT_NO_REPLACE_OBJECTS=1 (expect FAIL)"
( cd c_rep; runblock $O1 $T $H GIT_NO_REPLACE_OBJECTS=1 )
echo "== H-02 (grafts): .git/info/grafts: 'M P' (git 2.43.0)"
git clone -q origin1.git c_gr; ( cd c_gr; echo "$M $P" > .git/info/grafts; runblock $O1 $T $H )
echo "== H-02 control: same clone, GIT_GRAFT_FILE=/dev/null (expect FAIL)"
( cd c_gr; runblock $O1 $T $H GIT_GRAFT_FILE=/dev/null )
# ---- world 2: subdirectory. H adds handoff.md AND docs/handoff.md; follow-up F makes ROOT handoff.md executable (100755) => contract violated
git init -q -b $BR w2; cd w2; tick; echo t > src.txt; git add .; git commit -qm T; T2=$(git rev-parse HEAD)
tick; echo h > handoff.md; mkdir docs; echo hd > docs/handoff.md; git add .; git commit -qm H; H2=$(git rev-parse HEAD)
tick; chmod +x handoff.md; git add handoff.md; git commit -qm "chmod +x root handoff"; cd ..
git clone -q --bare w2 origin2.git; O2=$W/origin2
echo "world2: remote tip root handoff.md mode: $(git -C origin2.git ls-tree $BR -- handoff.md | cut -d' ' -f1)"
git clone -q origin2.git c_sub
echo "== H-03 control: run from the clone ROOT (expect FAIL: mode 100755)"; ( cd c_sub; runblock $O2 $T2 $H2 )
echo "== H-03: run from clone subdirectory docs/ (cwd-relative pathspecs)"; ( cd c_sub/docs; runblock $O2 $T2 $H2 )
# ---- world 3: valid chain, run from subdirectory (false FAIL) and root (PASS)
git init -q -b $BR w3; cd w3; tick; echo t > src.txt; git add .; git commit -qm T; T3=$(git rev-parse HEAD)
tick; echo h > handoff.md; mkdir docs; echo x > docs/x.txt; git add .; git commit -qm H; H3=$(git rev-parse HEAD)
tick; echo more >> handoff.md; git add .; git commit -qm F1; cd ..
git clone -q --bare w3 origin3.git; O3=$W/origin3; git clone -q origin3.git c_valid
echo "== H-03b valid chain from ROOT (expect PASS)"; ( cd c_valid; runblock $O3 $T3 $H3 )
echo "== H-03b valid chain from docs/ (false FAIL by S6)"; ( cd c_valid/docs; runblock $O3 $T3 $H3 )
