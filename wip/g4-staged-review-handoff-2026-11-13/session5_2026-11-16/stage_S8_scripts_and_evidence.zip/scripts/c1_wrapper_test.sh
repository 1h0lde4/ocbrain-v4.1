#!/bin/bash
# S8 own: S4 C-1 / S6 claim-8 check. A git wrapper alters ONLY the 1st `git ls-remote` output (adds extra words after the exact ref name on the single line); the 2nd call is genuine. Local origin path.
set -u
S=$(cd "$(dirname "$0")/.." && pwd); BLK=$S/pkg/review_package/rev3/verify_block_rev3.sh; BR=docs/g4-fts-errata-handoff-oct2026
W=$S/work/c1; rm -rf $W; mkdir -p $W/wrap; cd $W
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null GIT_AUTHOR_NAME=a GIT_AUTHOR_EMAIL=a@e.invalid GIT_COMMITTER_NAME=a GIT_COMMITTER_EMAIL=a@e.invalid
git init -q -b $BR w; cd w; echo t>s; git add .; git commit -qm T; T=$(git rev-parse HEAD); echo h>handoff.md; git add .; git commit -qm H; H=$(git rev-parse HEAD); echo f>>handoff.md; git add .; git commit -qm F; TIP=$(git rev-parse HEAD); cd ..
git clone -q --bare w origin.git; git clone -q origin.git cl
cat > wrap/git <<WEOF
#!/bin/bash
if [ "\$1" = ls-remote ]; then
  n=\$(cat $W/n 2>/dev/null || echo 0); n=\$((n+1)); echo \$n > $W/n
  if [ \$n = 1 ]; then printf '%s\trefs/heads/$BR EXTRA WORDS NOT A REF NAME\n' "$TIP"; exit 0; fi
fi
exec /usr/bin/git "\$@"
WEOF
chmod +x wrap/git
sed -e "4s#^CANON=[^ ]*#CANON=$W/origin#" -e "6s/^T=[0-9a-f]\{40\}/T=$T/" -e "7s/^H=[0-9a-f]\{40\}/H=$H/" $BLK > blk.sh
cd cl; env -i PATH=$W/wrap:/usr/bin:/bin HOME=$W LANG=C GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null bash ../blk.sh > ../out.txt 2> ../err.txt; echo "exit=$?"; cut -c1-200 ../out.txt; echo "ls-remote calls seen by wrapper: $(cat ../n)"
