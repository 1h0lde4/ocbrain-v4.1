#!/usr/bin/env python3
"""S8 own code: plain-http loopback server. Always answers 401 Basic and logs request line + Authorization present/absent (never the value)."""
import sys, json, time, http.server
port=int(sys.argv[1]); log=sys.argv[2]
class H(http.server.BaseHTTPRequestHandler):
    protocol_version="HTTP/1.1"
    def log_message(self,*a): pass
    def _r(self):
        n=int(self.headers.get("Content-Length") or 0)
        if n: self.rfile.read(n)
        a=self.headers.get("Authorization")
        with open(log,"a") as f: f.write(json.dumps(dict(t=round(time.time(),3),port=port,host=self.headers.get("Host"),req=f"{self.command} {self.path}",authz=("present("+a.split(" ")[0]+")") if a else "absent",status=401))+"\n")
        self.send_response(401); self.send_header("WWW-Authenticate",'Basic realm="s8"'); self.send_header("Content-Length","0"); self.end_headers()
    do_GET=_r; do_POST=_r
http.server.HTTPServer(("127.0.0.1",port),H).serve_forever()
