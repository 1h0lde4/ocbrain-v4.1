#!/bin/bash
# S8 own: proof that nothing can leave the machine inside `unshare -rn` (lo only)
python3 -I -c 'import fcntl,socket,struct; s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); f=struct.unpack("16sH14s",fcntl.ioctl(s,0x8913,struct.pack("16sH14s",b"lo",0,b"")))[1]; fcntl.ioctl(s,0x8914,struct.pack("16sH14s",b"lo",f|1,b""))'
python3 -I - <<'PY'
import socket
for host,port in (("1.1.1.1",443),("8.8.8.8",53)):
    s=socket.socket(); s.settimeout(3)
    try: s.connect((host,port)); print("CONNECT",host,port,"SUCCEEDED (LEAK!)")
    except Exception as e: print("connect",host,port,"failed:",type(e).__name__,e)
try: print("github.com resolves to", socket.gethostbyname("github.com"))
except Exception as e: print("github.com does not resolve:",type(e).__name__,e)
print("interfaces:", [n for _,n in socket.if_nameindex()])
PY
