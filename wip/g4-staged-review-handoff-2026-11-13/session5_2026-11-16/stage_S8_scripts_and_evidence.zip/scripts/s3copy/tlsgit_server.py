#!/usr/bin/env python3
"""Loopback TLS smart-HTTP git server for review tests (own code).
Usage: tlsgit_server.py --cert C --key K --root DIR --log FILE --listen LABEL:BIND:PORT:REPO:AUTH [...]
AUTH: none | 401 (always 401 Basic) | basic (401 if no Authorization header, else serve)
Maps ANY GET to <repo>/info/refs?service=git-upload-pack and ANY POST to <repo>/git-upload-pack
(so that '?@' / '#@' URL forms that change the request target still reach the repository),
and logs the real request target. Authorization header is logged only as present/absent (+scheme)."""
import argparse, json, os, ssl, subprocess, sys, threading, time, http.server, socketserver

ap = argparse.ArgumentParser()
ap.add_argument("--cert"); ap.add_argument("--key"); ap.add_argument("--root"); ap.add_argument("--log")
ap.add_argument("--listen", action="append", default=[])
a = ap.parse_args()
LOCK = threading.Lock()

def log(rec):
    rec["t"] = round(time.time(), 3)
    with LOCK, open(a.log, "a") as f:
        f.write(json.dumps(rec, sort_keys=True) + "\n")

def make_handler(label, bind, port, repo, auth):
    class H(http.server.BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        def log_message(self, *x): pass
        def _serve(self):
            n = int(self.headers.get("Content-Length") or 0)
            body = self.rfile.read(n) if n else b""
            if self.headers.get("Transfer-Encoding", "").lower() == "chunked":
                body = b""
                while True:
                    ln = int(self.rfile.readline().strip() or b"0", 16)
                    if ln == 0:
                        self.rfile.readline(); break
                    body += self.rfile.read(ln); self.rfile.readline()
            authz = self.headers.get("Authorization")
            rec = dict(server=label, listen=f"{bind}:{port}", client=f"{self.client_address[0]}:{self.client_address[1]}",
                       sni=getattr(self.request, "_sni", None), host_header=self.headers.get("Host"),
                       request_line=f"{self.command} {self.path} {self.request_version}",
                       authorization=("present(" + authz.split(" ")[0] + ")") if authz else "absent",
                       repo=repo, auth_mode=auth, content_type=self.headers.get("Content-Type"))
            if auth == "401" or (auth == "basic" and not authz):
                rec["status"] = 401
                self.send_response(401); self.send_header("WWW-Authenticate", 'Basic realm="loopback-test"')
                self.send_header("Content-Length", "0"); self.end_headers(); log(rec); return
            env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "GIT_HTTP_EXPORT_ALL": "1", "GIT_PROJECT_ROOT": a.root,
                   "REMOTE_ADDR": self.client_address[0], "REQUEST_METHOD": self.command,
                   "GIT_CONFIG_GLOBAL": "/dev/null", "GIT_CONFIG_SYSTEM": "/dev/null"}
            if self.command == "GET":
                env["PATH_INFO"] = f"/{repo}/info/refs"; env["QUERY_STRING"] = "service=git-upload-pack"
            else:
                env["PATH_INFO"] = f"/{repo}/git-upload-pack"; env["QUERY_STRING"] = ""
                env["CONTENT_TYPE"] = self.headers.get("Content-Type", "application/x-git-upload-pack-request")
                env["CONTENT_LENGTH"] = str(len(body))
            if self.headers.get("Git-Protocol"): env["GIT_PROTOCOL"] = self.headers["Git-Protocol"]
            if self.headers.get("Content-Encoding"): env["HTTP_CONTENT_ENCODING"] = self.headers["Content-Encoding"]
            p = subprocess.run(["git", "http-backend"], input=body, env=env, capture_output=True)
            hdr, _, out = p.stdout.partition(b"\r\n\r\n")
            status, heads = 200, []
            for ln in hdr.decode("latin1").split("\r\n"):
                if ":" not in ln: continue
                k, v = ln.split(":", 1)
                if k.lower() == "status": status = int(v.strip().split()[0])
                else: heads.append((k, v.strip()))
            rec["status"] = status; rec["resp_bytes"] = len(out)
            self.send_response(status)
            for k, v in heads:
                if k.lower() not in ("content-length", "transfer-encoding"): self.send_header(k, v)
            self.send_header("Content-Length", str(len(out))); self.end_headers(); self.wfile.write(out); log(rec)
        do_GET = _serve; do_POST = _serve
    return H

class Srv(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True; allow_reuse_address = True
    def __init__(s, addr, h, ctx):
        s.ctx = ctx; super().__init__(addr, h)
    def get_request(s):
        sock, addr = s.socket.accept()
        return s.ctx.wrap_socket(sock, server_side=True), addr

ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); ctx.load_cert_chain(a.cert, a.key)
ctx.sni_callback = lambda s, name, c: setattr(s, "_sni", name)
for spec in a.listen:
    label, bind, port, repo, auth = spec.split(":")
    srv = Srv((bind, int(port)), make_handler(label, bind, int(port), repo, auth), ctx)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    print("listening", label, bind, port, repo, auth, flush=True)
threading.Event().wait()
