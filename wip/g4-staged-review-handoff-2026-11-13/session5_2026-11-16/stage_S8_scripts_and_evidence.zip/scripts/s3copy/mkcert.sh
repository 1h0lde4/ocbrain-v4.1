#!/bin/bash
# one self-signed cert: SAN DNS:github.com, DNS:evil.example, IP:127.0.0.1
set -e
D=${1:?dir}
mkdir -p "$D"
openssl req -x509 -newkey rsa:2048 -nodes -keyout "$D/key.pem" -out "$D/cert.pem" -days 3 \
  -subj "/CN=github.com" -addext "subjectAltName=DNS:github.com,DNS:evil.example,IP:127.0.0.1" >/dev/null 2>&1
chmod 600 "$D/key.pem"
openssl x509 -in "$D/cert.pem" -noout -ext subjectAltName | tail -1
