#!/usr/bin/env python3
"""summarise one row dir -> one JSON line (classification fields); run with python3 -I"""
import json, os, sys, re
d = sys.argv[1]; rd = lambda n: open(os.path.join(d, n), errors="replace").read() if os.path.exists(os.path.join(d, n)) else ""
out, err = rd("d_stdout.txt"), rd("d_stderr.txt")
n1 = int((rd("c_run1_log_lines.txt") or "0").strip() or 0)
reqs = [json.loads(l) for l in rd("server_requests.jsonl").splitlines() if l.strip()][:n1]
printed_pass = any(l.startswith("PASS") for l in out.splitlines())
rc = rd("d_exitcode.txt").strip()
ident = re.search(r"identity_check=(\w+)", rd("b_normalisation_result.txt"))
parsed = re.search(r"parsed_url=(.*)", rd("b_normalisation_result.txt"))
dest = sorted({(r["server"], r["listen"], r["host_header"], r["sni"]) for r in reqs})
rec = dict(row=os.path.basename(d.rstrip("/")), url=rd("a_remote_url_as_given.txt").rstrip("\n"), roundtrip=rd("a_roundtrip.txt").strip(),
           parsed_url=parsed.group(1) if parsed else None, identity=ident.group(1) if ident else None,
           exit=rc, printed_PASS=printed_pass, identity_fail_msg=("origin is not the canonical repository" in out),
           servers_contacted=[list(x) for x in dest], n_requests_run1=len(reqs),
           first_request_line=reqs[0]["request_line"] if reqs else None,
           authz=sorted({r["authorization"] for r in reqs}))
labels = {x[0] for x in dest}
if printed_pass and rc == "0":
    rec["classification"] = "FALSE PASS" if "EVIL8443" in labels or not labels else ("correct PASS" if labels == {"CANON443"} else "MIXED/CHECK")
else:
    rec["classification"] = "correct FAIL" if True else ""
rec["stdout_head"] = out[:300]; rec["stderr_head"] = err[:600]
print(json.dumps(rec, sort_keys=True))
