#!/bin/bash
# wrapper: runs one row inside a fresh loopback-only network namespace with proxies and ambient credentials removed
S=$(cd "$(dirname "$0")/.." && pwd)
exec env -i PATH=/usr/bin:/bin:/usr/local/bin HOME=/nonexistent unshare -rn bash $S/scripts/run_row.sh "$@"
