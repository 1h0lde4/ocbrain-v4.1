#!/usr/bin/env python3
import os, sys, json, re
base = sys.argv[1]; rows = sys.argv[2:]
for row in rows:
    d = os.path.join(base, row); rd = lambda n: open(os.path.join(d, n), errors="replace").read() if os.path.exists(os.path.join(d, n)) else ""
    n1 = int((rd("c_run1_log_lines.txt") or "0").strip() or 0)
    reqs = [json.loads(l) for l in rd("server_requests.jsonl").splitlines() if l.strip()][:n1]
    out, err = rd("d_stdout.txt"), rd("d_stderr.txt")
    b = rd("b_normalisation_result.txt").replace("\n", "; ")
    if reqs:
        r = reqs[0]; dest = "%s listen=%s SNI=%s Host=%s client=%s authz(first)=%s req1=`%s` (n=%d, authz set=%s)" % (r["server"], r["listen"], r["sni"], r["host_header"], r["client"], r["authorization"], r["request_line"][:80], len(reqs), sorted({x["authorization"] for x in reqs}))
    else: dest = "NO REQUEST REACHED ANY SERVER"
    outl = [l for l in out.splitlines()]
    kind = "PASS-line" if any(l.startswith("PASS") for l in outl) else "FAIL-lines(%d)+TRANSFER INCOMPLETE" % sum(l.startswith("FAIL") for l in outl)
    frm = [l for l in err.splitlines() if l.startswith(("From", "fatal: unable", "fatal: could", "fatal: Auth"))][:1]
    print("%s | url=`%s` | b: %s | c: %s | d: exit=%s stdout=%s stderr1=`%s`" % (row, rd("a_remote_url_as_given.txt").strip(), b, dest, rd("d_exitcode.txt").strip(), kind, (frm[0] if frm else "")[:110]))
