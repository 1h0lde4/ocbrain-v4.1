#!/bin/bash
# usage: run_rows.sh ROWSFILE SUMMARYFILE
S=$(cd "$(dirname "$0")/.." && pwd); : > "$2"
while IFS='|' read -r id url ca ea cr er; do
  [ -z "$id" ] && continue
  bash $S/scripts/run_row_ns.sh "$id" "$url" "$ca" "$ea" "$cr" "$er"
  python3 -I $S/scripts/summarize_row.py $S/evidence/rows/$id >> "$2"
  python3 -I -c 'import json,sys; r=json.loads(open(sys.argv[1]).read().splitlines()[-1]); print(r["row"],"|",r["identity"],"| PASS?",r["printed_PASS"],"exit",r["exit"],"|",[x[0] for x in r["servers_contacted"]],"|",r["classification"])' "$2"
done < "$1"
