#!/bin/bash
# usage (run INSIDE `unshare -rn`, via run_row_ns.sh): run_row.sh ROWID URL CANON_AUTH EVIL_AUTH CANON_REPO [EVIL_REPO]
# Brings lo up, starts servers (CANON443 = github.com:443 mapped, EVIL8443 on 127.0.0.1:8443), builds an empty client repo with
# origin=URL, runs the UNMODIFIED block (only T= and H= lines substituted) and records everything.
set -u
S=$(cd "$(dirname "$0")/.." && pwd); ROW=$1; URL=$2; CAUTH=${3:-none}; EAUTH=${4:-none}; CREPO=${5:-decoy}; EREPO=${6:-good}
E=$S/evidence/rows/$ROW; rm -rf "$E"; mkdir -p "$E"
python3 -I -c 'import fcntl,socket,struct; s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); f=struct.unpack("16sH14s",fcntl.ioctl(s,0x8913,struct.pack("16sH14s",b"lo",0,b"")))[1]; fcntl.ioctl(s,0x8914,struct.pack("16sH14s",b"lo",f|1,b""))'
# leak guard: public address must be unreachable in this namespace
python3 -I -c 'import socket;s=socket.socket();s.settimeout(2);s.connect(("1.1.1.1",443))' 2>/dev/null && { echo "LEAK: 1.1.1.1 reachable; abort" > "$E/ABORT"; exit 99; }
GT=$(sed -n 's/.* T=\([0-9a-f]*\) .*/\1/p' $S/work/srv/hashes_good.txt); GH=$(sed -n 's/.* H=\([0-9a-f]*\) .*/\1/p' $S/work/srv/hashes_good.txt)
DT=$(sed -n 's/.* T=\([0-9a-f]*\) .*/\1/p' $S/work/srv/hashes_decoy.txt); DH=$(sed -n 's/.* H=\([0-9a-f]*\) .*/\1/p' $S/work/srv/hashes_decoy.txt)
python3 -I $S/scripts/tlsgit_server.py --cert $S/work/tls/cert.pem --key $S/work/tls/key.pem --root $S/work/srv --log "$E/server_requests.jsonl" \
  --listen "CANON443:127.0.0.1:443:$CREPO.git:$CAUTH" --listen "EVIL8443:127.0.0.1:8443:$EREPO.git:$EAUTH" > "$E/server_stdout.txt" 2>&1 &
SP=$!
for i in $(seq 1 50); do grep -q 'listening EVIL8443' "$E/server_stdout.txt" 2>/dev/null && break; sleep 0.1; done
# block copy: ONLY T= (line 6) and H= (line 7) substituted
BLK=$S/pkg/review_package/rev3/verify_block_rev3.sh
sed -e "6s/^T=[0-9a-f]\{40\}/T=$GT/" -e "7s/^H=[0-9a-f]\{40\}/H=$GH/" $BLK > "$E/block_under_test.sh"
{ diff <(cat $BLK) "$E/block_under_test.sh" | grep '^[<>]' | cut -c1-60; echo "diff-lines-changed: $(diff $BLK $E/block_under_test.sh | grep -c '^[<>]') (expect 4: lines 6,7 old+new)"; } > "$E/block_diff.txt"
# client: empty repo (no objects) with origin = crafted URL
C=$E/client; rm -rf $C; mkdir -p $C
CLEAN=(env -i PATH=/usr/bin:/bin:/usr/local/bin HOME=$E LANG=C GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null GIT_TERMINAL_PROMPT=0
  GIT_AUTHOR_NAME=a GIT_AUTHOR_EMAIL=a@example.invalid GIT_COMMITTER_NAME=a GIT_COMMITTER_EMAIL=a@example.invalid
  NO_PROXY=127.0.0.1,github.com,evil.example no_proxy=127.0.0.1,github.com,evil.example
  GIT_SSL_CAINFO=$S/work/tls/cert.pem GIT_CONFIG_COUNT=3
  GIT_CONFIG_KEY_0=http.curloptResolve GIT_CONFIG_VALUE_0=github.com:443:127.0.0.1
  GIT_CONFIG_KEY_1=http.curloptResolve GIT_CONFIG_VALUE_1=github.com:8443:127.0.0.1
  GIT_CONFIG_KEY_2=http.curloptResolve GIT_CONFIG_VALUE_2=evil.example:8443:127.0.0.1)
( cd $C && "${CLEAN[@]}" git init -q . && "${CLEAN[@]}" git remote add origin "$URL" ) > "$E/setup.txt" 2>&1
printf '%s\n' "$URL" > "$E/a_remote_url_as_given.txt"
( cd $C && "${CLEAN[@]}" git remote get-url origin ) > "$E/a_remote_url_as_stored.txt" 2>&1
cmp -s "$E/a_remote_url_as_given.txt" "$E/a_remote_url_as_stored.txt" && echo "roundtrip: IDENTICAL" > "$E/a_roundtrip.txt" || echo "roundtrip: DIFFERENT" > "$E/a_roundtrip.txt"
# (b) block's own normalisation (line 15) and identity test (line 16 condition) in a harness; URL from git remote get-url
{ echo 'CANON=https://github.com/1h0lde4/ocbrain-v4.1'; echo "URL=\$(cd $C && ${CLEAN[*]} git remote get-url origin 2>/dev/null)"; sed -n 15p $BLK
  echo 'printf "parsed_url=%s\n" "$URL"'
  echo '[ "${URL%.git}" = "$CANON" ] && echo "identity_check=ACCEPT" || echo "identity_check=REJECT"'; } > "$E/b_norm_harness.sh"
bash "$E/b_norm_harness.sh" > "$E/b_normalisation_result.txt" 2>&1
# main run: unmodified block, stdout/stderr separate
( cd $C && "${CLEAN[@]}" bash "$E/block_under_test.sh" > "$E/d_stdout.txt" 2> "$E/d_stderr.txt"; echo $? > "$E/d_exitcode.txt" )
cat "$E/d_stdout.txt" "$E/d_stderr.txt" > "$E/d_combined_out_then_err.txt"
wc -l < "$E/server_requests.jsonl" > "$E/c_run1_log_lines.txt" 2>/dev/null || echo 0 > "$E/c_run1_log_lines.txt"
# second run, interleaved (2>&1), for ordering of messages
( cd $C && "${CLEAN[@]}" bash "$E/block_under_test.sh" > "$E/d_interleaved_2to1.txt" 2>&1; echo $? > "$E/d_exitcode_run2.txt" )
kill $SP 2>/dev/null; wait $SP 2>/dev/null
exit 0
