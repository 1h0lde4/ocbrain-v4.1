#!/bin/bash
# builds bare repos good.git (T -> H -> F1, F1 changes handoff.md alone) and decoy.git (different history, same branch)
set -e
D=${1:?dir}; BR=docs/g4-fts-errata-handoff-oct2026
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null
export GIT_AUTHOR_NAME=a GIT_AUTHOR_EMAIL=a@example.invalid GIT_COMMITTER_NAME=a GIT_COMMITTER_EMAIL=a@example.invalid
rm -rf "$D"; mkdir -p "$D"; cd "$D"
mk() { # $1 = name, $2 = seed
  local w=work_$1; git init -q -b "$BR" "$w"; cd "$w"
  export GIT_AUTHOR_DATE="2026-10-23T10:00:00Z" GIT_COMMITTER_DATE="2026-10-23T10:00:00Z"
  echo "transfer $2" > src.txt; git add src.txt; git commit -q -m "T transfer $2"; T=$(git rev-parse HEAD)
  export GIT_AUTHOR_DATE="2026-10-23T10:01:00Z" GIT_COMMITTER_DATE="2026-10-23T10:01:00Z"
  echo "handoff $2" > handoff.md; git add handoff.md; git commit -q -m "H handoff $2"; H=$(git rev-parse HEAD)
  export GIT_AUTHOR_DATE="2026-10-23T10:02:00Z" GIT_COMMITTER_DATE="2026-10-23T10:02:00Z"
  echo "followup $2" >> handoff.md; git add handoff.md; git commit -q -m "F1 followup $2"
  cd ..; git clone -q --bare "$w" "$1.git"; echo "$1 T=$T H=$H TIP=$(git -C $1.git rev-parse $BR)"
}
mk good good | tee hashes_good.txt
mk decoy decoy | tee hashes_decoy.txt
