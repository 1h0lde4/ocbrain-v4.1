#!/usr/bin/env python3
"""scan every row dir given: where do DUMMYTOKEN / URL-like strings appear in stdout, stderr, interleaved run"""
import os, sys, re, json
base = sys.argv[1]
for row in sys.argv[2:]:
    d = os.path.join(base, row)
    rd = lambda n: open(os.path.join(d, n), errors="replace").read() if os.path.exists(os.path.join(d, n)) else ""
    print("=== %s\n  url: %s\n  exit: %s | printed PASS: %s" % (row, rd("a_remote_url_as_given.txt").strip(), rd("d_exitcode.txt").strip(), any(l.startswith("PASS") for l in rd("d_stdout.txt").splitlines())))
    for name in ("d_stdout.txt", "d_stderr.txt", "d_interleaved_2to1.txt"):
        t = rd(name); tok = [l for l in t.splitlines() if "DUMMYTOKEN" in l]; url = [l for l in t.splitlines() if re.search(r"https?://|github\.com|127\.0\.0\.1", l)]
        print("  %-24s lines=%d token_lines=%d url_lines=%d" % (name, len(t.splitlines()), len(tok), len(url)))
        for l in tok: print("     TOKEN>", l[:230])
        if name == "d_stderr.txt":
            for l in url:
                if "DUMMYTOKEN" not in l: print("     URL  >", l[:230])
    # block's own stdout lines (FAIL/PASS) shown for the record
    for l in rd("d_stdout.txt").splitlines():
        if l.startswith(("FAIL","PASS","TRANSFER")): print("     out :", l[:140])
