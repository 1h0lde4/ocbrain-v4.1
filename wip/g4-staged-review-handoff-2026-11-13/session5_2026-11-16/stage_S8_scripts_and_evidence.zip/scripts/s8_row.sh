#!/bin/bash
# S8 own driver. Run INSIDE `unshare -rn` via s8_row_ns.sh.
# usage: s8_row.sh ROW URL CAUTH EAUTH CREPO EREPO [BLOCKFILE]
#  CANON443  = 127.0.0.1:443  (github.com mapped)  serves CREPO with CAUTH
#  EVIL8443  = 127.0.0.1:8443 (also evil.example:8443) serves EREPO with EAUTH
#  EVIL18443 = 127.0.0.1:18443 serves EREPO with EAUTH
#  EVIL443B  = 127.0.0.2:443  (evil.example:443 mapped) serves EREPO with EAUTH
#  plain http 401 server on 127.0.0.1:18401 (log: http401.jsonl); dead ports: 127.0.0.1:1
# Each row: fresh client A (stdout+stderr interleaved to ONE file), fresh client B (separate streams), fresh client C (bash -x with LINENO trace, interleaved).
set -u
S=$(cd "$(dirname "$0")/.." && pwd); ROW=$1; URL=$2; CAUTH=${3:-none}; EAUTH=${4:-none}; CREPO=${5:-decoy}; EREPO=${6:-good}
BLK_SRC=${7:-$S/pkg/review_package/rev3/verify_block_rev3.sh}
E=$S/evidence/rows/$ROW; rm -rf "$E"; mkdir -p "$E"
python3 -I -c 'import fcntl,socket,struct; s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); f=struct.unpack("16sH14s",fcntl.ioctl(s,0x8913,struct.pack("16sH14s",b"lo",0,b"")))[1]; fcntl.ioctl(s,0x8914,struct.pack("16sH14s",b"lo",f|1,b""))'
python3 -I -c 'import socket;s=socket.socket();s.settimeout(2);s.connect(("1.1.1.1",443))' 2>/dev/null && { echo "LEAK: 1.1.1.1 reachable; abort" > "$E/ABORT"; exit 99; }
GT=$(sed -n 's/.* T=\([0-9a-f]*\) .*/\1/p' $S/work/srv/hashes_good.txt); GH=$(sed -n 's/.* H=\([0-9a-f]*\) .*/\1/p' $S/work/srv/hashes_good.txt)
python3 -I $S/scripts/s3copy/tlsgit_server.py --cert $S/work/tls/cert.pem --key $S/work/tls/key.pem --root $S/work/srv --log "$E/server_requests.jsonl" \
  --listen "CANON443:127.0.0.1:443:$CREPO.git:$CAUTH" --listen "EVIL8443:127.0.0.1:8443:$EREPO.git:$EAUTH" \
  --listen "EVIL18443:127.0.0.1:18443:$EREPO.git:$EAUTH" --listen "EVIL443B:127.0.0.2:443:$EREPO.git:$EAUTH" > "$E/server_stdout.txt" 2>&1 &
SP=$!
python3 -I $S/scripts/http401.py 18401 "$E/http401.jsonl" > "$E/http401_stdout.txt" 2>&1 &
HP=$!
for i in $(seq 1 60); do grep -q 'listening EVIL443B' "$E/server_stdout.txt" 2>/dev/null && break; sleep 0.1; done
sleep 0.3
sed -e "6s/^T=[0-9a-f]\{40\}/T=$GT/" -e "7s/^H=[0-9a-f]\{40\}/H=$GH/" "$BLK_SRC" > "$E/block_under_test.sh"
{ diff "$BLK_SRC" "$E/block_under_test.sh" | grep '^[<>]' | cut -c1-70; echo "changed-lines: $(diff "$BLK_SRC" "$E/block_under_test.sh" | grep -c '^[<>]') (4 = lines 6 and 7 old+new only)"; } > "$E/block_diff.txt"
printf '%s\n' "$URL" > "$E/url_as_given.txt"
CLEAN=(env -i PATH=/usr/bin:/bin:/usr/local/bin HOME=$E LANG=C GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null GIT_TERMINAL_PROMPT=0
  GIT_AUTHOR_NAME=a GIT_AUTHOR_EMAIL=a@example.invalid GIT_COMMITTER_NAME=a GIT_COMMITTER_EMAIL=a@example.invalid
  NO_PROXY=127.0.0.1,127.0.0.2,github.com,evil.example no_proxy=127.0.0.1,127.0.0.2,github.com,evil.example
  GIT_SSL_CAINFO=$S/work/tls/cert.pem GIT_CONFIG_COUNT=4
  GIT_CONFIG_KEY_0=http.curloptResolve GIT_CONFIG_VALUE_0=github.com:443:127.0.0.1
  GIT_CONFIG_KEY_1=http.curloptResolve GIT_CONFIG_VALUE_1=github.com:8443:127.0.0.1
  GIT_CONFIG_KEY_2=http.curloptResolve GIT_CONFIG_VALUE_2=evil.example:8443:127.0.0.1
  GIT_CONFIG_KEY_3=http.curloptResolve GIT_CONFIG_VALUE_3=evil.example:443:127.0.0.2)
mkclient() { local c=$E/$1; rm -rf "$c"; mkdir -p "$c"; ( cd "$c" && "${CLEAN[@]}" git init -q . && "${CLEAN[@]}" git remote add origin "$URL" ) >> "$E/setup.txt" 2>&1; }
n() { wc -l < "$E/server_requests.jsonl" 2>/dev/null || echo 0; }
mkclient clientA; mkclient clientB; mkclient clientC
n0=$(n)
( cd $E/clientA && "${CLEAN[@]}" bash "$E/block_under_test.sh" > "$E/A_interleaved.txt" 2>&1; echo $? > "$E/A_exit.txt" )
n1=$(n)
( cd $E/clientB && "${CLEAN[@]}" bash "$E/block_under_test.sh" > "$E/B_stdout.txt" 2> "$E/B_stderr.txt"; echo $? > "$E/B_exit.txt" )
n2=$(n)
( cd $E/clientC && "${CLEAN[@]}" env PS4='+L${LINENO}> ' bash -x "$E/block_under_test.sh" > "$E/C_xtrace_interleaved.txt" 2>&1; echo $? > "$E/C_exit.txt" )
n3=$(n)
echo "requests: runA=$((n1-n0)) runB=$((n2-n1)) runC=$((n3-n2))" > "$E/request_counts.txt"
( cd $E/clientA && "${CLEAN[@]}" git remote get-url origin ) > "$E/url_as_stored.txt" 2>&1
kill $SP $HP 2>/dev/null; wait $SP $HP 2>/dev/null
exit 0
