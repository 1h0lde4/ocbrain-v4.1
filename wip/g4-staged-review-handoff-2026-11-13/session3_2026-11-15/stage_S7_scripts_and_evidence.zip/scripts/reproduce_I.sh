#!/usr/bin/env bash
# Reproduce S7 / item I from scratch. usage: bash reproduce_I.sh WORKDIR   (WORKDIR must be new/empty)
set -euo pipefail
W="$1"; Z=/tmp/claude-0/-home-claude/3adcc49e-2c16-5b57-97ab-65b038335fc4/scratchpad/a9/package/g4_rev3_independent_review_package.zip
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$W"/{zipcopy,pkg,work,evidence}
cp "$Z" "$W/zipcopy/pkg.zip"
echo "391eb0a06784153af4591d6bbfdc0af87edce0f17dd2e2aae0a7593794ce2286  $W/zipcopy/pkg.zip" | sha256sum -c -
( cd "$W/pkg" && unzip -q ../zipcopy/pkg.zip && cd review_package && sha256sum -c SHA256SUMS.txt )
P="$W/pkg/review_package/optional_item_I"
cp "$P/check_addendum4.py" "$W/work/check_addendum4.py"
cp "$P"/CONSOLIDATED_EVIDENCE_REPORT_ADDENDUM_4_*.md "$W/work/addendum_base.md"
cp "$W/pkg/review_package/rev3/P1d_rev3_handoff_section7_18_verification_block_PROPOSED.patch" "$W/work/rev3.patch"
cp "$W/pkg/review_package/rev2/verify_block.sh" "$W/work/rev2_stub.txt"
mkdir -p "$W/work/dummy_ev" "$W/work/dummy_repo"; echo notazip > "$W/work/dummy_bundle.bin"
# derived instrument: lines 1-44 of the checker verbatim + 2 appended lines
head -n 44 "$W/work/check_addendum4.py" > "$W/work/front_gates.py"
printf 'print("FRONT-GATES RESULT:", "ok" if ok else "FAILURES")\nsys.exit(0 if ok else 1)\n' >> "$W/work/front_gates.py"
head -n 44 "$W/work/check_addendum4.py" | cmp - <(head -n 44 "$W/work/front_gates.py") && echo "front_gates.py lines 1-44 byte-identical to the checker copy"
python3 "$HERE/run_variants_I.py" "$W"
