STAGE S7: COMPLETE
SUBSTANTIVE FINDINGS: yes (item I only; three findings, all FALSE PASS of check_addendum4.py; no credential or URL output observed; the REV3 block was not exercised in this stage)

# REPORT S7 - criterion I (check_addendum4.py and its governing status line)

Date: 2026-11-14 (UTC). Reviewer: Claude (model "Sonnet 5.5", id claude-sonnet-5-5) sub-agent, independent context, same model family as the author, not a human.

## 1. Package integrity
- Zip full SHA-256 computed on the original and on my copy: 391eb0a06784153af4591d6bbfdc0af87edce0f17dd2e2aae0a7593794ce2286 = the authoritative value (full-value compare). Original not modified (copied to stage_S7/zipcopy/pkg.zip, extracted to stage_S7/pkg/).
- SHA256SUMS.txt inside the package: all 7 listed files OK. Files used: optional_item_I/check_addendum4.py (sha256 60d59bf53f63a39d6a37081b3d8b9e13fd0abe2ea32ced15ced5f63b6953a308), the addendum report in the same folder (sha256 d619b7c87b4b3d242adc6922bbaa9fb770ad7025196db5b45a162c476fa637f8); copies in my work directory are byte-identical.

## 2. Acceptance condition for item I (as I read it)
Brief item I: judge, by reading and by testing mutated copies, whether check_addendum4.py "rejects incorrect statuses (for example 'G4 CLOSED'), ambiguous statements and duplicate or conflicting status lines elsewhere in the text", and report what it does not catch. Task prompt: a false PASS (the checker accepts a document whose governing status line `G4 OPEN · High · freeze-blocking. G5–G8 HELD. Freeze readiness NOT DECLARED.` is missing, altered or contradicted) is substantive. Status-relevant code: S1 = line 24-25 (last non-empty line == the status string, exact); S2 = line 26 (`"**Governing statuses, unchanged:** " + status in txt`, substring anywhere); gate table = lines 27-42 (first table only; allowed words PASS/FAIL/BLOCKED/NOT RUN; one Overall row; Overall PASS iff all gates PASS; Overall row contains SELF-REVIEW ONLY); needles = lines 43-44 (bare substring presence of F7..F12, OPEN, "not VERIFIED", "not done").

## 3. Method and its limits (stated plainly)
- The checker takes 11 arguments, including an evidence directory, a git repository, a bundle zip and other files that are not in the package. The unmodified checker therefore cannot run to a PASS exit here: with dummy arguments it prints its early output, then dies at line 69 (zipfile) - exit 1 for every row, the unmodified baseline included (88 of 90 rows end in BadZipFile at line 69; two rows crash earlier, see minor findings). The exit status of the full run cannot discriminate between variants. NOT RUN: the checker's tail (lines 45-167, incl. the live `git ls-remote` at lines 161-164, which I did not execute).
- Instruments (both run with `python3 -I`, proxies unset, GIT_CONFIG_GLOBAL/SYSTEM=/dev/null; no network, none needed): (FULL) the unmodified copy with dummy arguments; (GATES) `front_gates.py` = lines 1-44 of the copy verbatim (cmp verified, evidence/front_gates_identity.txt) plus 2 appended lines (print, exit by `ok`). Verdict per row = GATES exit status (0 = checker accepts the status handling, 1 = rejects). The FAIL lines before "ids cited:" in FULL equal the FAIL lines of GATES in 90 of 90 rows. For every FALSE PASS row except T15 the FULL stdout is byte-identical to the baseline FULL stdout (evidence/I_full_vs_baseline.txt), so nothing else reachable in the checker reacted to my mutation. DERIVED (not observed): lines 69-167 do not read the status text beyond `bsha in txt` and `"must not be applied" in txt`, so I expect the complete checker to give the same verdict as GATES; I could not confirm it.
- Expectation per row is my reading of the brief. Rows where the brief does not decide (pure whitespace changes, status text quoted or hidden by markdown structure) are marked "undecided"; they are not counted as substantive.
- 90 variants were built from the addendum copy by one script and run in one loop (scripts/run_variants_I.py); raw output per row in evidence/.

## 4. Criteria table
| Criterion | Status | Evidence | Reasoning |
|---|---|---|---|
| I - how check_addendum4.py handles the governing status line, and robustness against the weaknesses named in the brief | **FAIL** | evidence/I_summary.tsv, I_summary_table.md, <ID>.out/.rc; findings I-1, I-2, I-3 | All 30 alterations of the governing line or of the last line that the contract says must fail were rejected (one character, dash and dot variants, case, whitespace, tab, NBSP, homoglyph, CLOSED, deletion). But 18 variants with a contradicted, masked or duplicated status were accepted (FALSE PASS): conflicting or ambiguous status statements elsewhere, an altered governing line hidden by an intact copy in a code fence or comment, and conflicting gate tables. Every required check ran. |

## 5. What the checker catches and does not catch (observed)
Catches (every case rejected): governing line deleted or altered by one word/character/dash/dot/case/space/tab/NBSP/homoglyph/hard line break (S2); last line deleted, altered, followed by other text, zero-width-space line, tab/homoglyph/zero-width variant (S1); gate table absent, unknown or lower-case status words, Overall PASS with a non-PASS gate, Overall not PASS with all gates PASS, missing or duplicate Overall row, missing SELF-REVIEW ONLY, status only in a heading with no table.
Does not catch (observed FALSE PASS): see section 7. It tests that the required text is present once or more somewhere; it never tests that nothing else in the document contradicts it, that it is the only governing line, or that it is a live statement rather than quoted, fenced, commented or struck-through text. Only the first gate table is read.

