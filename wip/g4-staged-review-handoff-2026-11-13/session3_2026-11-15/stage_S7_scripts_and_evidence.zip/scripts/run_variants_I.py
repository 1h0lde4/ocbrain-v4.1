#!/usr/bin/env python3
"""Item I harness (stage S7). Builds variants of the Addendum-4 text, runs COPIES of check_addendum4.py on them.
Everything runs under W (own directory). No network. usage: python3 run_variants_I.py W
Two instruments per row:
  FULL  = unmodified copy of check_addendum4.py with dummy args (dies at line 69: needs files that are not in the package)
  GATES = front_gates.py = lines 1-44 of that copy verbatim + 2 appended lines (exit status = `ok`)
"""
import os, sys, re, subprocess, shutil
W = sys.argv[1]
WORK = f"{W}/work"; VD = f"{WORK}/variants"; EV = f"{W}/evidence"
os.makedirs(VD, exist_ok=True); os.makedirs(EV, exist_ok=True)
base = open(f"{WORK}/addendum_base.md", "rb").read().decode("utf-8")

WANT = "G4 OPEN · High · freeze-blocking. G5–G8 HELD. Freeze readiness NOT DECLARED."
PRE = "**Governing statuses, unchanged:** "
GOV = PRE + WANT + " No implementation authorized. This addendum changes no repository, no pull request and no decision item."
assert GOV in base and base.rstrip("\n").endswith("\n" + WANT) and base.count(GOV) == 1
HDR = "| Gate | Status | Evidence | Reason |"
G2 = "| F9, F10, F11 reproduced against revision 2 | **PASS** | I60, I61 | s12, s13, s14 give PASS where FAIL is required |"
OV = "| **Overall result (this addendum's scope)** | **PASS** | | **SELF-REVIEW ONLY** for the revision 3 text; qualified by the open findings below and the limits in section 8 |"
L7 = "7. **Statuses unchanged:** G4 OPEN · High · freeze-blocking; G5–G8 HELD; freeze readiness NOT DECLARED; D-1…D-11 OPEN; no implementation authorized."
F7 = "| F7 (Addendum 2) | **OPEN** |"
for s in (HDR, G2, OV, L7, F7):
    assert base.count(s) == 1, s

def one(t, old, new):
    assert t.count(old) == 1, old
    return t.replace(old, new)
def noreq(t):  # drop last line
    assert t.endswith(WANT + "\n"); return t[: -len(WANT) - 1]

V = []  # (id, group, expected PASS|FAIL|UNDEC, description, mutator)
def add(i, g, e, d, f): V.append((i, g, e, d, f))

add("B00", "base", "PASS", "unmodified addendum", lambda t: t)
# ---- A: governing line GOV (line 5) altered or absent, last line intact
add("A01", "gov", "FAIL", "GOV line deleted (last line intact)", lambda t: one(t, GOV + "\n\n", ""))
add("A02", "gov", "FAIL", "GOV: G4 OPEN -> G4 CLOSED", lambda t: one(t, GOV, GOV.replace("G4 OPEN", "G4 CLOSED")))
add("A03", "gov", "FAIL", "GOV: High -> Low", lambda t: one(t, GOV, GOV.replace("· High ·", "· Low ·")))
add("A04", "gov", "FAIL", "GOV: freeze-blocking -> not freeze-blocking", lambda t: one(t, GOV, GOV.replace("· freeze-blocking.", "· not freeze-blocking.")))
add("A05", "gov", "FAIL", "GOV: NOT DECLARED -> DECLARED", lambda t: one(t, GOV, GOV.replace("NOT DECLARED.", "DECLARED.")))
add("A06", "gov", "FAIL", "GOV: HELD -> RELEASED", lambda t: one(t, GOV, GOV.replace("HELD.", "RELEASED.")))
add("A07", "gov", "FAIL", "GOV: Cyrillic O (U+041E) in OPEN", lambda t: one(t, GOV, GOV.replace("OPEN", "ОPEN")))
add("A08", "gov", "FAIL", "GOV: hyphen in freeze-blocking -> U+2011", lambda t: one(t, GOV, GOV.replace("freeze-blocking", "freeze‑blocking")))
add("A09", "gov", "FAIL", "GOV: freeze-blocking -> 'freeze blocking'", lambda t: one(t, GOV, GOV.replace("freeze-blocking", "freeze blocking")))
add("A10", "gov", "FAIL", "GOV: middle dots -> U+2022 bullet", lambda t: one(t, GOV, GOV.replace("·", "•")))
add("A11", "gov", "FAIL", "GOV: middle dots -> U+22C5 dot operator", lambda t: one(t, GOV, GOV.replace("·", "⋅")))
add("A12", "gov", "FAIL", "GOV: middle dots -> ASCII hyphen", lambda t: one(t, GOV, GOV.replace("·", "-")))
add("A13", "gov", "FAIL", "GOV: en dash -> hyphen-minus (G5-G8)", lambda t: one(t, GOV, GOV.replace("G5–G8", "G5-G8")))
add("A14", "gov", "FAIL", "GOV: en dash -> em dash", lambda t: one(t, GOV, GOV.replace("G5–G8", "G5—G8")))
add("A15", "gov", "FAIL", "GOV: en dash -> U+2212 minus", lambda t: one(t, GOV, GOV.replace("G5–G8", "G5−G8")))
add("A16", "gov", "FAIL", "GOV: all lower case", lambda t: one(t, GOV, PRE + WANT.lower() + GOV[len(PRE + WANT):]))
add("A17", "gov", "FAIL", "GOV: 'Freeze Readiness' capital R", lambda t: one(t, GOV, GOV.replace("Freeze readiness", "Freeze Readiness")))
add("A18", "gov", "FAIL", "GOV: double space after OPEN", lambda t: one(t, GOV, GOV.replace("G4 OPEN ·", "G4 OPEN  ·")))
add("A19", "gov", "FAIL", "GOV: NBSP (U+00A0) instead of space in 'Freeze readiness'", lambda t: one(t, GOV, GOV.replace("Freeze readiness", "Freeze readiness")))
add("A20", "gov", "FAIL", "GOV: two spaces after the bold prefix", lambda t: one(t, GOV, GOV.replace("unchanged:** G4", "unchanged:**  G4")))
add("A21", "gov", "UNDEC", "GOV: status hard-wrapped (newline after 'freeze-blocking.')", lambda t: one(t, GOV, GOV.replace("freeze-blocking. G5", "freeze-blocking.\nG5")))
add("A22", "gov", "PASS", "GOV: two spaces after final period of the status (before 'No implementation')", lambda t: one(t, GOV, GOV.replace("DECLARED. No", "DECLARED.  No")))
add("A23", "gov", "FAIL", "GOV: prefix 'Governing status, unchanged:' (singular)", lambda t: one(t, GOV, GOV.replace("Governing statuses,", "Governing status,")))
add("A24", "gov", "UNDEC", "GOV: prefix without bold markers", lambda t: one(t, GOV, GOV.replace("**Governing statuses, unchanged:**", "Governing statuses, unchanged:")))
add("A25", "gov", "FAIL", "GOV: all wrong (G4 CLOSED / Low / not freeze-blocking / RELEASED / DECLARED)", lambda t: one(t, GOV, PRE + "G4 CLOSED · Low · not freeze-blocking. G5–G8 RELEASED. Freeze readiness DECLARED. No implementation authorized."))
# ---- L: last line
add("L01", "last", "FAIL", "last line deleted", noreq)
add("L02", "last", "FAIL", "last line: G4 CLOSED", lambda t: noreq(t) + WANT.replace("G4 OPEN", "G4 CLOSED") + "\n")
add("L03", "last", "UNDEC", "last line + trailing space", lambda t: noreq(t) + WANT + " \n")
add("L04", "last", "UNDEC", "last line with leading space", lambda t: noreq(t) + " " + WANT + "\n")
add("L05", "last", "PASS", "CRLF line endings throughout", lambda t: t.replace("\n", "\r\n"))
add("L06", "last", "PASS", "CRLF on the last line only", lambda t: noreq(t) + WANT + "\r\n")
add("L07", "last", "FAIL", "extra non-empty line 'G4 CLOSED.' after the last line", lambda t: t + "G4 CLOSED.\n")
add("L08", "last", "PASS", "blank and whitespace-only lines after the last line", lambda t: t + "\n\n   \t\n\n")
add("L09", "last", "FAIL", "zero-width-space-only line after the last line", lambda t: t + "​\n")
add("L10", "last", "UNDEC", "form feed (U+000C) appended to the last line", lambda t: noreq(t) + WANT + "\x0c")
add("L11", "last", "PASS", "no newline at end of file", lambda t: t.rstrip("\n"))
add("L12", "last", "FAIL", "empty file", lambda t: "")
add("L13", "last", "PASS", "last line duplicated (two identical final lines)", lambda t: t + WANT + "\n")
add("L14", "last", "UNDEC", "last line inside an unclosed code fence (``` before it)", lambda t: noreq(t) + "```\n" + WANT + "\n")
add("L15", "last", "UNDEC", "last line inside an unclosed HTML comment (<!-- before it)", lambda t: noreq(t) + "<!--\n" + WANT + "\n")
add("L16", "last", "UNDEC", "last line as a blockquote ('> ' prefix)", lambda t: noreq(t) + "> " + WANT + "\n")
add("L17", "last", "PASS", "UTF-8 BOM at start of file", lambda t: "﻿" + t)
add("L18", "last", "FAIL", "last line: Cyrillic O in OPEN", lambda t: noreq(t) + WANT.replace("OPEN", "ОPEN") + "\n")
add("L19", "last", "FAIL", "last line: zero-width space inside", lambda t: noreq(t) + WANT.replace("NOT DECLARED", "NOT​ DECLARED") + "\n")
add("L20", "last", "UNDEC", "last line + trailing NBSP", lambda t: noreq(t) + WANT + " \n")
add("A26", "gov", "FAIL", "GOV: tab instead of space in 'G5–G8 HELD'", lambda t: one(t, GOV, GOV.replace("G5–G8 HELD", "G5–G8\tHELD")))
add("L21", "last", "UNDEC", "last line hard-wrapped over two lines", lambda t: noreq(t) + WANT.replace("blocking. G5", "blocking.\nG5") + "\n")
add("L22", "last", "FAIL", "last line: tab instead of space", lambda t: noreq(t) + WANT.replace("Freeze readiness", "Freeze\treadiness") + "\n")
# ---- T: gate table
def drop_table(t):
    s = t.index(HDR); e = t.index(OV) + len(OV) + 1
    return t[:s] + t[e:]
add("T01", "gate", "FAIL", "gate table deleted", drop_table)
add("T02", "gate", "FAIL", "gate table header renamed to '| Gate | Result |'", lambda t: one(t, HDR, "| Gate | Result | Evidence | Reason |"))
add("T03", "gate", "FAIL", "a gate status 'PASSED'", lambda t: one(t, G2, G2.replace("**PASS**", "**PASSED**")))
add("T04", "gate", "FAIL", "a gate status 'Pass'", lambda t: one(t, G2, G2.replace("**PASS**", "**Pass**")))
add("T05", "gate", "FAIL", "one gate FAIL, overall PASS", lambda t: one(t, G2, G2.replace("**PASS**", "**FAIL**")))
add("T06", "gate", "PASS", "one gate FAIL, overall FAIL with SELF-REVIEW ONLY (internally consistent)", lambda t: one(one(t, G2, G2.replace("**PASS**", "**FAIL**")), OV, OV.replace("**PASS**", "**FAIL**")))
add("T07", "gate", "FAIL", "overall row without 'SELF-REVIEW ONLY'", lambda t: one(t, OV, OV.replace("**SELF-REVIEW ONLY**", "**independently reviewed**")))
add("T08", "gate", "FAIL", "overall row removed", lambda t: one(t, OV + "\n", ""))
add("T09", "gate", "FAIL", "two overall rows", lambda t: one(t, OV, OV + "\n" + OV))
add("T10", "gate", "FAIL", "all gates PASS, overall FAIL", lambda t: one(t, OV, OV.replace("**PASS**", "**FAIL**")))
add("T11", "gate", "FAIL", "overall status 'PASS (provisional)'", lambda t: one(t, OV, OV.replace("**PASS**", "**PASS (provisional)**")))
def head_only(t):
    return drop_table(t) + "\n### Overall: PASS\n" if False else one(drop_table(t), "Not part of this scope and **not done:**", "### Overall: PASS\n\nNot part of this scope and **not done:**")
add("T12", "gate", "FAIL", "table removed, status only in a level-3 heading '### Overall: PASS'", head_only)
SECOND = "\n\nSecond table:\n\n| Gate | Status | Evidence | Reason |\n|---|---|---|---|\n| Decoy gate | **FAIL** | x | y |\n| **Overall result** | **PASS** | | **SELF-REVIEW ONLY** |"
add("T13", "gate", "FAIL", "second gate table (gate FAIL, overall PASS) after the real one", lambda t: one(t, OV, OV + SECOND))
add("T14", "gate", "FAIL", "orphan row '| Late gate | **FAIL** |' after a blank line below the table", lambda t: one(t, OV, OV + "\n\n| Late gate | **FAIL** | x | y |"))
def decoy_first(t):
    t2 = one(t, G2, G2.replace("**PASS**", "**FAIL**"))  # real table now inconsistent (FAIL gate, overall PASS)
    decoy = "```\n" + HDR + "\n|---|---|---|---|\n| Decoy | **PASS** | | |\n| **Overall result** | **PASS** | | **SELF-REVIEW ONLY** |\n```\n\n"
    return one(t2, HDR, decoy + HDR)
add("T15", "gate", "FAIL", "fenced all-PASS decoy table first; real table inconsistent (FAIL gate, overall PASS)", decoy_first)
add("T16", "gate", "PASS", "separator row with alignment colons |:---|:---:|", lambda t: one(t, HDR + "\n|---|---|---|---|", HDR + "\n|:---|:---:|---|---|"))
add("T17", "gate", "UNDEC", "overall row indented by one space", lambda t: one(t, OV, " " + OV))
add("T18", "gate", "FAIL", "gate row named 'overall ...' lower-case replaced; no 'Overall' row left", lambda t: one(t, "| **Overall result (this addendum's scope)** |", "| **overall result (this addendum's scope)** |"))
add("T19", "gate", "UNDEC", "malformed one-cell row '| stray |' directly after the overall row", lambda t: one(t, OV, OV + "\n| stray |"))
# ---- C: conflicting / duplicate / ambiguous statements elsewhere (GOV and last line intact)
add("C01", "conflict", "FAIL", "body sentence 'G4 CLOSED.' appended to result item 7", lambda t: one(t, L7, L7 + " G4 CLOSED."))
add("C02", "conflict", "FAIL", "body sentence 'Freeze readiness DECLARED.' appended to item 7", lambda t: one(t, L7, L7 + " Freeze readiness DECLARED."))
add("C03", "conflict", "FAIL", "item 7 rewritten: G4 CLOSED / Low / not freeze-blocking / RELEASED / DECLARED", lambda t: one(t, L7, "7. **Statuses unchanged:** G4 CLOSED · Low · not freeze-blocking; G5–G8 RELEASED; freeze readiness DECLARED; no implementation authorized."))
CONF = "**Governing statuses, unchanged:** G4 CLOSED · Low · not freeze-blocking. G5–G8 RELEASED. Freeze readiness DECLARED."
add("C04", "conflict", "FAIL", "second, conflicting governing line inserted after the real one", lambda t: one(t, GOV, GOV + "\n\n" + CONF))
add("C05", "conflict", "FAIL", "second, conflicting governing line inserted before the real one", lambda t: one(t, GOV, CONF + "\n\n" + GOV))
add("C06", "conflict", "FAIL", "conflicting status as a blockquote after the real line", lambda t: one(t, GOV, GOV + "\n\n> G4 CLOSED. Freeze readiness DECLARED."))
add("C07", "conflict", "FAIL", "conflicting status as a level-3 heading '### G4 CLOSED'", lambda t: one(t, "## 2. What was received", "### G4 CLOSED\n\n## 2. What was received"))
add("C08", "conflict", "FAIL", "conflicting row '| G4 | **CLOSED** |' in the findings table", lambda t: one(t, "| F6 (Addendum 1) | not changed | metadata only |", "| F6 (Addendum 1) | not changed | metadata only |\n| G4 | **CLOSED** | freeze-blocking lifted |"))
add("C09", "conflict", "FAIL", "retraction after the required text on the GOV line itself", lambda t: one(t, GOV, GOV + " UPDATE: G4 is now CLOSED and freeze readiness is DECLARED."))
add("C10", "conflict", "FAIL", "'Retracted: ' before the GOV line on the same line", lambda t: one(t, GOV, "Retracted: " + GOV))
add("C11", "conflict", "FAIL", "GOV line struck through (~~...~~), conflicting line below it", lambda t: one(t, GOV, "~~" + GOV + "~~\n\n" + CONF))
add("C12", "conflict", "PASS", "identical duplicate of the GOV line elsewhere", lambda t: one(t, "## 2. What was received", GOV + "\n\n## 2. What was received"))
add("C13", "conflict", "UNDEC", "'G4 CLOSED' only inside a fenced code block (quotation)", lambda t: one(t, "## 2. What was received", "```\nG4 CLOSED · Low · not freeze-blocking. Freeze readiness DECLARED.\n```\n\n## 2. What was received"))
add("C14", "conflict", "UNDEC", "adjacent: finding F7 status OPEN -> CLOSED (not the governing line)", lambda t: one(t, F7, "| F7 (Addendum 2) | **CLOSED** |"))
add("C15", "conflict", "FAIL", "ambiguous hedge: 'Whether G4 remains OPEN is undecided; G4 may be CLOSED.'", lambda t: one(t, L7, L7 + " Whether G4 remains OPEN is undecided; G4 may be CLOSED."))
# ---- M: masking (required line present as substring but not as the live governing line)
add("M01", "mask", "FAIL", "line 5 altered to G4 CLOSED; intact required line inside a fenced code block elsewhere", lambda t: one(one(t, GOV, GOV.replace("G4 OPEN", "G4 CLOSED")), "## 2. What was received", "```\n" + GOV + "\n```\n\n## 2. What was received"))
add("M02", "mask", "FAIL", "line 5 altered to G4 CLOSED; intact required line inside an HTML comment elsewhere", lambda t: one(one(t, GOV, GOV.replace("G4 OPEN", "G4 CLOSED")), "## 2. What was received", "<!-- " + GOV + " -->\n\n## 2. What was received"))
add("M03", "mask", "UNDEC", "line 5 deleted; required line only as a blockquote elsewhere", lambda t: one(one(t, GOV + "\n\n", ""), "## 2. What was received", "> " + GOV + "\n\n## 2. What was received"))
add("M04", "mask", "UNDEC", "line 5 deleted; required line only inside a table cell elsewhere", lambda t: one(one(t, GOV + "\n\n", ""), "| F6 (Addendum 1) | not changed | metadata only |", "| F6 (Addendum 1) | not changed | metadata only |\n| " + GOV + " | x |"))
add("M05", "mask", "UNDEC", "line 5 deleted; required line only inside an HTML comment (final line still asserts the status)", lambda t: one(t, GOV, "<!-- " + GOV + " -->"))
add("M06", "mask", "UNDEC", "line 5 deleted; required line only in a level-3 heading", lambda t: one(t, GOV, "### " + GOV))
add("M07", "mask", "FAIL", "line 5 replaced by conflicting line; real required line only inside an HTML comment (no visible status)", lambda t: one(t, GOV, CONF + "\n\n<!-- " + GOV + " -->"))

# ---------------- runner
ENV = {k: v for k, v in os.environ.items() if k.lower() not in ("https_proxy", "http_proxy", "all_proxy")}
ENV.update(GIT_CONFIG_GLOBAL="/dev/null", GIT_CONFIG_SYSTEM="/dev/null", GIT_TERMINAL_PROMPT="0", GIT_CEILING_DIRECTORIES=WORK, NO_PROXY="127.0.0.1")
def run(script, f):
    args = ["python3", "-I", script, f, f"{WORK}/dummy_ev", f"{WORK}/dummy_repo", f"{WORK}/dummy_bundle.bin", f"{WORK}/rev3.patch",
            f"{WORK}/rev2_stub.txt", f"{WORK}/addendum_base.md", f"{WORK}/addendum_base.md", f"{WORK}/addendum_base.md", f"{WORK}/addendum_base.md", f"{WORK}/addendum_base.md"]
    r = subprocess.run(args, capture_output=True, env=ENV, cwd=WORK + "/dummy_repo", timeout=60)
    return r.returncode, r.stdout.decode("utf-8", "replace"), r.stderr.decode("utf-8", "replace")

rows = []
for i, g, e, d, f in V:
    out = f(base); data = out if isinstance(out, bytes) else out.encode("utf-8")
    vf = f"{VD}/{i}.md"; open(vf, "wb").write(data)
    rc_g, o_g, e_g = run(f"{WORK}/front_gates.py", vf)
    rc_f, o_f, e_f = run(f"{WORK}/check_addendum4.py", vf)
    for tag, (rc, o, er) in (("", (rc_g, o_g, e_g)), (".full", (rc_f, o_f, e_f))):
        open(f"{EV}/{i}{tag}.out", "w").write(o); open(f"{EV}/{i}{tag}.err", "w").write(er); open(f"{EV}/{i}{tag}.rc", "w").write(str(rc) + "\n")
    fails_g = [l for l in o_g.splitlines() if l.startswith("FAIL:")]
    pre_f = o_f.split("ids cited:")[0]
    fails_f = [l for l in pre_f.splitlines() if l.startswith("FAIL:")]
    got = "PASS" if rc_g == 0 else "FAIL"
    crash = "Traceback" in e_g
    cons = "yes" if (fails_g == fails_f) else "NO"
    if e == "UNDEC": cls = f"UNDECIDED-by-brief (checker {got})"
    elif got == e: cls = "correct " + got
    elif got == "PASS": cls = "FALSE PASS"
    else: cls = "false FAIL"
    rows.append((i, g, e, got, cls, rc_g, rc_f, cons, "crash" if crash else "", "; ".join(x[6:].strip() for x in fails_g), d))
hdr = ["id", "group", "contract_expected", "checker_front_gates", "classification", "gates_rc", "full_rc", "full_vs_gates_FAIL_lines_equal", "gates_run_crashed", "FAIL_messages", "description"]
with open(f"{EV}/I_summary.tsv", "w") as fo:
    fo.write("\t".join(hdr) + "\n")
    for r in rows: fo.write("\t".join(str(x) for x in r) + "\n")
from collections import Counter
print(Counter(r[4] for r in rows)); print("rows:", len(rows))
