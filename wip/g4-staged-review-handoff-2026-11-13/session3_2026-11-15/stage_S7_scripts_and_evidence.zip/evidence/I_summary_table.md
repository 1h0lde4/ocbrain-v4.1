| ID | Variant (mutation of the addendum text) | Contract expects | Checker | Classification | Check that fired |
|---|---|---|---|---|---|
| B00 | unmodified addendum | PASS | PASS | correct PASS | - |
| A01 | GOV line deleted (last line intact) | FAIL | FAIL | correct FAIL | S2 substring |
| A02 | GOV: G4 OPEN -> G4 CLOSED | FAIL | FAIL | correct FAIL | S2 substring |
| A03 | GOV: High -> Low | FAIL | FAIL | correct FAIL | S2 substring |
| A04 | GOV: freeze-blocking -> not freeze-blocking | FAIL | FAIL | correct FAIL | S2 substring |
| A05 | GOV: NOT DECLARED -> DECLARED | FAIL | FAIL | correct FAIL | S2 substring |
| A06 | GOV: HELD -> RELEASED | FAIL | FAIL | correct FAIL | S2 substring |
| A07 | GOV: Cyrillic O (U+041E) in OPEN | FAIL | FAIL | correct FAIL | S2 substring |
| A08 | GOV: hyphen in freeze-blocking -> U+2011 | FAIL | FAIL | correct FAIL | S2 substring |
| A09 | GOV: freeze-blocking -> 'freeze blocking' | FAIL | FAIL | correct FAIL | S2 substring |
| A10 | GOV: middle dots -> U+2022 bullet | FAIL | FAIL | correct FAIL | S2 substring |
| A11 | GOV: middle dots -> U+22C5 dot operator | FAIL | FAIL | correct FAIL | S2 substring |
| A12 | GOV: middle dots -> ASCII hyphen | FAIL | FAIL | correct FAIL | S2 substring |
| A13 | GOV: en dash -> hyphen-minus (G5-G8) | FAIL | FAIL | correct FAIL | S2 substring |
| A14 | GOV: en dash -> em dash | FAIL | FAIL | correct FAIL | S2 substring |
| A15 | GOV: en dash -> U+2212 minus | FAIL | FAIL | correct FAIL | S2 substring |
| A16 | GOV: all lower case | FAIL | FAIL | correct FAIL | S2 substring |
| A17 | GOV: 'Freeze Readiness' capital R | FAIL | FAIL | correct FAIL | S2 substring |
| A18 | GOV: double space after OPEN | FAIL | FAIL | correct FAIL | S2 substring |
| A19 | GOV: NBSP (U+00A0) instead of space in 'Freeze readiness' | FAIL | FAIL | correct FAIL | S2 substring |
| A20 | GOV: two spaces after the bold prefix | FAIL | FAIL | correct FAIL | S2 substring |
| A21 | GOV: status hard-wrapped (newline after 'freeze-blocking.') | undecided | FAIL | undecided by brief (checker FAIL) | S2 substring |
| A22 | GOV: two spaces after final period of the status (before 'No implementation') | PASS | PASS | correct PASS | - |
| A23 | GOV: prefix 'Governing status, unchanged:' (singular) | FAIL | FAIL | correct FAIL | S2 substring |
| A24 | GOV: prefix without bold markers | undecided | FAIL | undecided by brief (checker FAIL) | S2 substring |
| A25 | GOV: all wrong (G4 CLOSED / Low / not freeze-blocking / RELEASED / DECLARED) | FAIL | FAIL | correct FAIL | S2 substring |
| L01 | last line deleted | FAIL | FAIL | correct FAIL | S1 last line |
| L02 | last line: G4 CLOSED | FAIL | FAIL | correct FAIL | S1 last line |
| L03 | last line + trailing space | undecided | FAIL | undecided by brief (checker FAIL) | S1 last line |
| L04 | last line with leading space | undecided | FAIL | undecided by brief (checker FAIL) | S1 last line |
| L05 | CRLF line endings throughout | PASS | PASS | correct PASS | - |
| L06 | CRLF on the last line only | PASS | PASS | correct PASS | - |
| L07 | extra non-empty line 'G4 CLOSED.' after the last line | FAIL | FAIL | correct FAIL | S1 last line |
| L08 | blank and whitespace-only lines after the last line | PASS | PASS | correct PASS | - |
| L09 | zero-width-space-only line after the last line | FAIL | FAIL | correct FAIL | S1 last line |
| L10 | form feed (U+000C) appended to the last line | undecided | PASS | undecided by brief (checker PASS) | - |
| L11 | no newline at end of file | PASS | PASS | correct PASS | - |
| L12 | empty file | FAIL | FAIL | correct FAIL | headings, then crash |
| L13 | last line duplicated (two identical final lines) | PASS | PASS | correct PASS | - |
| L14 | last line inside an unclosed code fence (``` before it) | undecided | PASS | undecided by brief (checker PASS) | - |
| L15 | last line inside an unclosed HTML comment (<!-- before it) | undecided | PASS | undecided by brief (checker PASS) | - |
| L16 | last line as a blockquote ('> ' prefix) | undecided | FAIL | undecided by brief (checker FAIL) | S1 last line |
| L17 | UTF-8 BOM at start of file | PASS | PASS | correct PASS | - |
| L18 | last line: Cyrillic O in OPEN | FAIL | FAIL | correct FAIL | S1 last line |
| L19 | last line: zero-width space inside | FAIL | FAIL | correct FAIL | S1 last line |
| L20 | last line + trailing NBSP | undecided | FAIL | undecided by brief (checker FAIL) | S1 last line |
| A26 | GOV: tab instead of space in 'G5–G8 HELD' | FAIL | FAIL | correct FAIL | S2 substring |
| L21 | last line hard-wrapped over two lines | undecided | FAIL | undecided by brief (checker FAIL) | S1 last line |
| L22 | last line: tab instead of space | FAIL | FAIL | correct FAIL | S1 last line |
| T01 | gate table deleted | FAIL | FAIL | correct FAIL | gate table |
| T02 | gate table header renamed to 'Gate / Result' | FAIL | FAIL | correct FAIL | gate table |
| T03 | a gate status 'PASSED' | FAIL | FAIL | correct FAIL | gate table |
| T04 | a gate status 'Pass' | FAIL | FAIL | correct FAIL | gate table |
| T05 | one gate FAIL, overall PASS | FAIL | FAIL | correct FAIL | gate table |
| T06 | one gate FAIL, overall FAIL with SELF-REVIEW ONLY (internally consistent) | PASS | PASS | correct PASS | - |
| T07 | overall row without 'SELF-REVIEW ONLY' | FAIL | FAIL | correct FAIL | gate table |
| T08 | overall row removed | FAIL | FAIL | correct FAIL | gate table |
| T09 | two overall rows | FAIL | FAIL | correct FAIL | gate table |
| T10 | all gates PASS, overall FAIL | FAIL | FAIL | correct FAIL | gate table |
| T11 | overall status 'PASS (provisional)' | FAIL | FAIL | correct FAIL | gate table |
| T12 | table removed, status only in a level-3 heading '### Overall: PASS' | FAIL | FAIL | correct FAIL | gate table |
| T13 | second gate table (gate FAIL, overall PASS) after the real one | FAIL | PASS | **FALSE PASS** | - |
| T14 | orphan row 'Late gate FAIL row' after a blank line below the table | FAIL | PASS | **FALSE PASS** | - |
| T15 | fenced all-PASS decoy table first; real table inconsistent (FAIL gate, overall PASS) | FAIL | PASS | **FALSE PASS** | - |
| T16 | separator row with alignment colons (:---, :---:) | PASS | FAIL | false FAIL | gate table |
| T17 | overall row indented by one space | undecided | FAIL | undecided by brief (checker FAIL) | gate table |
| T18 | gate row named 'overall ...' lower-case replaced; no 'Overall' row left | FAIL | FAIL | correct FAIL | gate table |
| T19 | malformed one-cell row 'stray' directly after the overall row | undecided | FAIL | undecided by brief (checker FAIL) | crash (IndexError) |
| C01 | body sentence 'G4 CLOSED.' appended to result item 7 | FAIL | PASS | **FALSE PASS** | - |
| C02 | body sentence 'Freeze readiness DECLARED.' appended to item 7 | FAIL | PASS | **FALSE PASS** | - |
| C03 | item 7 rewritten: G4 CLOSED / Low / not freeze-blocking / RELEASED / DECLARED | FAIL | PASS | **FALSE PASS** | - |
| C04 | second, conflicting governing line inserted after the real one | FAIL | PASS | **FALSE PASS** | - |
| C05 | second, conflicting governing line inserted before the real one | FAIL | PASS | **FALSE PASS** | - |
| C06 | conflicting status as a blockquote after the real line | FAIL | PASS | **FALSE PASS** | - |
| C07 | conflicting status as a level-3 heading '### G4 CLOSED' | FAIL | PASS | **FALSE PASS** | - |
| C08 | conflicting row 'G4 CLOSED' in the findings table | FAIL | PASS | **FALSE PASS** | - |
| C09 | retraction after the required text on the GOV line itself | FAIL | PASS | **FALSE PASS** | - |
| C10 | 'Retracted: ' before the GOV line on the same line | FAIL | PASS | **FALSE PASS** | - |
| C11 | GOV line struck through (~~...~~), conflicting line below it | FAIL | PASS | **FALSE PASS** | - |
| C12 | identical duplicate of the GOV line elsewhere | PASS | PASS | correct PASS | - |
| C13 | 'G4 CLOSED' only inside a fenced code block (quotation) | undecided | PASS | undecided by brief (checker PASS) | - |
| C14 | adjacent: finding F7 status OPEN -> CLOSED (not the governing line) | undecided | PASS | undecided by brief (checker PASS) | - |
| C15 | ambiguous hedge: 'Whether G4 remains OPEN is undecided; G4 may be CLOSED.' | FAIL | PASS | **FALSE PASS** | - |
| M01 | line 5 altered to G4 CLOSED; intact required line inside a fenced code block elsewhere | FAIL | PASS | **FALSE PASS** | - |
| M02 | line 5 altered to G4 CLOSED; intact required line inside an HTML comment elsewhere | FAIL | PASS | **FALSE PASS** | - |
| M03 | line 5 deleted; required line only as a blockquote elsewhere | undecided | PASS | undecided by brief (checker PASS) | - |
| M04 | line 5 deleted; required line only inside a table cell elsewhere | undecided | PASS | undecided by brief (checker PASS) | - |
| M05 | line 5 deleted; required line only inside an HTML comment (final line still asserts the status) | undecided | PASS | undecided by brief (checker PASS) | - |
| M06 | line 5 deleted; required line only in a level-3 heading | undecided | PASS | undecided by brief (checker PASS) | - |
| M07 | line 5 replaced by conflicting line; real required line only inside an HTML comment (no visible status) | FAIL | PASS | **FALSE PASS** | - |
