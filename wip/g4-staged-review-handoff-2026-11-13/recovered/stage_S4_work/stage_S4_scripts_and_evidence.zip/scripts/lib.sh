# shared helpers for S4 (sourced). Requires S (stage dir) and OUT (evidence dir) set by caller.
export GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null GIT_TERMINAL_PROMPT=0
export GIT_AUTHOR_NAME=Rev GIT_AUTHOR_EMAIL=rev@example.invalid GIT_COMMITTER_NAME=Rev GIT_COMMITTER_EMAIL=rev@example.invalid
export GIT_AUTHOR_DATE="2026-01-01T00:00:00Z" GIT_COMMITTER_DATE="2026-01-01T00:00:00Z"
G=/usr/bin/git
BR=docs/g4-fts-errata-handoff-oct2026
ORIG=$S/work/block_orig.sh
WRAPDIR=$S/work/wrap
NOPROXY=(env -u HTTPS_PROXY -u https_proxy -u HTTP_PROXY -u http_proxy -u ALL_PROXY -u all_proxy NO_PROXY=127.0.0.1)
cm() { $G add -A -f . && $G commit -q --allow-empty -m "$1"; }
# run_block id clonedir T H CANON usewrap(0/1) [VAR=val ...]
run_block() {
  local id=$1 cl=$2 T=$3 H=$4 CANON=$5 uw=$6; shift 6
  local blk=$OUT/blocks/$id.sh; mkdir -p $OUT/blocks
  sed -E "s|^CANON=[^ ]*|CANON=$CANON|; s|^T=[0-9a-f]*|T=$T|; s|^H=[0-9a-f]*|H=$H|" $ORIG > $blk
  diff $ORIG $blk | grep -c '^>' > $OUT/blocks/$id.changedlines
  local P=$PATH; [ "$uw" = 1 ] && P=$WRAPDIR:$PATH
  rm -f $OUT/$id.wlog $OUT/$id.wstate
  ( cd $cl && "${NOPROXY[@]}" PATH=$P WRAP_STATE=$OUT/$id.wstate WRAP_LOG=$OUT/$id.wlog WRAP_BR=$BR "$@" bash $blk >$OUT/$id.stdout 2>$OUT/$id.stderr )
  echo $? > $OUT/$id.rc
}
# classify id expect -> TSV: rc outcome class firstfail
classify() {
  local id=$1 exp=$2 rc out last npass nfail cls ff
  rc=$(<$OUT/$id.rc); last=$(tail -n1 $OUT/$id.stdout)
  npass=$(grep -c '^PASS' $OUT/$id.stdout); nfail=$(grep -c '^FAIL' $OUT/$id.stdout)
  if [ "$rc" = 0 ] && [ "$npass" = 1 ] && [ "$nfail" = 0 ]; then out=PASS
  elif [ "$rc" = 1 ] && [ "$npass" = 0 ] && [ "$last" = "TRANSFER INCOMPLETE — REMOTE CHECKPOINT NOT VERIFIED" ]; then out=FAIL
  else out="ODD(rc=$rc,pass=$npass,fail=$nfail)"; fi
  case "$exp:$out" in
    PASS:PASS) cls="correct PASS";; FAIL:FAIL) cls="correct FAIL";;
    FAIL:PASS) cls="FALSE PASS";; PASS:FAIL) cls="false FAIL";;
    TOL:PASS) cls="tolerated PASS (remote conformant; input not producible by real git)";; TOL:FAIL) cls="fail-closed FAIL (remote conformant; minor)";;
    AMBIG:*) cls="ambiguous contract; observed $out";;
    *) cls="ODD";;
  esac
  ff=$(grep -m1 '^FAIL' $OUT/$id.stdout | cut -c1-120)
  printf '%s\t%s\t%s\t%s' "$rc" "$out" "$cls" "$ff"
}
index() { echo "$1 : $2" >> $S/evidence/INDEX.txt; }
