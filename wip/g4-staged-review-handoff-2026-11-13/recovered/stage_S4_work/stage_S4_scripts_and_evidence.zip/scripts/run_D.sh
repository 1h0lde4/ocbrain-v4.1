#!/bin/bash
# Item D rows: handoff.md integrity (real git states, real git, no wrapper). Usage: bash run_D.sh
S=/tmp/claude-0/-home-claude/d441201d-0373-573d-8f64-186072f858d3/scratchpad/a8/stage_S4
OUT=$S/evidence/D; rm -rf $OUT $S/work/d; mkdir -p $OUT $S/work/d
. $S/scripts/lib.sh
start() { rm -rf $ROW/w $ROW/origin.git; mkdir -p $ROW; W=$ROW/w; $G init -q -b $BR $W; cd $W; echo r>README; cm c0; C0=$($G rev-parse HEAD); }
mkT() { mkdir -p docs; echo a>docs/a.txt; cm T; TT=$($G rev-parse HEAD); }
mkH() { echo v1>handoff.md; cm H; HH=$($G rev-parse HEAD); }
chm() { echo "$1"; }
# --- row builders: each leaves cwd=$W, branch BR at the intended remote tip, TT and HH set ---
D01() { mkT; mkH; }
D02() { mkT; mkH; echo v2>handoff.md; cm F1; }
D03() { mkT; mkH; echo v2>handoff.md; cm F1; echo v3>handoff.md; cm F2; }
D04() { mkT; mkH; rm handoff.md; ln -s ../x handoff.md; cm F1; }
D05() { mkT; rm -f handoff.md; ln -s ../x handoff.md; cm H; HH=$($G rev-parse HEAD); }
D06() { mkT; mkH; rm handoff.md; mkdir handoff.md; echo i>handoff.md/inner.txt; cm F1; }
D07() { mkT; mkH; chmod +x handoff.md; cm F1; }
D08() { mkT; echo v1>handoff.md; chmod +x handoff.md; cm H; HH=$($G rev-parse HEAD); }
D09() { mkT; mkH; $G rm -q --cached handoff.md; $G update-index --add --cacheinfo 160000,$TT,handoff.md; $G commit -q -m F1; }
D10() { mkT; $G update-index --add --cacheinfo 160000,$TT,handoff.md; $G commit -q -m H; HH=$($G rev-parse HEAD); }
D11() { mkT; echo v1>handoff.md.bak; cm H; HH=$($G rev-parse HEAD); }
D12a() { mkT; echo v1>Handoff.md; cm H; HH=$($G rev-parse HEAD); }
D12b() { mkT; echo v1>HANDOFF.MD; cm H; HH=$($G rev-parse HEAD); }
D12c() { mkT; echo v1>handoff.MD; cm H; HH=$($G rev-parse HEAD); }
D12d() { mkT; echo v1>"handoff.md "; cm H; HH=$($G rev-parse HEAD); }
D12e() { mkT; echo v1>handoff.mdx; cm H; HH=$($G rev-parse HEAD); }
D12f() { mkT; echo v1>" handoff.md"; cm H; HH=$($G rev-parse HEAD); }
D13() { mkT; mkH; echo v2>handoff.md; echo d>Handoff.md; cm F1; }
D14() { mkdir -p docs; echo a>docs/a.txt; echo d>Handoff.md; cm T; TT=$($G rev-parse HEAD); mkH; }
D15() { mkT; mkH; rm handoff.md; cm F1; echo v1>handoff.md; cm F2; }
D16() { mkT; mkH; $G mv handoff.md handoff2.md; $G commit -q -m F1; }
D17() { mkT; echo same>old_handoff.md; cm T; TT=$($G rev-parse HEAD); $G mv old_handoff.md handoff.md; $G commit -q -m H; HH=$($G rev-parse HEAD); }
D18() { echo v1>handoff.md; cm T; TT=$($G rev-parse HEAD); echo v2>handoff.md; cm H; HH=$($G rev-parse HEAD); }
D19() { mkT; echo o>docs/b.txt; cm H; HH=$($G rev-parse HEAD); echo v1>handoff.md; cm F1; }
D20() { mkT; printf "a\nb\nc\nd\ne\n">handoff.md; cm H; HH=$($G rev-parse HEAD); $G checkout -q -b side $HH; sed -i "5s/.*/side/" handoff.md; cm S1; $G checkout -q $BR; sed -i "1s/.*/main/" handoff.md; cm F1; $G merge -q --no-ff -m M side; }
D21() { mkT; $G checkout -q -b side $TT; echo b>docs/b.txt; cm S; $G checkout -q $BR; mkH; $G merge -q --no-ff -m M side; }
D22() { mkT; mkH; echo v2>handoff.md; echo z>docs/a.txt; cm F1; }
D23() { mkT; mkH; chmod +x handoff.md; cm F1; chmod -x handoff.md; cm F2; }
D24() { mkT; mkH; $G commit -q --allow-empty -m F1; }
D25() { mkT; mkH; rm handoff.md; ln -s ../x handoff.md; cm F1; rm handoff.md; echo v3>handoff.md; cm F2; }
D26() { mkT; mkdir -p sub; echo v1>sub/handoff.md; cm H; HH=$($G rev-parse HEAD); }
D27() { mkT; $G checkout -q -b X $TT; echo x>docs/x.txt; cm X; $G checkout -q $BR; $G merge -q --no-ff --no-commit X; echo v1>handoff.md; $G add handoff.md; $G commit -q -m H; HH=$($G rev-parse HEAD); }
D28() { mkT; echo t2>docs/t2.txt; cm T2; mkH; }
D29() { mkT; echo c>docs/c.txt; mkH; }
D30() { echo old>handoff.md; cm c0b; mkT; $G rm -q handoff.md; $G commit -q -m T3; TT=$($G rev-parse HEAD); mkH; }
D31() { mkT; mkH; rm handoff.md; $G rm -q --cached handoff.md 2>/dev/null; $G update-index --add --cacheinfo 160000,$TT,handoff.md; $G commit -q -m F1; $G rm -q --cached handoff.md; echo v3>handoff.md; $G add handoff.md; $G commit -q -m F2; }
D32() { mkT; echo v1>handoff.md; chmod +x handoff.md; cm H; HH=$($G rev-parse HEAD); chmod -x handoff.md; cm F1; }
D33() { mkT; mkH; tr=$($G cat-file tree HEAD^{tree} | python3 -I -c 'import sys;d=sys.stdin.buffer.read();sys.stdout.buffer.write(d.replace(b"100644 handoff.md\x00",b"100664 handoff.md\x00"))' | $G hash-object -t tree -w --literally --stdin 2>>$OUT/D33.setup.err); c=$($G commit-tree $tr -p HEAD -m F1 2>>$OUT/D33.setup.err) && $G update-ref refs/heads/$BR $c; }
D35() { mkT; mkH; echo v2>handoff.md; cm F1; F1=$($G rev-parse HEAD); echo v3>handoff.md; $G add handoff.md; tr=$($G write-tree); m=$($G commit-tree $tr -p $F1 -p $HH -m M); $G update-ref refs/heads/$BR $m; $G reset -q --hard; }
D36() { mkT; mkH; $G rm -q handoff.md; $G commit -q -m F1; }
D37() { mkT; echo v1>handoff.md; $G add handoff.md; tr=$($G cat-file tree $($G write-tree) | python3 -I -c 'import sys;d=sys.stdin.buffer.read();sys.stdout.buffer.write(d.replace(b"100644 handoff.md\x00",b"100664 handoff.md\x00"))' | $G hash-object -t tree -w --literally --stdin 2>>$OUT/D37.setup.err); HH=$($G commit-tree $tr -p $TT -m H 2>>$OUT/D37.setup.err); $G update-ref refs/heads/$BR $HH; }
D34() { mkT; mkH; $G checkout -q -b br2 $HH; echo v2>handoff.md; cm F1; $G checkout -q $BR; $G reset -q --hard br2; }
ROWS=$(cat <<'TBL'
D01|PASS|tip=H (no follow-ups), handoff.md 100644 added by H
D02|PASS|H + one follow-up modifying handoff.md only
D03|PASS|H + two follow-ups modifying handoff.md only
D04|FAIL|follow-up replaces handoff.md by a symlink (120000) [brief A-iii]
D05|FAIL|H itself adds handoff.md as a symlink
D06|FAIL|follow-up replaces handoff.md by a directory handoff.md/inner.txt
D07|FAIL|follow-up mode-only change 100644->100755 (tip 100755) [brief A-vi]
D08|FAIL|H adds handoff.md with mode 100755
D09|FAIL|follow-up replaces handoff.md by a gitlink (160000) entry
D10|FAIL|H adds handoff.md as a gitlink (160000) entry
D11|FAIL|only handoff.md.bak exists (similar name), no handoff.md
D12a|FAIL|only Handoff.md exists (different case)
D12b|FAIL|only HANDOFF.MD exists
D12c|FAIL|only handoff.MD exists
D12d|FAIL|only 'handoff.md ' (trailing space) exists
D12e|FAIL|only handoff.mdx exists
D12f|FAIL|only ' handoff.md' (leading space) exists
D13|FAIL|follow-up changes handoff.md and adds Handoff.md (two paths)
D14|PASS|Handoff.md decoy added in T itself; handoff.md added by H (both in tip tree)
D15|AMBIG|follow-up deletes handoff.md, later follow-up re-adds it (handoff.md added twice)
D16|FAIL|follow-up renames handoff.md -> handoff2.md (tip has no handoff.md)
D17|AMBIG|H adds handoff.md by renaming old_handoff.md that existed in T
D18|FAIL|handoff.md already added by T; H only modifies it (H is not the adding commit)
D19|FAIL|H does not touch handoff.md; a later commit adds it
D20|FAIL|clean merge commit M in the chain: F1 and side S1 both children of H, each editing handoff.md only
D21|FAIL|merge of a side branch rooted at T into H (merge in chain)
D22|FAIL|follow-up changes handoff.md and docs/a.txt
D23|PASS|follow-up chmod +x then follow-up chmod -x (tip 100644; each changes handoff.md only)
D24|FAIL|empty follow-up commit (changes nothing)
D25|PASS|file->symlink in F1, symlink->file in F2 (tip regular 100644)
D26|FAIL|only sub/handoff.md exists (not at repo root)
D27|FAIL|H is a merge commit (parents T and X) that adds handoff.md
D28|FAIL|extra commit T2 between T and H (H parent is T2, not T)
D29|PASS|H adds handoff.md and also docs/c.txt (contract does not restrict H's other paths)
D30|AMBIG|handoff.md added in c0, deleted in T3 (=T), re-added by H
D31|PASS|gitlink in F1, regular file again in F2 (tip regular)
D32|PASS|H adds 100755, F1 chmod -x (tip 100644)
D33|FAIL|follow-up tree with RAW mode 100664 (git reads it as 100644: apparent empty change; equals D24 in effect)
D35|FAIL|merge M with parents (F1,H) (redundant parent, handoff.md changed alone)
D36|FAIL|follow-up deletes handoff.md (tip has no handoff.md)
D37|AMBIG|H adds handoff.md with RAW tree mode 100664 (git canonicalises it to 100644 when reading)
D34|PASS|branch built through side branch+reset (linear H->F1) control
TBL
)
printf 'id\texpect\trc\toutcome\tclassification\tfirst_FAIL_line\tstderr_bytes\tdesc\n' > $OUT/SUMMARY.tsv
while IFS='|' read -r id exp desc; do
  [ -z "$id" ] && continue
  ROW=$S/work/d/$id; TT=; HH=; start; [ -z "$(type -t $id)" ] && { echo "no builder $id"; continue; }
  $id >>$OUT/$id.build.log 2>&1
  $G -C $W push -q $ROW/origin.git HEAD:refs/heads/$BR 2>/dev/null || { $G init -q --bare $ROW/origin.git; $G -C $W push -q $ROW/origin.git HEAD:refs/heads/$BR; }
  cd $S; $G clone -q -b $BR $ROW/origin.git $ROW/clone 2>>$OUT/$id.build.log
  $G -C $ROW/clone log --graph --format='%h %p | %s' --raw --no-abbrev-commit -M 2>/dev/null | head -40 > $OUT/$id.graph.txt
  $G -C $ROW/clone ls-tree HEAD -- . | head -12 > $OUT/$id.tiptree.txt
  run_block $id $ROW/clone $TT $HH $ROW/origin 0
  sb=$(wc -c < $OUT/$id.stderr)
  printf '%s\t%s\t%s\t%s\t%s\n' "$id" "$exp" "$(classify $id $exp)" "$sb" "$desc" >> $OUT/SUMMARY.tsv
  for f in stdout stderr rc graph.txt tiptree.txt; do [ -f $OUT/$id.$f ] && index "evidence/D/$id.$f" "D row $id ($desc): $f"; done
done <<< "$ROWS"
index evidence/D/SUMMARY.tsv "item D summary table (all rows)"
echo "D rows done: $(($(wc -l < $OUT/SUMMARY.tsv)-1))"
