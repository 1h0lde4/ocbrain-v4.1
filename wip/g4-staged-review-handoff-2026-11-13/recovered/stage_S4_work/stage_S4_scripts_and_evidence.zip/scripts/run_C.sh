#!/bin/bash
# Item C rows: git ls-remote handling. Usage: bash run_C.sh   (from anywhere)
S=/tmp/claude-0/-home-claude/d441201d-0373-573d-8f64-186072f858d3/scratchpad/a8/stage_S4
OUT=$S/evidence/C; rm -rf $OUT $S/work/c $S/work/c_tpl; mkdir -p $OUT $S/work/c
. $S/scripts/lib.sh
TPL=$S/work/c_tpl; mkdir -p $TPL; W=$TPL/w
$G init -q -b $BR $W; cd $W
echo r>README; cm c0; mkdir docs; echo a>docs/a.txt; cm T; T=$($G rev-parse HEAD)
echo v1>handoff.md; cm H; H=$($G rev-parse HEAD)
echo v2>handoff.md; cm F1; F1=$($G rev-parse HEAD)
echo v3>handoff.md; cm F2; F2=$($G rev-parse HEAD)
$G init -q --bare $TPL/origin.git
$G push -q $TPL/origin.git $F1:refs/heads/$BR $F2:refs/heads/spare
echo "T=$T H=$H F1(tip)=$F1 F2(spare)=$F2" > $OUT/hashes.txt; cd $S
OR() { $G --git-dir="$ROW/origin.git" "$@"; }
pre_R06() { OR pack-refs --all; }
pre_R07() { OR pack-refs --all; OR update-ref refs/heads/$BR $F2; }
pre_R12() { OR symbolic-ref refs/heads/$BR refs/heads/spare; }
post_R01() { OR update-ref refs/heads/zz/refs/heads/$BR $F1; }
post_R02() { OR update-ref -d refs/heads/$BR; OR update-ref refs/heads/zz/refs/heads/$BR $F1; }
post_R03() { OR update-ref refs/tags/refs/heads/$BR $F1; }
post_R04() { OR tag -a -m x "refs/heads/$BR" $F1 2>>$OUT/R04.setup.err; }
post_R05() { OR update-ref refs/heads/Docs/g4-fts-errata-handoff-oct2026 $F1; }
post_R08() { OR update-ref refs/heads/${BR}-2 $F1; }
post_R09() { OR update-ref refs/heads/zz/$BR $F1; }
post_R10() { OR update-ref -d refs/heads/$BR; OR update-ref refs/heads/zz/$BR $F1; }
post_W51() { mkdir -p $ROW/clone/refs/heads/docs; : > $ROW/clone/refs/heads/docs/g4-fts-errata-handoff-oct2026; }
ROWS=$(cat <<'TBL'
W01|real|real|PASS|baseline, both ls-remote real
W02|fail_after_print|real|FAIL|1st call prints correct ref then exit 1 (brief A-ii)
W03|real|fail_after_print|FAIL|2nd (final) call prints correct ref then exit 1 (brief A-v variant)
W04|fail_after_print|fail_after_print|FAIL|both calls print correct ref then exit 1
W05|fail_after_print_128|real|FAIL|1st: ref, stderr fatal, exit 128
W06|real|fail_after_print_128|FAIL|2nd: ref, stderr fatal, exit 128
W07|fail_noprint|real|FAIL|1st: no stdout, exit 128
W08|real|fail_noprint|FAIL|2nd: no stdout, exit 128 (brief A-v)
W09|sigpipe_after_print|real|FAIL|1st: ref then killed by SIGPIPE (141)
W10|real|sigpipe_after_print|FAIL|2nd: ref then SIGPIPE
W11|zero|real|FAIL|1st: zero lines, exit 0
W12|real|zero|FAIL|2nd: zero lines, exit 0
W13|dup|real|FAIL|1st: same ref line twice
W14|real|dup|FAIL|2nd: same ref line twice
W15|two_other|real|FAIL|1st: correct line + refs/heads/other line
W16|real|two_other|FAIL|2nd: correct line + other line
W17|two_other_first|real|FAIL|1st: other line first, correct second
W18|real|two_other_first|FAIL|2nd: other line first
W19|wrongname|real|FAIL|1st: only refs/heads/other with right hash
W20|real|wrongname|FAIL|2nd: only refs/heads/other
W21|wrongcase|real|FAIL|1st: ref name with Docs/ capitalised
W22|real|wrongcase|FAIL|2nd: ref name capitalised
W23|tail|real|FAIL|1st: refs/heads/zz/refs/heads/<BR> only (simulated tail match)
W24|real|tail|FAIL|2nd: tail-matching name only
W25|tail_prefix_only|real|FAIL|1st: refs/heads/zz/<BR> (brief's example form) only
W26|real|tail_prefix_only|FAIL|2nd: refs/heads/zz/<BR> only
W27|suffix_junk|real|FAIL|1st: name with extra suffix X
W28|real|suffix_junk|FAIL|2nd: name with extra suffix X
W29|hash_differs|real|FAIL|1st: right name, different hash than fetched tip
W30|real|hash_differs|FAIL|2nd: right name, different hash than fetched tip
W31|hash_upper|real|TOL|1st: same hash upper-cased (not producible by git)
W32|hash_short|real|FAIL|1st: 12-char abbreviated hash
W33|nohash|real|FAIL|1st: line with empty hash field
W34|nul|real|TOL|1st: NUL byte between hash and tab (not producible by git)
W35|ws_lead|real|TOL|1st: leading/trailing blanks and tab padding
W36|space_sep|real|TOL|1st: space instead of tab separator
W37|cr|real|TOL|1st: CRLF line ending
W38|blank_lines|real|TOL|1st: empty lines around the single ref line
W39|ws_only_line|real|FAIL|1st: ref line + whitespace-only line (2 non-empty lines)
W40|trailing_field|real|TOL|1st: third field after the ref name
W41|stderr_noise|real|PASS|1st: correct line, exit 0, warning text on stderr
W42|long_lines|real|FAIL|1st: ref + 200000 other ref lines
W43|long_blank|real|TOL|1st: ref + 5 MB of empty lines
W44|peeled|real|FAIL|1st: ref + ref^{} line
W45|delete_real|real|FAIL|real ls-remote after branch deleted on origin (zero lines, exit 0)
W46|real|delete_real|FAIL|real final ls-remote after branch deleted on origin
W47|hide_real|real|FAIL|real ls-remote while origin path is unavailable (real exit 128)
W48|real|hide_real|FAIL|real final ls-remote while origin unavailable (brief A-v, real)
W49|move_real|real|FAIL|origin tip moved to F2 before 1st ls-remote
W50|real|move_real|FAIL|origin tip moved to F2 before final ls-remote (brief A-i/F)
W51|glob|real|FAIL|1st: name 'refs/*/*/*' with a matching path present in cwd (mechanism only)
W52|oneline_two|real|FAIL|1st: ONE line holding two ref pairs (mechanism only)
R01|real|real|PASS|REAL origin: extra branch refs/heads/zz/refs/heads/<BR> (real tail match)
R02|real|real|FAIL|REAL origin: <BR> deleted after clone, only tail-match branch exists
R03|real|real|PASS|REAL origin: lightweight tag refs/tags/refs/heads/<BR>
R04|real|real|PASS|REAL origin: annotated tag refs/tags/refs/heads/<BR>
R05|real|real|PASS|REAL origin: extra branch Docs/g4-... (case variant)
R06|real|real|PASS|REAL origin: pack-refs --all
R07|real|real|PASS|REAL origin: packed ref stale (F1) + loose ref newer (F2); tip F2
R08|real|real|PASS|REAL origin: extra branch <BR>-2 (suffix superset)
R09|real|real|PASS|REAL origin: extra branch refs/heads/zz/<BR> (brief's literal tail example)
R10|real|real|FAIL|REAL origin: <BR> deleted after clone, only refs/heads/zz/<BR> exists
R12|real|real|PASS|REAL origin: refs/heads/<BR> is a symbolic ref to refs/heads/spare (=F2)
TBL
)
printf 'id\texpect\trc\toutcome\tclassification\tfirst_FAIL_line\tls_remote_calls\tstderr_bytes\tdesc\n' > $OUT/SUMMARY.tsv
while IFS='|' read -r id m1 m2 exp desc; do
  [ -z "$id" ] && continue
  ROW=$S/work/c/$id; mkdir -p $ROW; cp -a $TPL/origin.git $ROW/origin.git
  declare -F pre_$id >/dev/null && pre_$id
  $G clone -q -b $BR $ROW/origin.git $ROW/clone 2>/dev/null
  declare -F post_$id >/dev/null && post_$id
  run_block $id $ROW/clone $T $H $ROW/origin 1 WRAP_MODE1=$m1 WRAP_MODE2=$m2 WRAP_ORIGIN=$ROW/origin.git WRAP_NEWTIP=$F2 WRAP_OTHER=$T
  nc=0; [ -f $OUT/$id.wlog ] && nc=$(wc -l < $OUT/$id.wlog)
  sb=$(wc -c < $OUT/$id.stderr)
  printf '%s\t%s\t%s\t%s\t%s\t%s\n' "$id" "$exp" "$(classify $id $exp)" "$nc" "$sb" "$desc" | awk -F'\t' 'BEGIN{OFS="\t"}{print $1,$2,$3,$4,$5,$6,$7,$8,$9}' >> $OUT/SUMMARY.tsv
  for f in stdout stderr rc wlog; do [ -f $OUT/$id.$f ] && index "evidence/C/$id.$f" "C row $id ($desc): $f"; done
done <<< "$ROWS"
index evidence/C/SUMMARY.tsv "item C summary table (all rows)"; index evidence/C/hashes.txt "item C synthetic commit hashes"
echo "C rows done: $(($(wc -l < $OUT/SUMMARY.tsv)-1))"
