#!/bin/bash
# Incidental output checks (not item C/D rows): what git itself prints on stderr. Local/loopback only.
S=/tmp/claude-0/-home-claude/d441201d-0373-573d-8f64-186072f858d3/scratchpad/a8/stage_S4
OUT=$S/evidence/INC; rm -rf $OUT $S/work/inc; mkdir -p $OUT $S/work/inc
. $S/scripts/lib.sh
TPL=$S/work/c_tpl; eval "$(sed 's/ F1(tip)=/ F1=/; s/ F2(spare)=/ F2=/' $S/evidence/C/hashes.txt | tr ' ' '\n' | sed 's/^/X_/')"
I1=$S/work/inc/I1; mkdir -p $I1; cp -a $TPL/origin.git $I1/origin.git; $G clone -q -b $BR $I1/origin.git $I1/clone 2>/dev/null
$G --git-dir=$I1/origin.git update-ref refs/heads/$BR $X_F2     # origin moves after clone: tracking ref is stale
run_block I1 $I1/clone $X_T $X_H $I1/origin 0
I2=$S/work/inc/I2; mkdir -p $I2; cp -a $TPL/origin.git $I2/origin.git; $G clone -q -b $BR $I2/origin.git $I2/clone 2>/dev/null
$G -C $I2/clone remote set-url origin "http://user:DUMMYTOKEN-xyz@127.0.0.1:1/x.git"
run_block I2 $I2/clone $X_T $X_H $I2/origin 0
I3=$S/work/inc/I3; mkdir -p $I3; cp -a $TPL/origin.git $I3/origin.git; $G clone -q -b $BR $I3/origin.git $I3/clone 2>/dev/null
$G -C $I3/clone remote set-url origin "https://user:DUMMYTOKEN-xyz@127.0.0.1:1/x.git"
run_block I3 $I3/clone $X_T $X_H $I3/origin 0
for id in I1 I2 I3; do echo "== $id rc=$(cat $OUT/$id.rc) token_in_stdout=$(grep -c DUMMYTOKEN $OUT/$id.stdout) token_in_stderr=$(grep -c DUMMYTOKEN $OUT/$id.stderr)"; echo "-- stdout"; cut -c1-220 $OUT/$id.stdout; echo "-- stderr"; cut -c1-260 $OUT/$id.stderr; for f in stdout stderr rc; do index evidence/INC/$id.$f "incidental output check $id: $f"; done; done > $OUT/INC_SUMMARY.txt 2>&1
index evidence/INC/INC_SUMMARY.txt "incidental output checks summary"
cat $OUT/INC_SUMMARY.txt
