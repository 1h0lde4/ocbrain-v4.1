# Reviewer-written local test server: HTTPS (self-signed) + HTTP smart git via git-http-backend, Basic auth required (user any, password DUMMYTOKEN-xyz).
# usage: httpsd.py <root> <tls|plain> <portfile> <logfile>
import sys, os, ssl, subprocess, base64
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
root, mode, portfile, logfile = sys.argv[1:5]
NOAUTH = len(sys.argv) > 5 and sys.argv[5] == 'noauth'
GOOD = 'DUMMYTOKEN-xyz'
class H(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.0'
    def log_message(self, fmt, *a):
        open(logfile, 'a').write((fmt % a) + '\n')
    def handle_any(self):
        auth = self.headers.get('Authorization', '')
        ok = False
        if auth.startswith('Basic '):
            try: ok = base64.b64decode(auth[6:]).decode().split(':', 1)[1] == GOOD
            except Exception: ok = False
        open(logfile, 'a').write('REQ %s %s auth=%s\n' % (self.command, self.path.split('?')[0], 'ok' if ok else ('bad' if auth else 'none')))
        if NOAUTH: ok = True
        if not ok:
            self.send_response(401); self.send_header('WWW-Authenticate', 'Basic realm="t"'); self.send_header('Content-Length', '0'); self.end_headers(); return
        path, _, qs = self.path.partition('?')
        env = {'PATH': '/usr/bin:/bin', 'GIT_PROJECT_ROOT': root, 'GIT_HTTP_EXPORT_ALL': '1', 'REQUEST_METHOD': self.command, 'PATH_INFO': path,
               'QUERY_STRING': qs, 'CONTENT_TYPE': self.headers.get('Content-Type', ''), 'REMOTE_USER': 'u', 'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_CONFIG_SYSTEM': '/dev/null'}
        if self.headers.get('Git-Protocol'): env['GIT_PROTOCOL'] = self.headers['Git-Protocol']
        if self.headers.get('Content-Encoding'): env['HTTP_CONTENT_ENCODING'] = self.headers['Content-Encoding']
        body = b''
        if self.headers.get('Transfer-Encoding', '').lower() == 'chunked':
            while True:
                n = int(self.rfile.readline().strip() or b'0', 16)
                if n == 0: self.rfile.readline(); break
                body += self.rfile.read(n); self.rfile.readline()
        else:
            n = int(self.headers.get('Content-Length', 0) or 0); body = self.rfile.read(n) if n else b''
        env['CONTENT_LENGTH'] = str(len(body))
        p = subprocess.run(['/usr/lib/git-core/git-http-backend'], input=body, env=env, capture_output=True)
        hdr, _, data = p.stdout.partition(b'\r\n\r\n')
        if not _: hdr, _, data = p.stdout.partition(b'\n\n')
        status = 200; heads = []
        for line in hdr.decode('latin1').splitlines():
            if line.lower().startswith('status:'): status = int(line.split()[1])
            elif ':' in line: heads.append(line.split(':', 1))
        self.send_response(status)
        for k, v in heads: self.send_header(k, v.strip())
        self.send_header('Content-Length', str(len(data))); self.end_headers(); self.wfile.write(data)
    do_GET = do_POST = handle_any
srv = ThreadingHTTPServer(('127.0.0.1', 0), H)
if mode == 'tls':
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); ctx.load_cert_chain(os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), '..', 'tls', 'c.pem'), os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), '..', 'tls', 'k.pem'))
    srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
open(portfile, 'w').write(str(srv.server_address[1]))
srv.serve_forever()
