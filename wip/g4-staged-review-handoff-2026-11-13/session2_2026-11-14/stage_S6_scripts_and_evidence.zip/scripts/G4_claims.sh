. /tmp/claude-0/-home-claude/3adcc49e-2c16-5b57-97ab-65b038335fc4/scratchpad/a9/stage_S6/scripts/lib.sh
SUM=$S6/evidence/G4_summary.tsv; : > $SUM; WRAP=$S6/wrap
say() { printf '%s\n' "$*" | tee -a $SUM; }
# ===== Part 1: identity-check acceptance table (wrapper returns the URL for `git remote get-url origin`; real origin is a local path; block CANON is the ORIGINAL github value)
world g4i 1; w=$S6/work/g4i; mkblock $w/block.sh "$(cat $w/T)" "$(cat $w/H)" "https://github.com/1h0lde4/ocbrain-v4.1"; mkdir -p $w/state
idrow() { # idrow TAG EXPECT url
  rm -f $w/state/lsr_n; runblock "$1" g4i PATH=$WRAP:/usr/bin:/bin WRAP_DIR=$w/state FAKE_GETURL="$3"; local v=$(verdict) f=""
  [ "$2" = REJECT ] && [ "$v" = PASS ] && f="*** identity ACCEPTED (expected reject) ***"; [ "$2" = ACCEPT ] && [ "$v" = FAIL ] && f="(rejected, expected accept)"
  printf '%s\t%s\t%s\t%s\t%s\n' "$1" "$2" "$v" "$f" "$3" | tee -a $SUM; }
say "== Part 1: identity acceptance (verdict PASS = identity accepted; everything else in the block is satisfied)"
C=https://github.com/1h0lde4/ocbrain-v4.1
idrow I01 ACCEPT "$C"; idrow I02 ACCEPT "$C.git"; idrow I03 ACCEPT "git@github.com:1h0lde4/ocbrain-v4.1.git"; idrow I04 ACCEPT "git@github.com:1h0lde4/ocbrain-v4.1"
idrow I05 ACCEPT "ssh://git@github.com/1h0lde4/ocbrain-v4.1.git"; idrow I06 ACCEPT "ssh://git@github.com/1h0lde4/ocbrain-v4.1"
idrow I07 ACCEPT "https://user:DUMMYTOKEN-xyz@github.com/1h0lde4/ocbrain-v4.1.git"; idrow I08 ACCEPT "https://DUMMYTOKEN-xyz@github.com/1h0lde4/ocbrain-v4.1"
idrow I09 REJECT "https://github.com@evil.example/1h0lde4/ocbrain-v4.1"; idrow I10 REJECT "https://evil.example/x@github.com/1h0lde4/ocbrain-v4.1"
idrow I11 REJECT "HTTPS://github.com/1h0lde4/ocbrain-v4.1"; idrow I12 REJECT "https://GITHUB.com/1h0lde4/ocbrain-v4.1"; idrow I13 REJECT "$C/"; idrow I14 REJECT "https://github.com:443/1h0lde4/ocbrain-v4.1"
idrow I15 REJECT "http://github.com/1h0lde4/ocbrain-v4.1"; idrow I16 REJECT "ssh://git:DUMMYTOKEN-xyz@github.com/1h0lde4/ocbrain-v4.1"; idrow I17 REJECT "$C?x=1"; idrow I18 REJECT "$C.git.git"
idrow I19 REJECT "git@github.com:/1h0lde4/ocbrain-v4.1"; idrow I20 REJECT "ssh://git@github.com:22/1h0lde4/ocbrain-v4.1"
idrow I21 REJECT "https://evil.example#@github.com/1h0lde4/ocbrain-v4.1"; idrow I22 REJECT "https://evil.example?@github.com/1h0lde4/ocbrain-v4.1"
idrow I23 REJECT 'https://evil.example\@github.com/1h0lde4/ocbrain-v4.1'; idrow I24 REJECT "https://evil.example:x@github.com/1h0lde4/ocbrain-v4.1"
idrow I25 REJECT "git@github.com:1h0lde4/ocbrain-v4.1.git/../../evil/repo"; idrow I26 REJECT ""
# ===== Part 2/3: real transports on loopback (TLS with self-signed cert, Basic auth, password DUMMYTOKEN-xyz)
w=$S6/work/g4c; world g4c 1; mkdir -p $w/srv/org; ln -sfn $w/origin.git $w/srv/org/repo.git
G clone -q --bare $w/origin.git $w/fork.git
"${CLEANENV[@]}" true; rm -f $w/port1 $w/port2 $w/port3 $w/srv*.log
python3 $S6/scripts/httpsd.py $w/srv tls $w/port1 $w/srv1.log & P1=$!
python3 $S6/scripts/httpsd.py $w/fork.git tls $w/port2 $w/srv2.log & P2=$!
python3 $S6/scripts/httpsd.py $w/srv plain $w/port3 $w/srv3.log & P3=$!
trap 'kill $P1 $P2 $P3 2>/dev/null' EXIT; sleep 1.5
PORT=$(cat $w/port1); PORT2=$(cat $w/port2); PORT3=$(cat $w/port3)
say ""; say "== Part 2: real transport, credential handling. TLS port=$PORT fork-server port=$PORT2 plain port=$PORT3 (dead port 1)"
CAN="https://127.0.0.1:$PORT/org/repo"
urow() { # urow TAG url [CANON]  -> run block with remote.origin.url=url, grep outputs for the dummy token
  local tag=$1 url=$2 canon=${3:-$CAN}; G -C $w/work config remote.origin.url "$url"; rm -f $w/block.sh; mkblock $w/block.sh "$(cat $w/T)" "$(cat $w/H)" "$canon"
  runblock $tag g4c GIT_SSL_CAINFO=$S6/tls/c.pem; local v=$(verdict) hit=NO; cat $S6/evidence/$tag.out $S6/evidence/$tag.err | grep -q 'DUMMYTOKEN' && hit=YES-TOKEN-IN-OUTPUT
  printf '%s\t%s\tverdict=%s\ttoken_in_output=%s\n' "$tag" "$url" "$v" "$hit" | tee -a $SUM
  grep -h 'DUMMYTOKEN' $S6/evidence/$tag.out $S6/evidence/$tag.err | cut -c1-260 | sed 's/^/      LEAK-LINE: /' | tee -a $SUM; }
urow U01 "https://user:DUMMYTOKEN-xyz@127.0.0.1:$PORT/org/repo.git"
urow U02 "https://DUMMYTOKEN-xyz@127.0.0.1:$PORT/org/repo.git"
urow U03 "https://user:DUMMYTOKEN-xyz-WRONG@127.0.0.1:$PORT/org/repo.git"
urow U04 "https://user:DUMMYTOKEN-xyz@127.0.0.1:1/org/repo.git" "https://127.0.0.1:1/org/repo"
urow U05 "https://127.0.0.1:$PORT/org/repo.git?token=DUMMYTOKEN-xyz"
urow U06 "http://user:DUMMYTOKEN-xyz@127.0.0.1:$PORT3/org/repo.git"
urow U07 "ssh://user:DUMMYTOKEN-xyz@127.0.0.1:1/org/repo.git"
urow U08 "https://127.0.0.1:$PORT/DUMMYTOKEN-xyz/repo.git"
urow U09 "https://user:DUMMYTOKEN-xyz@127.0.0.1:$PORT/other/repo.git"
urow U10 "https://token:DUMMYTOKEN-xyz@127.0.0.1:$PORT/org/repo"
urow U11 "https://DUMMYTOKEN-xyz:x-oauth-basic@127.0.0.1:$PORT/org/repo"
# ===== Part 3: userinfo-trick URLs against a fork server (identical history) -- which host does git really contact?
say ""; say "== Part 3: '#@' / '?@' look-alike URLs: block identity vs real connection (fork server on $PORT2 has identical history; canonical on $PORT)"
: > $w/srv1.log; : > $w/srv2.log
for form in "#" "?"; do
  tag=T3_$( [ "$form" = "#" ] && echo hash || echo query ); G -C $w/work config remote.origin.url "https://127.0.0.1:${PORT2}${form}@127.0.0.1:$PORT/org/repo.git"
  : > $w/srv1.log; : > $w/srv2.log; rm -f $w/block.sh; mkblock $w/block.sh "$(cat $w/T)" "$(cat $w/H)" "$CAN"; runblock $tag g4c GIT_SSL_CAINFO=$S6/tls/c.pem
  printf '%s\turl=https://127.0.0.1:%s%s@127.0.0.1:%s/org/repo.git\tverdict=%s\tidentity_msg=%s\tcanonical_server_requests=%s\tfork_server_requests=%s\n' "$tag" "$PORT2" "$form" "$PORT" "$(verdict)" "$(grep -c 'origin is not the canonical' $S6/evidence/$tag.out)" "$(grep -c '^REQ' $w/srv1.log)" "$(grep -c '^REQ' $w/srv2.log)" | tee -a $SUM
done
G -C $w/work config remote.origin.url "$w/origin.git"
kill $P1 $P2 $P3 2>/dev/null; wait 2>/dev/null; say done
