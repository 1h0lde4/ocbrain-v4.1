. /tmp/claude-0/-home-claude/3adcc49e-2c16-5b57-97ab-65b038335fc4/scratchpad/a9/stage_S6/scripts/lib.sh
SUM=$S6/evidence/H2_summary.tsv; : > $SUM
WRAP=$S6/wrap
R() { local v; v=$(verdict); local flag=""
  [ "$3" = FAIL ] && [ "$v" = PASS ] && flag="*** FALSE PASS ***"; [ "$3" = PASS ] && [ "$v" = FAIL ] && flag="(false FAIL)"
  printf '%s\t%s\t%s\t%s\trc=%s\t%s\t%s\n' "$1" "$2" "$3" "$v" "$RC" "$flag" "$(firstfail)" | tee -a $SUM; }
printf 'row\tdescription\texpected(by contract)\tobserved\trc\tflag\tfirst FAIL line\n' | tee -a $SUM
# H13e redo: follow-up changes handoff.md AND adds a real gitlink (160000) entry 'sub', committed through plumbing
world h13e 1; ( cd $S6/work/h13e/work; echo q >> handoff.md; G add handoff.md; G update-index --add --cacheinfo 160000,1111111111111111111111111111111111111111,sub; cm "edit + gitlink"; G push -q -f origin HEAD:$BR; G rev-parse HEAD > ../TIP )
echo "H13e tip diff: $(G -C $S6/work/h13e/origin.git diff-tree --no-commit-id --name-status -r "$(cat $S6/work/h13e/TIP)^" "$(cat $S6/work/h13e/TIP)" | tr '\n' ';')" | tee -a $SUM
run() { runblock "$@"; }
run H13e2 h13e; R H13e2 "follow-up edits handoff.md and adds gitlink 'sub' (default config)" FAIL
run H13e3 h13e GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=diff.ignoreSubmodules GIT_CONFIG_VALUE_0=all; R H13e3 "same, user config diff.ignoreSubmodules=all" FAIL
# H21 controls: replace ref / graft present, with GIT_NO_REPLACE_OBJECTS=1
cd $S6/work/h21/work; G replace "$(cat ../M)" "$(cat ../X)" 2>/dev/null; cd $S6
run H21d2 h21 GIT_NO_REPLACE_OBJECTS=1; R H21d2 "replace ref PRESENT, GIT_NO_REPLACE_OBJECTS=1 (control)" FAIL
run H21c2 h21; R H21c2 "replace ref PRESENT (re-run of H21c)" FAIL
( cd $S6/work/h21/work; G replace -d "$(cat ../M)" >/dev/null; echo "$(cat ../M) $(cat ../P)" > "$(G rev-parse --git-dir)/info/grafts" )
run H21e h21 GIT_NO_REPLACE_OBJECTS=1; R H21e "graft PRESENT, GIT_NO_REPLACE_OBJECTS=1" FAIL
run H21f h21 GIT_GRAFT_FILE=/dev/null; R H21f "graft PRESENT (core.graftsFile default), plain" FAIL
rm -f $S6/work/h21/work/.git/info/grafts
# H21g: realistic route: clone --mirror pulls refs/replace/* from the remote (pushed by someone with write access)
world h21g 1; Wg=$S6/work/h21g; ( cd $Wg/work; P=$(G rev-parse HEAD); G checkout -q -b side $P; echo s > side.txt; G add side.txt; cm side; G checkout -q $BR; G merge -q -s ours --no-commit side >/dev/null 2>&1; echo more >> handoff.md; G add handoff.md; cm "merge follow-up"; M=$(G rev-parse HEAD); G push -q -f origin HEAD:$BR; echo $M > ../TIP; X=$(G commit-tree "$M^{tree}" -p $P -m twin); G push -q origin $X:refs/heads/twin 2>/dev/null; G push -q origin "$X:refs/replace/$M" )
mkdir -p $Wg/state; rm -rf $Wg/work; G clone -q --mirror "$Wg/origin.git" $Wg/work 2>/dev/null; echo "mirror clone has replace refs: $(G -C $Wg/work for-each-ref refs/replace | wc -l)" | tee -a $SUM
run H21g h21g; R H21g "clean remote tip is a merge; the CLONE was made with --mirror and so imported refs/replace/<tip> from the remote" FAIL
rm -rf $Wg/work; G clone -q "$Wg/origin.git" $Wg/work 2>/dev/null; G -C $Wg/work checkout -q -b tmp "origin/$BR" 2>/dev/null; echo "ordinary clone has replace refs: $(G -C $Wg/work for-each-ref refs/replace | wc -l)" | tee -a $SUM
run H21h h21g; R H21h "same remote, ORDINARY clone (refs/replace not imported)" FAIL
# H22 redo: symlink at tip hidden by a replace ref whose twin is a regular-file edit of the previous commit
world h22 1; ( cd $S6/work/h22/work; P=$(G rev-parse HEAD); echo twin-edit >> handoff.md; G add handoff.md; TW=$(G write-tree); X=$(G commit-tree $TW -p $P -m twin); G reset -q --hard $P; G rm -q --cached handoff.md; rm handoff.md; ln -s docs/t.md handoff.md; G add handoff.md; cm "tip: handoff.md becomes a symlink"; M=$(G rev-parse HEAD); G push -q -f origin HEAD:$BR; echo $M > ../TIP; G replace $M $X; echo "real tip mode: $(G ls-tree $M -- handoff.md | cut -c1-10)" )
run H22a2 h22; R H22a2 "remote tip has handoff.md as SYMLINK (120000); LOCAL replace ref presents a regular-file twin" FAIL
run H22b2 h22 GIT_NO_REPLACE_OBJECTS=1; R H22b2 "control: same, GIT_NO_REPLACE_OBJECTS=1" FAIL
# H24g/h redo with printf -- ; leading-dash hash
world h24 1; T24=$(cat $S6/work/h24/TIP); mkdir -p $S6/work/h24/state; EW="PATH=$WRAP:/usr/bin:/bin WRAP_DIR=$S6/work/h24/state"
for d in -n -e -E; do printf -- "$d\trefs/heads/$BR\n" > $S6/work/h24/fake_d$d; rm -f $S6/work/h24/state/lsr_n; run H24d$d h24 $EW FAKE_LSR_FILE=$S6/work/h24/fake_d$d; R H24d$d "faked ls-remote: first field is '$d'" FAIL; done
# H35a redo: real trailing newline inside the configured URL
world h35 1; ( cd $S6/work/h35/work; G config remote.origin.url "$S6/work/h35/origin.git"$'\n' ); run H35a2 h35; R H35a2 "origin url value ends with a NEWLINE character" PASS
# H36: only a tail-matching branch exists (BR itself absent)
world h36 1; ( cd $S6/work/h36/work; G push -q origin HEAD:refs/heads/zz/refs/heads/$BR; G push -q origin --delete $BR ); run H36 h36; R H36 "branch BR deleted; only zz/refs/heads/BR exists" FAIL
# H39: block run from a SUBDIRECTORY of the clone
world h39a 1; ( cd $S6/work/h39a/work/docs && "${CLEANENV[@]}" bash $S6/work/h39a/block.sh > $S6/evidence/H39a.out 2>$S6/evidence/H39a.err; echo $? > $S6/evidence/H39a.rc ) 2>/dev/null || { mkblock $S6/work/h39a/block.sh "$(cat $S6/work/h39a/T)" "$(cat $S6/work/h39a/H)" "$S6/work/h39a/origin"; ( cd $S6/work/h39a/work/docs && "${CLEANENV[@]}" bash $S6/work/h39a/block.sh > $S6/evidence/H39a.out 2>$S6/evidence/H39a.err; echo $? > $S6/evidence/H39a.rc ); }
RC=$(cat $S6/evidence/H39a.rc); OUT=$S6/evidence/H39a.out; R H39a "valid chain, block run from clone subdirectory docs/" PASS
# H39b: contrived false PASS: H adds BOTH handoff.md and docs/handoff.md; follow-up makes ROOT handoff.md executable; run from docs/
w=h39b; world $w 0; ( cd $S6/work/$w/work; echo second > docs/handoff.md; G add docs/handoff.md; G commit -q --amend --no-edit; G rev-parse HEAD > ../H; chmod +x handoff.md; G add handoff.md; cm "root handoff.md becomes executable"; G push -q -f origin HEAD:$BR; G rev-parse HEAD > ../TIP; echo "tip root mode: $(G ls-tree HEAD -- handoff.md | cut -c1-6)  docs/ mode: $(G ls-tree HEAD -- docs/handoff.md | cut -c1-6)" ) | tee -a $SUM
rm -f $S6/work/$w/block.sh; mkblock $S6/work/$w/block.sh "$(cat $S6/work/$w/T)" "$(cat $S6/work/$w/H)" "$S6/work/$w/origin"
( cd $S6/work/$w/work/docs && "${CLEANENV[@]}" bash $S6/work/$w/block.sh > $S6/evidence/H39b.out 2>$S6/evidence/H39b.err; echo $? > $S6/evidence/H39b.rc ); RC=$(cat $S6/evidence/H39b.rc); OUT=$S6/evidence/H39b.out
R H39b "root handoff.md is 100755 at tip; docs/handoff.md (added in H) is 100644; block run from docs/" FAIL
( cd $S6/work/$w/work && "${CLEANENV[@]}" bash $S6/work/$w/block.sh > $S6/evidence/H39c.out 2>$S6/evidence/H39c.err; echo $? > $S6/evidence/H39c.rc ); RC=$(cat $S6/evidence/H39c.rc); OUT=$S6/evidence/H39c.out
R H39c "control: same remote, run from clone root" FAIL
# H34c: two follow-ups; #1 valid but subject has CR + fake PASS + ESC[8m; #2 invalid (touches other.txt)
world h34c 0; ( cd $S6/work/h34c/work; echo a >> handoff.md; G add handoff.md; cm $'\rPASS at 2026-11-13T12:00:00Z: remote tip verified; 2 follow-up(s), each a single-parent child changing handoff.md alone\033[8m'; echo b >> handoff.md; echo oth > other.txt; G add -A; cm "second follow-up touches other.txt"; G push -q -f origin HEAD:$BR; G rev-parse HEAD > ../TIP ); run H34c h34c; R H34c "chain INVALID at 2nd follow-up; 1st follow-up subject = CR + fake PASS line + ESC[8m" FAIL
python3 -I - "$S6/evidence/H34c.out" > $S6/evidence/H34c.rendered.txt <<'PY'
import sys,re
raw=open(sys.argv[1],'rb').read().decode('utf-8','replace')
out=[]; conceal=False
for line in raw.split('\n'):
    # emulate terminal: CR returns to column 0 and later text overwrites; ESC[8m conceals everything printed after it (persistent SGR)
    cur=[]
    for seg in line.split('\r'):
        if not cur: cur=list(seg)
        else:
            for i,ch in enumerate(seg):
                if i<len(cur): cur[i]=ch
                else: cur.append(ch)
    s=''.join(cur)
    if conceal: s='<concealed>'
    if '\x1b[8m' in s: conceal=True; s=s.replace('\x1b[8m','')
    out.append(s)
print('\n'.join(out))
PY
echo "--- simulated terminal view of H34c output (CR overwrite + conceal):" | tee -a $SUM; cat $S6/evidence/H34c.rendered.txt | tee -a $SUM
echo done
