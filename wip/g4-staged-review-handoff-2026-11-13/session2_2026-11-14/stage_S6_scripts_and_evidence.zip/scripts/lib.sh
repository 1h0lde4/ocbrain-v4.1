# lib.sh - sourced by S6 harness scripts. Reads the package block only by copying it (sed) into work/; never executes package files directly.
S6=/tmp/claude-0/-home-claude/3adcc49e-2c16-5b57-97ab-65b038335fc4/scratchpad/a9/stage_S6
PKG=$S6/pkg2/review_package
BLOCK_ORIG=$PKG/rev3/verify_block_rev3.sh
REALGIT=/usr/bin/git
BR=docs/g4-fts-errata-handoff-oct2026
# Hermetic environment for every git call made by the harness and the block (no proxies, no tokens, no global config)
CLEANENV=(env -i HOME=/nonexistent LANG=C.UTF-8 TZ=UTC PATH=/usr/bin:/bin GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null GIT_TERMINAL_PROMPT=0
  GIT_AUTHOR_NAME=Rev GIT_AUTHOR_EMAIL=rev@example.invalid GIT_COMMITTER_NAME=Rev GIT_COMMITTER_EMAIL=rev@example.invalid NO_PROXY=127.0.0.1)
G() { "${CLEANENV[@]}" $REALGIT "$@"; }
N=0
cm() { # cm "msg" [extra commit args]  (commit with strictly increasing fixed dates)
  N=$((N+1)); local d; d=$(printf '2026-01-01T00:%02d:%02dZ' $((N/60)) $((N%60)))
  "${CLEANENV[@]}" GIT_AUTHOR_DATE=$d GIT_COMMITTER_DATE=$d $REALGIT commit -q -m "$1" "${@:2}"; }
cmd() { # cmd DATE "msg" args - commit with explicit date (for ordering tests)
  "${CLEANENV[@]}" GIT_AUTHOR_DATE=$1 GIT_COMMITTER_DATE=$1 $REALGIT commit -q -m "$2" "${@:3}"; }
world() { # world NAME [nfollow]  => $S6/work/NAME/{origin.git,work,T,H,TIP}; branch BR = T -> H -> follow-ups (each edits handoff.md only)
  local w=$S6/work/$1 nf=${2:-0} i
  rm -rf "$w"; mkdir -p "$w"; N=0
  G init -q --bare -b main "$w/origin.git"
  G clone -q "$w/origin.git" "$w/work" 2>/dev/null
  ( cd "$w/work" || exit 1
    G checkout -q -b main; echo base > README; G add README; cm base; G push -q origin main
    G checkout -q -b "$BR"; mkdir -p docs; echo transfer > docs/t.md; G add docs; cm transfer; G rev-parse HEAD > ../T
    printf 'handoff v0\n' > handoff.md; G add handoff.md; cm handoff; G rev-parse HEAD > ../H
    for ((i=1;i<=nf;i++)); do printf 'handoff edit %s\n' $i >> handoff.md; G add handoff.md; cm "followup $i"; done
    G rev-parse HEAD > ../TIP; G push -q origin "$BR" ) || return 1
}
mkblock() { # mkblock OUTFILE T H CANON : copy block, substituting ONLY the values on the CANON=, T=, H= lines
  sed -e "s|^CANON=[^ ]*|CANON=$4|" -e "s|^T=[0-9a-f]*|T=$2|" -e "s|^H=[0-9a-f]*|H=$3|" "$BLOCK_ORIG" > "$1"
  local nd; nd=$(diff "$BLOCK_ORIG" "$1" | grep -c '^>')
  [ "$nd" = 3 ] || echo "WARNING: mkblock changed $nd lines (expected 3)" >&2
}
# runblock TAG WORLD [extra env assignments...] : run block in world's clone, hermetic env; save evidence/TAG.{out,err,rc}; set globals OUT ERR RC
runblock() {
  local tag=$1 w=$S6/work/$2; shift 2
  [ -f "$w/block.sh" ] || mkblock "$w/block.sh" "$(cat $w/T)" "$(cat $w/H)" "$w/origin"
  ( cd "$w/work" && "${CLEANENV[@]}" "$@" ${SHELLBIN:-bash} "$w/block.sh" ${BLOCKARGS} > "$S6/evidence/$tag.out" 2> "$S6/evidence/$tag.err"; echo $? > "$S6/evidence/$tag.rc" )
  RC=$(cat "$S6/evidence/$tag.rc"); OUT=$S6/evidence/$tag.out; ERR=$S6/evidence/$tag.err
}
verdict() { if grep -q '^PASS' "$OUT" && [ "$RC" = 0 ]; then echo PASS; else echo FAIL; fi; }
firstfail() { grep -m1 '^FAIL' "$OUT" | cut -c1-110; }
idx() { echo "$1 : $2" >> "$S6/evidence/INDEX.txt"; }
