. /tmp/claude-0/-home-claude/3adcc49e-2c16-5b57-97ab-65b038335fc4/scratchpad/a9/stage_S6/scripts/lib.sh
OUTSUM=$S6/evidence/F_summary.tsv; : > $OUTSUM
WRAP=$S6/wrap
row() { echo -e "$*" | tee -a $OUTSUM; }
mkspare() { # create commit X (child of TIP, edits handoff.md) on origin refs/heads/spare
  local w=$S6/work/$1; ( cd $w/work && G checkout -q --detach "$(cat ../TIP)" && echo "advance" >> handoff.md && G add handoff.md && cm advance && G push -q origin HEAD:refs/heads/spare && G rev-parse HEAD > ../X ) ; }
orig() { echo "$S6/work/$1/origin.git"; }
remote_tip() { G -C "$(orig $1)" rev-parse "refs/heads/$BR"; }
resetbr() { G -C "$(orig $1)" update-ref "refs/heads/$BR" "$(cat $S6/work/$1/TIP)"; rm -f $S6/work/$1/state/*; mkdir -p $S6/work/$1/state; }
W=f; world $W 1; mkspare $W; mkdir -p $S6/work/$W/state; T=$(cat $S6/work/$W/T); TIP=$(cat $S6/work/$W/TIP); X=$(cat $S6/work/$W/X)
ADV="git -C $(orig $W) update-ref refs/heads/$BR $X"; BACK="git -C $(orig $W) update-ref refs/heads/$BR $TIP"
ADVBIN="$S6/wrap/advance.sh"; printf '#!/usr/bin/bash\n/usr/bin/git -C %s update-ref refs/heads/%s %s\n' "$(orig $W)" "$BR" "$X" > $ADVBIN; chmod +x $ADVBIN
BACKBIN="$S6/wrap/back.sh"; printf '#!/usr/bin/bash\n/usr/bin/git -C %s update-ref refs/heads/%s %s\n' "$(orig $W)" "$BR" "$TIP" > $BACKBIN; chmod +x $BACKBIN
EW="PATH=$WRAP:/usr/bin:/bin WRAP_DIR=$S6/work/$W/state OBS_LOG=$S6/work/$W/state/obs"
row "row\tdescription\texpected\tobserved\trc\tfirst FAIL line / note"
# F01 baseline
resetbr $W; runblock F01 $W; row "F01\tbaseline, remote stable, 1 follow-up\tPASS\t$(verdict)\t$RC\t$(firstfail)"
# F02 remote moves right AFTER the final observation (before the block prints PASS)
resetbr $W; runblock F02 $W $EW ADV_LSR2_AFTER=$ADVBIN
row "F02\tremote moves immediately after the final ls-remote\tPASS (unavoidable)\t$(verdict)\t$RC\tremote tip after run=$(remote_tip $W | cut -c1-12) verified tip=$(echo $TIP | cut -c1-12); PASS line says: $(grep '^PASS' $OUT | grep -o 'remote tip [0-9a-f]*' )"
# F03 moves between first live observation and final observation
resetbr $W; runblock F03 $W $EW ADV_LSR1_AFTER=$ADVBIN; row "F03\tremote moves after 1st ls-remote, before final\tFAIL\t$(verdict)\t$RC\t$(firstfail)"
# F04 moves between fetch and 1st ls-remote
resetbr $W; runblock F04 $W $EW ADV_LSR1_BEFORE=$ADVBIN; row "F04\tremote moves between fetch and 1st ls-remote\tFAIL\t$(verdict)\t$RC\t$(firstfail)"
# F05 moves during structural checks (at git ls-tree)
resetbr $W; runblock F05 $W $EW ADV_ON_LSTREE=$ADVBIN; row "F05\tremote moves during structural checks\tFAIL\t$(verdict)\t$RC\t$(firstfail)"
# F06 A-B-A: away after 1st ls-remote, back before final one
resetbr $W; runblock F06 $W $EW ADV_LSR1_AFTER=$ADVBIN ADV_LSR2_BEFORE=$BACKBIN; row "F06\tremote moves away after 1st ls-remote and back before the final one (A-B-A)\tPASS (tip identical at final observation)\t$(verdict)\t$RC\t$(firstfail)"
# F07 delay: PASS timestamp vs time of final observation (ls-remote answer received), 3 s of latency on the return path
resetbr $W; rm -f $S6/work/$W/state/obs; runblock F07 $W $EW DELAY_LSR2_AFTER=3
obs=$(tail -1 $S6/work/$W/state/obs); pt=$(grep -o '^PASS at [^:]*:[^:]*:[^:]*' $OUT | sed 's/PASS at //'); pe=$(date -u -d "${pt%Z*}Z" +%s 2>/dev/null)
row "F07\t3 s delay after the final ls-remote answer is obtained, before it returns\tPASS\t$(verdict)\t$RC\tobservation epoch=${obs%.*}; PASS-line time=$pt (epoch $pe); gap ~$(( pe - ${obs%.*} )) s"
# F07b natural gap without delay, 10 repetitions: gap between end of final ls-remote and PASS timestamp (ms resolution via wrapper clock vs date)
gaps=""; for i in 1 2 3 4 5 6 7 8 9 10; do resetbr $W; rm -f $S6/work/$W/state/obs; runblock F07b $W $EW; o=$(tail -1 $S6/work/$W/state/obs); gaps="$gaps $(date -u +%s.%N | awk -v o=$o '{printf "%.3f", $1-o}')"; done
row "F07b\tnatural latency between observation and runblock end (upper bound of gap), 10 runs\tn/a\t$(verdict)\t$RC\tseconds after observation until process end:$gaps"
# F08 follow-up that destroys handoff.md content (empty file); and binary garbage; PASS expected because content is never read
for kind in empty garbage; do
  w=f08$kind; world $w 1; ( cd $S6/work/$w/work; if [ $kind = empty ]; then : > handoff.md; else head -c 300 /dev/urandom > handoff.md; fi; G add handoff.md; cm "rewrite handoff ($kind)"; G push -q origin HEAD:$BR; G rev-parse HEAD > ../TIP ); 
  runblock F08$kind $w; row "F08$kind\tlast follow-up replaces handoff.md content with $kind (path-only check)\tPASS (block does not read content)\t$(verdict)\t$RC\t$(grep -c '^follow-up' $OUT) follow-up line(s) printed: $(grep '^follow-up' $OUT | tail -1 | cut -c1-80)"
done
# F09 stdout closed: exit status vs PASS line
resetbr $W; ( cd $S6/work/$W/work && "${CLEANENV[@]}" bash $S6/work/$W/block.sh >&- 2>$S6/evidence/F09.err; echo $? > $S6/evidence/F09.rc ); row "F09\tstdout closed (>&-) on a verifying run\texit 0 only if PASS printed\tn/a\t$(cat $S6/evidence/F09.rc)\tstderr: $(head -c 150 $S6/evidence/F09.err | tr '\n' ' ')"
resetbr $W
