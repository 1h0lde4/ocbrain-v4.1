. /tmp/claude-0/-home-claude/3adcc49e-2c16-5b57-97ab-65b038335fc4/scratchpad/a9/stage_S6/scripts/lib.sh
world smoke 2 && runblock smoke smoke && echo "verdict=$(verdict) rc=$RC" && cat $OUT && echo ---ERR && cat $ERR | head
diff "$BLOCK_ORIG" $S6/work/smoke/block.sh
