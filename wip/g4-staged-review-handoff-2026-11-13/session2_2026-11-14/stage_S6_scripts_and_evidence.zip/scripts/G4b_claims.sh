. /tmp/claude-0/-home-claude/3adcc49e-2c16-5b57-97ab-65b038335fc4/scratchpad/a9/stage_S6/scripts/lib.sh
SUM=$S6/evidence/G4b_summary.tsv; : > $SUM; say() { printf '%s\n' "$*" | tee -a $SUM; }
w=$S6/work/g4c; rm -f $w/p4 $w/p5; 
python3 $S6/scripts/httpsd.py $w/srv tls $w/p4 $w/srv4.log noauth & A=$!
python3 $S6/scripts/httpsd.py $w/fork.git tls $w/p5 $w/srv5.log noauth & B=$!
python3 $S6/scripts/httpsd.py $w/srv tls $w/p1 $w/srv1b.log & C=$!
trap 'kill $A $B $C 2>/dev/null' EXIT; sleep 1.5; P4=$(cat $w/p4); P5=$(cat $w/p5); P1=$(cat $w/p1)
urow() { local tag=$1 url=$2 canon=$3 pre=$4; G -C $w/work config remote.origin.url "$url"; [ -n "$pre" ] && G -C $w/work update-ref -d refs/remotes/origin/$BR
  rm -f $w/block.sh; mkblock $w/block.sh "$(cat $w/T)" "$(cat $w/H)" "$canon"; runblock $tag g4c GIT_SSL_CAINFO=$S6/tls/c.pem
  local hit=NO; cat $S6/evidence/$tag.out $S6/evidence/$tag.err | grep -q 'DUMMYTOKEN' && hit=YES-TOKEN-IN-OUTPUT
  printf '%s\t%s\tverdict=%s\ttoken_in_output=%s\n' "$tag" "$url" "$(verdict)" "$hit" | tee -a $SUM
  grep -h 'DUMMYTOKEN' $S6/evidence/$tag.out $S6/evidence/$tag.err | sort -u | cut -c1-260 | sed 's/^/      LEAK-LINE: /' | tee -a $SUM; }
say "== git's own messages for non-accepted / accepted URL forms (no-auth TLS server on $P4 serving the canonical tree; dead port 1)"
urow W1 "https://127.0.0.1:$P4/org/repo.git?token=DUMMYTOKEN-xyz" "https://127.0.0.1:$P4/org/repo"
urow W2 "https://127.0.0.1:$P4/DUMMYTOKEN-xyz/repo.git" "https://127.0.0.1:$P4/org/repo"
urow W3 "https://127.0.0.1:1/org/repo.git?token=DUMMYTOKEN-xyz" "https://127.0.0.1:1/org/repo"
urow W4 "https://user:DUMMYTOKEN-xyz@127.0.0.1:$P4/org/repo.git" "https://127.0.0.1:$P4/org/repo" fresh
urow W5 "https://DUMMYTOKEN-xyz@127.0.0.1:$P4/org/repo.git" "https://127.0.0.1:$P4/org/repo" fresh
urow W6 "https://DUMMYTOKEN-xyz@127.0.0.1:$P1/org/repo.git" "https://127.0.0.1:$P1/org/repo" fresh
say ""; say "== fork-with-identical-history reached through look-alike URLs. canonical(auth) TLS port=$P1; fork (no-auth, repo at server root) TLS port=$P5"
: > $w/srv5.log; : > $w/srv1b.log
urow V1 "https://127.0.0.1:$P5#@127.0.0.1:$P1/org/repo.git" "https://127.0.0.1:$P1/org/repo" fresh
say "      requests to canonical server: $(grep -c '^REQ' $w/srv1b.log); requests to fork server: $(grep -c '^REQ' $w/srv5.log); first fork request: $(grep -m1 '^REQ' $w/srv5.log)"
cp $S6/evidence/V1.out $S6/evidence/V1.out.keep
: > $w/srv5.log; : > $w/srv1b.log
urow V3 "https://127.0.0.1:$P5\\@127.0.0.1:$P1/org/repo.git" "https://127.0.0.1:$P1/org/repo" fresh
say "      requests to canonical server: $(grep -c '^REQ' $w/srv1b.log); requests to fork server: $(grep -c '^REQ' $w/srv5.log); first request logged: $(grep -m1 '^REQ' $w/srv5.log) / $(grep -m1 '^REQ' $w/srv1b.log)"
G -C $w/work config remote.origin.url "$w/origin.git"
kill $A $B $C 2>/dev/null; wait 2>/dev/null; say done
