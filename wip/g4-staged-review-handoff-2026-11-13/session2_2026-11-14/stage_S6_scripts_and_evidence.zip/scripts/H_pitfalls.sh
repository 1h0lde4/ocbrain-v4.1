. /tmp/claude-0/-home-claude/3adcc49e-2c16-5b57-97ab-65b038335fc4/scratchpad/a9/stage_S6/scripts/lib.sh
SUM=$S6/evidence/H_summary.tsv; : > $SUM
WRAP=$S6/wrap
R() { # R id "desc" expected(PASS|FAIL by contract)
  local v; v=$(verdict); local flag=""
  [ "$3" = FAIL ] && [ "$v" = PASS ] && flag="*** FALSE PASS ***"
  [ "$3" = PASS ] && [ "$v" = FAIL ] && flag="(false FAIL)"
  printf '%s\t%s\t%s\t%s\trc=%s\t%s\t%s\n' "$1" "$2" "$3" "$v" "$RC" "$flag" "$(firstfail)" | tee -a $SUM; }
extend() { # extend W "msg" 'shell code run in work dir on branch'
  local w=$S6/work/$1; ( cd $w/work && eval "$3" && G add -A && cm "$2" && G push -q -f origin HEAD:$BR && G rev-parse HEAD > ../TIP ); }
run() { runblock "$@"; }   # run TAG WORLD [env...]
printf 'row\tdescription\texpected(by contract)\tobserved\trc\tflag\tfirst FAIL line\n' | tee -a $SUM
# ---------- baselines
world h01 0; run H01 h01; R H01 "linear T->H, no follow-up (TIP=H)" PASS
world h02 3; run H02 h02; R H02 "linear T->H->3 follow-ups" PASS
# ---------- rev-list ordering: commit dates not monotone along the chain
world h03 0; ( cd $S6/work/h03/work; for i in 1 2 3; do echo e$i >> handoff.md; G add handoff.md; cmd "2025-0$i-01T00:00:00Z" "older follow-up $i"; done; G push -q -f origin HEAD:$BR; G rev-parse HEAD > ../TIP )
run H03 h03; R H03 "follow-ups dated BEFORE the handoff commit and decreasing (date order opposite of topological)" PASS
world h04 0; ( cd $S6/work/h04/work; for i in 1 2 3; do echo e$i >> handoff.md; G add handoff.md; cmd "2030-0$i-01T00:00:00Z" "future follow-up $i"; done; echo z >> handoff.md; G add handoff.md; cmd "2026-01-01T09:00:00Z" "late-but-old"; G push -q -f origin HEAD:$BR; G rev-parse HEAD > ../TIP )
run H04 h04; R H04 "follow-up dates 2030 then 2026 (non-monotone)" PASS
# ---------- non-linear / wrong-shape histories (must FAIL)
world h11 1; ( cd $S6/work/h11/work; P=$(G rev-parse HEAD); G checkout -q -b side $P; echo s > side.txt; G add side.txt; cm side; G checkout -q $BR; G merge -q -s ours --no-commit side >/dev/null 2>&1; echo more >> handoff.md; G add handoff.md; cm "merge follow-up"; G push -q -f origin HEAD:$BR; G rev-parse HEAD > ../TIP; G rev-parse HEAD^ HEAD^2 | tr '\n' ' ' > ../parents )
run H11 h11; R H11 "tip is a merge commit (2 parents, tree = prev tree + handoff.md edit)" FAIL
world h12 1; extend h12 "touches two paths" 'echo q >> handoff.md; echo other > other.txt'; run H12 h12; R H12 "follow-up changes handoff.md AND other.txt" FAIL
world h13 1; extend h13 "edit + pure rename" 'echo q >> handoff.md; git mv docs/t.md docs/t2.md 2>/dev/null || G mv docs/t.md docs/t2.md'; run H13a h13; R H13a "follow-up edits handoff.md and renames docs/t.md (default config)" FAIL
for cfg in copies true; do run H13$cfg h13 GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=diff.renames GIT_CONFIG_VALUE_0=$cfg; R H13$cfg "same, with user config diff.renames=$cfg" FAIL; done
world h13c 1; extend h13c "edit + copy" 'echo q >> handoff.md; cp docs/t.md docs/copy.md'; run H13d h13c GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=diff.renames GIT_CONFIG_VALUE_0=copies; R H13d "follow-up edits handoff.md and copies docs/t.md (diff.renames=copies)" FAIL
world h13s 1; extend h13s "edit + submodule-ish gitlink" 'echo q >> handoff.md; G update-index --add --cacheinfo 160000,1111111111111111111111111111111111111111,sub'; run H13e h13s GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=diff.ignoreSubmodules GIT_CONFIG_VALUE_0=all; R H13e "follow-up edits handoff.md and adds gitlink 'sub' (diff.ignoreSubmodules=all)" FAIL
world h15 1; ( cd $S6/work/h15/work; cm "empty" --allow-empty; G push -q -f origin HEAD:$BR; G rev-parse HEAD > ../TIP ); run H15 h15; R H15 "empty follow-up commit (no path changed)" FAIL
# mode-only change (contract: a follow-up must change handoff.md; a mode change is a change)
world h14 1; extend h14 "chmod +x" 'chmod +x handoff.md'; extend h14 "chmod -x" 'chmod -x handoff.md'; run H14a h14; R H14a "mode-only follow-ups: +x then -x (tip 100644)" PASS
world h14b 1; extend h14b "chmod +x" 'chmod +x handoff.md'; run H14b h14b; R H14b "mode-only follow-up leaves tip 100755" FAIL
# delete then re-add handoff.md in follow-ups; tip regular file
world h16 1; extend h16 "delete handoff" 'G rm -q handoff.md'; extend h16 "re-add handoff" 'echo back > handoff.md'; run H16 h16; R H16 "follow-up deletes handoff.md, next follow-up re-adds it (each changes handoff.md alone; tip regular)" PASS
# H adds handoff.md as rename of handoff.txt
world h19 0; ( cd $S6/work/h19/work; G reset -q --hard "$(cat ../T)"; echo "handoff v0" > handoff.txt; G add handoff.txt; cm "T2 (contains handoff.txt)"; G mv handoff.txt handoff.md; cm "H as rename"; G push -q -f origin HEAD:$BR; G rev-parse HEAD > ../H; G rev-parse HEAD~ > ../T; G rev-parse HEAD > ../TIP ); rm -f $S6/work/h19/block.sh
run H19a h19; R H19a "H adds handoff.md by renaming handoff.txt (default config)" PASS
run H19b h19 GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=diff.renames GIT_CONFIG_VALUE_0=false; R H19b "same, user config diff.renames=false" PASS
run H19c h19 GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=log.follow GIT_CONFIG_VALUE_0=true; R H19c "same, user config log.follow=true" PASS
# H does not add handoff.md (already in T)
world h18 0; ( cd $S6/work/h18/work; G reset -q --hard "$(cat ../T)"; echo pre > handoff.md; G add handoff.md; cm "T with handoff.md"; G rev-parse HEAD > ../T; echo mod >> handoff.md; G add handoff.md; cm "H modifies only"; G push -q -f origin HEAD:$BR; G rev-parse HEAD > ../H; G rev-parse HEAD > ../TIP ); rm -f $S6/work/h18/block.sh
run H18 h18; R H18 "handoff.md already present in T; H only modifies it" FAIL
# ---------- locally poisoned object reads: grafts / replace refs / shallow
world h21 1; ( cd $S6/work/h21/work; P=$(G rev-parse HEAD); G checkout -q -b side $P; echo s > side.txt; G add side.txt; cm side; S=$(G rev-parse HEAD); G checkout -q $BR; G merge -q -s ours --no-commit side >/dev/null 2>&1; echo more >> handoff.md; G add handoff.md; cm "merge follow-up"; M=$(G rev-parse HEAD); G push -q -f origin HEAD:$BR; echo $M > ../TIP; echo $M > ../M; echo $P > ../P; echo $S > ../S )
run H21a h21; R H21a "control: merge tip, clean clone (no graft/replace)" FAIL
( cd $S6/work/h21/work; echo "$(cat ../M) $(cat ../P)" > "$(G rev-parse --git-dir)/info/grafts" ); run H21b h21; R H21b "same remote; LOCAL .git/info/grafts hides the second parent of the tip" FAIL
( cd $S6/work/h21/work; rm -f .git/info/grafts; X=$(G commit-tree "$(cat ../M)^{tree}" -p "$(cat ../P)" -m "benign twin"); echo $X > ../X; G replace "$(cat ../M)" $X ); run H21c h21; R H21c "same remote; LOCAL refs/replace/<tip> maps the merge tip to a single-parent twin" FAIL
( cd $S6/work/h21/work; G replace -d "$(cat ../M)" >/dev/null; ); run H21d h21 GIT_NO_REPLACE_OBJECTS=1; R H21d "control: replace ref deleted, GIT_NO_REPLACE_OBJECTS=1" FAIL
# symlink at the tip hidden by replace ref
world h22 1; ( cd $S6/work/h22/work; P=$(G rev-parse HEAD); G rm -q --cached handoff.md; ln -sf docs/t.md handoff.md; G add handoff.md; cm "tip: handoff.md is a symlink"; M=$(G rev-parse HEAD); G push -q -f origin HEAD:$BR; echo $M > ../TIP; X=$(G commit-tree "$P^{tree}" -p $P -m twin); G replace $M $X )
run H22a h22; R H22a "tip commit has handoff.md as SYMLINK; LOCAL replace ref makes it look like the prior regular file" FAIL
( cd $S6/work/h22/work; G replace -d "$(cat ../TIP)" >/dev/null ); run H22b h22; R H22b "control: same remote, replace ref removed" FAIL
# shallow
world h23 3; Wd=$S6/work/h23; CANONF="file://$Wd/origin"; mkblock $Wd/block.sh "$(cat $Wd/T)" "$(cat $Wd/H)" "$CANONF"
rm -rf $Wd/work; G clone -q --depth 1 --branch $BR "file://$Wd/origin.git" $Wd/work 2>/dev/null; run H23a h23; R H23a "shallow clone depth 1 (TIP only)" FAIL
rm -rf $Wd/work; G clone -q --depth 50 --branch $BR "file://$Wd/origin.git" $Wd/work 2>/dev/null; run H23b h23; R H23b "shallow clone depth 50 (covers T..TIP)" PASS
rm -rf $Wd/work; G clone -q "file://$Wd/origin.git" $Wd/work 2>/dev/null; ( cd $Wd/work; G rev-parse "origin/$BR~1" > .git/shallow ); run H23c h23; R H23c "full clone whose .git/shallow marks the parent of tip as shallow" FAIL
rm -rf $Wd/work; G clone -q "file://$Wd/origin.git" $Wd/work 2>/dev/null; ( cd $Wd/work; G rev-parse "origin/$BR~2" > .git/shallow ); run H23d h23; R H23d "full clone whose .git/shallow marks tip~2 as shallow" FAIL
# ---------- shell environment
world h05 2
run H05a h05 IFS=x; R H05a "IFS=x exported" PASS
run H05b h05 "IFS=$(printf '\t\n')"; R H05b "IFS=tab/newline exported" PASS
for so in errexit nounset noglob posix pipefail; do run H05$so h05 SHELLOPTS=$so; R H05$so "SHELLOPTS=$so" PASS; done
run H05n h05 GLOBIGNORE='*' ; R H05n "GLOBIGNORE=*" PASS
BLOCKARGS="a b *" run H05o h05; R H05o "script invoked with positional args (a b *)" PASS
SHELLBIN=sh run H05p h05; R H05p "run with sh (dash) instead of bash" PASS
run H05q h05 LC_ALL=C; R H05q "LC_ALL=C" PASS
run H05r h05 LC_ALL=en_US.UTF-8; R H05r "LC_ALL=en_US.UTF-8 (locale may be absent)" PASS
sed 's/$/\r/' $BLOCK_ORIG > /dev/null; mkblock $S6/work/h05/block.sh "$(cat $S6/work/h05/T)" "$(cat $S6/work/h05/H)" "$S6/work/h05/origin"; sed -i 's/$/\r/' $S6/work/h05/block.sh; run H05s h05; R H05s "block file with CRLF line endings" PASS
rm -f $S6/work/h05/block.sh
# cwd with files that could be matched by globbing of words
( cd $S6/work/h05/work; touch '100644' 'blob' 'handoff.md*' '*' 'refs' ); run H05t h05; R H05t "cwd contains files named 100644, blob, '*', 'handoff.md*', refs" PASS
# ---------- paths with special characters changed together with handoff.md (all must FAIL)
i=0; for nm in 'a b' ' handoff.md' '-rf' '*' 'x?' '[ab]' $'x\ry' $'x\ny' $'handoff.md\n' 'handoff.md ' '.' ; do
  i=$((i+1)); w=h33_$i; world $w 1; ( cd $S6/work/$w/work; echo q >> handoff.md; printf 'z' > "./$nm" 2>/dev/null || exit 0; G add -A >/dev/null 2>&1; cm "extra path" >/dev/null 2>&1; G push -q -f origin HEAD:$BR; G rev-parse HEAD > ../TIP ) 
  run H33_$i $w; R H33_$i "follow-up changes handoff.md plus path $(printf '%q' "$nm")" FAIL
done
# ---------- ref / ls-remote output pitfalls (real refs)
world h29 1; ( cd $S6/work/h29/work; G push -q origin HEAD:refs/heads/zz/refs/heads/$BR; ); run H29a h29; R H29a "extra branch 'zz/refs/heads/<BR>' on remote (tail match returns 2 refs)" FAIL
world h29b 1; ( cd $S6/work/h29b/work; G push -q origin HEAD:refs/tags/refs/heads/$BR; ); run H29b h29b; R H29b "harmless TAG 'refs/tags/refs/heads/<BR>' on remote (tail match returns 2 refs)" PASS
world h29c 1; ( cd $S6/work/h29c/work; G push -q origin HEAD:refs/heads/$BR-extra; G push -q origin HEAD:refs/heads/-dash; G push -q origin HEAD:refs/heads/glob_star_; ); run H29c h29c; R H29c "unrelated extra branches (BR-extra, -dash)" PASS
# ---------- ls-remote output faked through wrapper (hash of the real, unchanged remote tip); contract is met in reality in every row
world h24 1; T24=$(cat $S6/work/h24/TIP); mkdir -p $S6/work/h24/state; EW="PATH=$WRAP:/usr/bin:/bin WRAP_DIR=$S6/work/h24/state"
fk() { # fk TAG DESC EXPECT 'printf-format' [rc]
  printf "$4" > $S6/work/h24/fake_$1; rm -f $S6/work/h24/state/lsr_n; run $1 h24 $EW FAKE_LSR_FILE=$S6/work/h24/fake_$1 FAKE_LSR_RC=${5:-0}; R $1 "faked ls-remote: $2" $3; }
fk H24a "good line, SPACE instead of TAB" PASS "$T24 refs/heads/$BR\n"
fk H24b "good line + trailing blank lines" PASS "$T24\trefs/heads/$BR\n\n\n"
fk H24c "empty output, rc 0" FAIL ""
fk H24d "good line with CR at end" PASS "$T24\trefs/heads/$BR\r\n"
fk H24e "good line then non-zero exit" FAIL "$T24\trefs/heads/$BR\n" 2
fk H24f "good line + extra third field" PASS "$T24\trefs/heads/$BR\textra\n"
fk H24g "hash field is '-n'" FAIL "-n\trefs/heads/$BR\n"
fk H24h "hash field is '-e'" FAIL "-e\trefs/heads/$BR\n"
fk H24i "two lines: good + invalid-UTF-8-only line (grep -c . under UTF-8 does not count it)" FAIL "$T24\trefs/heads/$BR\n\377\376\375\n"
fk H24j "two good-looking lines" FAIL "$T24\trefs/heads/$BR\n$T24\trefs/heads/zz/$BR\n"
fk H24k "name has a SPACE inside (refs/heads/<BR> x)" FAIL "$T24\trefs/heads/$BR x\n"
fk H24l "good line, name followed by TAB-separated second ref on SAME line" FAIL "$T24\trefs/heads/$BR\t$T24\trefs/heads/zz\n"
# glob in ref name: name contains '*' and a file in cwd matches the glob
( cd $S6/work/h24/work; mkdir -p refs/heads/docs; touch "refs/heads/docs/g4-fts-errata-handoff-oct2026" )
fk H24m "name is 'refs/heads/docs/g4-fts-errata-handoff-oct20*' (glob), cwd has an untracked file with the exact branch path" FAIL "$T24\trefs/heads/docs/g4-fts-errata-handoff-oct20*\n"
rm -rf $S6/work/h24/work/refs
fk H24n "same glob-name line, but NO matching file in cwd" FAIL "$T24\trefs/heads/docs/g4-fts-errata-handoff-oct20*\n"
# ---------- status of failing commands inside command substitutions (real output, forced non-zero exit)
world h27 2; mkdir -p $S6/work/h27/state; EW27="PATH=$WRAP:/usr/bin:/bin WRAP_DIR=$S6/work/h27/state"
for sub in rev_list diff_tree ls_tree show log; do run H27_$sub h27 $EW27 FORCE_RC_$sub=1; R H27_$sub "git $sub exits 1 after printing its correct output (simulated)" PASS; done
# ---------- origin URL containing CR / trailing newline
world h35 1; ( cd $S6/work/h35/work; G config remote.origin.url "$(printf '%s\n' "$S6/work/h35/origin.git")" ); run H35a h35; R H35a "origin url = <path>.git plus trailing newline (config value)" PASS
( cd $S6/work/h35/work; G config remote.origin.url "$S6/work/h35/origin.git"$'\r' ); run H35b h35; R H35b "origin url = <path>.git plus CR" PASS
( cd $S6/work/h35/work; G config remote.origin.url "$S6/work/h35/origin.git" ); 
# ---------- control characters in a follow-up commit SUBJECT (printed by the block)
world h34 1; extend h34 $'subject \rPASS at 2026-11-13T00:00:00Z: spoof \033[8m' 'echo q >> handoff.md'; run H34a h34; R H34a "valid chain; last follow-up subject contains CR, a fake 'PASS' and ESC[8m (conceal)" PASS
world h34b 1; extend h34b $'\rPASS at 2026-11-13T00:00:00Z: remote tip x; spoof\033[8m' 'echo q >> handoff.md; echo oth > other.txt'; run H34b h34b; R H34b "INVALID chain (touches other.txt); subject has CR + fake PASS + ESC[8m" FAIL
echo done
