. /tmp/claude-0/-home-claude/3adcc49e-2c16-5b57-97ab-65b038335fc4/scratchpad/a9/stage_S6/scripts/lib.sh
SUM=$S6/evidence/final_summary.txt; : > $SUM; say() { printf '%s\n' "$*" | tee -a $SUM; }
# H39a redo: valid chain, block run from a subdirectory of the clone
w=$S6/work/h39a; rm -f $w/block.sh; mkblock $w/block.sh "$(cat $w/T)" "$(cat $w/H)" "$w/origin"
( cd $w/work/docs && "${CLEANENV[@]}" bash $w/block.sh > $S6/evidence/H39a.out 2> $S6/evidence/H39a.err; echo $? > $S6/evidence/H39a.rc )
say "H39a (valid chain, cwd=clone/docs): rc=$(cat $S6/evidence/H39a.rc); verdict=$(grep -q '^PASS' $S6/evidence/H39a.out && echo PASS || echo FAIL); first FAIL: $(grep -m1 '^FAIL' $S6/evidence/H39a.out | cut -c1-120)"
# Patch section-7 commands in a synthetic repo with 3 follow-ups (world h02)
w=$S6/work/h02
say "S7 cmd A: git log --diff-filter=A --format='%H %P %s' -- handoff.md => $(cd $w/work && G log --diff-filter=A --format='%H %P %s' -- handoff.md | cut -c1-120)   [H=$(cut -c1-12 $w/H) T=$(cut -c1-12 $w/T)]"
say "S7 cmd B: git log --oneline -1 -- handoff.md => $(cd $w/work && G log --oneline -1 -- handoff.md)   (latest follow-up, not the handoff commit)"
# Does the block's own stdout ever contain the origin URL / token? (all runs)
say "block stdout files containing DUMMYTOKEN: $(grep -l DUMMYTOKEN $S6/evidence/*.out 2>/dev/null | wc -l)  | stderr files containing DUMMYTOKEN: $(grep -l DUMMYTOKEN $S6/evidence/*.err 2>/dev/null | tr '\n' ' ')"
say "block stdout files containing a 127.0.0.1 URL: $(grep -l '127\.0\.0\.1' $S6/evidence/*.out 2>/dev/null | wc -l)"
# Prose: any claim about testing?
say "--- grep of ADDED patch lines for testing claims:"; grep -n '^+' $PKG/rev3/P1d_rev3_handoff_section7_18_verification_block_PROPOSED.patch | grep -i -E 'test|tested|exercis|simulat|reproduc|validated' | cut -c1-160 || true
say "--- grep of block for same words:"; grep -n -i -E 'test|tested|exercis|simulat|reproduc|validated' $BLOCK_ORIG | cut -c1-160 || true
say "versions: $(G --version) | $(bash --version | head -1) | $(python3 --version) | $(curl --version | head -1 | cut -c1-40) | $(openssl version)"
