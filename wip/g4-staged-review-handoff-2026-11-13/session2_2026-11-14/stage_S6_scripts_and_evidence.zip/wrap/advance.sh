#!/usr/bin/bash
/usr/bin/git -C /tmp/claude-0/-home-claude/3adcc49e-2c16-5b57-97ab-65b038335fc4/scratchpad/a9/stage_S6/work/f/origin.git update-ref refs/heads/docs/g4-fts-errata-handoff-oct2026 655e512ac0a771d0379bb484e095f95d94450795
