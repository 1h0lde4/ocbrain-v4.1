"""
core/memory/sqlite_guard.py — the ONE reviewed SQLite connection factory
(R5-01 §2.5-§2.8).

Every application-managed SQLite connection in OCBrain is created through
:func:`open_database`.  The factory

  * builds the open target with the canonical URI constructor
    (:func:`core.memory.sqlite_contract.sqlite_file_uri`), so no raw path
    is ever concatenated into a ``file:`` URI;
  * installs a composed SQLite authorizer policy that DENIES every
    ``SQLITE_ATTACH`` operation — the default policy is "no attachment",
    and no reviewed application requirement exists for one;
  * applies the defence-in-depth connection configuration that the runtime
    ACTUALLY exposes, and records what was applied (a configuration that
    could not be set is never assumed);
  * keeps the loadable-extension surface closed.

WHY AN AUTHORIZER AND NOT A STRING CHECK
-----------------------------------------
``SQLITE_ATTACH`` is authorizer action code 24.  The authorizer is called
during statement preparation, so the denial happens BEFORE the destination
file is opened or created.  A SQL-text prefix or regular-expression check
would be defeated by a comment, an expression, a bound parameter or a
different statement form, so it is NOT used.

The authorizer is installed on the freshly created connection, i.e. BEFORE
any application SQL is prepared.  The connection class overrides
``set_authorizer`` so that a LATER registration by application code
replaces the callback but does NOT remove the policy: the caller's
callback is composed with the policy, and the policy is evaluated first.

MEASURED RUNTIME FACTS (the interpreter this repository is verified on)
------------------------------------------------------------------------
  SQLite 3.50.4, source id
  ``2025-07-30 19:33:53 4d8adfb30e03f9cf27f800a2c1ba3c48fb4ca1b08b0f5ed59a4d5ecbf45e20a3``
  * ``SQLITE_ATTACH`` is action code 24.
  * ``VACUUM INTO`` DOES report ``SQLITE_ATTACH`` (24) on this runtime, so
    the unconditional denial covers it as well.
  * ``ATTACH DATABASE (<expression>)`` reports action 24 with a NULL
    filename argument — the denial must not depend on the filename text.
  * ``SQLITE_DBCONFIG_ENABLE_ATTACH_CREATE`` / ``..._ATTACH_WRITE`` are NOT
    exposed by CPython's ``sqlite3`` module: the authorizer is the only
    COMPLETE control, and the DBCONFIG options would not have been
    sufficient even if they were.

LIMITATION
----------
The authorizer is a statement-level control.  It does not prevent the
Online Backup API from copying INTO a connection that was obtained
elsewhere; both ends of a backup must be created through this factory
(the inventory in
``docs/reports/independent-g4-fts/remediation5/B_DATABASE_ACCESS_ROUTE_INVENTORY.md``
records the audited backup sites).
"""
from __future__ import annotations

import sqlite3
import threading
from typing import Any, Callable, Dict, List, Optional

#: Authorizer action code for ``SQLITE_ATTACH`` (and, on the shipped
#: runtime, for ``VACUUM INTO``).
SQLITE_ATTACH_ACTION = 24

SQLITE_OK = getattr(sqlite3, "SQLITE_OK", 0)
SQLITE_DENY = getattr(sqlite3, "SQLITE_DENY", 8)

__all__ = [
    "open_database",
    "install_connection_guard",
    "denied_sql_operations",
    "reset_denied_sql_operations",
    "guard_status",
    "SQLITE_ATTACH_ACTION",
]


class _GuardState:
    """The audit trail of denied SQL operations."""

    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.denied: List[Dict[str, Any]] = []


_STATE = _GuardState()


def denied_sql_operations() -> List[Dict[str, Any]]:
    """The SQL operations the policy denied (audit trail)."""
    with _STATE.lock:
        return list(_STATE.denied)


def reset_denied_sql_operations() -> None:
    """Clear the audit trail (used by tests)."""
    with _STATE.lock:
        _STATE.denied.clear()


def _attach_denial_policy(action, arg1, arg2, dbname, trigger) -> int:
    """
    The authorizer policy.

    ``SQLITE_ATTACH`` is denied unconditionally.  The decision is based on
    the ACTION CODE, never on the filename text: an expression-based
    attachment reports a NULL filename argument on this runtime, and a
    ``VACUUM INTO`` destination is reported as an attachment too.
    """
    if action == SQLITE_ATTACH_ACTION:
        with _STATE.lock:
            _STATE.denied.append({
                "action": int(action),
                "action_name": "SQLITE_ATTACH",
                "arg1": None if arg1 is None else str(arg1),
                "arg2": None if arg2 is None else str(arg2),
                "dbname": None if dbname is None else str(dbname),
                "arg1_is_null": arg1 is None,
            })
        return SQLITE_DENY
    return SQLITE_OK


_FACTORIES: Dict[int, type] = {}


def _guarded_factory(base: Optional[type]) -> type:
    """
    Build (and cache) a connection class that composes the attach-denial
    policy into every authorizer registration.

    ``sqlite3.Connection`` is an immutable extension type, so the policy
    cannot be attached to the type itself; it is attached through the
    ``factory`` argument of ``sqlite3.connect`` instead.
    """
    base_type = base if base is not None else sqlite3.Connection
    if not (isinstance(base_type, type)
            and issubclass(base_type, sqlite3.Connection)):
        base_type = sqlite3.Connection
    cached = _FACTORIES.get(id(base_type))
    if cached is not None:
        return cached

    class GuardedConnection(base_type):                # type: ignore[misc,valid-type]
        """A connection whose authorizer can never be un-guarded."""

        _ocbrain_guarded = True

        def set_authorizer(self, callback):
            def composed(action, arg1, arg2, dbname, trigger):
                decision = _attach_denial_policy(action, arg1, arg2, dbname,
                                                 trigger)
                if decision == SQLITE_DENY:
                    return decision
                if callback is None:
                    return SQLITE_OK
                result = callback(action, arg1, arg2, dbname, trigger)
                # CPython interprets a non-integer return value as a
                # denial; normalise it.
                return SQLITE_OK if result is None else result

            return base_type.set_authorizer(self, composed)

    GuardedConnection.__name__ = "Guarded" + getattr(base_type, "__name__",
                                                      "Connection")
    GuardedConnection.__qualname__ = GuardedConnection.__name__
    _FACTORIES[id(base_type)] = GuardedConnection
    return GuardedConnection


def _apply_dbconfig(conn) -> Dict[str, Any]:
    """
    Defence-in-depth connection configuration.

    Only options the runtime ACTUALLY exposes are set; the result records
    what took effect.  The attachment DBCONFIG options are reported as
    unavailable — they are not silently assumed.
    """
    applied: Dict[str, Any] = {}
    name = "SQLITE_DBCONFIG_ENABLE_LOAD_EXTENSION"
    if hasattr(sqlite3, name) and hasattr(conn, "setconfig"):
        try:
            conn.setconfig(getattr(sqlite3, name), False)
            applied[name] = True
        except sqlite3.Error as exc:
            applied[name] = f"FAILED: {exc}"
    else:
        applied[name] = "NOT_EXPOSED_BY_THIS_PYTHON"
    for absent in ("SQLITE_DBCONFIG_ENABLE_ATTACH_CREATE",
                   "SQLITE_DBCONFIG_ENABLE_ATTACH_WRITE"):
        applied[absent] = "NOT_EXPOSED_BY_THIS_PYTHON"
    return applied


def _apply_limits(conn) -> Dict[str, Any]:
    """Lower the attached-database limit where the runtime supports it."""
    applied: Dict[str, Any] = {}
    if hasattr(conn, "setlimit") and hasattr(sqlite3, "SQLITE_LIMIT_ATTACHED"):
        try:
            conn.setlimit(sqlite3.SQLITE_LIMIT_ATTACHED, 0)
            applied["SQLITE_LIMIT_ATTACHED"] = conn.getlimit(
                sqlite3.SQLITE_LIMIT_ATTACHED)
        except sqlite3.Error as exc:
            applied["SQLITE_LIMIT_ATTACHED"] = f"FAILED: {exc}"
    else:
        applied["SQLITE_LIMIT_ATTACHED"] = "NOT_SUPPORTED"
    return applied


def install_connection_guard(conn) -> Dict[str, Any]:
    """
    Install the connection-level guard on a freshly created connection.

    The authorizer is installed BEFORE any application SQL is prepared
    (the connection has just been created, so no statement exists yet).
    """
    info: Dict[str, Any] = {}
    conn.set_authorizer(_attach_denial_policy)
    info["authorizer_installed"] = True
    info["dbconfig"] = _apply_dbconfig(conn)
    info["limits"] = _apply_limits(conn)
    if hasattr(conn, "enable_load_extension"):
        try:
            conn.enable_load_extension(False)
            info["load_extension_enabled"] = False
        except sqlite3.Error as exc:
            info["load_extension_enabled"] = f"FAILED: {exc}"
    return info


def guard_status() -> Dict[str, Any]:
    """A summary of the guard configuration (for evidence and audits)."""
    return {
        "sqlite_version": getattr(sqlite3, "sqlite_version", None),
        "attach_action_code": SQLITE_ATTACH_ACTION,
        "denied_operation_count": len(denied_sql_operations()),
        "policy": "no attachment; the SQLITE_ATTACH action is denied "
                  "unconditionally",
    }


def open_database(target: Any, *,
                  mode: Optional[str] = None,
                  timeout: Optional[float] = 20.0,
                  check_same_thread: bool = True,
                  factory: Optional[type] = None,
                  row_factory: Optional[Any] = None,
                  detect_types: int = 0,
                  cached_statements: Optional[int] = 128,
                  guard: bool = True) -> sqlite3.Connection:
    """
    The single reviewed SQLite connection factory.

    ``mode``
        ``"ro"``, ``"rw"`` or ``"rwc"`` — the open is then performed through
        the canonical URI constructor.  ``None`` keeps the ordinary
        path semantics of the original call site (which may create the
        file).
    """
    kwargs: Dict[str, Any] = {"check_same_thread": check_same_thread}
    if timeout is not None:
        kwargs["timeout"] = timeout
    if detect_types:
        kwargs["detect_types"] = detect_types
    if cached_statements is not None:
        kwargs["cached_statements"] = cached_statements
    kwargs["factory"] = _guarded_factory(factory)

    if mode is None:
        open_target: Any = target
    else:
        from core.memory.sqlite_contract import sqlite_file_uri
        open_target = sqlite_file_uri(str(target), mode)
        kwargs["uri"] = True

    conn = sqlite3.connect(open_target, **kwargs)
    try:
        if guard:
            install_connection_guard(conn)
        if row_factory is not None:
            conn.row_factory = row_factory
    except BaseException:
        try:
            conn.close()
        except sqlite3.Error:
            pass
        raise
    return conn
