"""
tests/conftest.py — test-environment setup and the F24 production boundary.

Two things happen here, and the ORDER matters:

  1. **A temporary memory path is established BEFORE any OCBrain module is
     imported** (`OCBRAIN_MEMORY_DIR`). The memory, cognitive-vault and
     graph-engine singletons construct their backing store at IMPORT time
     with a production default; replacing the singleton afterwards is too
     late. With the variable set, those imports build their stores under a
     temporary directory instead.

  2. **The production-access boundary is installed** — it PREVENTS access to
     the production memory directory and the production configuration files
     (it raises before the access happens) and is inherited by child
     processes through a generated `sitecustomize.py` on PYTHONPATH.

Both are installed at conftest IMPORT time, i.e. BEFORE pytest collects
(and therefore before it imports) any test module and before the
orchestrator/worker import chains run. A failed boundary installation
aborts the test run instead of degrading to "detection afterwards".

R5-01 / §7: the boundary is ALSO installed by the protected launcher
(`tests/run_g4_protected_pytest.py`) BEFORE pytest itself is imported, so
an import-time database open is already blocked when a plugin or an
`__init__` module runs.  Both entry points share `tests/_g4_bootstrap.py`,
so the two can never drift.

R5-01 / §0.4: the detection harness below no longer inspects the
production memory directory.  Stat-ing a production database is itself a
forbidden inspection, so the harness now runs against a SYNTHETIC
protected root with the production directory's layout; the prevention
boundary protects the production directory by PATH and never opens,
reads, hashes, stats or timestamps it.  The Round-4 evidence (which did
take production fingerprints) remains the historical record.

The Rev 3 runtime gate still defaults to "enforce", which refuses
memory-backend construction on an affected runtime (the one bundled with
this interpreter is affected — see
docs/reports/G4_FTS_REV3_REMEDIATION_REPORT.md). The whole test suite must
still run: it acknowledges the runtime EXPLICITLY. Under "acknowledge" the
gate never lies: every readiness report stays
`ready_degraded_runtime_not_supported` with memory_ready=False, and the
dedicated runtime-gate tests below remove the variable to prove the
refusal itself.

THIS IS A TEST-ENV-ONLY setting. It is NOT a production recommendation:
production must either upgrade the runtime, install a documented backport,
or register verified vendor-build provenance (Amendment 1 —D / report —R1).
"""
import os
import pathlib
import sys
import tempfile

import pytest

# Ensure the root directory is in the python path for absolute imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# ── F24 step 1 + 2: temporary memory path and the PREVENTION boundary ──────
#
# The shared bootstrap does exactly what the protected launcher does, in
# the same order, so the two entry points cannot drift.  It installs the
# boundary BEFORE any OCBrain import and exports the protected paths to
# every child interpreter (through a generated sitecustomize.py).
import importlib.util  # noqa: E402

_BOOTSTRAP_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               "_g4_bootstrap.py")
_spec = importlib.util.spec_from_file_location("g4_bootstrap", _BOOTSTRAP_PATH)
_g4_bootstrap = importlib.util.module_from_spec(_spec)
sys.modules["g4_bootstrap"] = _g4_bootstrap
_spec.loader.exec_module(_g4_bootstrap)

_PROTECTION_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                 "_g4_protection.py")
_pspec = importlib.util.spec_from_file_location("g4_protection",
                                                _PROTECTION_PATH)
_g4_protection = importlib.util.module_from_spec(_pspec)
sys.modules["g4_protection"] = _g4_protection
_pspec.loader.exec_module(_g4_protection)

_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

# The SYNTHETIC protected root: it mirrors the production layout
# (<root>/memory/<db> plus the companion sidecars) and is registered with
# the boundary as a DATA root, so the prevention boundary and the
# detection harness can both be exercised WITHOUT touching production.
_SYNTHETIC_PROTECTED_DIR = tempfile.mkdtemp(prefix="ocbrain-test-protected-")
os.makedirs(os.path.join(_SYNTHETIC_PROTECTED_DIR, "memory"), exist_ok=True)

_BOOTSTRAP_INFO = _g4_bootstrap.prepare(
    extra_protected=[_SYNTHETIC_PROTECTED_DIR],
    extra_data_roots=[os.path.join(_SYNTHETIC_PROTECTED_DIR, "memory")],
)
_PROTECTED_PATHS = list(_BOOTSTRAP_INFO["protected_paths"])


# ── F24 secondary net: the detection harness (defence in depth) ─────────────
#
# The prevention boundary is the primary control; this harness is the
# backstop for anything that bypasses the patched entry points (a C-level
# write, a library that opens the file through another API). It compares
# (size, mtime_ns) — a same-size write is invisible to a size-only check.
#
# R5-01: it runs against the SYNTHETIC protected root. The production
# memory directory is NOT scanned: stat-ing a production database is a
# forbidden inspection.
_PROD_MEMORY_DIR = os.path.join(_REPO_ROOT, ".data", "memory")
_SYNTHETIC_MEMORY_DIR = os.path.join(_SYNTHETIC_PROTECTED_DIR, "memory")


def _prod_memory_snapshot(directory=None):
    """(path -> (size, mtime_ns)) of every file under the given directory.

    The directory is a parameter so the fingerprint can be exercised
    against a temporary directory (a test must never write under
    .data/memory to prove the guard works)."""
    snap = {}
    root = os.path.abspath(directory or _SYNTHETIC_MEMORY_DIR)
    for dirpath, _dirnames, filenames in os.walk(root):
        for name in filenames:
            p = os.path.join(dirpath, name)
            try:
                st = os.stat(p)
                snap[p] = (st.st_size, st.st_mtime_ns)
            except OSError:
                snap[p] = None
    return snap


@pytest.fixture(autouse=True)
def _no_production_memory_access():
    """
    REV-G4-07.D detection harness: fails ANY test that creates, deletes,
    resizes OR MODIFIES a file under the protected synthetic memory
    directory. Files are only stat-ed — never opened.

    The PRODUCTION directory is deliberately not scanned (R5-01 / §0.4):
    inspecting it would itself be a forbidden production access. The
    production directory is protected by the prevention boundary, which
    rejects an access BEFORE any filesystem operation against it.
    """
    before = _prod_memory_snapshot()
    yield
    after = _prod_memory_snapshot()
    changed = {p: (before.get(p), after.get(p))
               for p in set(before) | set(after)
               if before.get(p) != after.get(p)}
    if changed:
        raise AssertionError(
            "REV-G4-07.D violation: the test session modified the "
            f"protected synthetic memory directory: {changed!r}. "
            "Tests must use isolated temporary databases (explicit "
            "tmp_path / --db), never the configured production paths.")


@pytest.fixture(autouse=True)
def _isolated_config_dir(tmp_path, monkeypatch):
    """
    The configuration a test exercises is a COPY in a temporary directory.

    `core.config.set()` / `set_module_state()` persist the settings they
    change straight back to `config/settings.toml` (and `models.toml`) — so
    a test that flips a setting rewrote the PRODUCTION configuration file.
    With the copy in place the write lands in the temporary directory and
    the repository's configuration is never modified by a test run
    (F24 / section 10, "protect production TOML files").

    The in-memory settings the config object already loaded are unchanged,
    so tests keep asserting against the real values.
    """
    import core.config as core_config

    # The copy lives in its OWN directory (not under tmp_path): a test that
    # asserts "nothing else was written under tmp_path" must not see it.
    target = pathlib.Path(tempfile.mkdtemp(prefix="ocbrain-test-config-"))
    target.mkdir(exist_ok=True)
    for name in ("settings.toml", "models.toml", "sources.toml",
                 "settings.yaml", "user_prefs.yaml"):
        src = os.path.join(_REPO_ROOT, "config", name)
        if os.path.exists(src):
            try:
                with open(src, "rb") as fh:
                    (target / name).write_bytes(fh.read())
            except OSError:
                pass
    monkeypatch.setattr(core_config, "CONFIG_DIR", target)
    return target


@pytest.fixture
def temp_data_dir(tmp_path):
    """
    Provides a temporary directory for tests that need to write to disk.
    """
    return str(tmp_path)


@pytest.fixture
def enforce_runtime_gate(monkeypatch):
    """
    Remove the suite-wide acknowledgement so a test can observe the default
    fail-closed behavior (constructor raises
    MemoryRuntimeCompatibilityError on an affected runtime).
    """
    monkeypatch.delenv("OCBRAIN_MEMORY_RUNTIME_ACK", raising=False)
    return monkeypatch


@pytest.fixture
def synthetic_protected_root():
    """The synthetic protected root registered with the boundary."""
    return _SYNTHETIC_PROTECTED_DIR
