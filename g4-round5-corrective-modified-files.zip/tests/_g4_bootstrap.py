"""
tests/_g4_bootstrap.py — the shared test-environment bootstrap (R5-01 §7).

Both the protected launcher (``tests/run_g4_protected_pytest.py``) and the
pytest ``conftest.py`` use THIS module, so the protection boundary can
never drift between the two entry points.

It performs, in this order:

  1. ``OCBRAIN_MEMORY_DIR`` -> a fresh temporary directory, so the
     import-time singletons (memory, cognitive vault, graph engine) build
     their backing store OUTSIDE the production directory;
  2. the protection boundary installation (see ``tests/_g4_protection.py``)
     — it MUST succeed, otherwise the caller fails closed;
  3. the export of the protected paths and the generation of the
     ``sitecustomize.py`` that installs the SAME boundary in every child
     Python interpreter BEFORE the child's own imports;
  4. the verification that the boundary is actually ACTIVE.

NO PRODUCTION FILE IS TOUCHED.  The boundary decides by PATH; it never
opens, reads, hashes, stats or timestamps a protected path.
"""
from __future__ import annotations

import os
import sys
import tempfile
from typing import Dict, List, Optional

PROTECTION_MODULE = "_g4_protection"


def repo_root() -> str:
    """The repository root (the parent of the ``tests`` directory)."""
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _load_protection():
    """Load ``tests/_g4_protection.py`` by path (no package import)."""
    import importlib.util
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "_g4_protection.py")
    spec = importlib.util.spec_from_file_location(PROTECTION_MODULE, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[PROTECTION_MODULE] = module
    spec.loader.exec_module(module)
    return module


def install_child_sitecustomize() -> str:
    """
    Generate the ``sitecustomize.py`` that installs the boundary in every
    child interpreter.

    ``sitecustomize`` is imported by the interpreter at start-up, BEFORE
    the child's own imports — so a child that imports project code cannot
    open a database before the boundary is installed.  A failure to
    install is NOT swallowed: the child fails CLOSED.
    """
    directory = tempfile.mkdtemp(prefix="ocbrain-test-sitecustomize-")
    target = os.path.join(directory, "sitecustomize.py")
    lines = [
        '"""Auto-generated child-process protection bootstrap."""',
        "import os",
        "import sys",
        "try:",
        "    import _g4_protection",
        "    _g4_protection.install_from_env()",
        "except BaseException as exc:",
        "    sys.stderr.write(",
        "        'OCBRAIN G4 PROTECTION: the production-access boundary "
        "could NOT be installed in this child process: %r\\n' % (exc,))",
        "    sys.stderr.flush()",
        "    os._exit(70)",
        "",
    ]
    with open(target, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))
    return directory


def _extend_pythonpath(*entries: str) -> None:
    current = os.environ.get("PYTHONPATH", "")
    parts = [p for p in current.split(os.pathsep) if p]
    for entry in entries:
        if entry and entry not in parts:
            parts.insert(0, entry)
    os.environ["PYTHONPATH"] = os.pathsep.join(parts)


def prepare(memory_dir: Optional[str] = None,
            extra_protected: Optional[List[str]] = None,
            extra_data_roots: Optional[List[str]] = None) -> Dict[str, object]:
    """
    Prepare the protected test environment.  Raises on any failure — the
    caller MUST fail closed.
    """
    root = repo_root()
    if root not in sys.path:
        sys.path.insert(0, root)

    # The Rev 3 runtime gate still defaults to "enforce"; the suite
    # acknowledges the affected runtime EXPLICITLY (see conftest.py).
    os.environ.setdefault("OCBRAIN_MEMORY_RUNTIME_ACK", "acknowledge")

    # The import-time singletons build their backing store under this
    # directory instead of the production one.
    if memory_dir is None:
        memory_dir = tempfile.mkdtemp(prefix="ocbrain-test-memory-")
    os.environ["OCBRAIN_MEMORY_DIR"] = memory_dir

    protection = _load_protection()
    # The repository whose PRODUCTION paths are protected.  It defaults to
    # the tree under test, but a campaign that runs a baseline state from a
    # temporary export must still protect the REAL production paths — the
    # temporary tree is scratch space, not production.
    production_root = os.environ.get("OCBRAIN_PROTECTED_ROOT") or root
    protected = list(protection.protected_paths_for(production_root))
    protected.extend(extra_protected or [])
    protection.install(protected,
                       extra_data_roots=list(extra_data_roots or []))
    protection.export_for_children(protected,
                                   data_roots=list(extra_data_roots or []))

    sitecustomize_dir = install_child_sitecustomize()
    _extend_pythonpath(sitecustomize_dir,
                       os.path.join(root, "tests"))

    if not protection.guard_active():
        raise RuntimeError(
            "the G4 production-access boundary did not install — refusing "
            "to run the suite without protection")

    import sqlite3
    if not protection.connector_is_wrapped():
        raise RuntimeError(
            "the G4 production-access boundary did not wrap sqlite3.connect "
            "— refusing to run the suite without protection")

    return {
        "repo_root": root,
        "memory_dir": memory_dir,
        "protected_paths": list(protected),
        "sitecustomize_dir": sitecustomize_dir,
        "identity_mechanism": protection.identity_mechanism(),
        "guard_active": True,
    }


def child_environment() -> List[str]:
    """The environment variables a child process needs to inherit."""
    return [
        "OCBRAIN_PROTECTED_PATHS",
        "OCBRAIN_TEST_ALLOW_CONFIG_WRITE",
        "OCBRAIN_MEMORY_DIR",
        "OCBRAIN_MEMORY_RUNTIME_ACK",
        "PYTHONPATH",
    ]
