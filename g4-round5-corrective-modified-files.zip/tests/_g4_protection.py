"""
tests/_g4_protection.py — process-level protection of production data
(F24/W20) and of the SQLite access surface (R5-01).

WHAT THIS MODULE IS
--------------------
An application-level **defence-in-depth** boundary that runs INSIDE the
Python process.  It is *not* an operating-system sandbox and it is *not*
race-free (see LIMITATIONS).

It has three jobs:

 1. **Production data protection (F24/W20).**  The configured production
    memory directory and the production configuration files are protected
    against read/write/create/delete/rename through the patched entry
    points (``sqlite3.connect``, ``builtins.open``, ``io.open``,
    ``os.open``, ``pathlib.Path.open``, ``os.mkdir``/``makedirs``,
    ``os.remove``/``unlink``/``rename``/``replace`` and the ``shutil``
    copy/move/remove helpers).

 2. **Strict SQLite URI semantics (R5-01 §2.2).**  The protection decision
    must be made about the path SQLite will ACTUALLY open.  The boundary
    therefore implements the URI structure (scheme / authority / path /
    query / fragment) with the measured semantics of the shipped runtime
    and applies a STRICT query-parameter allowlist.

 3. **Complete database-access protection (R5-01 §2.4-§2.8).**  The boundary
    also denies every ``SQLITE_ATTACH`` operation (which on this runtime
    also covers ``VACUUM INTO``) through the SQLite authorizer, protects
    the companion sidecar namespace (``-wal`` / ``-shm`` / ``-journal``)
    against direct opens, disables loadable extensions and lowers the
    attached-database limit — and does all of that BEFORE the underlying
    connector is reached.

MEASURED RUNTIME FACTS (the interpreter this repository is verified on)
------------------------------------------------------------------------
  Python 3.14.3 (MSC v.1944 64 bit AMD64), Windows x64
  SQLite 3.50.4, source id
  ``2025-07-30 19:33:53 4d8adfb30e03f9cf27f800a2c1ba3c48fb4ca1b08b0f5ed59a4d5ecbf45e20a3``
  * ``SQLITE_USE_URI`` is NOT a compile-time option of this build and no
    global URI configuration is active: URI processing is enabled PER
    CONNECTION (``uri=True``).  A ``file:`` string passed with
    ``uri=False`` is an ORDINARY file name.
  * ``SQLITE_ALLOW_URI_AUTHORITY`` is NOT compiled in.  SQLite itself
    rejects an authority other than the empty string or ``localhost``
    ("invalid uri authority: ...").
  * ``SQLITE_ATTACH`` is authorizer action code **24**.
  * ``VACUUM INTO`` DOES report ``SQLITE_ATTACH`` (24) on this runtime, so
    the unconditional attachment denial covers it as well.
  * ``ATTACH DATABASE (<expression>)`` reports action 24 with a **NULL**
    filename argument, so the denial must not depend on the filename text.
  * ``SQLITE_DBCONFIG_ENABLE_ATTACH_CREATE`` / ``..._ATTACH_WRITE`` are NOT
    exposed by CPython's ``sqlite3`` module — the authorizer is the only
    complete control.

LIMITATIONS (stated honestly; see the Round-5 report §B)
---------------------------------------------------------
  * This is an application-level control inside the Python process.  A
    sufficiently determined process with equivalent privileges (native
    code, a C extension, a child interpreter that does not inherit the
    environment) can bypass it.  It is NOT an OS sandbox.
  * It is **NOT atomic and NOT race-free**.  The interval between the
    path validation and SQLite's open is not closed: a hostile same-user
    process that replaces the filesystem object in that window is not
    detected.  The boundary performs path validation followed by a later
    open and does not claim otherwise.
  * A hard-link alias to a PROTECTION-TARGET file can only be detected by
    comparing filesystem identity, which requires reading metadata from
    that file.  The boundary therefore does NOT capture the identity of a
    protected path automatically (that would be a filesystem inspection of
    the protected target); production paths are protected by PATH, and
    synthetic paths may opt in to identity-based alias detection through
    ``install(..., identity_paths=[...])``.

NO PRODUCTION FILE IS INSPECTED BY THIS MODULE
----------------------------------------------
The boundary never opens, reads, hashes, stats or timestamps a protected
path in order to decide.  It compares normalized path strings and resolves
SYMLINK ALIASES through the link itself (``os.readlink``), never through
the target.  The detection harness that used to ``stat`` the production
memory directory was replaced in Round 5 by an equivalent synthetic
harness; the Round-4 evidence remains the historical record.
"""
from __future__ import annotations

import builtins
import io
import os
import shutil
import sqlite3
import stat as _stat
from typing import Dict, Iterable, List, Optional, Sequence, Tuple
from urllib.parse import unquote

PROTECTED_PATHS_ENV = "OCBRAIN_PROTECTED_PATHS"
ALLOW_CONFIG_ENV = "OCBRAIN_TEST_ALLOW_CONFIG_WRITE"
DATA_ROOTS_ENV = "OCBRAIN_PROTECTED_DATA_ROOTS"

#: The SQLite companion files that belong to a database file.
COMPANION_SUFFIXES = ("-wal", "-shm", "-journal")

#: Authorizer action code for ``SQLITE_ATTACH`` (and, on the shipped
#: runtime, for ``VACUUM INTO``).  See the module docstring.
SQLITE_ATTACH_ACTION = 24

#: The STRICT query-parameter allowlist.  The application only ever needs
#: ``mode=ro`` / ``mode=rw`` / ``mode=rwc``; every other parameter is
#: rejected — including the ones SQLite itself would forward to the VFS
#: (``vfs``, ``modeof``, ``nolock``, ``immutable``, ``psow``) and the ones
#: SQLite ignores but a custom VFS would not.
URI_QUERY_POLICY: Dict[str, frozenset] = {
    "mode": frozenset({"ro", "rw", "rwc"}),
}

#: The authorities that denote the LOCAL filesystem on the shipped runtime.
LOCAL_AUTHORITIES = frozenset({"", "localhost"})


class ProtectedPathError(PermissionError):
    """Raised when code attempts to touch a protected production path."""


class UriPolicyError(ProtectedPathError):
    """
    Raised when a ``file:`` URI is malformed, ambiguous, or violates the
    strict query-parameter policy.

    It is a ``ProtectedPathError`` so that every existing caller that
    catches the boundary keeps working.
    """


# ── path helpers ─────────────────────────────────────────────────────────────

def _strip_extended_prefix(path: str) -> str:
    """
    Remove the Windows extended-length / device prefixes.

    ``os.readlink`` on Windows returns the target in its EXTENDED-LENGTH
    form (``\\\\?\\C:\\...``), which would otherwise never compare equal to
    the ordinary spelling of the same path.  ``\\\\?\\UNC\\server\\share``
    is the extended form of the UNC path ``\\\\server\\share``.
    """
    text = str(path)
    if text.startswith("\\\\?\\UNC\\"):
        return "\\\\" + text[len("\\\\?\\UNC\\"):]
    if text.startswith("\\\\?\\"):
        return text[len("\\\\?\\"):]
    if text.startswith("\\\\.\\") and len(text) > 6 \
            and text[4].isalpha() and text[5] == ":":
        # the device-namespace spelling of a local drive
        return text[4:]
    return text


def _norm(path: str) -> str:
    try:
        return os.path.normcase(os.path.abspath(_strip_extended_prefix(path)))
    except (OSError, ValueError):
        return str(path)


def companion_paths_for(db_path: str) -> List[str]:
    """The SQLite companion files that belong to `db_path`."""
    text = str(db_path)
    return [text + suffix for suffix in COMPANION_SUFFIXES]


def protected_paths_for(repo_root: str,
                        extra: Optional[Iterable[str]] = None) -> List[str]:
    """
    The protected paths for this repository: the whole production memory
    directory (database + sidecars + the cognitive vault) and the production
    configuration files.
    """
    root = _norm(repo_root)
    protected: List[str] = [
        os.path.join(root, ".data", "memory"),
    ]
    for name in ("settings.toml", "models.toml", "sources.toml"):
        protected.append(os.path.join(root, "config", name))
    for item in extra or ():
        protected.append(_norm(item))
    return protected


# ── URI parsing ──────────────────────────────────────────────────────────────

class ParsedUri:
    """The parsed structure of a ``file:`` URI."""

    __slots__ = ("raw", "scheme", "authority", "path", "decoded_path",
                 "query", "fragment", "query_order")

    def __init__(self, raw: str, scheme: str, authority: Optional[str],
                 path: str, query: Dict[str, str], query_order: List[str],
                 fragment: Optional[str], decoded_path: str = "") -> None:
        self.raw = raw
        self.scheme = scheme
        self.authority = authority
        self.path = path
        self.decoded_path = decoded_path
        self.query = query
        self.query_order = query_order
        self.fragment = fragment

    def __repr__(self) -> str:                              # pragma: no cover
        return (f"ParsedUri(authority={self.authority!r}, "
                f"path={self.path!r}, query={self.query!r}, "
                f"fragment={self.fragment!r})")

    def as_dict(self) -> Dict[str, object]:
        return {"raw": self.raw, "scheme": self.scheme,
                "authority": self.authority, "path": self.path,
                "query": dict(self.query), "query_order": list(self.query_order),
                "fragment": self.fragment}


def _looks_like_uri(target: str) -> bool:
    return str(target)[:5].lower() == "file:"


def _decode_component(text: str, *, what: str, strict: bool) -> str:
    """
    Percent-decode `text` EXACTLY ONCE.

    The URI is a UTF-8 byte string, so the decoding is done at the BYTE
    level: a ``%HH`` escape contributes exactly one byte, a literal
    character contributes its UTF-8 bytes.  The result is then decoded as
    UTF-8.

    A malformed escape (``%`` not followed by two hex digits) and an
    encoded NUL (``%00``) are rejected in strict mode: both make the URI
    ambiguous, and SQLite would treat a malformed URI as an ordinary file
    name — a different target than the one the boundary reasons about.
    """
    raw = text.encode("utf-8", "surrogateescape")
    out = bytearray()
    i = 0
    n = len(raw)
    while i < n:
        byte = raw[i]
        if byte == 0x25:                    # '%'
            if i + 2 >= n:
                if strict:
                    raise UriPolicyError(
                        f"the {what} of the SQLite URI ends with a truncated "
                        f"percent escape: {text!r}")
                out.extend(raw[i:])
                break
            hexpart = raw[i + 1:i + 3]
            if len(hexpart) != 2 or any(c not in b"0123456789abcdefABCDEF"
                                        for c in hexpart):
                if strict:
                    raise UriPolicyError(
                        f"the {what} of the SQLite URI contains a malformed "
                        f"percent escape: {text!r}")
                out.extend(raw[i:])
                i += 1
                continue
            value = int(hexpart.decode("ascii"), 16)
            if value == 0:
                if strict:
                    raise UriPolicyError(
                        f"the {what} of the SQLite URI contains an encoded "
                        f"NUL (%00): {text!r}")
                out.extend(raw[i:])
                i += 1
                continue
            out.append(value)
            i += 3
            continue
        if byte == 0x00:
            if strict:
                raise UriPolicyError(
                    f"the {what} of the SQLite URI contains an embedded NUL")
        out.append(byte)
        i += 1
    try:
        return out.decode("utf-8")
    except UnicodeDecodeError:
        if strict:
            raise UriPolicyError(
                f"the {what} of the SQLite URI is not valid UTF-8")
        return out.decode("utf-8", "surrogateescape")


def _split_uri(text: str) -> Tuple[Optional[str], str, str, Optional[str]]:
    """
    Split the part after ``file:`` into (authority, path, query, fragment).

    The FRAGMENT is delimited by the first ``#`` and the QUERY by the first
    ``?`` BEFORE it — RFC 3986 order.  SQLite ignores the fragment
    entirely; a literal ``#`` in a file name is written ``%23`` and is
    therefore never confused with the fragment delimiter.
    """
    rest = text[5:]
    authority: Optional[str] = None
    if rest.startswith("//"):
        after = rest[2:]
        slash = after.find("/")
        if slash == -1:
            authority, tail = after, ""
        else:
            authority, tail = after[:slash], after[slash:]
        rest = tail
    hash_at = rest.find("#")
    fragment: Optional[str] = None
    if hash_at != -1:
        fragment = rest[hash_at + 1:]
        rest = rest[:hash_at]
    query = ""
    question_at = rest.find("?")
    if question_at != -1:
        query = rest[question_at + 1:]
        rest = rest[:question_at]
    return authority, rest, query, fragment


def _native_path(decoded: str, *, strict: bool) -> str:
    """
    Turn the DECODED URI path into the native filesystem path SQLite will
    use.

    Measured on the shipped runtime (Windows):

      * ``file:C:/dir/db``    -> ``C:\\dir\\db``  (the drive form is
        absolute even without the leading slash);
      * ``file:/C:/dir/db``   -> ``C:\\dir\\db``;
      * ``file:///C:/dir/db`` -> ``C:\\dir\\db``;
      * a relative path       -> resolved against the CURRENT WORKING
        DIRECTORY, exactly like SQLite;
      * ``file:/C:rel.db``    -> DRIVE-RELATIVE (the OS resolves it against
        the per-drive current directory) — ambiguous, so it is rejected in
        strict mode.
    """
    text = decoded
    if not text:
        if strict:
            raise UriPolicyError("the SQLite URI has an empty path")
        return ""
    if os.name == "nt":
        # UNC form (\\server\share\...) — keep it a UNC path.
        if text.startswith("\\\\"):
            return text
        # Drive form: "C:/..." or "/C:/..."
        candidate = text[1:] if (len(text) > 2 and text[0] == "/"
                                 and text[1].isalpha() and text[2] == ":") \
            else text
        if len(candidate) >= 2 and candidate[1] == ":" and candidate[0].isalpha():
            drive_relative = len(candidate) == 2 or candidate[2] not in "/\\"
            if drive_relative and strict:
                raise UriPolicyError(
                    f"the SQLite URI uses a drive-relative path ({text!r}); "
                    "it is ambiguous and is rejected")
            return candidate.replace("/", "\\")
        # A path that starts with a single backslash is drive-relative on
        # Windows; a path that starts with "/" is rooted on the current
        # drive.  Both are resolved by the OS, so let the OS resolve them.
        if text.startswith("/"):
            return os.path.abspath(text.replace("/", "\\"))
        return os.path.abspath(text)
    # POSIX
    if text.startswith("/"):
        return os.path.normpath(text)
    return os.path.abspath(text)


def parse_sqlite_uri(target, *, strict: bool = True) -> Optional[ParsedUri]:
    """
    Parse a ``file:`` URI into its components and apply the STRICT policy.

    Returns ``None`` when `target` is not a ``file:`` URI at all.

    In strict mode the function raises ``UriPolicyError`` for

      * an authority other than the empty string or ``localhost``
        (SQLite itself rejects those on this runtime);
      * a query parameter that is not in the allowlist;
      * a DUPLICATE query parameter;
      * a PERCENT-ENCODED query parameter name or value (a concealed
        option is rejected, not normalised);
      * a malformed percent escape;
      * an encoded or literal NUL;
      * an ambiguous drive-relative path.
    """
    text = str(target)
    if not _looks_like_uri(text):
        return None

    authority_raw, path_raw, query_raw, fragment_raw = _split_uri(text)

    # ---- authority -------------------------------------------------------
    authority: Optional[str] = None
    if authority_raw is not None:
        decoded_authority = _decode_component(
            authority_raw, what="authority", strict=strict)
        if strict:
            if decoded_authority.lower() not in LOCAL_AUTHORITIES:
                raise UriPolicyError(
                    f"the SQLite URI authority {decoded_authority!r} is not "
                    "a local-filesystem authority; this runtime rejects "
                    "every authority other than the empty string or "
                    "'localhost' (SQLITE_ALLOW_URI_AUTHORITY is not "
                    "compiled in)")
            authority = decoded_authority.lower()
        else:
            authority = decoded_authority

    # ---- fragment --------------------------------------------------------
    fragment: Optional[str] = None
    if fragment_raw is not None:
        fragment = _decode_component(fragment_raw, what="fragment",
                                      strict=strict)

    # ---- query -----------------------------------------------------------
    query: Dict[str, str] = {}
    query_order: List[str] = []
    if query_raw != "":
        for part in query_raw.split("&"):
            if part == "":
                if strict:
                    raise UriPolicyError(
                        "the SQLite URI query contains an empty parameter")
                continue
            if "=" not in part:
                if strict:
                    raise UriPolicyError(
                        f"the SQLite URI query parameter {part!r} has no "
                        "value; the structure is ambiguous")
                key, value = part, ""
            else:
                key, _, value = part.partition("=")
            if strict and ("%" in key or "%" in value):
                raise UriPolicyError(
                    f"the SQLite URI query parameter {key!r} is "
                    "percent-encoded; a concealed option is rejected, not "
                    "normalised")
            if strict and key not in URI_QUERY_POLICY:
                raise UriPolicyError(
                    f"the SQLite URI query parameter {key!r} is not in the "
                    f"allowlist {sorted(URI_QUERY_POLICY)}")
            if strict and key in query:
                raise UriPolicyError(
                    f"the SQLite URI query parameter {key!r} appears more "
                    "than once")
            if strict and value not in URI_QUERY_POLICY[key]:
                raise UriPolicyError(
                    f"the SQLite URI query parameter {key!r}={value!r} is "
                    f"not one of {sorted(URI_QUERY_POLICY[key])}")
            if key not in query:
                query_order.append(key)
            query[key] = value

    # ---- path ------------------------------------------------------------
    decoded_path = _decode_component(path_raw, what="path", strict=strict)
    native = _native_path(decoded_path, strict=strict)

    return ParsedUri(raw=text, scheme="file", authority=authority,
                     path=native, query=query, query_order=query_order,
                     fragment=fragment, decoded_path=decoded_path)


def _unc_path(authority: str, decoded_path: str) -> str:
    """The UNC form of a non-local authority (used by the LENIENT path)."""
    tail = decoded_path.replace("/", "\\")
    if not tail.startswith("\\"):
        tail = "\\" + tail
    if os.name == "nt":
        return "\\\\" + authority + tail
    return "//" + authority + tail


def _uri_to_path(target: str) -> str:
    """
    Convert a SQLite file URI into a native filesystem path.

    LENIENT resolver kept for backwards compatibility with the Round-4
    suite (it must not raise for a URI that merely *looks* unusual).  The
    STRICT policy that the connection boundary applies lives in
    ``parse_sqlite_uri``.

    The resolution follows the measured semantics of the shipped runtime:
    the fragment is stripped, the query is removed, percent escapes are
    decoded exactly once, the Windows drive form (``/C:/...`` and
    ``C:/...``) becomes a native drive path, a non-local authority becomes
    a UNC path, and a relative path is resolved against the current
    working directory.
    """
    text = str(target)
    if not _looks_like_uri(text):
        return text
    parsed = parse_sqlite_uri(text, strict=False)
    if parsed is None:                                    # pragma: no cover
        return text
    if parsed.authority is not None and parsed.authority.lower() \
            not in LOCAL_AUTHORITIES:
        # A foreign authority is a UNC share.
        return _unc_path(parsed.authority, parsed.decoded_path)
    return parsed.path


# ── guard state ──────────────────────────────────────────────────────────────

class _Guard:
    """The installed boundary state."""

    def __init__(self) -> None:
        self.protected: List[str] = []
        self.companions: List[str] = []
        self.data_roots: List[str] = []
        self.config_roots: List[str] = []
        self.identities: set = set()   # identity keys of opted-in files
        self.allow_config_write = False
        self.installed = False
        self.denied_sql: List[Dict[str, object]] = []
        self.connector_calls = 0
        self.rejected_connects: List[Dict[str, object]] = []


_GUARD = _Guard()


def _load_fsidentity():
    """Load the native filesystem-identity helper (self-contained)."""
    import importlib.util
    here = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(here, "_g4_fsidentity.py")
    spec = importlib.util.spec_from_file_location("_g4_fsidentity", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


try:
    import _g4_fsidentity as _fsid                     # noqa: F401
except Exception:                                       # pragma: no cover
    _fsid = _load_fsidentity()


def identity_mechanism() -> str:
    """The filesystem-identity mechanism this platform provides."""
    return _fsid.identity_mechanism()


def _identity_key(path: str):
    """The identity key of `path` (None when it cannot be obtained)."""
    identity = _fsid.file_identity(path)
    if identity is None:
        return None
    return _fsid.identity_key(identity)


def _is_link_like(path: str) -> bool:
    """
    True when the path component is a SYMLINK or another REPARSE POINT.

    On Windows a directory JUNCTION is a reparse point but NOT a symbolic
    link, so ``S_ISLNK`` alone does not see it.  ``os.lstat`` exposes
    ``st_reparse_tag`` on Windows; a non-zero tag means the component
    redirects to another object and must be resolved.
    """
    try:
        st = os.lstat(path)
    except OSError:
        return False
    if _stat.S_ISLNK(st.st_mode):
        return True
    tag = getattr(st, "st_reparse_tag", None)
    if tag is not None and int(tag) != 0:
        # IO_REPARSE_TAG_RESERVED_ZERO (0) is a normal file
        return True
    return False


def _resolve_symlink_aliases(path: str) -> str:
    """
    Resolve SYMLINK (and other reparse-point) aliases component by
    component.

    The LINK itself is read (``os.readlink``); the TARGET is never opened.
    This matters: resolving a link whose target is a production database
    must not open, stat or hash that database.  ``os.path.realpath`` is
    deliberately NOT used, because on Windows it resolves the final
    component through ``GetFinalPathNameByHandle``, which OPENS the file.
    """
    resolved = os.path.normpath(str(path))
    for _ in range(64):                    # a bounded loop: a link cycle
        drive, tail = os.path.splitdrive(resolved)
        prefix = drive + os.sep if drive else "."
        link = None
        for part in [p for p in tail.split(os.sep) if p not in ("", ".")]:
            candidate = os.path.join(prefix, part)
            if _is_link_like(candidate):
                link = candidate
                break
            prefix = candidate
        if link is None:
            return resolved
        try:
            target = os.readlink(link)
        except OSError:                    # pragma: no cover
            return resolved
        if os.path.isabs(target):
            resolved = os.path.normpath(target)
        else:
            resolved = os.path.normpath(
                os.path.join(os.path.dirname(link), target))
    return resolved


def _candidate_paths(target) -> List[str]:
    """
    Every path the target could denote.

    For a ``file:`` target BOTH interpretations are returned:

      * the URI interpretation (what SQLite opens when URI processing is
        enabled for the connection), and
      * the ordinary file-name interpretation (what SQLite opens when URI
        processing is NOT enabled — it treats the string literally).

    Denying on either interpretation is conservative and cannot map a
    protected target to an unprotected one.
    """
    if target is None:
        return []
    raw = str(target)
    candidates: List[str] = []
    if _looks_like_uri(raw):
        try:
            parsed = parse_sqlite_uri(raw, strict=False)
        except UriPolicyError:                       # pragma: no cover
            parsed = None
        if parsed is not None:
            if parsed.authority is not None and \
                    parsed.authority.lower() not in LOCAL_AUTHORITIES:
                candidates.append(_unc_path(parsed.authority,
                                            parsed.decoded_path))
            else:
                candidates.append(parsed.path)
        candidates.append(os.path.abspath(raw))
    else:
        candidates.append(os.path.abspath(raw))
    return candidates


def _is_protected(target, protected: Optional[Sequence[str]] = None
                  ) -> Optional[str]:
    """
    Return the protected root that `target` falls under, else None.

    Symlink aliases are resolved (a symlink INTO the production directory
    is the production directory) and a hard-link alias is recognised by its
    filesystem identity — but only for paths that were explicitly opted in
    to identity tracking (capturing the identity of a protected path would
    itself be a filesystem inspection of that path).
    """
    if target is None:
        return None
    roots = list(protected if protected is not None else _GUARD.protected)
    companions = _GUARD.companions
    candidates = _candidate_paths(target)

    # (1) pure path comparison — NO filesystem access.
    for candidate in candidates:
        norm = _norm(candidate)
        for root in roots:
            root_n = _norm(root)
            if norm == root_n or norm.startswith(root_n + os.sep):
                return root_n
        for companion in companions:
            comp_n = _norm(companion)
            if norm == comp_n:
                return comp_n

    # (2) symlink alias resolution (reads the LINK, never the target).
    for candidate in candidates:
        try:
            resolved = _resolve_symlink_aliases(candidate)
        except (OSError, ValueError):               # pragma: no cover
            continue
        norm = _norm(resolved)
        for root in roots:
            root_n = _norm(root)
            if norm == root_n or norm.startswith(root_n + os.sep):
                return root_n

    # (3) hard-link alias through the identity registry (opt-in only).
    if _GUARD.identities:
        for candidate in candidates:
            key = _identity_key(candidate)
            if key is not None and key in _GUARD.identities:
                return "hard-link-alias"
    return None


# ── the SQLite connection guard ──────────────────────────────────────────────

def _attach_denial_policy(action, arg1, arg2, dbname, trigger):
    """
    The composed authorizer policy.

    ``SQLITE_ATTACH`` is DENIED unconditionally — the default policy is "no
    attachment" and no reviewed application requirement exists for one.
    The denial deliberately does NOT look at the filename: on this runtime
    ``ATTACH DATABASE (<expression>)`` reports the action with a NULL
    filename argument, and ``VACUUM INTO`` reports the action with the
    destination path.

    The return value is an SQLite authorizer code: ``SQLITE_DENY`` for a
    denied operation and ``SQLITE_OK`` for an allowed one.  Returning
    ``None`` would be interpreted as a denial by CPython, so the policy
    never returns ``None``.
    """
    if action == SQLITE_ATTACH_ACTION:
        _GUARD.denied_sql.append({
            "action": int(action),
            "action_name": "SQLITE_ATTACH",
            "arg1": None if arg1 is None else str(arg1),
            "arg2": None if arg2 is None else str(arg2),
            "dbname": None if dbname is None else str(dbname),
            "arg1_is_null": arg1 is None,
        })
        return sqlite3.SQLITE_DENY
    return sqlite3.SQLITE_OK


_GUARDED_FACTORIES: Dict[int, type] = {}


def _make_guarded_factory(base_factory=None):
    """
    Build (and cache) a connection class that COMPOSES the attach-denial
    policy into every authorizer registration.

    ``sqlite3.Connection`` is an immutable extension type, so the policy
    cannot be attached to the type itself; it is attached through the
    ``factory`` argument of ``sqlite3.connect`` instead.  Overriding
    ``set_authorizer`` means that a later registration by application code
    REPLACES the callback but does NOT remove the policy — the caller's
    callback is composed with the policy, and the policy is evaluated
    first.
    """
    base = base_factory if base_factory is not None else sqlite3.Connection
    if not (isinstance(base, type) and issubclass(base, sqlite3.Connection)):
        base = sqlite3.Connection
    cached = _GUARDED_FACTORIES.get(id(base))
    if cached is not None:
        return cached

    class GuardedConnection(base):                    # type: ignore[misc,valid-type]
        """A connection whose authorizer can never be un-guarded."""

        _ocbrain_guarded = True

        def set_authorizer(self, callback):
            def composed(action, arg1, arg2, dbname, trigger):
                decision = _attach_denial_policy(action, arg1, arg2, dbname,
                                                 trigger)
                if decision == sqlite3.SQLITE_DENY:
                    return decision
                if callback is None:
                    return sqlite3.SQLITE_OK
                result = callback(action, arg1, arg2, dbname, trigger)
                # CPython interprets a non-integer return value as a
                # denial; normalise it so a permissive user callback does
                # not accidentally deny everything.
                return sqlite3.SQLITE_OK if result is None else result

            _GUARD.denied_sql.append({
                "action": -1, "action_name": "AUTHORIZER_REGISTERED",
                "arg1": None, "arg2": None, "dbname": None,
                "arg1_is_null": True,
            })
            return base.set_authorizer(self, composed)

    GuardedConnection.__name__ = "Guarded" + getattr(base, "__name__",
                                                      "Connection")
    GuardedConnection.__qualname__ = GuardedConnection.__name__
    _GUARDED_FACTORIES[id(base)] = GuardedConnection
    return GuardedConnection


def _apply_dbconfig(conn) -> Dict[str, object]:
    """
    Defence-in-depth connection configuration.

    Returns what was ACTUALLY applied — a configuration that could not be
    set is reported as such and never assumed.
    """
    applied: Dict[str, object] = {}
    name = "SQLITE_DBCONFIG_ENABLE_LOAD_EXTENSION"
    if hasattr(sqlite3, name) and hasattr(conn, "setconfig"):
        try:
            conn.setconfig(getattr(sqlite3, name), False)
            applied[name] = True
        except sqlite3.Error as exc:                  # pragma: no cover
            applied[name] = f"FAILED: {exc}"
    else:                                             # pragma: no cover
        applied[name] = "NOT_EXPOSED_BY_THIS_PYTHON"
    for absent in ("SQLITE_DBCONFIG_ENABLE_ATTACH_CREATE",
                   "SQLITE_DBCONFIG_ENABLE_ATTACH_WRITE"):
        applied[absent] = "NOT_EXPOSED_BY_THIS_PYTHON"
    return applied


def _apply_limits(conn) -> Dict[str, object]:
    """Lower the attached-database limit where the runtime supports it."""
    applied: Dict[str, object] = {}
    if hasattr(conn, "setlimit") and hasattr(sqlite3, "SQLITE_LIMIT_ATTACHED"):
        try:
            conn.setlimit(sqlite3.SQLITE_LIMIT_ATTACHED, 0)
            applied["SQLITE_LIMIT_ATTACHED"] = conn.getlimit(
                sqlite3.SQLITE_LIMIT_ATTACHED)
        except sqlite3.Error as exc:                  # pragma: no cover
            applied["SQLITE_LIMIT_ATTACHED"] = f"FAILED: {exc}"
    else:                                             # pragma: no cover
        applied["SQLITE_LIMIT_ATTACHED"] = "NOT_SUPPORTED"
    return applied


def install_connection_guard(conn) -> Dict[str, object]:
    """
    Install the connection-level guard on a freshly created connection.

    The authorizer is installed BEFORE any application SQL is prepared
    (the connection has just been created, so no statement exists yet).
    """
    info: Dict[str, object] = {}
    conn.set_authorizer(_attach_denial_policy)
    info["authorizer_installed"] = True
    info["dbconfig"] = _apply_dbconfig(conn)
    info["limits"] = _apply_limits(conn)
    if hasattr(conn, "enable_load_extension"):
        try:
            conn.enable_load_extension(False)
            info["load_extension_enabled"] = False
        except sqlite3.Error as exc:                  # pragma: no cover
            info["load_extension_enabled"] = f"FAILED: {exc}"
    return info


def guard_active() -> bool:
    """True when the boundary is installed in this process."""
    return bool(_GUARD.installed)


def connector_is_wrapped() -> bool:
    """True when ``sqlite3.connect`` is the guarded wrapper."""
    return bool(getattr(sqlite3.connect, "_ocbrain_g4_protected", False))


def denied_sql_operations() -> List[Dict[str, object]]:
    """The SQL operations the authorizer denied (audit trail)."""
    return list(_GUARD.denied_sql)


def rejected_connects() -> List[Dict[str, object]]:
    """The connect attempts the boundary rejected (audit trail)."""
    return list(_GUARD.rejected_connects)


# ── installation ─────────────────────────────────────────────────────────────

def install(protected: Sequence[str],
            allow_config_write: bool = False,
            identity_paths: Optional[Sequence[str]] = None,
            extra_data_roots: Optional[Sequence[str]] = None) -> None:
    """
    Install the prevention boundary in THIS process (idempotent).

    `allow_config_write` relaxes only the CONFIGURATION part of the
    boundary; production DATA is never writable under the boundary.

    `identity_paths` opts specific files in to IDENTITY-based alias
    detection (hard links).  Only synthetic paths should be listed: reading
    the identity of a protected path is itself a filesystem inspection of
    that path.

    `extra_data_roots` classifies additional protected paths as DATA roots
    (no access at all) instead of CONFIGURATION roots (read-only).
    """
    protected = [_norm(p) for p in protected]
    # The DATA roots are the derived production memory roots PLUS every
    # explicitly classified extra.  An explicit list EXTENDS the derived
    # set; it never replaces it (a replacement would silently downgrade
    # the production memory directory to a read-only CONFIGURATION root).
    derived = [p for p in protected
               if os.path.join(".data", "memory") in p]
    extra = [_norm(p) for p in (extra_data_roots or [])]
    data_roots = list(dict.fromkeys(derived + extra))
    config_roots = [p for p in protected if p not in data_roots]

    companions: List[str] = []
    for root in protected:
        if os.path.isdir(root):
            continue
        for companion in companion_paths_for(root):
            companions.append(_norm(companion))

    identities = set()
    for path in identity_paths or ():
        key = _identity_key(path)
        if key is not None:
            identities.add(key)

    _GUARD.protected = protected
    _GUARD.companions = companions
    _GUARD.data_roots = data_roots
    _GUARD.config_roots = config_roots
    _GUARD.allow_config_write = allow_config_write
    _GUARD.identities = identities

    real_connect = sqlite3.connect
    real_open = builtins.open
    real_io_open = io.open
    real_os_open = os.open
    real_remove = os.remove
    real_unlink = os.unlink
    real_rename = os.rename
    real_replace = os.replace
    real_mkdir = os.mkdir
    real_makedirs = os.makedirs
    real_path_open = None
    try:
        import pathlib
        real_path_open = pathlib.Path.open
    except Exception:                                  # pragma: no cover
        real_path_open = None

    def _check(target, write: bool) -> None:
        hit = _is_protected(target)
        if hit is None:
            return
        if hit == "hard-link-alias":
            raise ProtectedPathError(
                f"protected production data accessed through a hard-link "
                f"alias: {target!r}. The test environment must never open, "
                "write or initialize production data (F24/W20).")
        if hit in _GUARD.data_roots:
            # Production DATA: no access at all (read, write, create).
            raise ProtectedPathError(
                f"protected production data accessed: {target!r} is under "
                f"{hit!r}. The test environment must never open, write or "
                "initialize production data (F24/W20). Use an isolated "
                "temporary database instead.")
        # Production CONFIGURATION: modification is forbidden; reading the
        # configuration is how the application loads its settings and is
        # not a mutation.
        if not write:
            return
        if _GUARD.allow_config_write:
            return
        raise ProtectedPathError(
            f"protected production configuration modified: {target!r} is "
            f"under {hit!r}. The test environment must not rewrite the "
            "production configuration files (F24/W20).")

    def _check_connect(target, kwargs) -> None:
        """
        The connect-time decision (R5-01 §2.2).

        A ``file:`` target is parsed under the STRICT policy: a malformed,
        ambiguous or policy-violating URI is DENIED (fail closed) because
        the boundary must not reason about a different path than SQLite
        opens.  A URI-looking target passed with ``uri=False`` is treated
        as an ordinary file name by SQLite, so BOTH interpretations are
        checked; the target is never rewritten.
        """
        uri_flag = bool(kwargs.get("uri", False))
        raw = str(target)
        if _looks_like_uri(raw):
            if uri_flag:
                parse_sqlite_uri(raw, strict=True)      # raises on violation
            else:
                # SQLite would treat this as an ordinary file name.  The
                # strict policy still applies to the URI reading, but a
                # violation is not fatal here: the ordinary interpretation
                # is what SQLite opens, and it is checked as well.
                try:
                    parse_sqlite_uri(raw, strict=True)
                except UriPolicyError:
                    pass
        _check(target, write=not _is_readonly_connect(target, kwargs))

    def connect(target, *args, **kwargs):
        _GUARD.connector_calls += 1
        try:
            _check_connect(target, kwargs)
        except ProtectedPathError as exc:
            _GUARD.rejected_connects.append({
                "target": str(target),
                "uri": bool(kwargs.get("uri", False)),
                "error": str(exc),
            })
            raise
        user_factory = kwargs.get("factory")
        kwargs["factory"] = _make_guarded_factory(user_factory)
        conn = real_connect(target, *args, **kwargs)
        try:
            install_connection_guard(conn)
        except Exception:                              # pragma: no cover
            try:
                conn.close()
            except sqlite3.Error:
                pass
            raise
        return conn

    def open_(file, mode="r", *args, **kwargs):
        _check(file, write=any(c in str(mode) for c in "wxa+"))
        return real_open(file, mode, *args, **kwargs)

    def io_open(file, mode="r", *args, **kwargs):
        _check(file, write=any(c in str(mode) for c in "wxa+"))
        return real_io_open(file, mode, *args, **kwargs)

    def os_open(path, flags, *args, **kwargs):
        _check(path, write=bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT
                                         | os.O_APPEND | os.O_TRUNC)))
        return real_os_open(path, flags, *args, **kwargs)

    def remove(path, *args, **kwargs):
        _check(path, write=True)
        return real_remove(path, *args, **kwargs)

    def unlink(path, *args, **kwargs):
        _check(path, write=True)
        return real_unlink(path, *args, **kwargs)

    def rename(src, dst, *args, **kwargs):
        _check(src, write=True)
        _check(dst, write=True)
        return real_rename(src, dst, *args, **kwargs)

    def replace(src, dst, *args, **kwargs):
        _check(src, write=True)
        _check(dst, write=True)
        return real_replace(src, dst, *args, **kwargs)

    def mkdir(path, *args, **kwargs):
        _check(path, write=True)
        return real_mkdir(path, *args, **kwargs)

    def makedirs(name, *args, **kwargs):
        _check(name, write=True)
        return real_makedirs(name, *args, **kwargs)

    def path_open(self, *args, **kwargs):
        mode = args[0] if args else kwargs.get("mode", "r")
        _check(str(self), write=any(c in str(mode) for c in "wxa+"))
        if real_path_open is None:                    # pragma: no cover
            raise ProtectedPathError("pathlib.Path.open is unavailable")
        return real_path_open(self, *args, **kwargs)

    def _shutil_guard(fn, write=True):
        def guarded(src, dst=None, *args, **kwargs):
            _check(src, write=write)
            if dst is not None:
                _check(dst, write=write)
            return fn(src, dst, *args, **kwargs) if dst is not None \
                else fn(src, *args, **kwargs)
        return guarded

    sqlite3.connect = connect
    connect._ocbrain_g4_protected = True          # type: ignore[attr-defined]
    builtins.open = open_
    io.open = io_open
    os.open = os_open
    os.remove = remove
    os.unlink = unlink
    os.rename = rename
    os.replace = replace
    os.mkdir = mkdir
    os.makedirs = makedirs
    if real_path_open is not None:
        import pathlib
        pathlib.Path.open = path_open
    for name in ("copy", "copy2", "copyfile", "copytree", "move", "rmtree"):
        fn = getattr(shutil, name, None)
        if fn is not None:
            setattr(shutil, name, _shutil_guard(fn))
    _GUARD.installed = True


def _is_readonly_connect(target, kwargs) -> bool:
    """
    True when the connect arguments clearly request a read-only open.

    The decision is made on the PARSED URI (not on a substring search), so
    a query parameter that merely CONTAINS the text "mode=ro" cannot
    disguise a read-write open.
    """
    text = str(target)
    if _looks_like_uri(text):
        try:
            parsed = parse_sqlite_uri(text, strict=False)
        except UriPolicyError:                       # pragma: no cover
            parsed = None
        if parsed is not None:
            return parsed.query.get("mode") == "ro"
        return False
    return False


def install_from_env() -> None:
    """
    Install the boundary from the exported environment (child processes).

    A failure to install is NOT swallowed: the child fails closed rather
    than running without protection.
    """
    raw = os.environ.get(PROTECTED_PATHS_ENV, "")
    paths = [p for p in raw.split(os.pathsep) if p]
    if not paths:
        raise RuntimeError(
            "production protection requested but no protected paths were "
            "exported — refusing to run without the boundary")
    allow = os.environ.get(ALLOW_CONFIG_ENV, "") == "1"
    raw_roots = os.environ.get(DATA_ROOTS_ENV, "")
    data_roots = [p for p in raw_roots.split(os.pathsep) if p]
    install(paths, allow_config_write=allow,
            extra_data_roots=data_roots or None)


def export_for_children(protected: Sequence[str],
                        allow_config_write: bool = False,
                        data_roots: Optional[Sequence[str]] = None) -> None:
    """Export the protected paths (and the config opt-out) to children."""
    exported = [_norm(p) for p in protected]
    for root in list(exported):
        if os.path.isdir(root):
            continue
        for companion in companion_paths_for(root):
            normalized = _norm(companion)
            if normalized not in exported:
                exported.append(normalized)
    os.environ[PROTECTED_PATHS_ENV] = os.pathsep.join(exported)
    derived = [p for p in exported
               if os.path.join(".data", "memory") in p]
    all_roots = list(dict.fromkeys(
        [_norm(p) for p in (data_roots or [])] + derived))
    os.environ[DATA_ROOTS_ENV] = os.pathsep.join(all_roots)
    if allow_config_write:
        os.environ[ALLOW_CONFIG_ENV] = "1"
