#!/usr/bin/env python
"""
tests/run_g4_protected_pytest.py — the PROTECTED pytest launcher (R5-01 §7).

WHY A LAUNCHER
--------------
Pytest loads its builtin plugins, its external plugins and the initial
``conftest.py`` modules during start-up — BEFORE normal collection.  An
``autouse`` fixture is therefore too late to protect an IMPORT-TIME
database open, and a ``pytest_sessionstart`` hook is too late to protect a
plugin that imports project code during start-up.

This launcher installs the production-access boundary FIRST, verifies that
it is ACTIVE, and only THEN imports pytest.  It fails CLOSED: if the
boundary cannot be installed, pytest is never imported and the exit code
is non-zero.

USAGE
-----
    python tests/run_g4_protected_pytest.py [pytest arguments]

For example:

    python tests/run_g4_protected_pytest.py tests/test_g4_r5_corrections.py \
        -p no:cacheprovider -q
    python tests/run_g4_protected_pytest.py --collect-only -q

THIRD-PARTY PLUGIN AUTOLOAD
----------------------------
Third-party plugin autoload is disabled before pytest is imported: an
autoloaded plugin can import project modules (and therefore reach a
database) before the guard would be in place.  Plugins that the suite
genuinely needs are loaded EXPLICITLY, after the guard is installed.
"""
from __future__ import annotations

import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_REPO = os.path.dirname(_HERE)

# The launcher must be able to import the protection module and the
# bootstrap before anything else happens.
for _entry in (_HERE, _REPO):
    if _entry not in sys.path:
        sys.path.insert(0, _entry)

# Disable third-party plugin autoload BEFORE pytest is imported.  A
# plugin that imports project code at start-up would otherwise run before
# the boundary is installed.
os.environ.setdefault("PYTEST_DISABLE_PLUGIN_AUTOLOAD", "1")

#: Plugins the suite genuinely needs, loaded explicitly AFTER the guard.
#: ``asyncio`` is the pytest-asyncio plugin NAME (the entry point is
#: ``asyncio = pytest_asyncio.plugin``); it is required because
#: ``pyproject.toml`` sets ``asyncio_mode = "auto"`` — without it every
#: asynchronous test would be collected but never executed.
REQUIRED_PLUGINS = ("asyncio",)


def _fail_closed(message: str) -> int:
    sys.stderr.write("OCBRAIN G4 PROTECTION: " + message + "\n")
    sys.stderr.flush()
    return 70


def main(argv) -> int:
    # (1) standard library + the minimum protection bootstrap only.
    try:
        import _g4_bootstrap
    except BaseException as exc:                       # pragma: no cover
        return _fail_closed(
            f"the protection bootstrap could not be imported: {exc!r}")

    # (2) install the boundary, (3) verify that it took effect.
    try:
        info = _g4_bootstrap.prepare()
    except BaseException as exc:
        return _fail_closed(
            f"the production-access boundary could not be installed: "
            f"{exc!r}")

    try:
        import _g4_protection
        if not _g4_protection.guard_active():
            return _fail_closed("the protection boundary is not active")
        if not _g4_protection.connector_is_wrapped():
            return _fail_closed(
                "sqlite3.connect is not wrapped by the protection boundary")
    except BaseException as exc:
        return _fail_closed(
            f"the protection boundary could not be verified: {exc!r}")

    # (4) only NOW is pytest imported.
    try:
        import pytest
    except BaseException as exc:                       # pragma: no cover
        return _fail_closed(f"pytest could not be imported: {exc!r}")

    args = list(argv)
    for plugin in REQUIRED_PLUGINS:
        already = False
        for index, arg in enumerate(args):
            if arg == plugin:
                already = True
            elif arg == "-p" and index + 1 < len(args) \
                    and args[index + 1] == plugin:
                already = True
            elif arg.startswith("-p") and arg[2:] == plugin:
                already = True
        if not already:
            args = ["-p", plugin] + args

    # (5) run pytest and (6) preserve its exit code.
    try:
        code = int(pytest.main(args))
    except SystemExit as exc:                          # pragma: no cover
        code = int(exc.code or 0)
    return code


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
