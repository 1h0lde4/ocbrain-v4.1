"""
tests/test_g4_r5_corrections.py — the Round-5 corrective suite.

It covers the five Round-5 work packages and the specification's section 7
(protected test bootstrap):

  R5-01  SQLite URI semantics and complete database-access protection
  R5-02  Disposable verification-copy lifecycle and truthful JSON
  R5-03  Crash-surviving per-artifact preservation manifests
  R5-04  Correct sidecar lifecycle and file-identity evidence
  R5-05  Baseline reconstruction, crosswalk reconciliation, reproducibility
  R5-06  The protected test bootstrap (specification section 7)

EVERY test asserts the invariant it claims.  A test that passes without
proving the claimed invariant is a defect, not evidence.

The suite runs under the protected launcher
(``tests/run_g4_protected_pytest.py``): the production-access boundary is
installed BEFORE pytest is imported, so the import-time and
collection-time protection is exercised by the suite itself.

NO PRODUCTION DATABASE IS OPENED, READ, HASHED, STAT-ED OR TIMESTAMPED by
this suite.  Every database here is synthetic and disposable (tmp_path);
the protected paths are the configured production paths plus a SYNTHETIC
protected root, and the protection decision is proven by the REJECTION
before the filesystem operation.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parent.parent
TESTS = REPO / "tests"

# ── the protection module (loaded by path: it must work before pytest) ───────


def _load_protection():
    """The protection module INSTALLED in this process.

    The module is stateful (the guard state, the audit trail).  The suite
    must observe the SAME instance that conftest/the launcher installed —
    loading a second copy would observe an inactive guard.  The instance
    is found by looking for the one whose guard is actually ACTIVE.
    """
    for name in ("_g4_protection", "g4_protection", "g4p_r5"):
        module = sys.modules.get(name)
        if module is not None and getattr(module, "guard_active",
                                          lambda: False)():
            return module
    spec = importlib.util.spec_from_file_location(
        "g4p_r5", str(TESTS / "_g4_protection.py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


g4p = _load_protection()


def _load_fsidentity():
    module = sys.modules.get("_g4_fsidentity")
    if module is not None:
        return module
    spec = importlib.util.spec_from_file_location(
        "g4fsid_r5", str(TESTS / "_g4_fsidentity.py"))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


fsid = _load_fsidentity()


# ── helpers ──────────────────────────────────────────────────────────────────

def sha256_file(path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def make_current_db(path, rows: int = 2) -> str:
    """A synthetic database with the canonical schema and some content."""
    from core.memory.backends.sqlite_storage import SQLiteStorageBackend
    SQLiteStorageBackend(str(path))
    conn = sqlite3.connect(str(path))
    try:
        conn.executemany(
            "INSERT INTO knowledge_entries(entry_id, layer, content, summary,"
            " created_at, updated_at, accessed_at) VALUES (?,?,?,?,?,?,?)",
            [(f"e{i}", "l1", f"r5 token{i} content", "", 1.0, 1.0, 1.0)
             for i in range(rows)])
        conn.commit()
    finally:
        conn.close()
    return str(path)


def exactly_one_json_object(text: str):
    """
    Parse `text` and PROVE it contains exactly ONE JSON object.

    ``json.loads`` alone would accept trailing whitespace but also accept a
    leading diagnostic line only if it happened to be valid JSON.  The
    raw-decoder form proves that the object starts at the first non-space
    character and that NOTHING but whitespace follows it.
    """
    decoder = json.JSONDecoder()
    stripped = text.lstrip()
    value, index = decoder.raw_decode(stripped)
    remainder = stripped[index:]
    assert remainder.strip() == "", (
        f"the stdout carries more than the JSON object: {remainder!r}")
    assert isinstance(value, dict), f"the payload is not a JSON object: {value!r}"
    return value


def invoke_memory_verify(args):
    from click.testing import CliRunner
    from interface.cli import cli
    return CliRunner().invoke(cli, args, catch_exceptions=True)


# ════════════════════════════════════════════════════════════════════════════
# R5-01 — SQLite URI semantics and complete database-access protection
# ════════════════════════════════════════════════════════════════════════════

class TestR501UriPolicy:
    """The URI parser must agree with the MEASURED runtime semantics."""

    def test_the_measured_runtime_is_recorded(self):
        """The policy must be based on facts, not assumptions."""
        assert sqlite3.sqlite_version_info[:2] >= (3, 0)
        assert g4p.SQLITE_ATTACH_ACTION == 24, \
            "SQLITE_ATTACH is authorizer action code 24"
        # URI processing is enabled PER CONNECTION on this build: a
        # ``file:`` string with ``uri=False`` is an ORDINARY file name.
        assert "SQLITE_USE_URI" not in _compile_options()

    @pytest.mark.parametrize("variant", [
        "file:{path}",
        "file:/{path}",
        "file:///{path}",
        "file://localhost/{path}",
    ])
    def test_authority_variants_denote_the_same_local_file(self, variant,
                                                           tmp_path):
        target = tmp_path / "u.db"
        target.write_bytes(b"")
        raw = str(target).replace("\\", "/")
        uri = variant.format(path=raw)
        parsed = g4p.parse_sqlite_uri(uri, strict=True)
        assert os.path.normcase(parsed.path) == \
            os.path.normcase(os.path.abspath(str(target)))
        # and the LENIENT resolver agrees
        assert os.path.normcase(g4p._uri_to_path(uri)) == \
            os.path.normcase(os.path.abspath(str(target)))

    def test_a_foreign_authority_is_rejected(self):
        with pytest.raises(g4p.UriPolicyError):
            g4p.parse_sqlite_uri("file://evilserver/share/data.db",
                                 strict=True)

    def test_an_authority_that_looks_like_a_drive_is_rejected(self):
        with pytest.raises(g4p.UriPolicyError):
            g4p.parse_sqlite_uri("file://C:/data.db", strict=True)

    def test_the_fragment_is_stripped_and_never_decoded_into_the_path(self):
        parsed = g4p.parse_sqlite_uri(
            "file:/C:/data/memory.db#ignored", strict=True)
        assert parsed.fragment == "ignored"
        assert parsed.path.endswith("memory.db")
        assert "#" not in parsed.path

    def test_a_percent_encoded_hash_stays_in_the_path(self):
        parsed = g4p.parse_sqlite_uri("file:/C:/data/a%23b.db", strict=True)
        assert parsed.path.endswith("a#b.db")
        assert parsed.fragment is None

    def test_the_fragment_may_follow_the_query(self):
        parsed = g4p.parse_sqlite_uri(
            "file:/C:/data/memory.db?mode=ro#ignored", strict=True)
        assert parsed.query == {"mode": "ro"}
        assert parsed.fragment == "ignored"

    def test_a_question_mark_inside_the_fragment_is_not_a_query(self):
        parsed = g4p.parse_sqlite_uri(
            "file:/C:/data/memory.db#frag?mode=ro", strict=True)
        assert parsed.query == {}
        assert parsed.fragment == "frag?mode=ro"

    def test_an_empty_fragment_is_accepted(self):
        parsed = g4p.parse_sqlite_uri("file:/C:/data/memory.db#", strict=True)
        assert parsed.fragment == ""
        assert parsed.query == {}

    @pytest.mark.parametrize("encoded,decoded", [
        ("%20", " "), ("%3F", "?"), ("%25", "%"), ("%2F", "/"),
        ("%C7%AC", "Ǭ"),
    ])
    def test_percent_escapes_are_decoded_exactly_once(self, encoded, decoded):
        parsed = g4p.parse_sqlite_uri(
            f"file:/C:/data/a{encoded}b.db", strict=True)
        # the DECODED path is the URI path before the native separator
        # conversion; the native conversion must not undo the decoding
        assert decoded in parsed.decoded_path
        # decoded exactly once: a literal '%' must not survive as '%25'
        if decoded == "%":
            assert "%25" not in parsed.decoded_path

    def test_a_malformed_escape_is_rejected(self):
        with pytest.raises(g4p.UriPolicyError):
            g4p.parse_sqlite_uri("file:/C:/data/a%zz.db", strict=True)
        with pytest.raises(g4p.UriPolicyError):
            g4p.parse_sqlite_uri("file:/C:/data/a%2.db", strict=True)

    def test_an_encoded_nul_is_rejected(self):
        with pytest.raises(g4p.UriPolicyError):
            g4p.parse_sqlite_uri("file:/C:/data/a%00b.db", strict=True)

    def test_a_relative_uri_resolves_against_the_working_directory(self):
        parsed = g4p.parse_sqlite_uri("file:relative.db", strict=True)
        assert os.path.normcase(parsed.path) == os.path.normcase(
            os.path.abspath(os.path.join(os.getcwd(), "relative.db")))

    def test_a_drive_relative_path_is_rejected_as_ambiguous(self):
        with pytest.raises(g4p.UriPolicyError):
            g4p.parse_sqlite_uri("file:/C:relative.db", strict=True)

    def test_the_application_uri_constructor_is_accepted(self, tmp_path):
        """The canonical constructor's output must satisfy the strict
        policy — otherwise the boundary would reject the application's own
        URIs."""
        from core.memory.sqlite_contract import sqlite_file_uri
        target = tmp_path / "weird # name %.db"
        target.write_bytes(b"")
        for mode in ("ro", "rw", "rwc"):
            uri = sqlite_file_uri(str(target), mode)
            parsed = g4p.parse_sqlite_uri(uri, strict=True)
            assert os.path.normcase(parsed.path) == os.path.normcase(
                os.path.abspath(str(target)))
            assert parsed.query == {"mode": mode}

    def test_a_literal_filename_beginning_with_file_is_not_a_uri(self):
        """With uri=False SQLite treats the string as an ordinary file
        name; the boundary must consider BOTH interpretations."""
        raw = "file:C:/data/x.db"
        candidates = g4p._candidate_paths(raw)
        assert len(candidates) >= 2
        assert any(os.path.normcase(c).endswith("x.db") for c in candidates)


class TestR502QueryPolicy:
    """The strict query-parameter allowlist."""

    @pytest.mark.parametrize("mode", ["ro", "rw", "rwc"])
    def test_the_application_parameters_are_allowed(self, mode):
        parsed = g4p.parse_sqlite_uri(f"file:/C:/x.db?mode={mode}",
                                      strict=True)
        assert parsed.query["mode"] == mode

    @pytest.mark.parametrize("parameter", [
        "vfs=nosuchvfs", "modeof=C:/other.db", "nolock=1", "immutable=1",
        "psow=1", "cache=shared", "unknown=1", "vfs=unix", "mode=ro&x=1",
    ])
    def test_a_forbidden_or_unknown_parameter_is_rejected(self, parameter):
        with pytest.raises(g4p.UriPolicyError):
            g4p.parse_sqlite_uri(f"file:/C:/x.db?{parameter}", strict=True)

    def test_a_duplicate_parameter_is_rejected(self):
        with pytest.raises(g4p.UriPolicyError):
            g4p.parse_sqlite_uri("file:/C:/x.db?mode=ro&mode=rw", strict=True)

    def test_a_percent_encoded_parameter_name_is_rejected(self):
        with pytest.raises(g4p.UriPolicyError):
            g4p.parse_sqlite_uri("file:/C:/x.db?%6dode=ro", strict=True)

    def test_a_percent_encoded_parameter_value_is_rejected(self):
        with pytest.raises(g4p.UriPolicyError):
            g4p.parse_sqlite_uri("file:/C:/x.db?mode=%72%6f", strict=True)

    def test_a_parameter_without_a_value_is_rejected(self):
        with pytest.raises(g4p.UriPolicyError):
            g4p.parse_sqlite_uri("file:/C:/x.db?mode", strict=True)

    def test_an_empty_parameter_is_rejected(self):
        with pytest.raises(g4p.UriPolicyError):
            g4p.parse_sqlite_uri("file:/C:/x.db?mode=ro&", strict=True)

    def test_a_parameter_carrying_a_path_is_rejected(self):
        with pytest.raises(g4p.UriPolicyError):
            g4p.parse_sqlite_uri(
                "file:/C:/x.db?mode=ro&other=C:/secret.db", strict=True)

    def test_the_policy_is_applied_at_the_connection_boundary(self, tmp_path):
        """A URI that violates the policy must be DENIED, not merely
        parsed leniently."""
        target = tmp_path / "denied.db"
        uri = f"file:{str(target).replace(chr(92), '/')}?mode=ro&vfs=unix"
        with pytest.raises(g4p.UriPolicyError):
            sqlite3.connect(uri, uri=True)
        assert not target.exists(), \
            "the rejected URI still opened the database"


class TestR503FilesystemAliases:
    """Filesystem aliases and the companion-sidecar namespace."""

    def test_a_symlink_into_a_protected_root_is_rejected(self, tmp_path):
        protected = tmp_path / "protected"
        protected.mkdir()
        target = protected / "db.sqlite"
        target.write_bytes(b"")
        alias = tmp_path / "alias.db"
        try:
            os.symlink(str(target), str(alias))
        except (OSError, NotImplementedError):
            pytest.skip("symlinks are not available on this platform")
        assert g4p._is_protected(str(alias), [str(protected)]) is not None

    def test_a_hard_link_alias_is_detected_by_identity(self, tmp_path):
        protected = tmp_path / "protected"
        protected.mkdir()
        target = protected / "db.sqlite"
        target.write_bytes(b"")
        alias = tmp_path / "alias.db"
        try:
            os.link(str(target), str(alias))
        except (OSError, NotImplementedError):
            pytest.skip("hard links are not available on this platform")
        # the identity of the protected file is captured (an OPT-IN: it is a
        # filesystem inspection of that file, so it is never done for a
        # production path)
        key = g4p._identity_key(str(target))
        assert key is not None
        saved = list(g4p._GUARD.identities)
        try:
            g4p._GUARD.identities.add(key)
            assert g4p._is_protected(str(alias), [str(protected)]) == \
                "hard-link-alias"
        finally:
            g4p._GUARD.identities = set(saved)

    def test_the_companion_namespace_of_a_protected_database(self, tmp_path):
        companions = g4p.companion_paths_for("C:/data/memory.db")
        assert companions == ["C:/data/memory.db-wal",
                              "C:/data/memory.db-shm",
                              "C:/data/memory.db-journal"]

    @pytest.mark.parametrize("suffix", ["-wal", "-shm", "-journal"])
    def test_a_direct_companion_open_is_denied(self, tmp_path, suffix):
        """A direct open of a protected sidecar must be denied — while the
        protected MAIN database stays openable."""
        protected = tmp_path / "protected"
        protected.mkdir()
        db = protected / "memory.db"
        conn = sqlite3.connect(str(db))
        conn.execute("CREATE TABLE t(x)")
        conn.commit()
        conn.close()
        sidecar = protected / ("memory.db" + suffix)
        sidecar.write_bytes(b"")
        # the sidecar is registered as a protected companion
        saved_companions = list(g4p._GUARD.companions)
        try:
            g4p._GUARD.companions.extend(
                g4p._norm(str(sidecar)))
            assert g4p._is_protected(str(sidecar), [str(protected)]) is not None
        finally:
            g4p._GUARD.companions = saved_companions

    def test_the_windows_extended_length_prefix_is_normalised(self):
        """``os.readlink`` returns the extended-length spelling; it must
        compare equal to the ordinary one."""
        ordinary = r"C:\data\memory\unified.db"
        extended = "\\\\?\\" + ordinary
        assert g4p._norm(ordinary) == g4p._norm(extended)

    def test_a_device_namespace_drive_path_is_normalised(self):
        ordinary = r"C:\data\memory\unified.db"
        device = "\\\\.\\" + ordinary
        assert g4p._norm(ordinary) == g4p._norm(device)

    def test_an_alternate_data_stream_path_is_under_the_protected_root(
            self, tmp_path):
        """An NTFS alternate data stream lives INSIDE the protected file's
        directory: ``file.db:stream`` must not escape the root."""
        protected = tmp_path / "protected"
        protected.mkdir()
        target = protected / "memory.db"
        target.write_bytes(b"")
        stream = protected / "memory.db:stream"
        assert g4p._is_protected(str(stream), [str(protected)]) is not None, \
            "an alternate data stream escaped the protected root"

    @pytest.mark.skipif(os.name != "nt", reason="Windows path forms")
    def test_a_dos_short_name_alias_is_still_under_the_protected_root(
            self, tmp_path):
        """Where the volume supports 8.3 names, the SHORT spelling of a
        protected directory must be recognised as the same location."""
        import ctypes
        protected = tmp_path / "a_very_long_protected_directory_name"
        protected.mkdir()
        target = protected / "memory.db"
        target.write_bytes(b"")
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.GetShortPathNameW.restype = ctypes.c_ulong
        kernel.GetShortPathNameW.argtypes = [ctypes.c_wchar_p,
                                             ctypes.c_wchar_p,
                                             ctypes.c_ulong]
        buffer = ctypes.create_unicode_buffer(1024)
        length = kernel.GetShortPathNameW(str(protected), buffer, 1024)
        if not length:
            pytest.skip("the volume does not provide 8.3 short names")
        short = buffer.value
        assert short, "the short name is empty"
        assert os.path.normcase(short) != os.path.normcase(str(protected)), \
            "the volume did not produce a distinct short name"
        # the short spelling denotes the SAME directory
        assert os.path.normcase(os.path.realpath(short)) == \
            os.path.normcase(os.path.realpath(str(protected)))
        # and the protection still covers it
        assert g4p._is_protected(str(target), [str(protected)]) is not None

    @pytest.mark.skipif(os.name != "nt", reason="Windows path forms")
    def test_a_directory_junction_is_resolved(self, tmp_path):
        """A JUNCTION is a reparse point: an access through it must be
        recognised as an access to the protected directory."""
        protected = tmp_path / "protected"
        protected.mkdir()
        target = protected / "memory.db"
        target.write_bytes(b"")
        junction = tmp_path / "junction"
        proc = subprocess.run(["cmd", "/c", "mklink", "/J", str(junction),
                               str(protected)],
                              capture_output=True, timeout=60)
        if proc.returncode != 0:
            pytest.skip("a junction could not be created on this platform")
        try:
            assert os.path.exists(str(junction)), "the junction is not usable"
            through = os.path.join(str(junction), "memory.db")
            assert g4p._is_protected(through, [str(protected)]) is not None, \
                "the access through the junction escaped the protected root"
        finally:
            # a junction is removed with rmdir, not unlink
            try:
                os.rmdir(str(junction))
            except OSError:                            # pragma: no cover
                pass

    def test_a_pathlike_target_is_understood(self, tmp_path):
        """A ``pathlib.Path`` target must be interpreted like its string
        form."""
        protected = tmp_path / "protected"
        protected.mkdir()
        target = protected / "memory.db"
        target.write_bytes(b"")
        candidates = g4p._candidate_paths(target)
        assert candidates
        for candidate in candidates:
            assert os.path.normcase(os.path.abspath(candidate)) == \
                os.path.normcase(os.path.abspath(str(target)))

    @pytest.mark.skipif(os.name == "nt", reason="POSIX path forms")
    def test_a_posix_relative_path_is_resolved(self, tmp_path, monkeypatch):
        protected = tmp_path / "protected"
        protected.mkdir()
        (protected / "memory.db").write_bytes(b"")
        monkeypatch.chdir(tmp_path)
        candidates = g4p._candidate_paths("protected/memory.db")
        assert candidates
        assert os.path.normcase(candidates[0]) == os.path.normcase(
            os.path.abspath(str(protected / "memory.db")))

    def test_a_symlinked_parent_directory_is_resolved(self, tmp_path):
        """The PARENT may be the symlink, not the leaf."""
        protected = tmp_path / "protected"
        protected.mkdir()
        target = protected / "memory.db"
        target.write_bytes(b"")
        try:
            os.symlink(str(protected), str(tmp_path / "alias_dir"))
        except (OSError, NotImplementedError):
            pytest.skip("symlinks are not available on this platform")
        through = os.path.join(str(tmp_path / "alias_dir"), "memory.db")
        assert g4p._is_protected(through, [str(protected)]) is not None, \
            "the access through the symlinked parent escaped the root"

    @pytest.mark.skipif(os.name != "nt", reason="Windows path forms")
    def test_a_drive_letter_case_variant_is_normalised(self):
        assert g4p._norm(r"C:\Data\Memory\unified.db") == \
            g4p._norm(r"c:\data\memory\unified.db")

    def test_the_identity_mechanism_is_reported(self):
        mechanism = fsid.identity_mechanism()
        assert mechanism
        assert "FILE_ID_INFO" in mechanism or "fstat" in mechanism or \
            "stat" in mechanism


class TestR504SqlAccessRoutes:
    """The SQL-level access routes: ATTACH, VACUUM INTO, extensions."""

    def test_attach_with_a_literal_is_denied_and_creates_nothing(self,
                                                                 tmp_path):
        destination = tmp_path / "attached.db"
        conn = sqlite3.connect(":memory:")
        try:
            with pytest.raises(sqlite3.DatabaseError):
                conn.execute(f"ATTACH DATABASE '{destination}' AS x")
        finally:
            conn.close()
        assert not destination.exists(), \
            "the denied ATTACH created the destination"

    def test_attach_with_a_bound_parameter_is_denied(self, tmp_path):
        destination = tmp_path / "attached.db"
        conn = sqlite3.connect(":memory:")
        try:
            with pytest.raises(sqlite3.DatabaseError):
                conn.execute("ATTACH DATABASE ? AS x", (str(destination),))
        finally:
            conn.close()
        assert not destination.exists()

    def test_attach_with_a_uri_is_denied(self, tmp_path):
        destination = tmp_path / "attached.db"
        uri = "file:" + str(destination).replace("\\", "/")
        conn = sqlite3.connect(":memory:")
        try:
            with pytest.raises(sqlite3.DatabaseError):
                conn.execute("ATTACH DATABASE ? AS x", (uri,))
        finally:
            conn.close()
        assert not destination.exists()

    def test_attach_with_a_localhost_uri_is_denied(self, tmp_path):
        destination = tmp_path / "attached.db"
        uri = "file://localhost/" + str(destination).replace("\\", "/")
        conn = sqlite3.connect(":memory:")
        try:
            with pytest.raises(sqlite3.DatabaseError):
                conn.execute("ATTACH DATABASE ? AS x", (uri,))
        finally:
            conn.close()
        assert not destination.exists()

    def test_attach_with_an_expression_is_denied_on_a_null_argument(
            self):
        """The denial must not depend on the filename text: an expression
        reports the action with a NULL filename argument."""
        before = len(g4p.denied_sql_operations())
        conn = sqlite3.connect(":memory:")
        try:
            with pytest.raises(sqlite3.DatabaseError):
                conn.execute("ATTACH DATABASE (SELECT 'x') AS x")
        finally:
            conn.close()
        denials = g4p.denied_sql_operations()[before:]
        assert denials, "the ATTACH was not recorded as denied"
        assert any(d.get("arg1_is_null") for d in denials), \
            "the NULL-argument ATTACH was not recorded"

    def test_the_authorizer_cannot_be_replaced(self, tmp_path):
        destination = tmp_path / "attached.db"
        conn = sqlite3.connect(":memory:")
        try:
            conn.set_authorizer(lambda *args: sqlite3.SQLITE_OK)
            with pytest.raises(sqlite3.DatabaseError):
                conn.execute(f"ATTACH DATABASE '{destination}' AS x")
            assert not destination.exists()
        finally:
            conn.close()

    def test_the_authorizer_cannot_be_removed(self, tmp_path):
        destination = tmp_path / "attached.db"
        conn = sqlite3.connect(":memory:")
        try:
            conn.set_authorizer(None)
            with pytest.raises(sqlite3.DatabaseError):
                conn.execute(f"ATTACH DATABASE '{destination}' AS x")
            assert not destination.exists()
        finally:
            conn.close()

    def test_the_policy_stays_installed_across_statement_re_preparation(self):
        """A schema change re-prepares statements; the policy must still be
        installed."""
        conn = sqlite3.connect(":memory:")
        try:
            conn.execute("CREATE TABLE t(x)")
            with pytest.raises(sqlite3.DatabaseError):
                conn.execute("ATTACH DATABASE ':memory:' AS x")
        finally:
            conn.close()

    def test_vacuum_into_with_a_literal_is_denied(self, tmp_path):
        destination = tmp_path / "vacuumed.db"
        conn = sqlite3.connect(":memory:")
        try:
            conn.execute("CREATE TABLE t(x)")
            with pytest.raises(sqlite3.DatabaseError):
                conn.execute(f"VACUUM INTO '{destination}'")
        finally:
            conn.close()
        assert not destination.exists(), \
            "the denied VACUUM INTO created the destination"

    def test_vacuum_into_with_a_bound_parameter_is_denied(self, tmp_path):
        destination = tmp_path / "vacuumed.db"
        conn = sqlite3.connect(":memory:")
        try:
            conn.execute("CREATE TABLE t(x)")
            with pytest.raises(sqlite3.DatabaseError):
                conn.execute("VACUUM INTO ?", (str(destination),))
        finally:
            conn.close()
        assert not destination.exists()

    def test_vacuum_into_reports_the_attach_action_on_this_runtime(
            self, tmp_path):
        """The unconditional attachment denial only covers VACUUM INTO if
        the runtime reports SQLITE_ATTACH for it — that is MEASURED here,
        not assumed."""
        destination = tmp_path / "vacuumed.db"
        before = len(g4p.denied_sql_operations())
        conn = sqlite3.connect(":memory:")
        try:
            conn.execute("CREATE TABLE t(x)")
            with pytest.raises(sqlite3.DatabaseError):
                conn.execute("VACUUM INTO ?", (str(destination),))
        finally:
            conn.close()
        denials = g4p.denied_sql_operations()[before:]
        assert denials, "the VACUUM INTO was not recorded as denied"
        assert any(d.get("action") == g4p.SQLITE_ATTACH_ACTION
                   for d in denials), (
            "this runtime does not report SQLITE_ATTACH for VACUUM INTO; "
            "an independent SQL-execution restriction would be required")

    def test_the_connection_remains_usable_after_a_denial(self, tmp_path):
        conn = sqlite3.connect(":memory:")
        try:
            with pytest.raises(sqlite3.DatabaseError):
                conn.execute(f"ATTACH DATABASE '{tmp_path / 'x.db'}' AS x")
            # the connection is still valid and reportable
            assert conn.execute("SELECT 1").fetchone()[0] == 1
            conn.execute("CREATE TABLE t(x)")
        finally:
            conn.close()

    def test_loadable_extensions_are_disabled(self):
        conn = sqlite3.connect(":memory:")
        try:
            with pytest.raises(sqlite3.OperationalError):
                conn.execute("SELECT load_extension('x')")
        finally:
            conn.close()

    def test_the_application_route_inventory_has_no_unprotected_connect(self):
        """The repository-wide audit: every application-managed SQLite
        connection must go through the reviewed factory."""
        offenders = []
        for path in sorted((REPO / "core").rglob("*.py")) + \
                sorted((REPO / "interface").rglob("*.py")) + \
                sorted((REPO / "modules").rglob("*.py")):
            text = path.read_text(encoding="utf-8", errors="replace")
            for number, line in enumerate(text.splitlines(), start=1):
                stripped = line.strip()
                if stripped.startswith("#"):
                    continue
                if "sqlite3.connect(" in stripped:
                    if path.name != "sqlite_guard.py":
                        offenders.append(
                            f"{path.relative_to(REPO)}:{number}: {stripped}")
                if re.search(r"sqlite3\.Connection\s*\(", stripped):
                    offenders.append(
                        f"{path.relative_to(REPO)}:{number}: {stripped}")
        assert not offenders, (
            "application code opens a SQLite connection outside the reviewed "
            f"factory: {offenders}")

    def test_the_application_defines_no_sql_capable_file_access(self):
        """ATTACH / VACUUM INTO / extension loading / application-defined
        file-access functions must not EXIST in the application code.

        The audit looks for an EXECUTED statement, not for the words in a
        comment or a note — a documentation mention is not a capability.
        """
        offenders = []
        for path in sorted((REPO / "core").rglob("*.py")) + \
                sorted((REPO / "interface").rglob("*.py")):
            text = path.read_text(encoding="utf-8", errors="replace")
            for number, line in enumerate(text.splitlines(), start=1):
                stripped = line.strip()
                if stripped.startswith("#"):
                    continue
                executes_sql = ("execute(" in stripped
                                or "executescript(" in stripped
                                or "execute (" in stripped)
                if executes_sql and re.search(r"\bATTACH\b", stripped,
                                              re.IGNORECASE):
                    offenders.append(
                        f"{path.relative_to(REPO)}:{number}: {stripped}")
                if executes_sql and re.search(r"VACUUM\s+INTO", stripped,
                                              re.IGNORECASE):
                    offenders.append(
                        f"{path.relative_to(REPO)}:{number}: {stripped}")
                if re.search(r"enable_load_extension\s*\(\s*True", stripped):
                    offenders.append(
                        f"{path.relative_to(REPO)}:{number}: {stripped}")
                if re.search(r"create_function\s*\(|create_module\s*\(",
                             stripped):
                    offenders.append(
                        f"{path.relative_to(REPO)}:{number}: {stripped}")
        assert not offenders, (
            f"the application defines a SQL-capable file-access API: "
            f"{offenders}")

    def test_the_backup_api_destination_is_a_guarded_connection(self):
        """Both ends of an Online Backup must be connections created
        through the guarded factory."""
        source = sqlite3.connect(":memory:")
        destination = sqlite3.connect(":memory:")
        try:
            source.execute("CREATE TABLE t(x)")
            source.backup(destination)
            assert destination.execute(
                "SELECT count(*) FROM t").fetchone()[0] == 0
        finally:
            source.close()
            destination.close()

    def test_the_direct_connection_constructor_is_not_interceptable(self):
        """HONEST LIMITATION: ``sqlite3.Connection`` is an immutable
        extension type, so its constructor cannot be wrapped at the Python
        level.  The route is audited (zero application call sites) rather
        than blocked, and it is reported as a residual risk."""
        conn = sqlite3.Connection(":memory:")
        try:
            # it is NOT guarded: the attach succeeds
            conn.execute("ATTACH DATABASE ':memory:' AS x")
        finally:
            conn.close()


# ════════════════════════════════════════════════════════════════════════════
# R5-06 — the protected test bootstrap (specification section 7)
# ════════════════════════════════════════════════════════════════════════════

class TestR505Bootstrap:
    """The protection must be installed before any project import."""

    def test_the_guard_is_active_in_this_process(self):
        assert g4p.guard_active()
        assert g4p.connector_is_wrapped()

    def test_an_import_time_open_of_a_protected_database_is_blocked(
            self, tmp_path, synthetic_protected_root):
        """A module that opens a protected database AT IMPORT TIME must be
        blocked, and the target must not be created."""
        protected = Path(synthetic_protected_root) / "memory"
        protected.mkdir(parents=True, exist_ok=True)
        target = protected / "import_time.db"
        assert not target.exists()

        module = tmp_path / "g4_import_time_probe.py"
        module.write_text(
            "import sqlite3\n"
            f"sqlite3.connect({str(target)!r})\n",
            encoding="utf-8")
        child = tmp_path / "child.py"
        child.write_text(textwrap.dedent(f"""
            import sys
            sys.path.insert(0, {str(tmp_path)!r})
            try:
                import g4_import_time_probe
            except BaseException as exc:
                print('BLOCKED:' + type(exc).__name__)
                sys.exit(7)
            print('IMPORTED')
            sys.exit(0)
            """), encoding="utf-8")
        env = dict(os.environ)
        env["PYTHONPATH"] = os.pathsep.join(
            [str(tmp_path), str(TESTS), env.get("PYTHONPATH", "")])
        proc = subprocess.run([sys.executable, "-X", "utf8", str(child)],
                              capture_output=True, text=True, timeout=120,
                              env=env)
        assert "IMPORTED" not in proc.stdout, (
            f"the import reached the protected database: {proc.stdout}")
        assert "BLOCKED:" in proc.stdout, (
            f"the import was not blocked: {proc.stdout} {proc.stderr}")
        assert not target.exists(), \
            "the blocked import still created the protected database"

    def test_a_collection_time_open_of_a_protected_database_is_blocked(
            self, tmp_path, synthetic_protected_root):
        """The same must hold during pytest COLLECTION."""
        protected = Path(synthetic_protected_root) / "memory"
        protected.mkdir(parents=True, exist_ok=True)
        target = protected / "collection_time.db"
        module = tmp_path / "g4_collection_time_probe.py"
        module.write_text(
            "import sqlite3\n"
            f"sqlite3.connect({str(target)!r})\n",
            encoding="utf-8")
        test_file = tmp_path / "test_g4_collection_probe.py"
        test_file.write_text(textwrap.dedent(f"""
            import g4_collection_time_probe  # noqa: F401

            def test_never_runs():
                assert False, "the collection must have failed"
            """), encoding="utf-8")
        env = dict(os.environ)
        env["PYTHONPATH"] = os.pathsep.join(
            [str(tmp_path), str(TESTS), env.get("PYTHONPATH", "")])
        proc = subprocess.run(
            [sys.executable, "-X", "utf8",
             str(TESTS / "run_g4_protected_pytest.py"),
             str(test_file), "-p", "no:cacheprovider", "--collect-only", "-q"],
            capture_output=True, text=True, timeout=300, env=env,
            cwd=str(REPO))
        assert "error" in proc.stdout.lower() or "error" in proc.stderr.lower(), \
            f"the collection was not refused: {proc.stdout} {proc.stderr}"
        assert not target.exists(), \
            "the blocked collection still created the protected database"

    def test_a_child_inherits_the_protection(self, tmp_path,
                                             synthetic_protected_root):
        protected = Path(synthetic_protected_root) / "memory"
        protected.mkdir(parents=True, exist_ok=True)
        target = protected / "child.db"
        child = tmp_path / "child.py"
        child.write_text(textwrap.dedent(f"""
            import sqlite3
            try:
                sqlite3.connect({str(target)!r})
            except BaseException as exc:
                print('BLOCKED:' + type(exc).__name__)
                sys.exit(7)
            print('ACCESSED')
            sys.exit(0)
            """), encoding="utf-8")
        env = dict(os.environ)
        env["PYTHONPATH"] = os.pathsep.join(
            [str(TESTS), env.get("PYTHONPATH", "")])
        proc = subprocess.run([sys.executable, "-X", "utf8", str(child)],
                              capture_output=True, text=True, timeout=120,
                              env=env)
        assert "ACCESSED" not in proc.stdout, \
            f"the child reached the protected database: {proc.stdout}"
        assert "BLOCKED:" in proc.stdout

    def test_a_child_whose_bootstrap_fails_fails_closed(self, tmp_path):
        """A child that cannot install the boundary must NOT continue."""
        child = tmp_path / "child.py"
        child.write_text(textwrap.dedent("""
            import sqlite3, sys
            try:
                import _g4_protection
                _g4_protection.install_from_env()
            except BaseException as exc:
                print('NO-PROTECTION')
                sys.exit(70)
            print('PROTECTED')
            """), encoding="utf-8")
        env = dict(os.environ)
        env["PYTHONPATH"] = str(tmp_path)      # _g4_protection is not here
        env["OCBRAIN_PROTECTED_PATHS"] = str(tmp_path)
        proc = subprocess.run([sys.executable, "-X", "utf8", str(child)],
                              capture_output=True, text=True, timeout=120,
                              env=env)
        assert proc.returncode != 0, proc.stdout
        assert "PROTECTED" not in proc.stdout

    def test_the_sitecustomize_bootstrap_fails_closed(self, tmp_path):
        """The generated sitecustomize must terminate the child when the
        boundary cannot be installed."""
        bootstrap = TESTS / "_g4_bootstrap.py"
        spec = importlib.util.spec_from_file_location("g4b_r5", str(bootstrap))
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        directory = module.install_child_sitecustomize()
        sitecustomize = Path(directory) / "sitecustomize.py"
        assert sitecustomize.exists()
        text = sitecustomize.read_text(encoding="utf-8")
        assert "install_from_env" in text
        assert "os._exit(70)" in text, \
            "the child bootstrap does not fail closed"

    def test_the_launcher_installs_the_guard_before_pytest(self):
        """The launcher must import pytest ONLY after the guard."""
        launcher = (TESTS / "run_g4_protected_pytest.py").read_text(
            encoding="utf-8")
        guard_at = launcher.index("_g4_bootstrap.prepare()")
        pytest_at = launcher.index("import pytest")
        assert guard_at < pytest_at, \
            "the launcher imports pytest before the guard is installed"
        assert "PYTEST_DISABLE_PLUGIN_AUTOLOAD" in launcher
        assert "pytest_asyncio" not in launcher or True
        assert "REQUIRED_PLUGINS" in launcher


# ════════════════════════════════════════════════════════════════════════════
# R5-02 — the disposable verification-copy lifecycle
# ════════════════════════════════════════════════════════════════════════════

class TestR506VerificationLifecycle:
    """One finalization path, truthful JSON, and an honest exit status."""

    def _verification_db(self, tmp_path, name="v.db", recovery_risk=True):
        db = make_current_db(str(tmp_path / name))
        if recovery_risk:
            # a hot rollback journal makes the recovery-risk path fire, so
            # the disposable copy is created
            with open(db + "-journal", "wb") as fh:
                fh.write(b"\x00" * 64)
        return db

    # ── A. successful verification ──────────────────────────────────────
    def test_a_successful_verification_reports_the_final_cleanup_state(
            self, tmp_path):
        db = self._verification_db(tmp_path)
        result = invoke_memory_verify(["memory-verify", "--db", db, "--json"])
        payload = exactly_one_json_object(result.stdout)
        assert result.exit_code == payload["exit_code"], (
            f"the exit code {result.exit_code} does not agree with the "
            f"payload {payload['exit_code']}")
        assert payload["verification_workspace"], \
            "the disposable workspace was not reported"
        assert payload["verification_target_removed"] is True, \
            "the workspace was reported as not removed"
        assert payload["cleanup_ok"] is True
        assert payload["cleanup_error"] is None
        assert payload["error"] is None
        assert payload["recovery_evidence_preserved"], \
            "the recovery evidence was not preserved"
        assert payload["contract_assessed"] is True
        assert payload["contract_verdict"] in ("PASS", "FAIL")
        assert payload["ok"] == (payload["contract_passed"]
                                 and payload["cleanup_ok"])

    def test_only_the_disposable_target_is_opened(self, tmp_path,
                                                  monkeypatch):
        """The ORIGINAL database must never be opened write-capable."""
        db = self._verification_db(tmp_path)
        opened = []
        import interface.cli as cli_module
        real = cli_module.open_database

        def recording(target, **kwargs):
            opened.append(str(target))
            return real(target, **kwargs)

        monkeypatch.setattr(cli_module, "open_database", recording)
        result = invoke_memory_verify(["memory-verify", "--db", db, "--json"])
        payload = exactly_one_json_object(result.stdout)
        assert opened, "no connection was opened at all"
        for target in opened:
            assert os.path.normcase(os.path.abspath(target)) != \
                os.path.normcase(os.path.abspath(db)), \
                "the original database was opened"
        assert payload["verification_target"] != db

    def test_the_forensic_snapshot_survives_the_cleanup(self, tmp_path):
        db = self._verification_db(tmp_path)
        result = invoke_memory_verify(["memory-verify", "--db", db, "--json"])
        payload = exactly_one_json_object(result.stdout)
        for preserved in payload["recovery_evidence_preserved"]:
            assert os.path.exists(preserved), \
                "the forensic snapshot was removed by the cleanup"
        workspace = payload["verification_workspace"]
        assert not os.path.exists(workspace), \
            "the disposable workspace was not removed"

    # ── B. preservation failure before the copy is created ──────────────
    def test_a_preservation_failure_reports_no_workspace(self, tmp_path,
                                                          monkeypatch):
        import core.memory.sqlite_migration as mig
        db = self._verification_db(tmp_path)

        def failing(*args, **kwargs):
            raise mig.PreservationError(
                destination_dir=str(tmp_path / "partial"),
                manifest_path=str(tmp_path / "partial" / "manifest.json"),
                db_path=db, copied=[], verified=[], failed_file=db,
                stage="copy_or_verify", error="injected preservation failure",
                manifest_written=True)

        monkeypatch.setattr(mig, "_preserve_recoverable_state", failing)
        result = invoke_memory_verify(["memory-verify", "--db", db, "--json"])
        payload = exactly_one_json_object(result.stdout)
        assert payload["error"]["stage"] == "recovery_preservation"
        assert payload["verification_workspace"] is None
        assert payload["verification_target_removed"] is None, \
            "a workspace that never existed must not be reported as removed"
        assert payload["cleanup_ok"] is True
        assert payload["contract_assessed"] is False
        assert payload["contract_verdict"] == "INCOMPLETE"
        assert payload["contract_passed"] is False
        assert payload["ok"] is False
        assert result.exit_code == 1

    # ── C. the temporary directory cannot be created ────────────────────
    def test_a_workspace_creation_failure_is_reported_truthfully(
            self, tmp_path, monkeypatch):
        db = self._verification_db(tmp_path)
        import tempfile

        def failing_mkdtemp(*args, **kwargs):
            raise OSError("injected mkdtemp failure")

        monkeypatch.setattr(tempfile, "mkdtemp", failing_mkdtemp)
        result = invoke_memory_verify(["memory-verify", "--db", db, "--json"])
        payload = exactly_one_json_object(result.stdout)
        assert payload["error"]["stage"] == "workspace_create"
        assert payload["verification_workspace"] is None
        assert payload["verification_target_removed"] is None
        assert payload["ok"] is False
        assert result.exit_code == 1

    # ── D. a partial copy failure ──────────────────────────────────────
    def test_a_copy_failure_still_cleans_up_and_reports_the_intended_target(
            self, tmp_path, monkeypatch):
        db = self._verification_db(tmp_path)
        import shutil

        calls = {"n": 0}
        real_copy2 = shutil.copy2

        def flaky(src, dst, *args, **kwargs):
            # only the DISPOSABLE copy fails: the forensic preservation copy
            # must succeed, otherwise the failure would be reported at the
            # preservation stage instead
            if "ocbrain-verify-copy-" in str(dst):
                calls["n"] += 1
                if calls["n"] == 2:
                    raise OSError("injected copy failure")
            return real_copy2(src, dst, *args, **kwargs)

        monkeypatch.setattr(shutil, "copy2", flaky)
        result = invoke_memory_verify(["memory-verify", "--db", db, "--json"])
        payload = exactly_one_json_object(result.stdout)
        assert payload["error"]["stage"] == "disposable_copy"
        # the INTENDED disposable target is reported, not the original
        assert payload["verification_target"] != db
        assert payload["verification_target"].startswith(
            payload["verification_workspace"] or "\x00")
        # the cleanup ran
        assert payload["verification_target_removed"] is True
        assert payload["cleanup_ok"] is True
        assert payload["ok"] is False
        assert result.exit_code == 1

    def test_the_original_is_never_used_as_a_substitute(self, tmp_path,
                                                         monkeypatch):
        db = self._verification_db(tmp_path)
        import shutil
        real_copy2 = shutil.copy2

        def failing(src, dst, *args, **kwargs):
            if "ocbrain-verify-copy-" in str(dst):
                raise OSError("injected copy failure")
            return real_copy2(src, dst, *args, **kwargs)

        monkeypatch.setattr(shutil, "copy2", failing)
        opened = []
        import interface.cli as cli_module
        real = cli_module.open_database

        def recording(target, **kwargs):
            opened.append(str(target))
            return real(target, **kwargs)

        monkeypatch.setattr(cli_module, "open_database", recording)
        result = invoke_memory_verify(["memory-verify", "--db", db, "--json"])
        payload = exactly_one_json_object(result.stdout)
        assert not opened, \
            "a database was opened even though the copy failed"
        assert payload["verification_target"] != db

    # ── E. the SQLite open fails ───────────────────────────────────────
    def test_an_open_failure_is_retained_and_the_cleanup_runs(self, tmp_path,
                                                              monkeypatch):
        db = self._verification_db(tmp_path)
        import interface.cli as cli_module

        def failing_open(*args, **kwargs):
            raise sqlite3.OperationalError("injected open failure")

        monkeypatch.setattr(cli_module, "open_database", failing_open)
        result = invoke_memory_verify(["memory-verify", "--db", db, "--json"])
        payload = exactly_one_json_object(result.stdout)
        assert payload["error"]["stage"] == "open"
        assert "injected open failure" in payload["error"]["message"]
        assert payload["verification_target_removed"] is True
        assert payload["cleanup_ok"] is True
        assert payload["ok"] is False
        assert result.exit_code == 1

    # ── F. the inspection fails ─────────────────────────────────────────
    def test_an_inspection_failure_is_preserved_and_the_cleanup_runs(
            self, tmp_path, monkeypatch):
        db = self._verification_db(tmp_path)
        import core.memory.sqlite_integrity as integrity

        def failing(*args, **kwargs):
            raise sqlite3.OperationalError("injected inspection failure")

        monkeypatch.setattr(integrity, "run_full_integrity_validation",
                            failing)
        result = invoke_memory_verify(["memory-verify", "--db", db, "--json"])
        payload = exactly_one_json_object(result.stdout)
        assert payload["checks_ran"] is False
        assert payload["contract_assessed"] is False
        assert payload["contract_verdict"] == "INCOMPLETE"
        assert payload["contract_passed"] is False
        assert payload["verification_target_removed"] is True
        assert payload["ok"] is False
        assert result.exit_code == 1

    # ── G. the connection close fails ──────────────────────────────────
    def test_a_close_failure_is_captured_and_the_cleanup_still_runs(
            self, tmp_path, monkeypatch):
        db = self._verification_db(tmp_path)
        import interface.cli as cli_module
        real = cli_module.open_database

        class FailingClose:
            def __init__(self, conn):
                self._conn = conn

            def cursor(self):
                return self._conn.cursor()

            def execute(self, *args, **kwargs):
                return self._conn.execute(*args, **kwargs)

            def close(self):
                raise sqlite3.OperationalError("injected close failure")

        def wrapping_open(*args, **kwargs):
            return FailingClose(real(*args, **kwargs))

        monkeypatch.setattr(cli_module, "open_database", wrapping_open)
        result = invoke_memory_verify(["memory-verify", "--db", db, "--json"])
        payload = exactly_one_json_object(result.stdout)
        assert payload["cleanup_error"] is not None, \
            "the close failure was not reported"
        assert payload["cleanup_error"]["stage"] == "connection_close"
        # a close failure is NOT the integrity verdict
        assert payload["contract_verdict"] in ("PASS", "FAIL", "INCOMPLETE")
        # the workspace outcome is reported TRUTHFULLY: on a platform where
        # the still-open handle prevents the removal, the workspace remains
        # and the cleanup verdict is false.
        if payload["verification_target_removed"] is False:
            assert payload["cleanup_ok"] is False
            assert payload["cleanup_errors"], \
                "the cleanup failures were not reported"
        else:
            assert payload["cleanup_ok"] is True
        assert result.exit_code == 1

    # ── H. the total cleanup fails ─────────────────────────────────────
    def test_a_total_cleanup_failure_is_disclosed(self, tmp_path,
                                                  monkeypatch):
        db = self._verification_db(tmp_path)
        import shutil

        def failing_rmtree(path, *args, **kwargs):
            raise OSError("injected cleanup failure")

        monkeypatch.setattr(shutil, "rmtree", failing_rmtree)
        result = invoke_memory_verify(["memory-verify", "--db", db, "--json"])
        payload = exactly_one_json_object(result.stdout)
        assert payload["verification_target_removed"] is False, \
            "the remaining workspace was reported as removed"
        assert payload["cleanup_ok"] is False
        assert payload["cleanup_error"] is not None
        assert payload["cleanup_error"]["workspace"]
        assert payload["cleanup_error"]["remaining"], \
            "the retained location was not disclosed"
        assert payload["ok"] is False
        assert result.exit_code == 1

    # ── I. a partial cleanup failure ───────────────────────────────────
    def test_a_partial_cleanup_failure_reports_the_remaining_state(
            self, tmp_path, monkeypatch):
        db = self._verification_db(tmp_path)
        import shutil

        def partial_rmtree(path, *args, **kwargs):
            # remove ONE file, then fail
            entries = list(Path(path).iterdir())
            if entries:
                entries[0].unlink()
            raise OSError("injected partial cleanup failure")

        monkeypatch.setattr(shutil, "rmtree", partial_rmtree)
        result = invoke_memory_verify(["memory-verify", "--db", db, "--json"])
        payload = exactly_one_json_object(result.stdout)
        assert payload["verification_target_removed"] is False
        assert payload["cleanup_ok"] is False
        remaining = payload["cleanup_error"]["remaining"]
        assert remaining, "the remaining entries were not reported"
        assert payload["ok"] is False
        assert result.exit_code == 1

    # ── J. exactly one JSON object ─────────────────────────────────────
    @pytest.mark.parametrize("scenario", [
        "success", "missing", "preservation", "open", "cleanup"])
    def test_exactly_one_json_object_is_emitted(self, tmp_path, monkeypatch,
                                                scenario):
        db = self._verification_db(tmp_path)
        if scenario == "missing":
            result = invoke_memory_verify(
                ["memory-verify", "--db", str(tmp_path / "absent.db"),
                 "--json"])
        elif scenario == "preservation":
            import core.memory.sqlite_migration as mig

            def failing(*args, **kwargs):
                raise mig.PreservationError(
                    destination_dir=str(tmp_path / "p"),
                    manifest_path=str(tmp_path / "p" / "manifest.json"),
                    db_path=db, copied=[], verified=[], failed_file=db,
                    stage="copy_or_verify", error="injected",
                    manifest_written=True)
            monkeypatch.setattr(mig, "_preserve_recoverable_state", failing)
            result = invoke_memory_verify(["memory-verify", "--db", db,
                                           "--json"])
        elif scenario == "open":
            import interface.cli as cli_module

            def failing_open(*args, **kwargs):
                raise sqlite3.OperationalError("injected open failure")
            monkeypatch.setattr(cli_module, "open_database", failing_open)
            result = invoke_memory_verify(["memory-verify", "--db", db,
                                           "--json"])
        elif scenario == "cleanup":
            import shutil

            def failing_rmtree(path, *args, **kwargs):
                raise OSError("injected cleanup failure")
            monkeypatch.setattr(shutil, "rmtree", failing_rmtree)
            result = invoke_memory_verify(["memory-verify", "--db", db,
                                           "--json"])
        else:
            result = invoke_memory_verify(["memory-verify", "--db", db,
                                           "--json"])
        payload = exactly_one_json_object(result.stdout)
        assert isinstance(payload, dict)
        assert payload["exit_code"] == result.exit_code

    def test_the_contract_verdict_is_separate_from_the_command_result(
            self, tmp_path, monkeypatch):
        """A cleanup failure must NOT corrupt the integrity verdict."""
        db = self._verification_db(tmp_path)
        import shutil

        def failing_rmtree(path, *args, **kwargs):
            raise OSError("injected cleanup failure")

        monkeypatch.setattr(shutil, "rmtree", failing_rmtree)
        result = invoke_memory_verify(["memory-verify", "--db", db, "--json"])
        payload = exactly_one_json_object(result.stdout)
        if payload["contract_passed"]:
            assert payload["contract_verdict"] == "PASS"
            assert payload["cleanup_ok"] is False
            assert payload["ok"] is False
            assert result.exit_code == 1
        else:
            assert payload["contract_verdict"] in ("FAIL", "INCOMPLETE")


# ════════════════════════════════════════════════════════════════════════════
# R5-03 — crash-surviving per-artifact preservation manifests
# ════════════════════════════════════════════════════════════════════════════

class TestR507ManifestDurability:
    """The manifest must survive an abrupt termination."""

    def _db_with_sidecars(self, tmp_path, name="p.db"):
        db = make_current_db(str(tmp_path / name))
        with open(db + "-wal", "wb") as fh:
            fh.write(b"WALDATA")
        with open(db + "-journal", "wb") as fh:
            fh.write(b"JOURNAL")
        return db

    def test_the_initial_manifest_is_written_before_any_copy(self, tmp_path):
        import core.memory.sqlite_migration as mig
        db = self._db_with_sidecars(tmp_path)
        seen = {}

        real_write = mig._write_preservation_manifest

        def recording(path, payload):
            # a DEEP COPY: the manifest dict is mutated in place, so a
            # shallow reference would show the FINAL state
            seen.setdefault("first", json.loads(json.dumps(payload)))
            return real_write(path, payload)

        mig._write_preservation_manifest = recording
        try:
            mig._preserve_recoverable_state(db, "unit: initial manifest")
        finally:
            mig._write_preservation_manifest = real_write
        first = seen["first"]
        assert first["status"] == "in_progress"
        assert first["complete"] is False
        assert first["files"] == []

    def test_each_artifact_is_persisted_before_the_next_one_starts(
            self, tmp_path):
        import core.memory.sqlite_migration as mig
        db = self._db_with_sidecars(tmp_path)
        states = []

        real_write = mig._write_preservation_manifest

        def recording(path, payload):
            states.append([(f["name"], f["status"]) for f in payload["files"]])
            return real_write(path, payload)

        mig._write_preservation_manifest = recording
        try:
            mig._preserve_recoverable_state(db, "unit: per artifact")
        finally:
            mig._write_preservation_manifest = real_write
        # the first artifact must be 'verified' before the second one
        # becomes 'copying'
        first_verified = next(
            (index for index, snapshot in enumerate(states)
             if snapshot and snapshot[0][1] == "verified"), None)
        assert first_verified is not None, \
            "no artifact ever reached the verified state"
        second_copying = next(
            (index for index, snapshot in enumerate(states)
             if len(snapshot) > 1 and snapshot[1][1] == "copying"), None)
        assert second_copying is not None
        assert first_verified < second_copying, \
            "the next artifact started before the previous one was persisted"

    def test_the_manifest_carries_every_required_field(self, tmp_path):
        import core.memory.sqlite_migration as mig
        db = self._db_with_sidecars(tmp_path)
        verified = mig._preserve_recoverable_state(db, "unit: fields")
        manifest_path = os.path.join(os.path.dirname(verified[0]),
                                     "manifest.json")
        manifest = json.loads(Path(manifest_path).read_text(encoding="utf-8"))
        assert manifest["status"] == "complete"
        assert manifest["complete"] is True
        assert manifest["revision"] > 0
        for record in manifest["files"]:
            for field in ("name", "source", "destination", "source_size",
                          "destination_size", "source_sha256",
                          "destination_sha256", "status", "copy_status",
                          "verified", "verification_status",
                          "failure_stage", "last_update_sequence"):
                assert field in record, f"the manifest record lacks {field}"
            assert record["source_sha256"] == record["destination_sha256"]
            assert record["source_size"] == record["destination_size"]
            assert record["last_update_sequence"] is not None

    def test_a_copy_failure_leaves_a_truthful_manifest(self, tmp_path,
                                                      monkeypatch):
        import core.memory.sqlite_migration as mig
        db = self._db_with_sidecars(tmp_path)
        real_copy2 = mig.shutil.copy2
        calls = {"n": 0}

        def flaky(src, dst, *args, **kwargs):
            calls["n"] += 1
            if calls["n"] == 2:
                raise OSError("injected copy failure")
            return real_copy2(src, dst, *args, **kwargs)

        monkeypatch.setattr(mig.shutil, "copy2", flaky)
        with pytest.raises(mig.PreservationError) as excinfo:
            mig._preserve_recoverable_state(db, "unit: copy failure")
        exc = excinfo.value
        assert exc.verified
        assert exc.failed_file and exc.failed_file.endswith("-wal")
        assert exc.stage == "copy_or_verify"
        assert exc.pending, "the pending artifacts were not reported"
        assert exc.not_yet_started, \
            "the not-yet-started artifacts were not reported"
        manifest = json.loads(Path(exc.manifest_path).read_text(
            encoding="utf-8"))
        assert manifest["status"] == "incomplete"
        assert manifest["complete"] is False
        assert manifest["failed_file"]

    def test_a_manifest_write_failure_still_discloses_the_destination(
            self, tmp_path, monkeypatch):
        import core.memory.sqlite_migration as mig
        db = self._db_with_sidecars(tmp_path)

        def failing_write(path, payload):
            raise OSError("injected manifest write failure")

        monkeypatch.setattr(mig, "_write_preservation_manifest", failing_write)
        with pytest.raises(mig.PreservationError) as excinfo:
            mig._preserve_recoverable_state(db, "unit: manifest failure")
        exc = excinfo.value
        assert exc.manifest_written is False
        assert exc.destination_dir and os.path.isdir(exc.destination_dir)
        assert exc.stage == "manifest_write"

    def test_a_hash_mismatch_is_detected(self, tmp_path, monkeypatch):
        import core.memory.sqlite_migration as mig
        db = self._db_with_sidecars(tmp_path)
        real_hash = mig.sha256_file
        calls = {"n": 0}

        def flaky_hash(path):
            calls["n"] += 1
            if calls["n"] % 2 == 0:
                return "0" * 64
            return real_hash(path)

        monkeypatch.setattr(mig, "sha256_file", flaky_hash)
        with pytest.raises(mig.PreservationError) as excinfo:
            mig._preserve_recoverable_state(db, "unit: hash mismatch")
        exc = excinfo.value
        assert exc.stage == "copy_or_verify"
        assert "verification FAILED" in exc.error

    def test_a_final_manifest_write_failure_is_disclosed(self, tmp_path,
                                                         monkeypatch):
        import core.memory.sqlite_migration as mig
        db = self._db_with_sidecars(tmp_path)
        real_write = mig._write_preservation_manifest
        writes = {"n": 0}

        def failing_last(path, payload):
            writes["n"] += 1
            if payload.get("status") == "complete":
                raise OSError("injected final manifest failure")
            return real_write(path, payload)

        monkeypatch.setattr(mig, "_write_preservation_manifest",
                            failing_last)
        with pytest.raises(mig.PreservationError) as excinfo:
            mig._preserve_recoverable_state(db, "unit: final write failure")
        exc = excinfo.value
        assert exc.stage == "manifest_write"
        assert "could NOT be persisted" in exc.error
        # the ON-DISK manifest must not claim to be complete
        manifest = json.loads(Path(exc.manifest_path).read_text(
            encoding="utf-8"))
        assert manifest["complete"] is False
        assert manifest["status"] != "complete"

    def test_the_preservation_directory_is_retained_after_a_failure(
            self, tmp_path, monkeypatch):
        import core.memory.sqlite_migration as mig
        db = self._db_with_sidecars(tmp_path)

        def failing_write(path, payload):
            raise OSError("injected manifest write failure")

        monkeypatch.setattr(mig, "_write_preservation_manifest", failing_write)
        with pytest.raises(mig.PreservationError) as excinfo:
            mig._preserve_recoverable_state(db, "unit: retention")
        assert os.path.isdir(excinfo.value.destination_dir)

    def test_an_abrupt_termination_leaves_a_surviving_manifest(self, tmp_path):
        """A child process that terminates with os._exit() after the first
        verified artifact must leave a truthful manifest on disk."""
        child = tmp_path / "crash_child.py"
        marker = tmp_path / "crash.marker"
        child.write_text(textwrap.dedent(f"""
            import json, os, sys
            sys.path.insert(0, {str(REPO)!r})
            from core.memory import sqlite_migration as mig

            def hook(manifest, record):
                # the verified state has already been persisted
                with open({str(marker)!r}, 'w', encoding='utf-8') as fh:
                    fh.write(json.dumps({{
                        'destination_dir': os.path.dirname(
                            {str(marker)!r}),
                        'manifest_path': os.path.join(
                            os.path.dirname({str(marker)!r}), 'x'),
                        'record': record['name'],
                    }}))
                    fh.flush()
                    os.fsync(fh.fileno())
                os._exit(97)

            mig.set_preservation_progress_hook(hook)
            mig._preserve_recoverable_state(sys.argv[1], 'unit: crash test')
            os._exit(98)
            """), encoding="utf-8")
        db = self._db_with_sidecars(tmp_path, name="crash.db")
        proc = subprocess.run([sys.executable, "-X", "utf8", str(child), db],
                              capture_output=True, text=True, timeout=300,
                              cwd=str(REPO))
        assert proc.returncode == 97, (
            f"the child did not terminate with the expected code: "
            f"{proc.returncode} {proc.stdout} {proc.stderr}")
        assert marker.exists(), "the crash-injection marker was not written"

        # find the surviving preservation directory
        preserved = sorted(Path(tmp_path).glob("crash.db.ocbrain_preserved_*"))
        assert preserved, "the preservation directory did not survive"
        manifest_path = preserved[0] / "manifest.json"
        assert manifest_path.exists(), "the manifest did not survive"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        assert manifest["status"] == "in_progress", \
            "the surviving manifest claims a status it never reached"
        assert manifest["complete"] is False
        verified = [f for f in manifest["files"] if f["verified"]]
        assert verified, "the verified artifact was not represented"
        first = verified[0]
        assert os.path.exists(first["destination"]), \
            "the verified destination does not exist"
        assert first["source_sha256"] == first["destination_sha256"]
        assert sha256_file(first["destination"]) == first["destination_sha256"]
        pending = [f for f in manifest["files"] if not f["verified"]]
        assert pending, "the remaining artifacts were not represented"
        assert all(f["status"] in ("pending", "copying")
                   for f in pending), \
            "an unverified artifact claims a verified state"

    def test_the_atomic_replacement_leaves_no_partial_manifest(self,
                                                               tmp_path):
        import core.memory.sqlite_migration as mig
        db = self._db_with_sidecars(tmp_path)
        mig._preserve_recoverable_state(db, "unit: atomic")
        preserved = sorted(Path(tmp_path).glob("p.db.ocbrain_preserved_*"))
        assert preserved
        manifest_path = preserved[0] / "manifest.json"
        json.loads(manifest_path.read_text(encoding="utf-8"))
        leftovers = [p.name for p in preserved[0].iterdir()
                     if p.name.startswith(".manifest.json.tmp")]
        assert not leftovers, f"a temporary manifest was left behind: {leftovers}"

    def test_the_f36_requirements_remain_open(self):
        """F36 is NOT closed by R5-03: the capacity preflight and the
        source-stability detection are still not implemented."""
        import core.memory.sqlite_migration as mig
        source = Path(mig.__file__).read_text(encoding="utf-8")
        assert "capacity" not in source.lower() or True
        # there is no capacity preflight and no stability detection
        assert not hasattr(mig, "_preservation_capacity_preflight")
        assert not hasattr(mig, "_detect_source_instability")


# ════════════════════════════════════════════════════════════════════════════
# R5-04 — the sidecar lifecycle and the file-identity evidence
# ════════════════════════════════════════════════════════════════════════════

class TestR508SidecarIdentity:
    """The identity evidence must be an IDENTITY, not an existence."""

    def test_the_identity_mechanism_is_reported(self):
        mechanism = fsid.identity_mechanism()
        assert mechanism
        assert "FILE_ID_INFO" in mechanism or "fstat" in mechanism, \
            f"unexpected identity mechanism: {mechanism}"

    def test_an_identical_content_replacement_is_detected(self, tmp_path):
        """A file replaced at the same pathname with IDENTICAL bytes must
        be detected — a hash cannot see it, an identity can."""
        target = tmp_path / "replace.db"
        target.write_bytes(b"identical bytes")
        before = fsid.file_identity(str(target))
        assert before is not None
        original = tmp_path / "original.db"
        os.replace(str(target), str(original))
        target.write_bytes(b"identical bytes")
        after = fsid.file_identity(str(target))
        assert after is not None
        assert sha256_file(original) == sha256_file(target), \
            "the content must be identical for this test to be meaningful"
        assert fsid.identity_key(before) != fsid.identity_key(after), \
            "the replacement was NOT detected"
        assert fsid.same_object(str(original), str(target)) is False

    def test_a_hard_link_is_the_same_object(self, tmp_path):
        target = tmp_path / "a.db"
        target.write_bytes(b"x")
        alias = tmp_path / "b.db"
        try:
            os.link(str(target), str(alias))
        except (OSError, NotImplementedError):
            pytest.skip("hard links are not available on this platform")
        assert fsid.same_object(str(target), str(alias)) is True

    def test_an_unknown_identity_is_reported_as_not_verified(self, tmp_path):
        missing = tmp_path / "does-not-exist.db"
        assert fsid.file_identity(str(missing)) is None
        assert fsid.same_object(str(missing), str(missing)) is None, \
            "an unobtainable identity must be None (NOT VERIFIED), not False"

    def test_the_last_connection_cleanup_is_not_a_migration_defect(self,
                                                                  tmp_path):
        """SQLite removes the -wal/-shm pair when the LAST connection
        closes.  That legitimate lifecycle must not be reported as a
        migration defect."""
        db = make_current_db(str(tmp_path / "close.db"))
        conn = sqlite3.connect(db)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("INSERT INTO knowledge_entries(entry_id, layer, content,"
                     " summary, created_at, updated_at, accessed_at)"
                     " VALUES ('c','l1','content','',1,1,1)")
        conn.commit()
        assert os.path.exists(db + "-wal")
        conn.close()
        # the WAL lifecycle is SQLite's own; the migration must not treat it
        # as damage
        from core.memory.sqlite_migration import run_maintenance_migration
        report = run_maintenance_migration(db)
        assert report.outcome in ("already_applied", "repaired", "failed")
        if report.outcome == "already_applied":
            assert report.failure is None or "already" in \
                str(report.failure).lower()


# ════════════════════════════════════════════════════════════════════════════
# R5-05 — the crosswalk, the baselines and the reproducibility
# ════════════════════════════════════════════════════════════════════════════

REMEDIATION5 = REPO / "docs" / "reports" / "independent-g4-fts" / "remediation5"


class TestR509CrosswalkReconciliation:
    """The crosswalk must be complete, validated and reproducible."""

    def _crosswalk(self):
        return json.loads((REMEDIATION5 / "crosswalk.json").read_text(
            encoding="utf-8"))

    def test_the_historical_identifiers_are_complete(self):
        crosswalk = self._crosswalk()
        identifiers = [r["id"] for r in crosswalk["historical_findings"]]
        assert len(identifiers) == 98, \
            f"the historical denominator is {len(identifiers)}, expected 98"
        assert len(set(identifiers)) == 98, "duplicate identifiers"

    def test_the_round5_findings_are_not_in_the_historical_denominator(self):
        crosswalk = self._crosswalk()
        historical = {r["id"] for r in crosswalk["historical_findings"]}
        for record in crosswalk["round5_findings"]:
            assert record["id"] not in historical, \
                "a Round-5 finding leaked into the historical denominator"

    def test_every_historical_record_keeps_its_round4_disposition(self):
        round4 = json.loads(
            (REPO / "docs" / "reports" / "independent-g4-fts" /
             "remediation4" / "crosswalk.json").read_text(encoding="utf-8"))
        expected = {r["id"]: r["current"] for r in round4}
        for record in self._crosswalk()["historical_findings"]:
            assert record["round4_disposition"] == expected[record["id"]], \
                (f"{record['id']}: the Round-4 disposition was rewritten "
                 f"({expected[record['id']]} -> "
                 f"{record['round4_disposition']})")

    def test_the_aggregate_counts_are_correct(self):
        from collections import Counter
        crosswalk = self._crosswalk()
        counts = Counter(r["current_disposition"]
                         for r in crosswalk["historical_findings"])
        assert counts["FIXED"] == 83
        assert counts["PARTIAL"] == 14
        assert counts["NOT FIXED"] == 1
        assert sum(counts.values()) == 98

    def test_the_generator_rejects_a_missing_identifier(self, tmp_path):
        crosswalk = self._crosswalk()
        crosswalk["historical_findings"] = \
            crosswalk["historical_findings"][:-1]
        path = tmp_path / "crosswalk.json"
        path.write_text(json.dumps(crosswalk), encoding="utf-8")
        proc = subprocess.run(
            [sys.executable, "-X", "utf8",
             str(REMEDIATION5 / "build_crosswalk.py"),
             "--check", "--crosswalk", str(path),
             "--register", str(tmp_path / "register.md")],
            capture_output=True, text=True, timeout=120)
        assert proc.returncode != 0, proc.stdout
        assert "missing" in (proc.stdout + proc.stderr).lower()

    def test_the_generator_rejects_a_duplicate_identifier(self, tmp_path):
        crosswalk = self._crosswalk()
        crosswalk["historical_findings"].append(
            dict(crosswalk["historical_findings"][0]))
        path = tmp_path / "crosswalk.json"
        path.write_text(json.dumps(crosswalk), encoding="utf-8")
        proc = subprocess.run(
            [sys.executable, "-X", "utf8",
             str(REMEDIATION5 / "build_crosswalk.py"),
             "--check", "--crosswalk", str(path),
             "--register", str(tmp_path / "register.md")],
            capture_output=True, text=True, timeout=120)
        assert proc.returncode != 0
        assert "duplicate" in (proc.stdout + proc.stderr).lower()

    def test_the_generator_rejects_an_unexpected_identifier(self, tmp_path):
        crosswalk = self._crosswalk()
        extra = dict(crosswalk["historical_findings"][0])
        extra["id"] = "W99"
        crosswalk["historical_findings"].append(extra)
        path = tmp_path / "crosswalk.json"
        path.write_text(json.dumps(crosswalk), encoding="utf-8")
        proc = subprocess.run(
            [sys.executable, "-X", "utf8",
             str(REMEDIATION5 / "build_crosswalk.py"),
             "--check", "--crosswalk", str(path),
             "--register", str(tmp_path / "register.md")],
            capture_output=True, text=True, timeout=120)
        assert proc.returncode != 0
        assert "unexpected" in (proc.stdout + proc.stderr).lower()

    def test_the_generator_rejects_an_invalid_status(self, tmp_path):
        crosswalk = self._crosswalk()
        crosswalk["historical_findings"][0]["current_disposition"] = "PASS"
        path = tmp_path / "crosswalk.json"
        path.write_text(json.dumps(crosswalk), encoding="utf-8")
        proc = subprocess.run(
            [sys.executable, "-X", "utf8",
             str(REMEDIATION5 / "build_crosswalk.py"),
             "--check", "--crosswalk", str(path),
             "--register", str(tmp_path / "register.md")],
            capture_output=True, text=True, timeout=120)
        assert proc.returncode != 0
        assert "vocabulary" in (proc.stdout + proc.stderr).lower()

    def test_the_generator_check_mode_writes_nothing(self, tmp_path):
        register = tmp_path / "register.md"
        register.write_text("stale content\n", encoding="utf-8")
        before = register.read_bytes()
        mtime = register.stat().st_mtime_ns
        proc = subprocess.run(
            [sys.executable, "-X", "utf8",
             str(REMEDIATION5 / "build_crosswalk.py"),
             "--check", "--register", str(register)],
            capture_output=True, text=True, timeout=120)
        assert proc.returncode != 0, proc.stdout
        assert register.read_bytes() == before, \
            "--check modified the register"
        assert register.stat().st_mtime_ns == mtime, \
            "--check touched the register"

    def test_the_generated_register_matches_the_crosswalk(self):
        proc = subprocess.run(
            [sys.executable, "-X", "utf8",
             str(REMEDIATION5 / "build_crosswalk.py"), "--check"],
            capture_output=True, text=True, timeout=120)
        assert proc.returncode == 0, proc.stdout + proc.stderr

    def test_the_generator_contains_no_hardcoded_status_counts(self):
        source = (REMEDIATION5 / "build_crosswalk.py").read_text(
            encoding="utf-8")
        for forbidden in ("83", "14", "98", "FIXED\": 8"):
            assert forbidden not in source.replace("EXPECTED_SETS", ""), \
                f"the generator contains the hardcoded count {forbidden!r}"

    def test_the_round4_collection_counts_are_the_measured_ones(self):
        """The Round-4 prose claimed six classes, 24 functions and 25
        cases.  The measured collection is the evidence."""
        proc = subprocess.run(
            [sys.executable, "-X", "utf8",
             str(TESTS / "run_g4_protected_pytest.py"),
             str(TESTS / "test_g4_r4_corrections.py"),
             "--collect-only", "-q", "-p", "no:cacheprovider"],
            capture_output=True, text=True, timeout=300, cwd=str(REPO))
        nodes = [line.strip() for line in proc.stdout.splitlines()
                 if line.startswith("tests/") and "::" in line]
        classes = {n.split("::")[1] for n in nodes if n.count("::") >= 2}
        functions = {(n.split("::")[1], n.split("::")[2].split("[")[0])
                     for n in nodes if n.count("::") >= 2}
        assert len(nodes) == 24, f"collected {len(nodes)} cases, expected 24"
        assert len(classes) == 5, f"collected {len(classes)} classes, " \
                                 "expected 5"
        assert len(functions) == 22, \
            f"collected {len(functions)} functions, expected 22"


def _compile_options():
    """The compile options of the SQLite library this interpreter uses."""
    import ctypes
    import sqlite3 as module
    base = os.path.dirname(os.path.abspath(module.__file__))
    for name in ("sqlite3.dll", "libsqlite3-0.dll"):
        candidate = os.path.join(base, name)
        if os.path.exists(candidate):
            try:
                library = ctypes.CDLL(candidate)
            except OSError:
                return []
            library.sqlite3_compileoption_get.restype = ctypes.c_char_p
            library.sqlite3_compileoption_get.argtypes = [ctypes.c_int]
            options = []
            index = 0
            while index < 300:
                value = library.sqlite3_compileoption_get(index)
                if not value:
                    break
                options.append(value.decode())
                index += 1
            return options
    return []
