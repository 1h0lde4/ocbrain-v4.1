"""
tests/_g4_fsidentity.py — native filesystem identity (R5-01 §2.3, R5-04 §5.4).

The Round-3/4 boundary compared candidates by PATH STRING.  That is not an
identity: a file can be REPLACED at the same pathname by a different
filesystem object with byte-identical content, and the string comparison
cannot see the difference.

This module answers a different question — "is this the SAME filesystem
object?" — using the strongest mechanism the platform offers:

  Windows  ``GetFileInformationByHandleEx(FileIdInfo)`` returns the 64-bit
           volume serial number and the 128-bit FILE_ID of the object behind
           an OPEN HANDLE.  When that call is unavailable the module falls
           back to ``os.stat().st_dev`` / ``st_ino`` (on Windows those are
           the volume serial number and the 64-bit file index).

  POSIX    ``os.fstat()`` on a HELD file descriptor gives ``st_dev`` and
           ``st_ino`` — the POSIX file identity.

The mechanism that was actually used is ALWAYS reported, because a fallback
is a weaker guarantee and must not be presented as the stronger one.

LIMITATIONS (stated honestly — see the Round-5 report §B):

  * This is a Python-level, application-level defence-in-depth measure.
    It is NOT an OS sandbox and it is NOT race-free: between the moment a
    path is validated and the moment SQLite opens it, a hostile
    same-user process could replace the object.  No atomic
    "check-and-open-by-identity" primitive is used here.
  * A replaced file at the same pathname is detected (the identity
    changes), but only if the replacement is observed through a *handle*
    opened after the replacement.
"""
from __future__ import annotations

import ctypes
import os
import stat as _stat
from typing import Optional, Tuple

__all__ = [
    "identity_mechanism",
    "file_identity",
    "same_object",
    "identity_key",
    "IDENTITY_UNAVAILABLE",
]

IDENTITY_UNAVAILABLE = "unavailable"

# ── Windows FILE_ID_INFO ─────────────────────────────────────────────────────
# typedef struct _FILE_ID_INFO {
#   ULONG             VolumeSerialNumber;
#   FILE_ID_128       FileId;          // BYTE Identifier[16]
# } FILE_ID_INFO;
_FILE_ID_INFO_CLASS = 18                 # FileIdInfo
_INVALID_HANDLE_VALUE = -1

_win = None
if os.name == "nt":                                     # pragma: no branch
    try:
        _win = ctypes.WinDLL("kernel32", use_last_error=True)
    except OSError:                                     # pragma: no cover
        _win = None


class _FILE_ID_INFO(ctypes.Structure):                 # pragma: no cover
    """
    The NATIVE Windows layout.

    Measured on this platform (not assumed): ``sizeof(FILE_ID_INFO)`` is
    24, not 20 — ``FILE_ID_128`` is 8-byte aligned inside the structure, so
    four padding bytes follow ``VolumeSerialNumber`` and the 128-bit file
    id starts at offset 8.  Passing a 20-byte buffer makes
    ``GetFileInformationByHandleEx`` fail with ERROR_BAD_LENGTH (24).
    """
    _fields_ = [("VolumeSerialNumber", ctypes.c_ulong),
                ("_padding", ctypes.c_uint),
                ("FileId", ctypes.c_ubyte * 16)]


def _win_file_id_info(path: str):
    """
    Return ``(volume_serial_number, file_id_128_hex)`` for `path`, or None.

    The file is opened through the native handle API so that the identity is
    that of the OBJECT the path resolves to right now (a handle-based
    identity cannot be fooled by a path that was swapped between the
    directory lookup and the metadata read).
    """
    if _win is None:
        return None
    GENERIC_READ = 0x80000000
    FILE_SHARE_READ = 0x00000001
    FILE_SHARE_WRITE = 0x00000002
    FILE_SHARE_DELETE = 0x00000004
    OPEN_EXISTING = 3
    FILE_FLAG_BACKUP_SEMANTICS = 0x02000000
    INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value

    CreateFileW = _win.CreateFileW
    CreateFileW.restype = ctypes.c_void_p
    CreateFileW.argtypes = [ctypes.c_wchar_p, ctypes.c_ulong, ctypes.c_ulong,
                             ctypes.c_void_p, ctypes.c_ulong, ctypes.c_ulong,
                             ctypes.c_void_p]
    GetFileInformationByHandleEx = _win.GetFileInformationByHandleEx
    GetFileInformationByHandleEx.restype = ctypes.c_int
    GetFileInformationByHandleEx.argtypes = [ctypes.c_void_p, ctypes.c_int,
                                             ctypes.c_void_p, ctypes.c_ulong]
    CloseHandle = _win.CloseHandle
    CloseHandle.restype = ctypes.c_int
    CloseHandle.argtypes = [ctypes.c_void_p]

    handle = CreateFileW(path, GENERIC_READ,
                         FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                         None, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS, None)
    if not handle or handle == INVALID_HANDLE_VALUE:
        return None
    try:
        info = _FILE_ID_INFO()
        ok = GetFileInformationByHandleEx(handle, _FILE_ID_INFO_CLASS,
                                          ctypes.byref(info),
                                          ctypes.sizeof(info))
        if not ok:
            return None
        file_id = bytes(bytearray(info.FileId)).hex()
        return (int(info.VolumeSerialNumber), file_id)
    finally:
        CloseHandle(handle)


def _stat_identity(path: str):
    """(st_dev, st_ino) through the normal stat API (never opens the file
    for reading — it is metadata only)."""
    try:
        st = os.stat(path)
    except OSError:
        return None
    return (int(st.st_dev), int(st.st_ino))


def identity_mechanism() -> str:
    """The identity mechanism this platform provides, as a stable token."""
    if os.name == "nt":
        if _win is not None and hasattr(_win, "GetFileInformationByHandleEx"):
            return "windows:FILE_ID_INFO(volume_serial+file_id_128)"
        return "posix:stat(st_dev,st_ino)"
    return "posix:fstat(st_dev,st_ino)"


def identity_key(identity: Optional[dict]):
    """A comparable key for an identity record, or None."""
    if not identity:
        return None
    return (identity.get("mechanism"), identity.get("volume_serial"),
            identity.get("file_id"), identity.get("device"), identity.get("inode"))


def file_identity(path: str) -> Optional[dict]:
    """
    The filesystem identity of `path`, or None when it cannot be obtained.

    The returned record always names the mechanism that produced it.
    """
    if path is None:
        return None
    text = str(path)
    if os.name == "nt":
        native = _win_file_id_info(text)
        if native is not None:
            volume, file_id = native
            return {"mechanism": "windows:FILE_ID_INFO(volume_serial+file_id_128)",
                    "path": text,
                    "volume_serial": volume,
                    "file_id": file_id,
                    "device": None, "inode": None}
        stat_id = _stat_identity(text)
        if stat_id is not None:
            return {"mechanism": "posix:stat(st_dev,st_ino)",
                    "path": text,
                    "volume_serial": None, "file_id": None,
                    "device": stat_id[0], "inode": stat_id[1]}
        return None
    stat_id = _stat_identity(text)
    if stat_id is None:
        return None
    return {"mechanism": "posix:fstat(st_dev,st_ino)",
            "path": text,
            "volume_serial": None, "file_id": None,
            "device": stat_id[0], "inode": stat_id[1]}


def same_object(first: str, second: str) -> Optional[bool]:
    """
    True when both paths resolve to the SAME filesystem object.

    Returns None when the identity could not be established (the caller must
    then report NOT VERIFIED — never "different").
    """
    a = file_identity(first)
    b = file_identity(second)
    if a is None or b is None:
        return None
    ka, kb = identity_key(a), identity_key(b)
    if ka is None or kb is None:
        return None
    return ka == kb


def is_symlink(path: str) -> bool:
    try:
        return _stat.S_ISLNK(os.lstat(path).st_mode)
    except OSError:
        return False
