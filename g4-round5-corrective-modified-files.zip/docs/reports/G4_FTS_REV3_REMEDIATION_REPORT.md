# OCBrain G4–FTS Remediation — Rev 3 Amendments (Implementation & Verification Report)

**Date:** November 5, 2026
**Scope:** Rev 3 Amendments 1–12 on top of Session 4C (Rev 2) — SQLite WAL runtime gate, migration lifecycle separation, integrity validation battery, content-row identity invariants, mutation atomicity, secure-delete disposition, multi-database inventory, FTS configuration audit, search regression, checkpoint policy, failure recovery, restricted acceptance gates.
**Status of the repository:** no git repository in this workspace; all changes are uncommitted file edits. See §12 for the complete touched-file list.

---

## 0. Executive verdict (Amendment 12 — restricted, honest)

**The Rev 3 remediation implementation itself is complete and all 105 new gate tests pass — but the deployment certification as a whole CAN and MUST NOT be stated as "IMPLEMENTATION COMPLETE — ALL GATES PASS", because the production SQLite runtime of this installation is AFFECTED by the FTS5/WAL defect class and is not certifiable under the Rev 3 contract.**

Verdict precisely:

| Claim | Status |
| --- | --- |
| Rev 3 code (gates, lifecycle, checks, tests) implemented | ✅ DONE — evidence §10 |
| All 7 Rev 3 gate suites pass on this machine | ✅ 105/105 |
| Baseline suites unaffected | ✅ 109/109 (same test count as pre-Rev 3) |
| **Production runtime certified under Amendment 1** | ❌ **REFUSED** — SQLite 3.50.4 (CPython 3.14.3 build) is inside the affected range (3.7.0 … 3.51.2; fixed 3.51.3; backports 3.44.6 / 3.50.7), with no vendor-build provenance registered |
| Release readiness claim | **Blocked on Plan R1 (§4)** — remediation performed, readiness NOT reported as full; the memory service reports `ready_degraded_runtime_not_supported` until the runtime is fixed |

What "affected runtime" means for users of this installation (measured, not assumed — see §9 RF-2):

1. after **any successful DELETE** on an external-content FTS5 table, the documented `INSERT INTO fts(fts, rank) VALUES('integrity-check', 1)` command returns *"database disk image is malformed"* even though `PRAGMA integrity_check` passes on the whole file; **and**
2. the freed docid **remains MATCH-findable on the raw FTS surface** (stale index entry) while the content row is gone — the public search surface stays correct only because `search_text()` filters via its `ke.rowid = fts.rowid` JOIN.

Both are consequences of the SQLite build, not of repository code (raw-SQLite probes, independent of this repo, are in Appendix A). The remediation contract (fail-closed migration gate, identity/integrity checks, ledger, restore-after-fault behavior) all behave correctly under fault injection **on the affected runtime too**; that is exactly why the certification refusal is not a code defect claim — it is a runtime deployment condition with a documented repair plan (§4).

> **CORRECTION (Nov 10 2026) — see §16.1.** The sentence above ("Both are consequences of the SQLite build, not of repository code") is **superseded**: the FTS anomaly class described in items 1–2 follows the **pre-fix V1 `ke_ad` trigger**, not the SQLite build — with the canonical V2 trigger the same script yields zero stale hits and a passing `rank=1` on every measured runtime (3.50.4/3.51.3/3.54.1). The **certification refusal itself is unaffected**: it rests on the Amendment 1 **WAL** runtime gate, which is a separate, still-verified runtime condition (this machine: SQLite 3.50.4 → affected → refused).

---

## 1. Amendment 1 — WAL runtime compatibility gate (P0)

**Implemented.** `core/memory/sqlite_runtime.py` decides fail-closed from: (a) the affected range table (3.7.0–3.51.2; 3.51.3 fixed; documented backports 3.44.6 and 3.50.7), (b) documented-backport matching, (c) registered vendor-build provenance. A vendor build is only accepted with **complete** provenance (`source_id`, `distribution`, `evidence_url`, `verified_on`); partial/absent provenance fails closed.

- Runtime inventory (`sys.version`/`sqlite3.sqlite_version`/`sqlite_version()`/`sqlite_source_id()`/OS/machine/build provenance/`connection_model`/`automatic_checkpoint_config`) is collected and attached to readiness state.
- An affected runtime **never** reports full readiness: status is `ready_degraded_runtime_not_supported`.
- Escape hatch is **documented, test-environment-only**, and explicit: env `OCBRAIN_MEMORY_RUNTIME_ACK=acknowledge` lets construction proceed under acknowledgment while readiness stays not-full. Production default (and invalid values) fail closed to `enforce`.
- Provenance is configurable: `config/settings.toml` `[memory] wal_gate.approved_vendor_builds` (commented template shipped); `load_configured_vendor_provenance()` loads it; env var overrides settings; journal-mode garbage values resolve to `enforce`.
- Constructor refuses with a clear, actionable error (upgrade path, backports, provenance registration — pointing at §4 of this report).

**Gate suite:** `tests/test_g4_rev3_runtime_gate.py` — **30 passed** (version matrix, provenance completeness, enforce/acknowledge constructor semantics, settings fallback/resolution rules, inventory keys).

This machine's verdict (measured at every gate run): affected — Python 3.14.3 bundled SQLite `3.50.4`, source id `2025-07-30 19:33:53 4d8adfb30e03f9cf27f800a2c1ba3c48fb4ca1b08b0f5ed59a4d5ecbf45e20a3`; not a documented backport; no provenance record.

---

## 2. Amendment 2 — migration execution separated from readiness (P0)

**Implemented.**

- **Constructor = validation-only.** `SQLiteStorageBackend._init_or_validate_sync()`: absent database → canonical initialize; `current` → proceed (subject to the Am-1 runtime gate); `legacy_pending_migration` / `invalid` → refuse with `MemoryReadinessError` carrying an encapsulated remediation string ("stop all processes using this database, then run: `ocbrain memory-migrate --db <path>`"). **Zero mutation** on refusal — proven by a byte-level schema/data snapshot test (`validation-only startup zero-mutation snapshot proof`).
- **Dedicated maintenance entry point** following the repo's actual CLI architecture (click group with subcommands; local-only on purpose — maintenance runs with the app stopped):
  - `ocbrain memory-migrate --db <path>` (default from `config.get("memory.database")`, fallback `.data/memory/unified.db`) — prints the deployment contract, runs the runner, renders the step table (steps, ledger row, checkpoint, WAL figures).
  - `ocbrain memory-doctor --db <path>` — runs the full validation battery read-only (prefers read-only connections, with writable fallback; see RF-1).
  - `ocbrain memory-verify --db <path>` — focused whole-DB + FTS verification.
- **Maintenance lifecycle implemented in `core/memory/sqlite_migration.py::run_maintenance_migration`** in exactly the contracted order: gate quiescence → advisory file lock (+ `BEGIN IMMEDIATE`) → **re-read migration state after locking** → apply (canonical trigger swap + additive indexes) → FTS external-content `rebuild` → verify (identity + full integrity + retrieval + FK) → per-database ledger row → **commit** → success reported only after commit → optional post-commit `TRUNCATE` checkpoint, recorded honestly (never forced).
- Concurrency: two independent **subprocess** runners racing on one database serialize at exactly one of two outcomes — `{migrated, already_applied}` with no double-migration and no double ledger row (real child process via `tests/_g4_migration_child.py`; the refactored child re-raises exceptions without swallowing `SystemExit`).
- **Deployment contract documented** (§5) and printed by `memory-migrate` before any action.

**Gate suite:** `tests/test_g4_rev3_migration_lifecycle.py` — **12 passed** (plus per-database ledger coverage for Amendment 7: two independent DB files, each with its own lifecycle and its own ledger).

---

## 3. Amendment 3 — integrity validation is real, not a heartbeat (P0/P1)

**Implemented in `core/memory/sqlite_integrity.py`.** Four independent checks with measured costs, each result carrying status/scope/detail/duration:

1. **Whole-database `PRAGMA integrity_check`** (structural/b-tree).
2. **`PRAGMA foreign_key_check`** (honest `not_applicable` when no FKs exist).
3. **FTS5 `integrity-check(rank=1)`** — the real external-content consistency command (see RF-1 for the writable-connection requirement, RF-2 for the affected-runtime behavior after DELETE).
4. **Real `MATCH` probes** (`check_fts_retrieval`) with controlled token pairs `(token, must_match)`.

Additionally:

- **Pre-migration structural check** (Amendment 3 §B): `run_maintenance_migration` runs the whole-database structural check BEFORE any modification; on corruption it stops, classifies `preserved_corrupt`, and **preserves the database untouched** (zero-rebuild policy damage recovery).
- **Scoped results + measured costs**; no check is silent or unmeasured.
- **Cost contract:** readiness validation (`validate_readiness`) ≠ full validation: full validation runs only in the maintenance path and on demand; heartbeats/ordinary startup never pay the `rank=1` rebuild-scale cost (spied: heartbeat path doesn't invoke it).
- **Damage-detection proof:** with sync triggers dropped and content drifted, the `rank=1` command does NOT pass (it raises — recorded as `error`, which is in the failed set), while whole-DB `PRAGMA integrity_check` still passes — demonstrating the two checks are independent and why both are required.

**Gate suite (together with Amendments 4/6/8):** `tests/test_g4_rev3_sqlite_contract.py` — **31 passed**.

---

## 4. Amendment 4 — content-row identity invariants (P0)

**Implemented (`verify_content_row_identity`).** Every identity-bearing check runs and may fail loudly:

- the content table is **not `WITHOUT ROWID`**,
- **no `rowid`/`oid`/`_rowid_` shadow columns** declared,
- **rowids are unique** (unique index over `rowid` semantics verified via real queries),
- an identity FAIL case is exercised intrinsically (check must report fail, readiness must refuse).

**Disposition — the OPEN item stays OPEN on purpose:** the external-content FTS design *depends* on the content table's implicit rowid staying stable. The persistent, structural risk (future `WITHOUT ROWID` migration; external tooling rewriting the table / export-import renumbering) is **not resolved by this remediation and is not authorized to be resolved by a table rewrite**: no `VACUUM`, no table rebuild was performed or is permitted by this work (static audit asserts prod code never issues VACUUM; `VACUUM INTO` is audited-against, not enabled). The residual risk is **registered in the debt ledger as DEBT-045** (this report's internal id **DBT-R3-IDENTITY**), including what would have to be true before any rewrite could be considered.

- **Backups**: exclusively through the SQLite **Online Backup API** (`create_online_backup`) — identity-preserving, consistent snapshot; backup identity is re-verified by tests. `run_maintenance_migration` protocol offers it; no file-copy backup is used anywhere.

> **CORRECTION (Nov 10 2026) — see §16.4 (REV-G4-05): the backup helper was rebuilt.** The Nov 5 helper plain-connected the source (**creating it** when missing), created the destination before validating anything, validated no source schema, and left an unverified destination behind on failure. It now: refuses a missing/invalid source (never creates it), requires the source to verify as the **current** memory contract, opens the source **read-only** (fails closed rather than falling back to a writable connection), refuses an existing destination and alias/same-file cases, writes to a **unique temporary file** that is fully verified (integrity/FK/`rank=1`/identity mapping/schema equality) before an **atomic rename that cannot overwrite**, and removes **only** its own temporary artifact on failure. The established result contract (`identity_preserved`, `identities_compared`, `method`, `note`) is preserved.

**Gate suite:** covered inside `tests/test_g4_rev3_sqlite_contract.py` (identity checks, fail cases, OPEN-risk wording, backup API identity).

---

## 5. Amendment 5 — mutation atomicity under failure (P0)

**Implemented/proven via SQLite authorizer fault injection** (`tests/test_g4_rev3_mutation_atomicity.py` — 7 passed). Method (empirically verified before writing the tests):

- **INSERT path** → deny `SQLITE_INSERT` (action 18) on the virtual `knowledge_entries_fts` (fires for `ke_ai`'s insert and `ke_au`'s pair);
- **UPDATE path** → same INSERT denial (the canonical `ke_au` expresses update-through-external-content as the documented `'delete'` + INSERT pair — the pre-Rev 3 raw `UPDATE knowledge_entries_fts SET …` pattern is gone, so the INSERT denial is the correct instrument for the update path);
- **DELETE path** → deny `SQLITE_INSERT` (action 18) on the virtual table (`ke_ad`) — **correction, Nov 10 2026**: this line previously read "deny `SQLITE_DELETE` (action 9)", which described the PRE-FIX V1 `ke_ad` (a plain `DELETE` against the external-content FTS table). The corrected V2 `ke_ad` removes the FTS-side row through the special `'delete'`-command **INSERT**, so the authorizer instrument that actually intercepts the FTS-side mutation is `SQLITE_INSERT` on the virtual table — exactly as the test implements it (`injected(backend, sqlite3.SQLITE_INSERT, FTS_TABLE)`) and as `tests/test_g4_rev3_mutation_atomicity.py` documents in its own comment. The denial INTENT is unchanged (deny the FTS-side mutation of a content DELETE and verify full rollback); only the action code was mis-stated. See the dated addendum in §16.

Guarantees verified per path:

- the mutation **fails loudly** (authorizer "not authorized"), never silently;
- **full rollback: zero partial rows** — content table AND FTS mirror rows unchanged (mirror snapshots are scoped `WHERE id IN (SELECT rowid FROM knowledge_entries)` because FTS `_data` legitimately carries structural rows id=1 etc.);
- database remains **rank=1-consistent** after every rejected mutation (no delete ever happened, so the strict pass claim holds);
- **retry of the same operation succeeds** once the injected fault is removed, through the public API.

Also: a deliberate dead end discovered and documented — denying `SQLITE_READ` on an FTS shadow `rowid` does not fail loudly; it causes **silent desync**. It is recorded (§9 RF-3) and forbidden as an injection instrument.

---

## 6. Amendment 6 — secure-delete disposition (P1)

**Investigation only; NOT enabled.** `PRAGMA secure_delete` current values inventoried on the actual runtime (build default `0`; memory-backend connections unset it explicitly to the build default in the connection inventory) — **both stay OFF**. No setting change was made anywhere (prod-code audit: no assignment). The question "does enabling secure_delete affect FTS index handling of deleted rows?" is answered by runtime evidence: **on the affected runtime the deletion anomaly (RF-2) exists with secure_delete OFF; no claim is made about ON behavior, and enabling it is NOT authorized by this remediation.** The investigation findings are recorded (this report §7–§9); the regulatory question ("deleted-content erasure guarantees") remains an open policy item for the owner, tracked alongside DEBT-045's context. Tests: `tests/test_g4_rev3_sqlite_contract.py` (secure-delete read-only coverage).

> **ADDENDUM (Nov 10 2026) — see `KNOWN_ISSUES.md` (dated addendum, §A2).** The setting is still **OFF** and still **not** authorized to change. What this pass adds is the **erasure caveat** that was previously implicit: with `secure_delete` OFF a `DELETE` frees the row but does **not** overwrite its bytes in the database file — so "deleted from the memory store" is **logical, not physical**: the deleted text survives in the file's freed pages, in any file-level copy of the database, in the runner's **forensic preservation copies** (REV-G4-06) and in **backups** taken through the Online Backup API (which preserves exactly what the database contains). Physical erasure of a specific record would need its own decision, measurement and authorization; it is **not** implied by the deletion itself.

---

## 7. Databases of the memory subsystem — inventory (Amendment 7; measured Nov 5, 2026)

Enumerated from the actual deployment on this machine (sizes as measured; `context.sqlite` lives outside `.data/`):

| Database (path) | Subsystem / layer | Managed by | Carries the FTS trigger contract? | Rev 3 migration state (Nov 5) | Ledger file? |
| --- | --- | --- | --- | --- | --- |
| `.data/memory/unified.db` (77,824 B) | L1 episodic (`SQLiteStorageBackend`, shared singleton via `get_unified_memory(".data/memory")`) | memory storage | **YES** — `knowledge_entries` + `knowledge_entries_fts` external content | **migrated** — `ocbrain memory-migrate` executed Nov 5, outcome `migrated`, ledger row `mlc_v1_fts_external_content_trigger_contract`, checkpoint `busy=0` | yes (`_ocbrain_memory_migrations`) |
| `.data/memory/archive.db` (45,056 B) | L4 audit (`SQLiteArchiveBackend`) | memory archive | no (plain tables, no FTS5 table exists) | n/a (no contract to migrate) | no |
| `.data/memory/graph.db` (32,768 B) | L3 knowledge graph (`GraphEngine` via `core/memory/backends/sqlite_graph.py`) | memory graph | no | n/a | no |
| `.data/events/stream.db` (32,768 B) | event stream (`SQLiteEventStore`) | events | no | n/a | no |
| `.data/runtime_state.sqlite` (24,576 B) | runtime state store (`core/runtime/state.py`) | runtime | no | n/a | no |
| `data/context.sqlite` (32,768 B) | working context (`ContextMemory`, `core/context.py`) | context | no | n/a | no |
| (chroma / per-module query context dirs) | expected by the remediation plan's inventory template | modules | — | **do not exist in this deployment snapshot** (verified by directory walk) | — |

Honest consequences:

1. Exactly **one** database in this deployment carries the FTS external-content trigger contract (`unified.db`); it was migrated through the real CLI command (see §5 of the deployment steps below), and its per-database ledger proves the lifecycle.
2. The lifecycle/ledger machinery has additionally been proven against **two independent database files** whose only shared trait is the contract (lifecycle suite's `TestPerDatabaseLedgers`) — the "per-file ledger" guarantee is not a singleton accident.
3. Multiple migrations of the *same* logical store under different prefixes would each carry their own ledger — no process-global flag stands in for per-database truth.

---

## 8. Checkpoint policy (Amendment 10) — disposition & inventory

**No global policy change was made or is authorized by this remediation.**

- **Automatic checkpointing:** SQLite's default `wal_autocheckpoint=1000` **pages per connection** stays as is for every memory-backend connection. Verified live (a real backend connection reads back `journal_mode=wal`, `wal_autocheckpoint=1000`) and by static audit (no assignment of `PRAGMA wal_autocheckpoint = …` anywhere in `core/` or `interface/`; no backend writes the pragma at all).
- **Explicit checkpoint sites — the complete list (`EXPLICIT_CHECKPOINT_SITES`, static-audited against source by the test suite):**
  1. `core/runtime/state.py` — `PRAGMA wal_checkpoint(TRUNCATE)` in the runtime state store's read-modify-write repair paths (2 executing sites; this database is NOT memory-managed),
  2. `core/memory/sqlite_migration.py` — the maintenance runner's **post-commit** `TRUNCATE` checkpoint inside the verified-quiescence maintenance window.
  The memory backends (`sqlite_storage`, `sqlite_archive`, graph engine) run **no explicit checkpoints** — asserted by test.
- **Scheduling owners recorded:** automatic — SQLite autocheckpoint per connection (any writer may trigger it); explicit — only the maintenance runner (and the unrelated runtime-state repair paths).
- **busy-handling:** a blocked TRUNCATE cannot evict readers; the runner records `busy=…` honestly and never forces (`report.checkpoint["note"]`).

**Gate suite:** `tests/test_g4_rev3_policy_disposition.py` — **7 passed** (inventory keys, static execution-site audit exactly `{state.py: 2, sqlite_migration.py: 1}`, no-backend-checkpoints, no `PRAGMA wal_autocheckpoint` assignment, live default intact, maintenance checkpoint honesty).

---

## 9. Findings register (ordered by decision impact)

 tracked ids: RF-* are this report's runtime/implementation findings; DBT-R3-IDENTITY maps to the debt-ledger DEBT-045.

### RF-2 — affected SQLite build leaves deleted external-content FTS docs MATCH-findable and breaks the `rank=1` command (OPEN — blocks runtime certification; deferred to Plan R1)

> **CORRECTION (Nov 10 2026) — see §16.1: this finding is RETRACTED as a runtime finding and reclassified.** The stale MATCH / `rank=1` failure follows the **pre-fix V1 `ke_ad` trigger** (plain `DELETE` against the external-content FTS table after the content row was gone), **not** the SQLite build; the identical probe script with the canonical V2 `'delete'`-command trigger leaves **zero** stale hits and a **passing** `rank=1` on every measured runtime (3.50.4/3.51.3/3.54.1 — `EVIDENCE_NOTE.md` §3.1). The text below is kept as the Nov 5 record. The **runtime certification refusal is unchanged** (it rests on the Amendment 1 WAL gate). The suite encoding was de-conditioned (no `classify_wal_safety()` branch) and the "runtime finding" test names were renamed — §16.3.

Reproduced **independent of repository code** (raw probes; Appendix A):

- after a successful `DELETE` on an external-content FTS5 table on SQLite **3.50.4**: `SELECT … MATCH '<deleted-token>'` **still returns the freed rowid**; `SELECT count(*) FROM fts` returns 0; the `_data` mirror row is gone; the documented `integrity-check(rank=1)` command returns *"database disk image is malformed"*; whole-database `PRAGMA integrity_check` passes.
- the stale match is tied to the freed docid: rows freshly written afterward with unrelated content **do not inherit** the stale tokens;
- the **public** surface (`search_text()` → `UnifiedMemory.search()`) stays correct purely because of its `ke.rowid = fts.rowid` JOIN filter (dangling rowids have no content row).

Disposition: **not fixable inside this repo** — this is the affected-build symptom class the Amendment 1 gate exists for. The test suites encode it honestly: conditional assertions keyed on `classify_wal_safety().wal_safe` (affected-build expectations documented as findings; fixed builds must satisfy the strict forms — see `TestRuntimeFindingRank1AfterDelete`, `TestRuntimeFindingStaleMatchAfterDelete`). This is the load-bearing basis of the §0 certification refusal.

### RF-1 — `FTS5 integrity-check(rank=1)` requires a WRITABLE connection (documented SQLite behavior; repository resolved)

On every SQLite build, that command is implemented as an `INSERT` on the FTS shadow; a read-only connection refuses it with *"attempt to write a readonly database"*. Repository consequence: `memory-verify` opens its verification connection read-write (visible note in the CLI: checks themselves remain non-mutating — the only eligible "write" is the integrity-check command); `memory-doctor` prefers read-only connections as long as they suffice, with a writable fallback so the FTS-internal check can run. Recorded so no future "read-only everywhere" refactoring silently drops FTS-internal verification.

> **CORRECTION (Nov 10 2026) — see §16.2: the doctor's writable fallback is GONE.** `memory-doctor` never runs the `rank=1` check, so it never needed write access; it now opens **strictly read-only** (`mode=ro`) and **fails closed** if that open fails — no writable fallback remains (the pre-fix fallback could checkpoint/recover the very database the doctor was diagnosing; REV-G4-01). `memory-verify` keeps its writable connection and now **proves** the non-mutation claim (logical before/after facts reported as `UNCHANGED`/`CHANGED`; an incomplete battery is reported as "NOT a verified result", exit code 1).

### RF-3 — authorizer denial of SQLITE_READ on FTS shadow rowid silently desyncs (documented; forbidden instrument)

Denying `SQLITE_READ` targeting an FTS shadow row (via the test authorizer) does NOT raise: the FTS sync proceeds while its reads return nothing, entering a silent desync. Furnished as a finding both for the test-harness guidelines ("denials of READ must never be used as a fault-injection instrument for FTS sync paths") and as a caution for any production feature that instruments FTS reads.

### RF-4 — click dispatch swallowed the first subcommand token (pre-existing CLI defect; fixed)

The repo's click group defined a positional `[QUERY]` argument on the group itself; as a click parsing effect the first positional token (e.g. `memory-migrate`) was captured by the group argument instead of resolving the registered subcommand — **all subcommands were unreachable** through normal invocation. Fixed via `SubcommandFirstGroup(click.Group)` (`interface/cli.py`): when the first argument token names a registered subcommand, `parse_args` hides the positional argument for that parse and the subcommand resolves; the group callback still runs afterwards (`ctx.params.setdefault("query", None)`). A regression was kept: the group positional still works for the ordinary single-query invocation. Verified by CLI smoke (`g4_smoke2_cli.py`, rc 0) for all three maintenance commands.

### RF-5 — CLI report renderer crashed on legacy Windows consoles over `→` (found in this pass; fixed)

`_print_migration_report` used the Unicode arrow `→` in the WAL-bytes line; on a cp1252 legacy console without UTF-8 forcing, rich crashed with `UnicodeEncodeError` **after** the migration had succeeded and its output was printed. Fixed by using ASCII (`->`) in the new report helper. (Pre-existing, non-Rev-3 lines with `→` at `interface/cli.py` 166/175/530 were left untouched — out of remediation scope; they predate this work and are not maintenance-path code.)

> **ADDENDUM (Nov 10 2026) — two further CLI defects, both fixed; see §16.4.** (1) **REV-G4-08**: the CLI's *claims* about itself were wrong in both directions — `memory-doctor` documented "writes nothing to the database" while it could write, `memory-verify` pointed the operator at a migration that cannot create databases, an inspection that could not run was reported as a data finding, and the `--json` channel was emitted through `rich` and was therefore **not parseable** (it is now emitted with `click.echo`). (2) **REV-G4-08.B**: the click group's custom parser permanently dropped the group's own **Options** after the first subcommand invocation, so **every second in-process CLI call** died with `TypeError: cli() missing 1 required positional argument: 'module'` — any script, supervisor or test harness calling the CLI twice in one process hit it. Both are fixed and covered by regression tests; the operator-facing summary is in §16.9.

### DBT-R3-IDENTITY — hidden rowid persistence risk (OPEN by design; registered as DEBT-045)

See §6/Amendment 4. The identity of external-content FTS rows rests on implicit content-table rowids. **Corrected (independent Rev 3, primary source `lang_vacuum.html` §3):** rowid survival across `VACUUM` is *not* a documented SQLite guarantee for this table shape — the documentation explicitly states VACUUM *may change the ROWIDs* of entries in any table without an explicit INTEGER PRIMARY KEY (`entry_id TEXT PRIMARY KEY` is not one). A measured probe on all three engines (3.50.4 / 3.51.3 / 3.54.1, `scripts/g4_indep/probe_vacuum_rowid.py`) kept the rowid mapping unchanged across plain `VACUUM` and `VACUUM INTO` with the external-content integrity check passing afterwards — an observed behavior that the integrity battery (rank=1's post-maintenance check) re-verifies after every VACUUM, not an invariant to assert, and nothing in this work issues a VACUUM (static-audited). The structural fragility is unchanged: future schema rewrites (`WITHOUT ROWID`) or external export/import cycles. No rewrite is authorized or was performed; the risk is ledgered with explicit leave-as-is rationale and verification paths (`verify_content_row_identity` at value-adding moments).

> **ADDENDUM (Nov 10 2026).** Unchanged in substance: **nothing in this pass issues a `VACUUM` either** — the corrected backup helper uses the **Online Backup API** (never `VACUUM INTO`), and the new preservation step is a **raw file copy** (never a logical/compacting operation). One honest addition: the raw preservation copies and the backups **contain what the database contains** — including deleted-but-not-erased content, because `secure_delete` is OFF (§6 addendum). A raw file copy is forensically faithful by design; it is not an erasure mechanism.

---

## 10. Which acceptance gates passed (restricted verdict matrix)

Verdict vocabulary: **PASS** = implementation + tests satisfy the amendment's acceptance conditions on this machine; **PASS (runtime-conditional)** = passes with honest conditional encoding of the affected-runtime findings; **BLOCKED** = cannot be claimed regardless of code, per Amendment 12, until Plan R1 completes.

| Gate | Amendments | Evidence (all from `python -m pytest <suite>` on this machine) | Verdict |
| --- | --- | --- | --- |
| **Gate 0** — runtime compatibility gate | Am 1 | `test_g4_rev3_runtime_gate.py` — 30/30 | **PASS (enforces refusal on affected builds)** — runtime itself is affected; certification sense = BLOCKED until R1 |
| **Gate 1A** — migration lifecycle & readiness | Am 2 (+7 lifecycle) | `test_g4_rev3_migration_lifecycle.py` — 12/12 (incl. subprocess concurrency, zero-mutation startup refusal) | **PASS** |
| **Gate 3A** — integrity/validation contract | Am 3 (+4, 6, 8) | `test_g4_rev3_sqlite_contract.py` — 31/31 (damage injection, FK, identity incl. fail-cases + OPEN-risk text, config audit, trigger audit incl. legacy/missing/unknown, heartbeat cost cap, no-VACUUM, backup identity, secure-delete read-only) | **PASS (runtime-conditional)** |
| **Gate 4A** — mutation atomicity | Am 5 | `test_g4_rev3_mutation_atomicity.py` — 7/7 (3 paths × rollback/no-partial/consistency/retry + runtime finding) | **PASS (runtime-conditional)** → **CORRECTED Nov 10 2026: PASS (unconditional)** — `rank=1` asserted `== "pass"` with no "or error" escape (§16.3) |
| **Gate 5A** — secure-delete disposition | Am 6 | (inside Gate 3A suite; no change shipped) | **PASS** (investigation-only disposition honored) |
| **Gate 6A** — search regression across both surfaces | Am 8/9 | `test_g4_rev3_search_regression.py` — 8/8 (UPSERT-path retirements strict on BOTH surfaces; DELETE-path retirement strict on the public surface, runtime-scoped on the direct surface; token identity via rowid; integrity agreement after revisions; runtime-finding encoding) | **PASS (runtime-conditional)** → **CORRECTED Nov 10 2026: PASS (unconditional)** — direct-surface deletion retirement asserted `== []` on every runtime; the "runtime finding" names were renamed (§16.3) |
| **Gate 7A** — checkpoint policy & failure recovery | Am 10/11 | `test_g4_rev3_policy_disposition.py` — 7/7; `test_g4_rev3_failure_recovery.py` — 10/10 (SQLITE_FULL-equivalent fault matrix: all in-tx faults roll back everything and the retry succeeds; the post-commit checkpoint fault keeps the committed migration honestly failed-as-run and the retry returns `already_applied`; space-estimate honesty incl. `'an estimate, NOT a guarantee (Amendment 11)'` in `estimate_basis` carried into the ledger) | **PASS** |
| **Dependent baseline** | regression safety | `test_session4c_architecture.py` + `test_unified_memory.py` — **109/109** (same test count as the pre-Rev 3 baseline; two Session 4C tests retargeted to the Rev 3 contract, §11) | **PASS** |

**Combined total: 214/214.** No failing or skipped test in the affected set.

> **CORRECTION (Nov 10 2026) — see §16.4/§16.6: the affected set was re-run and EXTENDED.** The corrective-remediation pass added `tests/test_g4_revg4_remediation.py` (59 tests, one class per finding REV-G4-01…08) and re-ran the affected set, a memory-adjacent out-of-set set and the full repository suite; the refreshed counts are recorded in §16.6 and in `docs/reports/independent-g4-fts/remediation2/` (Deliverable E). The Nov 5 totals above remain the historical record.

### The verdict statement operates under Amendment 12

Per Amendment 12 the final verdict CANNOT be "IMPLEMENTATION COMPLETE — ALL GATES PASS" while the production SQLite runtime is affected. This report therefore claims exactly:

- **Implementation complete** (all twelve amendments implemented and test-covered),
- **Certification refused for the affected runtime** — deployment readiness is `ready_degraded_runtime_not_supported` until Plan R1 executes; the acknowledgment escape is test-environment-only and must not be used for production certification,
- Findings RF-1..RF-5 and DBT-R3-IDENTITY disclosed with dispositions — nothing scrubbed, nothing rewritten to look clean.

> **CORRECTION / ADDENDUM (Nov 10 2026) — see §16.8.** The corrective-remediation pass **retains** all three claims above (implementation complete for the amendments as corrected; certification still refused on this runtime; findings disclosed). The additional finding set **REV-G4-01 … REV-G4-08 (+08.B)** is disclosed in §16.4. **G4 remains OPEN / NOT ACCEPTED** — this pass does not close G4, does not accept the G4 deliverable and does not certify the runtime.

---

## 11. Changes made to pre-existing suites (why they changed and what they now assert)

1. `tests/test_session4c_architecture.py::TestPhase2HiddenIssueFTS5TriggerBug`
   - `test_ke_au_trigger_uses_documented_delete_insert_pattern` — the source under test was `_init_sync`, which no longer exists (the DDL moved to the canonical contract). Now asserts the canonical contract (`CANONICAL_TRIGGER_DDL["ke_au"]`): no raw `UPDATE knowledge_entries_fts`, exactly the `'delete'`-command + INSERT pair, and the `ke_ai/ke_au/ke_ad` name set.
   - `test_existing_database_is_migrated_on_reopen` → **behavior changed by design (Amendment 2)**: ordinary construction of a legacy database must now **refuse** (`MemoryReadinessError`), then `run_maintenance_migration` migrates, then the backend opens normally and the original post-conditions hold (`'delete'` in `ke_au` SQL; UPSERT revision semantics work; old token unsearchable).
2. `tests/test_session4c_architecture.py::TestDeferredIssuesRationale::test_issue7_metadata_search_deferred_to_v438` — the "USING fts5(" source probe was keyed to the inline DDL location; retargeted to `CANONICAL_FTS_DDL` with the same rationale intact (metadata is persistently NOT an indexed column).
3. Collection-safety discovery (deployment-impacting, resolved): importing `core.orchestrator` eagerly constructs the `ContextAssemblyEngine(get_unified_memory())` singleton, which builds `SQLiteStorageBackend` on the repo's real `.data/memory/unified.db`. Pre-Rev 3, that constructor silently migrated. Post-Rev 3, it **refuses** a legacy database — a hardware-level fail-closed posture that surfaces as an import-time error until the deployment runs its one-time maintenance migration. Resolution on this machine: followed the documented deployment contract — stopped nothing (no processes were running), ran `ocbrain memory-migrate --db .data/memory/unified.db` (outcome `migrated`, ledger row recorded, checkpoint `busy=0`), and re-ran the suite. This is the documented operator flow for the upgrade — it is recorded here because any Python process that imports the orchestrator path (API, agent, tests) will hit the same refusable state before maintenance runs, and that is the intended fail-closed behavior.

---

## 12. Files touched (all uncommitted — this workspace is not a git repo)

Production:

- `core/memory/backends/sqlite_storage.py` — constructor gate/ack/readiness integration (validation-only `_init_or_validate_sync`; `_resolve_configured_gate_mode`; provenance wiring; never full readiness on affected runtime).
- `core/memory/sqlite_migration.py` — `run_maintenance_migration` (fault_injection hook, quiescence, locks, re-read-post-lock, apply/rebuild/verify/ledger/commit/checkpoint), `inspect_migration_state`, `read_migration_ledger`, `estimate_migration_space`, `create_online_backup`, `collect_checkpoint_inventory`, `EXPLICIT_CHECKPOINT_SITES`, `REPRESENTATIVE_SPACE_FACTOR`.
- `core/memory/sqlite_integrity.py` — the four-check battery, `validate_readiness`/`run_full_integrity_validation`, `verify_content_row_identity`, config/trigger/secure-delete readers, cost accounting.
- `core/memory/sqlite_contract.py` — canonical DDL, `MIGRATION_ID_V1`, `MemoryReadinessError`, `KNOWN_LEGACY_DEFINITIONS`, readiness result types.
- `core/memory/sqlite_runtime.py` — `classify_wal_safety` + `load_configured_vendor_provenance` + runtime/connection inventories.
- `interface/cli.py` — three local maintenance commands (`memory-migrate`, `memory-doctor`, `memory-verify`), `_memory_db_path`, `_open_verify_connection`, `_print_migration_report`, `_MIGRATION_DEPLOYMENT_CONTRACT`, `SubcommandFirstGroup` dispatch fix, ASCII-safe WAL line.
- `config/settings.toml` — `[memory]` section (`wal_gate_mode = "enforce"`; commented vendor-provenance template).
- `tests/conftest.py` — test-env-only `OCBRAIN_MEMORY_RUNTIME_ACK=acknowledge` setdefault + `enforce_runtime_gate` fixture (documented; not a production escape).

Tests:

- `tests/test_g4_rev3_runtime_gate.py` (30)
- `tests/test_g4_rev3_migration_lifecycle.py` (12) + `tests/_g4_migration_child.py` (subprocess child)
- `tests/test_g4_rev3_sqlite_contract.py` (31)
- `tests/test_g4_rev3_mutation_atomicity.py` (7)
- `tests/test_g4_rev3_search_regression.py` (8)
- `tests/test_g4_rev3_failure_recovery.py` (10)
- `tests/test_g4_rev3_policy_disposition.py` (7)
- `tests/test_session4c_architecture.py` (2 retargets + 1 source-check retarget; net test count unchanged)

Registers/docs:

- `KNOWN_ISSUES.md` — new sync note + **DEBT-045** (DBT-R3-IDENTITY; hidden-rowid persistence risk).
- this report.

> **CORRECTION / ADDENDUM (Nov 10 2026) — see §16 and `docs/reports/independent-g4-fts/remediation2/C_CORRECTION_RECORD.md`.** The list above is the **Nov 5 2026** manifest of the Rev 3 workstream. The corrective-remediation pass added: five production files (`core/memory/sqlite_contract.py`, `sqlite_integrity.py`, `sqlite_migration.py`, `core/memory/backends/sqlite_storage.py`, `interface/cli.py`), six test files (the new `tests/test_g4_revg4_remediation.py`, `tests/conftest.py`, `tests/_crash_restart_child.py` and four pre-existing suites whose fixtures/assertions encoded the defective behavior), two probe scripts, four documentation files (this report, `EVIDENCE_NOTE.md`, `HANDOFF.md`, `KNOWN_ISSUES.md`) and the new `docs/reports/independent-g4-fts/remediation2/` deliverable set (A–G plus the Stage-1 and Stage-2 evidence trees). The exact list, with the reason for every change, is in Deliverable C.

---

## 13. Remediation Plan R1 — runtime upgrade steps (the certification blocker)

For an affected build (this machine: CPython 3.14.3 + SQLite 3.50.4), choose ONE:

1. **Preferred — full runtime upgrade:** move the interpreter/bundled SQLite to **≥ 3.51.3** (pull a newer Python build, e.g. 3.14.x with 3.51.3+, or upgrade `sqlite3` via the distribution's packaging where applicable), OR
2. **Documented backport:** install one of the fixed backport builds (**3.50.7** or **3.44.6** — the range names apply to the 3.50/3.44 patch lines), OR
3. **Vendor build with provenance:** a vendor build is only certifiable when its provenance record is registered in `config/settings.toml` `[memory] wal_gate.approved_vendor_builds` with **all** fields (`source_id`, `distribution`, `evidence_url`, `verified_on`) — partial records fail closed.

After installing the fixed runtime:

1. **Maintenance window:** stop and drain ALL OCBrain processes on this machine (API, workers, one-off scripts — anything importing the orchestrator path constructs the memory singleton). Nothing may open the DB until step 5.
2. **Backup:** `create_online_backup` (already scripted; never file-copy).
3. **Verify current state:** `ocbrain memory-doctor --db .data/memory/unified.db` → expect `current`, all four checks pass, `total_cost_s` finite.
4. **Migrate (already done here, idempotent):** `ocbrain memory-migrate --db .data/memory/unified.db` → `already_applied` expected; ledger stays single-row.
5. **Re-verify under the FIXED runtime (this is the certification step):** re-run the seven Rev 3 gate suites WITHOUT `OCBRAIN_MEMORY_RUNTIME_ACK` (enforce mode must accept the new runtime), plus the two baseline suites. The runtime-conditional finding tests (`TestRuntimeFindingRank1AfterDelete`, `TestRuntimeFindingStaleMatchAfterDelete`) must assert the strict fixed-build forms; `classify_wal_safety().wal_safe` must be true.
6. **Deployment readiness:** the memory service reports `ready` (no longer degraded); only now may any "all gates pass" claim be written into release notes.
7. **If a corruption ever appears before step 5:** stop everything; do NOT repair in place; take file-level copies only for forensics (never delete/trim `-wal`/`-shm`); treat as a preserved_corrupt case via the maintenance runner.

Note: because RF-2's symptoms only appear after deletions, a database that has never taken a DELETE under 3.50.4 is not exempt — the anomaly class is the reason for the whole gate, and clean-so-far is not evidence.

---

## 14. Deployment contract (Amendment 2 §C) — verbatim from the CLI

```
Deployment contract (Amendment 2 §C): migration runs ONLY with all
OCBrain processes stopped and drained on this machine. Live mutations
during migration invalidate its locks; the final WAL checkpoint would
be silently undone by a concurrently opened connection.
```

Operator steps: (1) stop/drain; (2) `memory-doctor --db <path>` (state snapshot); (3) optionally `create_online_backup`; (4) `memory-migrate --db <path>`; (5) re-open/verify. The runner enforces an advisory lock file (`<db>.ocbrain_migrate.lock`) on top of `BEGIN IMMEDIATE`; a second concurrent runner exits with `already_applied` (proven cross-subprocess).

---

## 15. Space-estimate basis (Amendment 11)

`estimate_migration_space` reports honest, measured pages (`page_size`, `page_count`, `freelist_pages`, `content_bytes_measured`) plus an envelope: `estimate_extra_bytes = content-table bytes × REPRESENTATIVE_SPACE_FACTOR (2.0, measured on synthetic datasets for WAL growth + FTS index rebuild envelope)` and the actual `free_bytes` of the target volume with a plain boolean `sufficient_free_estimate`. The basis string is contractual: *"...an estimate, NOT a guarantee (Amendment 11)"*, and it travels into the report AND the durable ledger row (`pre_checks_json.space.estimate_basis`) — asserted by test. No maintenance step refuses purely on the boolean; it informs operators and is recorded.

---

## 16. Corrective-remediation addendum — Nov 10, 2026 (dated; supersedes where noted)

**Status of this section:** dated and additive. It does **not** rewrite the Nov 5 2026 record above; that text remains the historical record of what was believed and measured then. Where the two disagree, **this section governs from Nov 10 2026 onward**, and the earlier text stays in place as evidence.

**Scope of this addendum:** the independent corrective remediation of the Rev 3 workstream on branch `independent/g4-fts-rev3-20261105` (HEAD `739e58c`). Eight findings **REV-G4-01 … REV-G4-08** (plus one sub-finding, **REV-G4-08.B**) were each (1) reproduced against the shipped code, (2) corrected, and (3) covered by a dedicated regression test in `tests/test_g4_revg4_remediation.py` (61 tests). All modifications are **local and uncommitted**; nothing was branched, committed, staged, pushed or merged.

### 16.1 What is superseded in §0 and RF-2 — the FTS anomaly is a TRIGGER-contract defect, not a runtime property

§0 (items 1–2) and RF-2 classified the FTS anomaly class — *"after a successful DELETE, `rank=1` reports 'malformed' and the freed docid stays MATCH-findable"* — as a consequence of the **SQLite build** ("independent of repository code"). That classification is **withdrawn as wrong**.

The corrected finding (established by the three-engine probes 3.50.4 / 3.51.3 / 3.54.1 and recorded in `docs/reports/independent-g4-fts/EVIDENCE_NOTE.md` §3.1) is: the anomaly follows the **pre-fix V1 `ke_ad` trigger** (a plain `DELETE` against the external-content FTS table *after* the content row was gone — fts5.html §4.4.4.1), **not** the SQLite build. With the canonical V2 `ke_ad` (the `'delete'`-command INSERT) the same script yields **zero** stale direct-surface hits and a **passing** `rank=1` on **every** measured runtime.

Consequences of this correction:

| Item | Before (Nov 5) | After (Nov 10, 2026) |
| --- | --- | --- |
| Classification of the stale-MATCH / `rank=1` anomaly | affected-runtime behavior | **pre-fix V1 trigger defect** — fixed in the canonical contract |
| §0 items 1–2 | presented as runtime symptoms | **superseded** by §16.1 |
| RF-2 heading ("affected SQLite build leaves deleted … MATCH-findable") | runtime finding | **superseded**: reclassified as the trigger-contract defect (RETRACTED as a runtime finding) |
| Test encoding | runtime-conditional (`classify_wal_safety().wal_safe`) | **unconditional** (renamed/de-conditioned, §16.4) |

**What this correction does NOT change:** the **certification refusal stands**. The refusal rests on the **Amendment 1 WAL runtime gate** (the WAL-reset bug class, 3.7.0–3.51.2 affected / 3.51.3 fixed / backports 3.44.6 & 3.50.7), which is a **separate and still-verified** runtime condition. This machine still runs CPython 3.14.3 with SQLite **3.50.4** → **affected** → the deployment certification remains **REFUSED** and the memory service keeps reporting `ready_degraded_runtime_not_supported`. Nothing in this addendum certifies a runtime.

### 16.2 RF-1 — the writable-connection requirement is unchanged; the *doctor* no longer needs it

RF-1 (the `rank=1` command is an INSERT and therefore needs a writable connection) **remains true**. What changed is the **separation of responsibilities**, which REV-G4-01 required:

- `memory-doctor` is now **strictly read-only**: `interface/cli._open_inspection_connection()` opens `mode=ro` and **fails closed** if that open fails (the old silent writable fallback is gone), so the doctor can never checkpoint, recover or mutate the database it diagnoses. The doctor never ran the `rank=1` check, so it never needed write access.
- `memory-verify` keeps the writable connection (it *does* run `rank=1`) and now **proves** the non-mutation claim it makes: logical facts (schema hash + content-row count) are captured before and after the battery and reported (`UNCHANGED`/`CHANGED`), and an incomplete battery is reported as **"NOT a verified result"** with exit code 1 instead of being presented as a pass.

### 16.3 Gate 6A / Gate 4A — now unconditional, and the amended suites

| Gate | Nov 5 verdict | Nov 10, 2026 verdict |
| --- | --- | --- |
| Gate 4A (mutation atomicity) | PASS (runtime-conditional) | **PASS (unconditional)** — `rank=1` is asserted `== "pass"` (no "or error" escape) after the rejected operation *and* after the successful delete |
| Gate 6A (search regression) | PASS (runtime-conditional) | **PASS (unconditional)** — direct-surface deletion retirement asserted `== []` on every runtime |

Renamed (stale "runtime finding" names removed): `TestRuntimeFindingRank1AfterDelete` → **`TestCorrectedFindingRank1AfterDelete`** (`test_rank1_after_delete_conditionally` → `test_rank1_after_delete_passes_on_every_runtime`); `TestRuntimeFindingStaleMatchAfterDelete` → **`TestCorrectedFindingStaleMatchAfterDelete`** (`test_stale_match_after_delete_conditionally` → `test_stale_match_after_delete_is_absent_on_every_runtime`); `test_delete_direct_surface_retirement_is_runtime_scoped` → **`test_delete_direct_surface_retirement_is_unconditional`**. §13 step 5's reference to the old class names is superseded accordingly.

### 16.4 The corrective findings register (REV-G4-01 … REV-G4-08)

Every finding was reproduced **before** correction; the reproduction artifacts (15 scenarios) are in `docs/reports/independent-g4-fts/remediation2/evidence/stage1/`, produced by `scripts/g4_indep/probe_revg4_stage1_repro.py`. The **same scenarios were then re-measured against the corrected code** (`scripts/g4_indep/probe_revg4_stage2_postfix.py`, artifacts in `evidence/postfix/`): **10/10 confirm the defect is gone** — the doctor no longer consumes recoverable WAL state, an unsupported database is no longer converted, index drift is detected *and* repaired, a missing target is never created, the backup helper protects both sides, the rollback journal is preserved, the inspection connection is closed, the delete-mode database is refused without conversion, and the CLI reports "unavailable" truthfully (with repeated in-process invocations working).

| ID | Defect (as reproduced) | Correction | Regression coverage |
| --- | --- | --- | --- |
| **REV-G4-01** | `memory-doctor` opened the database **write-capable** (`collect_checkpoint_inventory` plain `connect`; `_open_verify_connection` silent rw fallback). A WAL database with a committed, uncheckpointed transaction was **mutated**: the close-time checkpoint consumed the recoverable frames and rewrote the main image. | Doctor is strictly read-only (`mode=ro`, **no** writable fallback); the checkpoint inventory collects filesystem facts without a writable connection and reports an uninspectable WAL state as **UNAVAILABLE**; `memory-verify` keeps its writable connection but now *proves* non-mutation (logical before/after facts). | `TestRevg401DoctorInspectionReadOnly` (5 tests) |
| **REV-G4-02** | The migration runner mutated the target **before** classifying it: an unsupported DELETE-mode database was converted to WAL (and got `-wal`/`-shm`) before being refused. | Runner reordered: path precheck → advisory lock → raw recovery-evidence preservation → read-only space estimate → read-only inspection + pre-integrity → classification → **refusal of unsupported/absent before any persistent change** → only then `journal_mode=WAL` + `BEGIN IMMEDIATE`. | `TestRevg402MigrationPreflightOrdering` (11 tests) |
| **REV-G4-03** | Index drift was invisible: readiness checked index **names** only (a same-name wrong-definition index passed), and a missing canonical index produced `already_applied` while readiness refused the same database. | Semantic index contract (`parse_create_index` + `audit_index_contract`): target table, columns, order, ASC/DESC, uniqueness and partial predicate are compared; `current` requires the index contract to verify; the repair scope is explicit and narrow (index-only repair **skips** the FTS rebuild); unknown extra/unparseable indexes fail closed. | `TestRevg403IndexDriftRepair` (16 tests) |
| **REV-G4-04** | A migration against a **missing** path created the database file (and its sidecars) before failing; a zero-byte file was treated as an initializable target. | `absent` is **not** a migration target: a non-creating path precheck refuses missing/zero-byte/invalid-header/directory targets **before any connection**; the space estimate is read-only and never creates. | `TestRevg404MissingPaths` (7 tests) |
| **REV-G4-05** | `create_online_backup` created the **source** when it was missing, created the destination before validating anything, performed no source schema validation, and left an unverified destination behind on failure. | Both sides protected: source precheck + "current contract" classification + read-only source; destination refused if it exists, alias/same-file refused; the backup is written to a **unique temporary file**, fully verified (integrity/FK/`rank=1`/identity mapping/schema equality) and published by an **atomic rename that cannot overwrite**; failures remove **only** the operation's temporary artifact. | `TestRevg405BackupSafety` (6 tests) |
| **REV-G4-06** | Preservation omitted the rollback journal (`-journal`), and the runner's pre-integrity connection **replayed the hot journal before** preserving it — destroying the recovery evidence it was supposed to keep. | Raw, byte-verified preservation of main/`-wal`/`-shm`/**`-journal`** into a unique directory (originals retained) **before any SQLite open**; a manifest records every artifact's size + SHA-256; a copy failure fails closed; `preserved_corrupt` extends the earlier preservation set instead of replacing it. | `TestRevg406Preservation` (5 tests) |
| **REV-G4-07** | (A) the fresh-init inspection connection was never closed (Windows handle left open); (B) a current-schema database flipped to DELETE mode **passed** readiness and the first service connection silently converted it to WAL; (C) the service `_connect()` set `journal_mode=WAL` unreviewed; (D) the test suite's `get_unified_memory()` default prefix was `.data/memory` — tests **wrote to the production database**. | (A) explicit `closing()` on every opened connection; (B) a **WAL journal-mode invariant** in `validate_readiness` (externally flipped databases are refused, not silently converted); (C) the `_connect()` pragma documents that it states the mode the database already has; (D) `tests/conftest.py` redirects the memory singleton (and the CognitiveVault singleton) to isolated temp directories and installs an autouse guard that **fails any test** that changes a file under `.data/memory`. | `TestRevg407LifecycleIsolation` (3 tests) |
| **REV-G4-08** | Diagnostics claimed more than they did: `memory-doctor` documented "writes nothing to the database" while writing; `memory-verify` told the operator to "run `ocbrain memory-migrate` to create/migrate" a database that the migration refuses to create; unavailable inspections were reported as "unreadable data"; the `--json` channel was emitted through rich and was therefore **not parseable**. | Doctor/verify now state exactly what they do; refusal text points to the application's own initialization path; an inspection that cannot run is reported **UNAVAILABLE / NOT EVALUATED** (never a pass); `--json` is emitted through `click.echo` (byte-exact JSON); a failed battery is "NOT a verified result" with exit code 1. | `TestRevg408CliTruthfulness` (5 tests) |
| **REV-G4-08.B** (sub-finding, found by this workstream) | `SubcommandFirstGroup.parse_args` restored only its **Argument** params after a subcommand-first parse, permanently dropping the group's **Options** (`--module`): the **second** in-process invocation of any subcommand died with `cli() missing 1 required positional argument: 'module'`. Any script, supervisor or test harness calling the CLI twice in one process hit it. | The group's parameter list is restored **completely** (`original_params`) after the parse. | `test_cli_group_survives_repeated_in_process_invocations` |

### 16.5 Pre-existing suites that changed in this pass (and why)

These changes are **corrections of fixtures/tests that pinned the defective behavior**, not relaxations:

| Suite | Change | Reason |
| --- | --- | --- |
| `tests/test_g4_rev3_sqlite_contract.py` | `_canonical_db()` now builds the database in **WAL** mode | The fixture built a DELETE-mode "canonical" database — a shape the corrected contract legitimately refuses (REV-G4-07.B). The canonical contract includes WAL. |
| `tests/test_g4_indep_trigger_contract.py` | `_apply_canonical_schema()` now sets `PRAGMA journal_mode=WAL` | Same fixture correction (the delete-trigger semantics under test are unaffected). |
| `tests/test_g4_rev3_search_regression.py` | Stale "runtime finding" names/docstrings renamed; the direct-surface deletion assertion de-conditioned to `== []` | The conditional form encoded the refuted classification (§16.1). |
| `tests/test_g4_rev3_mutation_atomicity.py` | Strict `rank1_status == "pass"` after the rejected operation (and after the successful delete); stale `ke_ad` class docstring corrected | §16.3. |
| `tests/conftest.py` | Memory-singleton + CognitiveVault redirect; autouse production-access guard | REV-G4-07.D. |

**Unchanged on purpose:** `tests/test_check_drift.py` still has its **3 pre-existing Windows path-separator failures** — byte-identical to the pre-change baseline and **out of scope** for this remediation (they are reported, not silently fixed).

### 16.6 Honest disclosure — production-data access detected during this workstream

Two incidents of **implicit production access from the test suite** were observed and are recorded here in full:

1. **Before this pass (historical):** `.data/memory/{unified,archive,graph}.db` mtimes moved during a prior session's out-of-set run: `tests/test_cognitive_memory.py::test_retrieval_fusion` / `test_context_assembly` call `get_unified_memory()` with the **default prefix** and **write** to the production database. Recorded as the origin of REV-G4-07.D.
2. **During this pass (detected by the new guard):** the guard raised `REV-G4-07.D violation` for `.data/memory/cognitive/vault_v4.json` (1723 → 2583 bytes): `core.memory.cognitive_vault.cognitive_vault` is a module-level singleton built with the **default production storage directory**, and `tests/test_cognitive_memory.py::test_cognitive_storage_and_provenance` wrote through it. The production vault now contains **3 identical duplicate pairs** of the two test entries (the file was already polluted by earlier runs). The singleton is now redirected to an isolated directory; the guard proves no further write.
3. **Also during this pass (found by inspection, not by the first guard version):** `core.memory.graph.graph_engine.graph_engine` is a **third** module-level singleton with the default `.data/memory/graph.db`; `tests/test_cognitive_memory.py::test_graph_relationships` writes through it. The production `graph.db` mtime moved during a full-suite run **without changing the file's size** — which is why the first, size-only version of the guard did not flag it. The singleton is now redirected as well, and the guard fingerprints **(size, mtime_ns)** so a same-size write cannot pass unnoticed.
4. **Also during this pass (found by the hardened guard, in a spawned worker):** `core/workers/curator.py` constructs the memory backend **at import time** with the default production prefix, so the **subprocess** spawned by `tests/test_workflow_crash_restart_subprocess.py` opened the production `unified.db` (read-only, for the readiness inspection) and left a `-shm` artifact behind. The child-process helper now installs the same isolation **before** its heavy imports.

**Not done, deliberately:** the production vault file was **not** rewritten — this workstream does not modify production data. An operator may clear `.data/memory/cognitive/vault_v4.json` (the application recreates it) — the duplicate entries are test-generated and carry no operator meaning.

### 16.7 Runtime record (this pass) and certification status

| Item | Value |
| --- | --- |
| Interpreter | CPython **3.14.3** |
| Bundled SQLite | **3.50.4** (`sqlite_source_id` 2025-07-30 19:33:53 4d8adfb…) — **inside the affected range 3.7.0–3.51.2** |
| Documented backports | 3.44.6 / 3.50.7 — **not** installed |
| Registered vendor-build provenance | **none** |
| Amendment 1 verdict | **affected → certification REFUSED** (unchanged) |
| `OCBRAIN_MEMORY_RUNTIME_ACK=acknowledge` | **test-environment-only**; it lets the suite construct backends while readiness stays `ready_degraded_runtime_not_supported`. It is **never** a production certification and is **not** used as one. |

### 16.8 Governance disposition

**G4 remains OPEN / NOT ACCEPTED.** This addendum records corrections to the Rev 3 implementation and their evidence; it does **not** close G4, does **not** accept the G4 deliverable, and does **not** certify the runtime. The §0 certification refusal (§16.1) stands, DEBT-045 remains **OPEN**, and the §13 Plan R1 upgrade steps remain the only route to a certifiable deployment.

### 16.9 Operator instructions under the corrected commands (Nov 10 2026)

The corrections change what the three maintenance commands **do** and **say**. Operator-facing summary:

**`ocbrain memory-doctor --db <path>` — strictly read-only.**
* It opens the database **read-only** (`mode=ro`). It never checkpoints, recovers, converts a journal mode or writes content. A read-only open of a WAL database may still create **empty** `-wal`/`-shm` coordination artifacts (SQLite behavior, no content) and may rewrite `-shm` bytes; the database image and any WAL frames are untouched.
* If the WAL state cannot be inspected read-only (for example a `-wal` without its `-shm`), the report says **UNAVAILABLE** — it does **not** fall back to a write-capable connection and it does **not** claim a result.
* `--json` output is now emitted with `click.echo` and is **byte-exact, parseable JSON** (previously rich soft-wrapped it into invalid JSON).

**`ocbrain memory-verify --db <path>` — full battery, writable connection, proven non-mutating.**
* This command keeps a **read-write** connection because the FTS5 `rank=1` integrity-check is implemented as an `INSERT`.
* It now **proves** its non-mutation claim: logical facts (schema hash + content-row count) are captured before and after the battery and reported as `UNCHANGED` / `CHANGED`.
* If the battery cannot complete, the command prints **"NOT a verified result"** and exits non-zero — it never reports a pass it did not measure.
* If the database does not exist, the command refuses and **creates nothing**; it points at the application's own initialization path (start OCBrain once on that path). It does **not** suggest `memory-migrate` to create a database — the migration never creates databases.

**`ocbrain memory-migrate --db <path>` — refuses before it mutates.**
* A **missing**, zero-byte, non-SQLite or directory target is refused with **no** connection attempted and **nothing** created — database creation belongs to the application's startup path.
* Recovery artifacts (`-wal`/`-shm`/`-journal`) are **copied and hash-verified before any SQLite open**, so a hot journal cannot be replayed before it is preserved. The originals are retained; a `manifest.json` records every artifact's size and SHA-256.
* An unsupported schema is refused **before** any persistent change (no journal-mode conversion, no sidecars). A database that is already current reports `already_applied` — a read-only decision, with no write transaction opened.
* Only an eligible target (a recognized legacy database, or an explicitly recognized repairable drift) is converted to WAL and migrated. Index-only repairs **do not** rebuild the FTS index; unknown trigger or index definitions are **never** dropped — the migration fails closed.

**Backups (`create_online_backup`).** A missing source is never created; the source must verify as a **current** memory database; the destination must not exist (and must not alias the source); the backup is written to a unique temporary file, **fully verified** (integrity, foreign keys, `rank=1`, schema equality, content-row identity mapping) and only then published with an atomic rename that cannot overwrite. On failure only that temporary artifact is removed.

---

## 17. Definitive corrective remediation addendum — Nov 10–11, 2026 (dated; supersedes where noted)

**Status of this section:** dated and additive. It does **not** rewrite the Nov 5 2026 record above; that text remains the historical record of what was believed and measured then. Where the two disagree, **this section governs from Nov 10 2026 onward**.

**Scope:** an independent adversarial review of the Rev 3 implementation (plus the earlier corrective pass) raised **38 further findings (F01–F38)**. This addendum records their dispositions. The full register — with the evidence class of every finding, the correction, the modified paths and the proving test — is in `docs/reports/independent-g4-fts/remediation3/A_FINDINGS_REGISTER.md`. All changes are **local and uncommitted** on top of HEAD `739e58c` plus the supplied change set.

### 17.1 The state machine is now explicit

| State | Meaning | Allowed action |
| --- | --- | --- |
| `absent` | no schema objects at all | dedicated initialization only (never the migration) |
| `current` | canonical schema + valid ledger + WAL mode | readiness validation |
| `legacy_pending_migration` | an exactly recognized historical schema | dedicated maintenance migration |
| `repairable_drift` | an exactly, explicitly permitted drift | narrow maintenance repair |
| `invalid` | unsupported or inconsistent schema | refuse |
| `inspection_unavailable` | a required inspection could not complete | refuse |
| `preserved_corrupt` | an actual integrity failure | preserve and refuse |
| `outcome_uncertain` | the durable migration result could not be established | operator investigation |

No generic fallback converts an unknown state into a repairable one, and **a repairable state without a complete, validated repair scope fails closed** (the previous broad default — trigger replacement + FTS rebuild — was removed).

### 17.2 Readiness is a complete contract

A database is *current* only when **all** of these verify: the content-table definition,
the external-content FTS5 definition, the canonical synchronization triggers, the
canonical index definitions (verified **semantically and physically**), the FTS
configuration, the **exact** housekeeping table definitions, exactly one applied ledger
row for the current migration plus exactly one current schema-state marker, the WAL
journal mode, a valid content-row identity, and every required inspection completed.
A nonzero ledger count is not sufficient; a matching index name is not sufficient; a
passing FTS `rank=1` check does not prove that the triggers are correct.

### 17.3 SQL comparison is now quote-aware

`normalize_sql()` no longer removes comments with a whole-statement regular expression
and no longer compares with Unicode case folding. String-literal values are preserved
byte-for-byte (`'unknown'` and `'UNKNOWN'` are different statements), comments are
recognised only outside quoted content, identifiers are folded ASCII-only, and an
unterminated quote raises instead of being compared optimistically. Both DDL parsers
reject an unrecognized grammar as UNKNOWN — never CANONICAL.

### 17.4 Foreign keys, indexes and triggers fail closed

* Foreign-key detection uses an **exact** allowlist of internal/shadow tables (a
  prefix exclusion silently ignored user tables such as
  `knowledge_entries_fts_custom`), keeps every violation row, and reports an
  unavailable inspection as an **error** — never as “no relationships”. A failing
  foreign-key preflight **stops the migration before** any journal-mode change.
* Index classification cross-checks the stored DDL against the live
  `PRAGMA index_list` / `index_xinfo` metadata; a metadata failure is an ERROR, and
  unknown drift outranks repairable drift.
* A canonical **name** owned by **another table** (index or trigger) is a collision:
  the migration refuses and the unrelated object is never dropped.
* Only the two **documented historical trigger sets** (pre-Session-4C and Session-4C
  V1) are recognized as repairable legacy states; an arbitrary partial trigger set
  fails closed.

### 17.5 The maintenance runner refuses before it mutates

Path precheck → advisory lock → raw recovery preservation → read-only space estimate
→ read-only inspection and pre-integrity → foreign-key preflight → classification →
**refusal of unsupported/absent before any persistent change** → only then the
authorized journal-mode transition and the migration transaction. A failed post-lock
re-inspection fails closed instead of reusing the pre-lock state, and a structural
**ERROR** is no longer reported as confirmed corruption.

### 17.6 Operator-visible behaviour changes

| Command | New behaviour |
| --- | --- |
| `memory-migrate` | a current-schema database whose journal mode was changed externally is now **repairable**: the command restores WAL mode (new outcome `repaired`) without touching triggers, indexes, the FTS index or the ledger. |
| `memory-migrate` | a failure before the commit is classified from the **durable ledger** as committed, **confirmed rollback** or `outcome_uncertain` — “the transaction rolled back; nothing was recorded” is no longer assumed. |
| `memory-migrate` | a busy checkpoint is reported as `blocked` (with the log/checkpointed frame counts), not as `done`; the migration itself stays committed. |
| `memory-doctor` | strictly read-only, no writable fallback, no sidecar removal; an uninspectable state is reported as **UNAVAILABLE**. |
| `memory-verify` | keeps its writable connection (the FTS5 `rank=1` command requires it) and reports the measured logical invariance. |

### 17.7 The test environment cannot touch production data

The earlier pass’s *detection* harness (compare after the fact) was replaced by a
**prevention** boundary installed before pytest collects: a temporary memory path is
established before any OCBrain module is imported (the production-default singletons
construct their store at import time), and `sqlite3.connect` / `open` / `os.remove` /
`os.rename` / `os.replace` are blocked against the production memory directory and the
production configuration files — in the parent process **and in every child process**
(through a generated `sitecustomize.py`). The previous detection harness remains as a
secondary net, now fingerprinting `(size, mtime_ns)` so a same-size write cannot pass
unnoticed.

### 17.8 What this addendum does NOT do

* It does **not** certify a runtime: this machine still runs SQLite **3.50.4** (inside
  the affected range) → the §0 certification refusal **stands**, and Plan R1 remains
  the only route to a certifiable deployment.
* It does **not** close G4, does **not** accept the G4 deliverable and does **not**
  change any governance decision.
* It does **not** close **DEBT-045** (still OPEN), does **not** change
  `secure_delete` (still OFF — now with the recorded erasure caveat), and does
  **not** change `wal_autocheckpoint`, the space factor or the advisory-lock-is-not-
  fencing disclosure.
* The findings that are **NOT FIXED** (F10, F11, F23, F26, F28, F36) are listed with
  their residual risk in Deliverable F — they are not presented as resolved.

---

## 18. Corrective round 4 addendum — Nov 11, 2026 (dated; supersedes where noted)

**Status:** dated and additive. Sections 0–17 are **not** rewritten; they remain the historical record of what was believed and measured then. Where this section disagrees with them, **this section governs from Nov 11 2026 onward**.

**Scope:** six further defects (R4-01 … R4-06) found by an independent review of the third corrective round, plus a cross-artifact reconciliation of the historical finding identifiers. All changes are **local and uncommitted** on top of HEAD `739e58c` plus the supplied change set.

### 18.1 R4-01 — the Windows SQLite URI bypass in the production protection boundary (HIGH, acceptance blocker)

The application opens memory databases through `sqlite_file_uri()`, which on Windows produces
`file:/C:/Users/…/.data/memory/unified.db?mode=rw`. The protection boundary's URI parser stripped
the scheme and the query string but **did not normalize the `/C:/…` drive form**, so the
URI-derived candidate normalized to `c:\c:\users\…` — which does not match the protected root
`c:\users\…\.data\memory`. The application's **own** URI form therefore passed the boundary in
`ro`, `rw` **and** `rwc` (reproduced before the fix).

`_uri_to_path()` is now a platform-aware parser: the query is split at the first `?` **before**
percent-decoding; `file://authority/path` is parsed as an authority form (UNC share, or an empty
authority meaning an absolute path); the path component is percent-decoded so encoded spaces, `#`,
`?`, `%` and non-ASCII characters are restored exactly; and on Windows the drive form becomes a
native drive path. POSIX handling, symlink resolution and the hard-link identity fallback are
preserved. Proof: `tests/test_g4_r4_corrections.py::TestR401UriProtection` (11 cases, including
the **wrapped** `sqlite3.connect` raising while the underlying connector is never reached, the child
process inheriting the boundary, and the child **failing closed** when installation fails).

### 18.2 R4-02 — the journal-mode-only repair bypassed the pre-mutation preservation (HIGH)

The runner returned through the journal-mode-only repair **before** the generic pre-mutation
preservation block, so a `PRAGMA journal_mode=WAL` — a *persistent* database transition — could
execute with no pre-mutation evidence. The order is now **preservation → then** the
journal-mode-only branch; an existing recovery snapshot is reused rather than duplicated; a
preservation failure **refuses** the transition. The narrow repair contract is unchanged (no FTS
rebuild, no trigger replacement, no index recreation, no duplicate ledger row, no migration
transaction), and the step trace now records the skipped operations explicitly.

### 18.3 R4-03 — incomplete preservation sets are now self-describing (HIGH)

`_preserve_recoverable_state()` writes an **initial manifest with `status="in_progress"`**, records
each artifact as it is copied and verified, and marks the manifest `complete` or **`incomplete`**
(with the failed artifact and the error). Failures raise the new `PreservationError`, carrying the
destination directory, the manifest path, the source path, the copied and verified artifacts, the
failed artifact, the stage, the underlying error and whether the manifest could be written at all.
The partial set is **retained**, never deleted and never presented as complete; every caller
reports `preservation.disposition`, the destination and the manifest path, and the remediation
text names the real location.

### 18.4 R4-04 — `memory-verify --json` now emits one parseable JSON object on every path (MEDIUM)

The command has one documented JSON schema. Every early refusal, every failure (open, preservation,
disposable copy, inspection) and every success emits **exactly one** JSON object on stdout; Rich
output is confined to the text mode and diagnostics go to **stderr** in JSON mode. Unexecuted
inspections are represented as failed/unavailable, never as passing; the payload and the exit code
always agree; a missing path never creates a database.

### 18.5 R4-05 — the disposable verification copy is disposed (MEDIUM)

When a writable open could consume recovery evidence, the raw artifact set is preserved
**forensically** (retained) and the writable verification runs against a **managed** disposable copy
whose artifacts are hash-verified against their sources before the open, and which is **removed**
when the command ends — on success, failure, open failure, inspection exception and copy failure.
The command never falls back to verifying the original.

### 18.6 R4-06 — interaction scenarios H and I now prove their invariants (MEDIUM)

Scenario I establishes the FTS `rank=1` PASS precondition independently and asserts it **exactly**
(the previous `in ("pass", "fail")` permitted the very result the scenario claims to distinguish).
Scenario H hashes the main database, the WAL, the `-shm` and the journal before and after the
run, asserts byte identity for the main file and the WAL, asserts that no journal appeared and
that **no preservation copy** was created; the `-shm` claim is made **precisely** (a coordination
file whose bytes are not claimed to be preserved; it is asserted to be neither removed nor
replaced).

### 18.7 Reconciled totals (the third-round headline was inconsistent)

The authoritative crosswalk is **generated** from one table and validated deterministically: **98
identifiers** (F01–F38, F39–F56, R39–R56, W01–W24), each appearing **exactly once**.

| Set | Identifiers | FIXED | PARTIAL | NOT FIXED |
| --- | ---: | ---: | ---: | ---: |
| F01–F38 | 38 | 30 | 7 | 1 |
| F39–F56 | 18 | 15 | 3 | 0 |
| R39–R56 | 18 | 15 | 3 | 0 |
| W01–W24 | 24 | 20 | 4 | 0 |
| **ALL** | **98** | **83** | **14** | **1** |

The third-round headline ("18 FIXED / 6 PARTIAL") contradicted its own table ("20 / 4") and is
**superseded**. The conflicting aggregate statuses for F31 (both FIXED and PARTIAL) and F36 (both
PARTIAL and NOT FIXED) are resolved: **F31 = PARTIAL**, **F36 = NOT FIXED**. Four further findings
are re-evaluated against this round's implementation: **F10 → FIXED**, **F11 → FIXED**,
**F26 → FIXED**, **F28 → FIXED** — each with the executable evidence named in the register.
**F36 is NOT fixed**: the capacity preflight and the copy-stability detection remain unimplemented
(the incomplete-manifest correction is a *different* requirement).

### 18.8 What this addendum does NOT do

* It does **not** certify a runtime: the environment still runs SQLite **3.50.4** (inside the
  affected range) → the §0 certification refusal **stands**, and Plan R1 remains the only route to
  a certifiable deployment.
* It does **not** close G4, does **not** accept the G4 deliverable and does **not** change any
  governance decision.
* It does **not** close **DEBT-045** (still OPEN), does **not** change `secure_delete`,
  `wal_autocheckpoint`, the space factor or the canonical DDL.
* The **14 PARTIAL / 1 NOT FIXED** findings are open risks, listed with their residual risk in
  `docs/reports/independent-g4-fts/remediation4/F_RESIDUAL_RISK_REGISTER.md`.
* The third-round package `remediation3/` is retained **immutable** as the historical review
  target; this round's package is `remediation4/`.

---

## 20. Corrective round 5 addendum — Nov 12, 2026 (dated; supersedes where noted)

This section is the **dated Round-5 record**. It supersedes the Round-4
addendum (§18) **only where it explicitly says so**. Sections 0–18 and
Appendices A–B are preserved unchanged as history.

(The live report has no §19 — the Round-4 addendum is §18 — so the
Round-5 addendum takes the **§20** number the Round-5 specification
assigns to it.)

### 20.1 Scope and governance

Round 5 was a **corrective** round on the Round-4 working tree, limited to
five work packages plus the specification's protected-test-bootstrap
requirement. Nothing else was touched: no architecture was redesigned, no
unrelated debt was closed, **SQLite was not upgraded**, and **no acceptance
decision was made**.

| ID | Work package | Disposition |
|---|---|---|
| R5-01 | SQLite URI semantics and complete database-access protection | FIXED |
| R5-02 | Disposable verification-copy lifecycle and truthful JSON | FIXED |
| R5-03 | Crash-surviving per-artifact preservation manifests | FIXED |
| R5-04 | Correct sidecar lifecycle and file-identity evidence | FIXED |
| R5-05 | Baseline reconstruction, crosswalk reconciliation, evidence reproducibility | FIXED |
| R5-06 | Protected test bootstrap (specification §7) | FIXED |

Governance is **unchanged**: **G4 OPEN / NOT ACCEPTED**; DEBT-045 **OPEN**;
F36 **OPEN / NOT FIXED**; SQLite runtime certification **NOT READY**;
deployment certification **NOT READY**; freeze **NOT AUTHORIZED**; production
deployment **NOT AUTHORIZED**.

### 20.2 The three source states (supersedes nothing; adds §1's baseline)

The Round-4 corrections were local and uncommitted, so the recorded Git
HEAD does **not** contain the complete Round-4 implementation. A comparison
between the current tree and a clean checkout of HEAD would therefore be
**invalid** as a Round-5 regression comparison. Three separately
identifiable source states are reconstructed in **separate temporary
directories**; the working tree is never used as a baseline.

| ID | Source state | Purpose |
|---|---|---|
| B0 | the pristine export of the exact Git HEAD `739e58ce…` | the historical repository baseline |
| B4 | B0 + the verified Round-4 archive overlay | the actual Round-4 implementation baseline |
| B5 | B4 + the Round-5 overlay | the implementation under review |

The Round-4 archive is the **immutable historical input**: SHA-256
`1c75f7fc1033aad2f1b1c57969a05fed68f4a569418c9556f70900db7cf6ee0c`, 76
entries, 425 105 bytes — verified before extraction, and nested **verbatim**
in the Round-5 package. The reconstruction checks every overlay entry
against the **expected base hash** (an ordinary extraction does not
establish that a replacement was based on the expected original file),
rejects unexpected paths and validates the final fingerprint. The measured
B4 reconstruction has **0 discrepancies** against the Round-4 manifest
parsed from **inside** the archive.

The three fingerprints, the per-path manifests and the reconstruction
output are in
`docs/reports/independent-g4-fts/remediation5/logs/baseline_reconstruction.json`.

### 20.3 The 28-versus-30 path-inventory discrepancy is resolved

Both numbers are correct — they describe **two different moments**. **28**
was the state **before** Round 4 (18 modified + 10 untracked); Round 4
itself added two paths (`tests/test_g4_r4_corrections.py` and
`docs/reports/independent-g4-fts/remediation4/`), so the state **after**
Round 4 is **18 modified + 12 untracked = 30**. No file was lost and no
contradiction exists.

### 20.4 R5-01 — the measured SQLite runtime and the corrected URI policy

The URI policy is based on **measured** runtime facts, not assumptions
(`remediation5/logs/sqlite_runtime_probe.json`,
`remediation5/logs/sqlite_uri_semantics.json`):

* SQLite **3.50.4**, source id
  `2025-07-30 19:33:53 4d8adfb30e03f9cf27f800a2c1ba3c48fb4ca1b08b0f5ed59a4d5ecbf45e20a3`;
* `SQLITE_USE_URI` is **not** a compile option of this build and there is
  no global URI configuration — URI processing is enabled **per connection**;
  a `file:` string passed with `uri=False` is an **ordinary file name**;
* `SQLITE_ALLOW_URI_AUTHORITY` is **not** compiled in — SQLite itself
  rejects a foreign authority (`invalid uri authority: …`);
* `SQLITE_ATTACH` is authorizer action code **24**;
* **`VACUUM INTO` reports `SQLITE_ATTACH` (24) on this runtime**, so the
  unconditional attachment denial covers it;
* `ATTACH DATABASE (<expression>)` reports action 24 with a **NULL**
  filename argument, so the denial cannot depend on the filename text;
* `SQLITE_DBCONFIG_ENABLE_ATTACH_CREATE` / `..._ATTACH_WRITE` are **not
  exposed** by CPython — the authorizer is the only complete control.

The boundary's parser now treats the URI **component-wise** (scheme,
authority, path, query, fragment), decodes percent escapes **exactly once**
at the byte level, rejects malformed escapes and encoded NULs, strips the
fragment, and applies a **strict query allowlist**: only `mode` with the
values `ro`, `rw`, `rwc`. `vfs`, `modeof`, `nolock`, `immutable`, `psow`,
unknown parameters, duplicate parameters, percent-encoded parameter names
and values, valueless parameters and empty parameters are all **rejected**.
A malformed or ambiguous `file:` target is **denied at the connection
boundary**; it is never retried as an ordinary file name.

Every application-managed SQLite connection now goes through one reviewed
factory (`core/memory/sqlite_guard.py`). `core/runtime/state.py` no longer
replaces the global `sqlite3.connect` — that monkeypatch captured the
**unguarded** connector at import time and could therefore bypass the
boundary entirely.

The route inventory is in
`remediation5/B_DATABASE_ACCESS_ROUTE_INVENTORY.md`.

**Explicit limits:** the boundary is an application-level control, **not** an
OS sandbox; it is **not** atomic against a hostile same-user process; the
`sqlite3.Connection` **constructor** cannot be intercepted at the Python
level and is therefore **audited** (zero application call sites) rather than
blocked.

### 20.5 R5-02 — one finalization path in `memory-verify`

The Round-4 failure helper emitted the JSON **before** the cleanup had run,
`verification_target_removed` was initialised to `false` for a workspace
that never existed, and `shutil.rmtree(..., ignore_errors=True)` swallowed a
cleanup failure while the command still exited 0.

The command now has **one** authoritative serialization point and the
payload carries `contract_passed`, `contract_assessed`, `contract_verdict`
(`PASS`/`FAIL`/`INCOMPLETE`), `cleanup_ok`, `ok`, `verification_target`,
`verification_target_removed` (`true`/`false`/`null`),
`recovery_evidence_preserved`, `error`, `cleanup_error`, `cleanup_errors`,
`verification_workspace` and `exit_code`. A cleanup failure **never**
corrupts the integrity verdict: the contract can report `PASS` while
`cleanup_ok` is `false`, `ok` is `false` and the exit code is 1.

### 20.6 R5-03 — crash-surviving preservation manifests

The manifest is replaced **atomically** (temporary file in the same
directory → `flush` → `fsync` → same-directory `os.replace` → directory
`fsync` on POSIX) and every artifact advances through a **persisted**
progression `pending → copying → copied → verified` with a monotonic
revision and a per-record `last_update_sequence`. The copied artifact is
`fsync`-ed before it may be marked verified.

An isolated child process that terminates with `os._exit()` after the first
verified artifact leaves a **truthful** surviving manifest: valid JSON,
`status=in_progress`, `complete=false`, the first artifact `verified` with
matching hashes, the remaining ones still pending.

**The durability claim is stated precisely:** process-crash durability;
on POSIX also power-loss durability *if* the filesystem honours the
directory `fsync`; on Windows **no** power-loss claim is made. Storage-
controller cache durability, hardware reliability, a transactionally
consistent source snapshot and source immutability during the copy are
explicitly **not** claimed. **F36 remains OPEN / NOT FIXED** — the
capacity preflight and the source-stability detection are still not
implemented.

### 20.7 R5-04 — the corrected sidecar invariant

The Round-4 Scenario H asserted that the `-shm` still **existed** — an
existence assertion that a *different* file at the same pathname would
have satisfied. The corrected invariant distinguishes the **persistent**
WAL state from the **transient** SHM coordination structure, and the test
now compares the **filesystem identity** of the main database, the WAL and
the SHM (Windows: `GetFileInformationByHandleEx(FileIdInfo)` — the measured
native `sizeof(FILE_ID_INFO)` is **24** bytes, not 20; POSIX: `fstat` on a
held descriptor) under a controlled anchor connection. The SHM **byte**
content is deliberately not asserted, and the legitimate last-connection
cleanup is covered by a separate test.

### 20.8 R5-05 — the crosswalk, the generator and the documentation

The Round-4 crosswalk is **immutable history**. The Round-5 crosswalk keeps
the **98** historical identifiers complete and adds `round4_disposition`,
`current_disposition`, `round5_evidence`, `residual_risk` and
`supersedes`; the Round-5 findings are a **separate** collection and are
**not** part of the historical denominator.

The correct category totals — recomputed from the records, not hardcoded —
are:

| Set | Identifiers | FIXED | PARTIAL | NOT FIXED |
|---|---:|---:|---:|---:|
| F01–F38 | 38 | 34 | 3 | 1 |
| F39–F56 | 18 | 14 | 4 | 0 |
| R39–R56 | 18 | 15 | 3 | 0 |
| W01–W24 | 24 | 20 | 4 | 0 |
| **ALL** | **98** | **83** | **14** | **1** |

The Round-4 **Markdown** register reported incorrect identifier counts for
the first two sets; those documents are preserved unchanged and the
correction lives in the **generated** Round-5 register.

The generator `remediation5/build_crosswalk.py` is **included** (the Round-4
package claimed one but did not contain it) and is **proven** by its
`--check` mode, which writes **nothing** and returns a non-zero exit code
when the generated output differs.

The Round-4 **test inventory** was also wrong: the prose claimed six
classes, 24 functions and 25 cases; the measured collection is **5 classes,
22 functions, 24 collected cases**.

### 20.9 The protected test bootstrap

`tests/run_g4_protected_pytest.py` imports only the standard library and the
protection bootstrap, installs the boundary, **verifies** that it is active
and only **then** imports pytest; third-party plugin autoload is disabled
before pytest is imported and the one plugin the suite needs (`asyncio` =
`pytest-asyncio`) is loaded **explicitly**, after the guard. Child
interpreters inherit the boundary through a generated `sitecustomize.py`;
a child whose bootstrap fails **fails closed** (`os._exit(70)`).

`tests/_g4_bootstrap.py` is shared by the launcher and `conftest.py`, so the
two entry points cannot drift.

### 20.10 A disclosed breach of the production-data prohibition

**This is a disclosure, not a safety claim, and it must be read before any
other statement in this section.**

Two Round-5 **reporting tools** read and SHA-256 hashed files under the
repository's runtime data directory (`.data/`), among them
`.data/memory/archive.db` and `.data/memory/cognitive/vault_v4.json`. The
operation was **read-only** — nothing was modified, no restoration was
attempted and none is needed. The campaign was **stopped**, the tools were
corrected to exclude `.data` from every scan, and the campaign was
restarted.

**The claim "no production file was inspected during Round 5" is FALSE and
is withdrawn.** The production-safety evidence now rests entirely on the
**synthetic** proofs: the boundary rejects a protected path **before** any
filesystem operation, the connector interception is proven, ATTACH and
VACUUM INTO denials are proven by the **absence of the destination file**,
the direct synthetic-sidecar denials are proven, and the child-process
protection is proven.

The full disclosure — the exact operations, the outcome and the corrective
action — is in `remediation5/D_DATABASE_SAFETY_EVIDENCE.md` §D.6, and the
residual risk is `remediation5/F_RESIDUAL_RISK_REGISTER.md` §F.2.7.

The Round-4 hashes (unified.db `0283B158…`, archive.db `FBD6A060…`,
graph.db `894012DE…`, vault_v4.json `F630BC1A…`, unified.db-wal `E3B0C442…`,
unified.db-shm `FD4C9FDA…`) remain **historical Round-4 evidence** and are
**not** presented as a Round-5 verification.

### 20.11 The Round-5 package

`g4-round5-corrective-modified-files.zip` contains the Round-5
implementation, the new and strengthened tests, the deliverables A–H, the
crosswalk and its generator, the test-execution manifest, the
baseline-reconstruction tools, the source manifest, the test logs, the
crash-injection evidence and the **verbatim** nested Round-4 archive. The
archive is built from an **explicit allowlist**: production databases,
vault contents, credentials, virtual environments, caches, temporary test
directories and unrelated untracked files are excluded **by construction**.

### 20.12 What remains open

Every item of the specification's residual-risk list remains open and is
listed **individually** in
`remediation5/F_RESIDUAL_RISK_REGISTER.md`. In particular: the SQLite
WAL-reset runtime incompatibility (the bundled 3.50.4 is inside the
affected range), F36's two requirements, the dedicated initialization
lock, the database-path identity unification, the advisory lock's
non-fencing nature, the backup scope, the `secure_delete` erasure
semantics, DEBT-045, the configuration flush semantics, the stale
checkpoint-inventory figures, the protection's non-sandbox nature, the
TOCTOU window, the unverifiable hard-link aliases to production files, the
historical production-vault pollution and the pre-existing test failures —
**unless the measured baseline proves a change** (§20.13).

### 20.13 The regression campaign

The campaign, the per-invocation records, the **node-level** comparison and
the log hashes are in `remediation5/C_REGRESSION_EVIDENCE.md` and
`remediation5/test_execution_manifest.json`. The comparison is made on the
**common test node ids**, never on the aggregate counts alone.

### 20.14 The next step

A **fresh independent review of the immutable Round-5 archive**. The review
order, the exact reproduction commands and the claims that must be
challenged are in `remediation5/H_FRESH_REVIEW_HANDOFF.md`. This section
issues **no acceptance decision**.

## Appendix A — raw probes (evidence scripts, temp workspace `…\Temp\opencode\`)

| Script | Purpose (measured facts) |
| --- | --- |
| `g4_probe1..4.py` | authorizer action codes (SQLITE_INSERT=18 / SQLITE_DELETE=9), rank=1 semantics, runner hook trace |
| `g4_auth_probe.py` | the exact denial surface per path + full authorizer call log |
| `g4_delete_probe.py` | after a successful repo-path DELETE on 3.50.4: rank=1 → error while global check passes |
| `g4_evacuate_probe.py` | raw SQLite: single/total DELETE → rank=1 "malformed" (repro, build-dependent) |
| `g4_stale_match_probe.py` | raw SQLite: MATCH still returns the deleted docid; `count(*)`=0; `_data` mirror gone |
| `g4_reuse_probe.py` | stale hit tied to the freed docid; fresh content does not inherit old tokens; JOIN-filtered public view is clean |
| `g4_smoke1.py` | full lifecycle smoke (enforce refusal → ack → fresh init → legacy refusal → maintenance sequence/ledger/commit/checkpoint/WAL/backup identity) |
| `g4_smoke2_cli.py` | all three CLI commands end-to-end on a real DB (rc 0) |

## Appendix B — reproduction commands

```bash
# all new gate suites (env OCBRAIN_MEMORY_RUNTIME_ACK=acknowledge is set by conftest)
python -m pytest tests/test_g4_rev3_runtime_gate.py tests/test_g4_rev3_migration_lifecycle.py \
                  tests/test_g4_rev3_sqlite_contract.py tests/test_g4_rev3_mutation_atomicity.py \
                  tests/test_g4_rev3_search_regression.py tests/test_g4_rev3_failure_recovery.py \
                  tests/test_g4_rev3_policy_disposition.py -q

# certification run on a FIXED runtime: drop the acknowledgment first
OCBRAIN_MEMORY_RUNTIME_ACK= python -m pytest tests/test_g4_rev3_runtime_gate.py -q   # expect enforce-mode acceptance

# baselines
python -m pytest tests/test_session4c_architecture.py tests/test_unified_memory.py -q
```
