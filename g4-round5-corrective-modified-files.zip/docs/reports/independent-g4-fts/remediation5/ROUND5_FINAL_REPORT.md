# Round 5 — Final Report

**Date:** 2026-11-12
**Target:** G4 FTS Rev 3 — Round-4 corrective worktree
**Branch / HEAD:** `independent/g4-fts-rev3-20261105` @ `739e58ce185a527d2d2f58c7622c5108f5b0e0db` (both unchanged)
**Round-4 input archive:** `g4-round4-corrective-modified-files.zip` — SHA-256 `1c75f7fc1033aad2f1b1c57969a05fed68f4a569418c9556f70900db7cf6ee0c`, 76 entries, 425 105 bytes
**Final governance disposition:** **G4 OPEN / NOT ACCEPTED / NO PASS**

---

## A. Baseline and provenance

### A.1 The original state

| Property | Value |
|---|---|
| branch | `independent/g4-fts-rev3-20261105` |
| HEAD | `739e58ce185a527d2d2f58c7622c5108f5b0e0db` |
| staged changes | 0 |
| tracked modifications | 18 |
| untracked paths | 12 |
| deleted | 0 |
| symbolic links in the index | 0 |

### A.2 The three source states

The Round-4 corrections were local and uncommitted, so the recorded HEAD
does **not** contain the complete Round-4 implementation; a comparison
against a clean checkout of HEAD would be **invalid** as a Round-5
regression comparison. Three separately identifiable source states are
reconstructed in **separate temporary directories**:

| ID | Source state | Files | Fingerprint |
|---|---|---:|---|
| B0 | the pristine export of the exact HEAD | 580 | `499d6aedca08764acf7926420501e8e623c651fa012c1d9a2035bb3ded2a4207` |
| B4 | B0 + the verified Round-4 archive overlay | 638 | `8185f1bb73d71ea2b6e7ffd810ffc912043df6e95fda99080aeb9506a0be8e59` |
| B5 | B4 + the Round-5 overlay | see `logs/baseline_reconstruction.json` | see `logs/baseline_reconstruction.json` |

The B4 reconstruction has **0 discrepancies** against the Round-4 source
manifest parsed from **inside** the archive; the overlay replaces 18 files
and adds 58. The three fingerprints are distinct.

### A.2.1 What "the same source" means for the campaign

Each campaign invocation runs in a **separate temporary copy** of its
source state, so the delivered working tree is never modified by a test
run.  The copy is byte-identical to the delivered working tree in every
file that is a **test input** — everything under `core/`, `interface/`,
`tests/`, `modules/`, `learning/`, `scripts/` and the top-level files.
The only files that may differ are the **generated evidence documents**
under `docs/reports/independent-g4-fts/remediation5/` (the regression
evidence, the test-execution manifest, the source manifest, the overlay
patch and the logs), because those ARE the campaign's own output.

### A.3 The 28-versus-30 path-inventory discrepancy

Both numbers are correct — they describe **two different moments**. **28**
was the state **before** Round 4 (18 modified + 10 untracked). Round 4
itself added two paths (`tests/test_g4_r4_corrections.py` and
`docs/reports/independent-g4-fts/remediation4/`), so the state **after**
Round 4 is **18 modified + 12 untracked = 30**. No file is missing and no
contradiction exists.

---

## B. R5-01 — SQLite protection

### B.1 The actual SQLite URI configuration (measured)

SQLite **3.50.4**, source id
`2025-07-30 19:33:53 4d8adfb30e03f9cf27f800a2c1ba3c48fb4ca1b08b0f5ed59a4d5ecbf45e20a3`
(`tools/sqlite_runtime_probe.py`, `logs/sqlite_runtime_probe.json`):

* `SQLITE_USE_URI` is **not** a compile option and no global URI
  configuration is active — URI processing is enabled **per connection**
  (`uri=True`); with `uri=False` a `file:` string is an **ordinary file
  name**;
* `SQLITE_ALLOW_URI_AUTHORITY` is **not** compiled in — SQLite itself
  rejects a foreign authority;
* `SQLITE_ATTACH` is authorizer action code **24**;
* **`VACUUM INTO` reports `SQLITE_ATTACH` (24)** on this runtime;
* `ATTACH DATABASE (<expression>)` reports action 24 with a **NULL**
  filename argument;
* `SQLITE_DBCONFIG_ENABLE_ATTACH_CREATE` / `..._ATTACH_WRITE` are **not
  exposed** by CPython.

### B.2 The URI parser

Component-wise (scheme / authority / path / query / fragment), decoded
exactly once at the byte level, with malformed escapes and encoded NULs
rejected, the fragment stripped and a **strict** query allowlist
(`mode` ∈ {`ro`,`rw`,`rwc`}). `vfs`, `modeof`, `nolock`, `immutable`,
`psow`, unknown parameters, duplicates, percent-encoded parameter names and
values, valueless parameters and empty parameters are rejected. A malformed
or ambiguous `file:` target is **denied** at the connection boundary and is
never retried as an ordinary file name.

### B.3 Windows and POSIX path identity

`GetFileInformationByHandleEx(FileIdInfo)` on Windows (the **measured**
native `sizeof(FILE_ID_INFO)` is 24 bytes, so the 128-bit file id starts at
offset 8); `fstat` on a held descriptor on POSIX. The mechanism actually
used is always reported. Symlinks **and other reparse points** (a Windows
directory junction is a reparse point but not an `S_ISLNK` link) are
resolved through the **link**, never through the target.

### B.4 The companion-sidecar handling

`-wal`, `-shm` and `-journal` are protected as a namespace of the
protected database. A direct open of a protected sidecar as an independent
database is **denied**; SQLite's own internal VFS opens of those files
while opening an approved database are **not** intercepted by the Python
wrapper — the wrapper intercepts the application-level entry points, and
the documentation says so explicitly.

### B.5 The database-opening route inventory

Eleven routes were audited (`B_DATABASE_ACCESS_ROUTE_INVENTORY.md`). The
outcome: **no** application-managed connection outside the reviewed
factory; the global `sqlite3.connect` monkeypatch **removed**; the
`sqlite3.Connection` constructor **cannot** be intercepted (audited, zero
application call sites); no `apsw`, no `ctypes` SQLite, no native
extension, no loadable extension, no application-defined SQL function or
virtual table.

### B.6 The authorizer behaviour

`SQLITE_ATTACH` is denied **unconditionally**, on the **action code** and
never on the filename text. The policy is installed on the freshly created
connection (before any application SQL is prepared) and the connection class
overrides `set_authorizer()`, so a later registration **composes** with the
policy instead of replacing it, and `set_authorizer(None)` cannot remove
it.

### B.7 ATTACH and VACUUM INTO tests

Literal, bound parameter, URI, `localhost` URI, expression (NULL
argument), relative path, authorizer replacement, authorizer removal,
schema-change re-preparation, `VACUUM INTO` literal, `VACUUM INTO` bound
parameter — every case is denied and the destination is **not** created.

### B.8 DBCONFIG and limit defence in depth

`SQLITE_DBCONFIG_ENABLE_LOAD_EXTENSION` is set to false (and
`enable_load_extension(False)` is called); `SQLITE_LIMIT_ATTACHED` is set
to 0. The two attachment DBCONFIG options are **not exposed** by CPython
and are reported as such — they are never assumed. The **unconditional
authorizer denial** remains the primary control.

### B.9 The explicit limits

The boundary is an application-level control, **not** an OS sandbox, and it
is **not** atomic: the interval between the path validation and SQLite's
open is not closed against a hostile same-user process.

---

## C. R5-02 — the verification lifecycle

### C.1 The refactored control flow

One ordered lifecycle, **one** authoritative serialization point, no failure
helper that emits JSON before finalization.

### C.2 The result semantics

`contract_passed`, `contract_assessed`, `contract_verdict`
(`PASS`/`FAIL`/`INCOMPLETE`), `cleanup_ok`, `ok`, `verification_target`,
`verification_target_removed` (`true`/`false`/`null`),
`recovery_evidence_preserved`, `error`, `cleanup_error`, `cleanup_errors`,
`verification_workspace`, `exit_code`.

### C.3 The failure matrix

Cases A–J of the specification are covered: success, preservation failure
before the copy, workspace-creation failure, partial copy failure, SQLite
open failure, inspection failure, connection-close failure, total cleanup
failure, partial cleanup failure and the exactly-one-JSON-object proof.

### C.4 The verdict separation

A cleanup failure never corrupts the integrity verdict: `contract_passed`
can be `true` while `cleanup_ok` is `false`, `ok` is `false` and the exit
code is 1.

---

## D. R5-03 — the preservation durability

### D.1 The manifest lifecycle

`pending → copying → copied → verified`, with a monotonic revision and a
per-record `last_update_sequence`; the copied artifact is `fsync`-ed before
it may be marked verified.

### D.2 The atomic replacement

Temporary file in the same directory → `flush` → `fsync` → same-directory
`os.replace` → directory `fsync` on POSIX. The last valid manifest is kept
if a later update fails.

### D.3 The abrupt child termination

A child process terminates with `os._exit()` after the first verified
artifact. The surviving manifest is valid JSON with `status=in_progress`,
`complete=false`, the first artifact `verified` with matching hashes and
destination, and the remaining artifacts `pending`.

### D.4 The actual platform guarantees

**Process-crash durability.** On POSIX also power-loss durability *if* the
filesystem honours the directory `fsync`; on Windows **no** power-loss
claim is made. Storage-controller cache durability, hardware reliability, a
transactionally consistent source snapshot and source immutability during
the copy are explicitly **not** claimed.

### D.5 F36

**F36 remains OPEN / NOT FIXED**: the capacity preflight and the
source-stability detection are still not implemented.

---

## E. R5-04 — the sidecar identity evidence

### E.1 The controlled WAL setup

A synthetic WAL-mode database with a known committed WAL state, an anchor
connection held open for the whole operation and a read transaction that
holds the WAL snapshot.

### E.2 The byte and identity evidence

The main database and the WAL are byte-identical and **identity-identical**
before and after; the SHM is **identity-identical** (its bytes are
deliberately not asserted); no rollback journal appeared; no preservation
copy was created; the migration result is `already_applied`.

### E.3 The legitimate last-connection cleanup

A separate test closes the final connection deliberately: SQLite's own
WAL/SHM cleanup is **not** reported as a migration defect.

### E.4 The replacement detection

A file replaced at the same pathname with **byte-identical** content is
detected by the identity check (the hash cannot see it).

### E.5 The NOT VERIFIED cases

When the identity cannot be obtained, the identity claim is reported as
**not verified** (the helper returns `None`), never as "different".

---

## F. R5-05 — the reconciliation

### F.1 The correct 98-ID totals

| Set | Identifiers | FIXED | PARTIAL | NOT FIXED |
|---|---:|---:|---:|---:|
| F01–F38 | 38 | 34 | 3 | 1 |
| F39–F56 | 18 | 14 | 4 | 0 |
| R39–R56 | 18 | 15 | 3 | 0 |
| W01–W24 | 24 | 20 | 4 | 0 |
| **ALL** | **98** | **83** | **14** | **1** |

Every total is **computed** from the records; the generator contains no
hardcoded status counts.

### F.2 The historical/current separation

`round4_disposition` (never overwritten), `current_disposition`,
`round5_evidence`, `residual_risk`, `supersedes`. The Round-5 findings are
a **separate** collection and are **not** in the historical denominator.

### F.3 The generator

`build_crosswalk.py` reads the machine-readable crosswalk as its source of
truth, rejects missing / duplicate / unexpected identifiers and invalid
statuses, validates the set membership, computes every aggregate, renders
the register deterministically and provides a `--check` mode that writes
**nothing** and returns non-zero on a difference.

### F.4 The measured pytest collection

| Suite | Classes | Functions | Collected cases |
|---|---:|---:|---:|
| `tests/test_g4_r4_corrections.py` | **5** | **22** | **24** |
| `tests/test_g4_interaction_scenarios.py` | 0 | 12 | 12 |
| `tests/test_g4_f01_f38_remediation.py` | 16 | 49 | 65 |
| `tests/test_g4_revg4_remediation.py` | 8 | 55 | 61 |
| `tests/test_g4_r5_corrections.py` | 9 | 127 | 127 |

The Round-4 prose claimed **six** classes, **24** functions and **25**
cases; the measured values are **5 / 22 / 24**.

### F.5 The reconciled documentation

The Round-4 Markdown register's incorrect identifier counts were **not**
edited in place; the corrected register is generated. The Round-4
documentation is preserved unchanged.

---

## G. Regression results

### G.1 The three source states

| Source state | Collected | Passed | Failed | Errors | Skipped | Xfailed | Exit code | Duration (s) |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| B0 | 2322 | 2197 | 45 | 51 | 28 | 1 | 1 | 1159 |
| B4 | 2485 | 2382 | 22 | 51 | 29 | 1 | 1 | 1528 |
| B5 | 2613 | 2508 | 23 | 51 | 30 | 1 | 1 | 1581 |

Every invocation ran the **identical command** through the protected
launcher, in the same environment (Python, SQLite runtime, pytest,
dependency inventory and platform are recorded per invocation in
`test_execution_manifest.json`).  Campaign environment caveats are
recorded in §G.6.

### G.2 The node-level comparison

The comparison is made on the **common test node ids** — a later round
naturally adds test cases, so the aggregate counts alone cannot isolate a
regression.

**B0_vs_B4** — 2319 common node ids

| Classification | Count |
|---|---:|
| pass_in_both | 2192 |
| fail_in_both | 20 |
| error_in_both | 51 |
| new_failure | 2 |
| resolved_failure | 25 |
| new_error | 0 |
| resolved_error | 0 |
| skipped_status_changed | 29 |
| outcome_changed | 0 |

**Regressions:**

- new failure: `tests/test_b2c_cancellation.py::test_cancelling_one_request_does_not_affect_a_concurrent_request`
- new failure: `tests/test_orchestrator_memory_migration.py::TestSession4StayedInScope::test_web_learning_pipeline_still_uses_memory_vault`

**B4_vs_B5** — 2485 common node ids

| Classification | Count |
|---|---:|
| pass_in_both | 2380 |
| fail_in_both | 21 |
| error_in_both | 51 |
| new_failure | 2 |
| resolved_failure | 1 |
| new_error | 0 |
| resolved_error | 0 |
| skipped_status_changed | 30 |
| outcome_changed | 0 |

**Regressions:**

- new failure: `tests/test_g4_f01_f38_remediation.py::TestF24ProductionBoundary::test_the_boundary_is_installed_in_this_process`
- new failure: `tests/test_production_robustness.py::test_batched_state`

### G.2.1 The root causes of the two B4_vs_B5 new failures

Both failing nodes were investigated **empirically** on a disposable
copy of the delivered tree (production data excluded from the copy,
protected launcher, deterministic runs of well under one second).
The delivered evidence still describes attempt 5 exactly as measured:
**neither node was fixed in this round**, because either fix would
require a fresh full campaign to keep the evidence honest.

#### G.2.1.1 F24 — a campaign-harness configuration artifact

`tests/test_g4_f01_f38_remediation.py::TestF24ProductionBoundary::
test_the_boundary_is_installed_in_this_process` expects
`pytest.raises(PermissionError)` when it opens the **tree-local**
`.data\memory\unified.db`.  In the B5 invocation the boundary did not
deny the open, so the real `open` executed and failed with
`FileNotFoundError: [Errno 2] No such file or directory:
'...\g4_bases\B5\.data\memory\unified.db'` — a campaign copy has no
production memory directory at all.

Root cause — **the campaign harness configuration, not the code under
test**: `run_campaign.py` (line 258 of the delivered copy) sets
`OCBRAIN_PROTECTED_ROOT` to the **harness source root (the delivered
worktree)** for every invocation, so the boundary installed inside a
campaign copy protects the *worktree's* production paths, not the
copy's own `.data\memory`.  The test's premise — the tree under test is
the protected root — does not hold under that configuration: `_check`
passes and the untouched real open raises `FileNotFoundError`.

Experiment (identical code, identical launcher, one variable):

| Configuration | Result |
|---|---|
| `OCBRAIN_PROTECTED_ROOT` = the delivered worktree (exactly the campaign setting) | **FAILED** — the identical `FileNotFoundError` |
| no override (the tree under test is the protected root) | **PASSED** (0.23 s) — the open is denied with `PermissionError` |

Why B4 passed: the B4 invocation **launched at 10:32:13**, before
`run_campaign.py` was last modified (10:42:57); the B5 attempt-5
invocation launched at 11:40:11, after it.  The two invocations
therefore ran under **different boundary-root configurations** — the
harness files themselves (`tests/_g4_protection.py` and the launcher)
are byte-identical between the B4 tree and the worktree.  For this
node the B4_vs_B5 comparison measures a harness-configuration change,
not a code change.

Disposition: **not a Round-5 code regression**.  Recorded fix for the
next round: the test should derive its expected root from the exported
`OCBRAIN_PROTECTED_PATHS` (i.e. verify what is *actually* protected)
or skip with an explicit reason when the protected root is not the
tree under test.

#### G.2.1.2 `test_batched_state` — a latent test defect exposed by a correct R5-01 change

`tests/test_production_robustness.py::test_batched_state` fails at its
own final `os.remove('.data/test_state.sqlite')` with
`PermissionError: [WinError 32]` (file in use by another process),
with three nested `remove` frames at `_g4_protection.py:1026`.  The
boundary is **not** involved: `.data/test_state.sqlite` lies outside
the protected `.data/memory` root and `_check` passed.  The file was
genuinely still open.

Root cause — **the test never closes its inspection connection**.  It
verifies the flushed rows with
`with sqlite3.connect(db_path) as conn:` — a `sqlite3.Connection`
context manager **commits on exit but never closes**, so the handle
stays open.  Under the B0 and B4 invocations this was masked: their
`core/runtime/state.py` **monkeypatched the global `sqlite3.connect`**
so every connection — including the test's own — was created with
`factory=ClosingConnection`, whose `__exit__` **closes** the
connection.  R5-01 §2.5 removed that monkeypatch (it let code imported
before the boundary capture the unguarded connector — a bypass
hazard), so the test's inspection connection now stays open and the
subsequent `os.remove` fails.

Variant matrix (probe copy, protected launcher, deterministic):

| Variant | Sequence | `os.remove` result |
|---|---|---|
| V0 | the exact test sequence, Round-5 `state.py` | **REMOVE-FAIL** (WinError 32) |
| V1 | V0 + the inspection connection explicitly closed | REMOVE-OK |
| V2 | V0 + `gc.collect()` before the remove | REMOVE-FAIL |
| V3 | V0 + a 0.5 s sleep before the remove | REMOVE-FAIL |
| V4 | no `StateStore`: plain WAL connection, explicitly closed | REMOVE-OK |
| V5 | no `StateStore`: plain WAL connection left open (the test's own pattern) | **REMOVE-FAIL** (WinError 32) |

V1 and V4 prove the holder is the test's own unclosed connection; V5
reproduces the failure with **no Round-5 code involved at all**; V2/V3
rule out garbage collection and timing.  Cross-check: substituting the
Round-4 `core/runtime/state.py` → **PASSED** (0.38 s — the global
monkeypatch returns); restoring the Round-5 `state.py` → fails again
(0.44 s).  Every `StateStore` connection itself closes correctly.

Disposition: **not an application-code defect** — the R5-01 §2.5
removal of the monkeypatch is the intended fix and the application
code is correct; the failing node is a test-hygiene defect.  Recorded
fix for the next round: the test must close its inspection connection
(`contextlib.closing`, or `try` / `finally: conn.close()`).

#### G.2.1.3 Cross-reference to §B.10

The four attempt-4-era regressions recorded in
`B_IMPLEMENTATION_REPORT.md` §B.10 (two contracts: the
preservation-record shape and the CLI `None` rendering) all **pass**
in the delivered attempt-5 run; they were artifacts of the crashed
attempt-4 invocation, consistent with that section's record.  The two
nodes above are the only differences that remain in the healthy run,
and neither is an application-code regression.

### G.3 The Round-5-only tests

The Round-5 suite (`tests/test_g4_r5_corrections.py`) exists only in B5
and is therefore absent from the common-node comparison by construction.
Its result is recorded above.

### G.4 The Windows results

Every measurement in this campaign was taken on **Windows x64** — the
target platform of the specification.  The URI normalisation, the Windows
path identity, the direct sidecar protection, the junction/reparse-point
behaviour, the cleanup behaviour and the Scenario H file identity were all
exercised on Windows.

### G.5 The unverified tests

- none: every invocation completed with a normal pytest exit status (0 or 1)
- the **pre-existing** failures and errors are unchanged unless the measured baseline proves a change; they are listed per node id in `test_execution_manifest.json`

### G.6 Campaign environment caveats

§G.1's "same environment" is accurate for Python, SQLite, pytest, the
dependency inventory and the platform (all recorded per invocation in
`test_execution_manifest.json`), but three caveats are recorded for
honesty:

1. **Thread-mitigation variables were not identical.**  After the
   third B5 crash the driver set `OMP_NUM_THREADS=1`,
   `MKL_NUM_THREADS=1` and `TOKENIZERS_PARALLELISM=false` for the B5
   attempts 4–5 only — not for B0 or B4.  They are not part of the
   software under test and no pass/fail delta is attributable to them,
   but the identity claim does not extend to them.
2. **The per-invocation records capture no environment variables**
   (`environment` is `{}` in every record), so neither the mitigation
   variables nor `OCBRAIN_PROTECTED_ROOT` are visible there; both are
   documented here and in §G.2.1 instead.
3. **Four crashes occurred; two are recorded.**  The campaign's
   incident log (`C_REGRESSION_EVIDENCE.md` §C.4.1, generated from
   `RECORDED_INCIDENTS` in `build_regression_evidence.py`) records
   two; the complete count is four: B4 attempt 1 (1894 collected), B5
   attempts 2 and 3 (unmitigated), and B5 attempt 4 (2007 collected,
   mitigated yet still crashed).  Attempt 5 — the delivered B5 record
   — completed normally with exit 1.  All four were the same native
   access-violation family (exit code 3221225477) inside torch's
   model-materialisation thread pool, not in the code under test.

## H. Production safety

### H.1 The bootstrap evidence

The boundary is installed **before pytest is imported**; the launcher
verifies that it is active and fails closed otherwise.

### H.2 The import-time and collection-time blocking

Both are proven with a synthetic protected target that is **not** created.

### H.3 The connector interception

Proven by the rejection happening before the connector is reached.

### H.4 The ATTACH / VACUUM INTO denial

Proven by the **absence** of the destination file.

### H.5 The direct synthetic-sidecar denial

Proven.

### H.6 The child-process protection

Proven, including the fail-closed case.

### H.7 The confirmation about production data

**A breach occurred and is disclosed**: two Round-5 **reporting tools** read
and hashed production files under `.data/` before they were corrected. The
operation was read-only; nothing was modified; the campaign was stopped and
restarted; the tools now exclude `.data` from every scan. **The claim "no
production file was inspected during Round 5" is FALSE and is withdrawn.**
The full disclosure is in `D_DATABASE_SAFETY_EVIDENCE.md` §D.6.

The **test suite**, the protection boundary, the CLI, the migration runner
and the packaging tooling never touched a protected production database.

---

## I. Residual risks

Listed **individually** in `F_RESIDUAL_RISK_REGISTER.md`: the SQLite
WAL-reset runtime incompatibility, F36's two requirements, the dedicated
initialization lock, the database-path identity unification, the advisory
lock's non-fencing nature, the backup scope, the `secure_delete` erasure
semantics, DEBT-045, the configuration flush semantics, the stale
checkpoint-inventory figures, the protection's non-sandbox nature, the
TOCTOU window, the unverifiable hard-link aliases, the historical
production-vault pollution, the pre-existing test failures, the
`sqlite3.Connection` constructor route, the stricter-than-SQLite URI
policy, the Windows process-crash-only durability, the deliberately
unasserted SHM bytes, the synthetic-only detection harness, the
clean-environment child process and the tooling-coverage gap.

---

## J. The changed-file manifest

`G_SOURCE_MANIFEST.md` — every changed path with its type, mode, size,
SHA-256, status (added / modified / deleted), the related finding and the
related test.

---

## K. The archive identity

`package_manifest.json` and the build output record the archive name, the
size, the entry count, the SHA-256, the nested Round-4 archive's identity
and the reproduction commands. The nested Round-4 archive is verified
byte-identical, and the round-trip extraction is verified entry by entry.

---

## L. The governance state

| Property | Value |
|---|---|
| the original branch | **unchanged** |
| the original HEAD | **unchanged** |
| staged files | **0** |
| all changes | **uncommitted** |
| branch creations or switches | **none** |
| commits or pushes | **none** |
| PR creation or modification | **none** |
| merges or rebases | **none** |
| production database access by the **test suite** | **none** |
| production database access by the **reporting tools** | **YES — disclosed (§H.7)** |

### L.1 The working-tree inventory and a note on `git status`

The Round-4 baseline was **18 modified + 12 untracked = 30**.  After
Round 5 the content-level delta is **18 modified + 6 further modified
files + the new Round-5 files** (the six further files are
`core/context.py`, `core/migrator.py`, `core/events/event_stream.py`,
`core/memory/backends/sqlite_archive.py`, `core/memory/sqlite_runtime.py`
and `core/runtime/state.py` — the connection sites that now use the
reviewed factory).

`git status --porcelain` reports **50** modified paths.  **12 of them are
content-identical to HEAD after git's `text=auto` normalisation** — they
are the files whose working-tree line ending was restored to the
repository convention (`.gitattributes`: `* text=auto`, so the working
tree uses CRLF while the blob uses LF).  `git diff --stat` reports **38**
files, which is the content-level truth.  The restoration is deliberate:
it makes the delivered working tree **byte-identical to the reconstructed
B4 baseline** for every file Round 5 did not touch, so the Round-5 delta
contains only the intentional changes.

The tracked files that the **test runs** modified as a side effect
(`modules/*/knowledge.db/*` and `tests/core/cognitive/__pycache__/*.pyc`)
are restored to their committed state; they were clean in the Round-4
baseline and are not part of the Round-5 change set.

---

## M. The fresh independent-review handoff

`H_FRESH_REVIEW_HANDOFF.md` — the recommended review order, the exact
reproduction commands, the baseline reconstruction procedure, the relevant
source paths, the evidence locations, the expected results, the known
limitations and the **sixteen claims the reviewer must challenge**.
