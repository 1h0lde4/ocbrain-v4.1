"""
build_round5_crosswalk.py — produce the Round-5 machine-readable crosswalk.

The Round-4 crosswalk (``docs/reports/independent-g4-fts/remediation4/
crosswalk.json``) is IMMUTABLE HISTORICAL EVIDENCE.  This script READS it
and produces the Round-5 crosswalk, which keeps the 98 historical
identifiers complete and individually traceable and adds the Round-5
reassessment.

The separation is deliberate:

  * ``round4_disposition``  — the EXACT Round-4 disposition (never
    overwritten);
  * ``current_disposition`` — the status supported by the Round-5 evidence;
  * ``round5_evidence``     — the source, test and execution evidence;
  * ``residual_risk``       — the remaining limitation;
  * ``supersedes``          — the earlier finding or disposition that the
    Round-5 evidence supersedes, if any.

The Round-5 findings are in a SEPARATE collection and are NOT part of the
historical 98-identifier denominator.

The aggregate counts are COMPUTED from the records — never hardcoded.

Usage:
    python build_round5_crosswalk.py [--round4 <crosswalk.json>]
                                      [--out <crosswalk.json>]
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from collections import Counter, OrderedDict
from pathlib import Path

HERE = Path(__file__).resolve().parent
REMEDIATION4 = HERE.parent.parent / "remediation4" / "crosswalk.json"

#: The vocabulary allowed for a Round-5 disposition.
ROUND5_STATUSES = ("FIXED", "PARTIAL", "NOT FIXED", "NOT VERIFIED",
                    "NOT APPLICABLE")

#: The historical identifiers, by SET.  Membership is a structural property
#: of the identifier namespaces; no STATUS COUNT is encoded here.
SET_MEMBERSHIP = OrderedDict((
    ("F01-F38", ["F%02d" % n for n in range(1, 39)]),
    ("F39-F56", ["F%02d" % n for n in range(39, 57)]),
    ("R39-R56", ["R%02d" % n for n in range(39, 57)]),
    ("W01-W24", ["W%02d" % n for n in range(1, 25)]),
))

#: The identifiers that Round 5 REASSESSED, with the reason and the
#: Round-5 evidence.  Every other identifier keeps its Round-4
#: disposition; its Round-5 evidence states that the Round-4 evidence was
#: re-executed unchanged in the Round-5 campaign.
REASSESSED = {
    "W20": {
        "disposition": "FIXED",
        "reason": (
            "R5-01 closed the remaining supported SQLite access paths that "
            "could reach a protected database without passing through the "
            "guarded connector: ATTACH, VACUUM INTO, the captured "
            "`sqlite3.connect` alias in core/runtime/state.py, direct "
            "companion-sidecar opens, the malformed/ambiguous URI forms and "
            "the unprotected query parameters. No supported access path "
            "bypasses the boundary any more, so the FIXED disposition "
            "stands - with a sharper statement of what the boundary is NOT."),
        "evidence": (
            "tests/test_g4_r5_corrections.py::TestR501UriPolicy; "
            "::TestR504SqlAccessRoutes; ::TestR506Bootstrap; "
            "tests/test_g4_interaction_scenarios.py::test_k_…; "
            "docs/reports/independent-g4-fts/remediation5/"
            "D_DATABASE_SAFETY_EVIDENCE.md"),
        "risk": (
            "The boundary is a Python-level, application-level "
            "defence-in-depth control - NOT an operating-system sandbox. "
            "It is not atomic: the interval between the path validation and "
            "SQLite's open is not closed against a hostile same-user "
            "process. A hard-link alias to a production file cannot be "
            "verified without touching that file. The route inventory is "
            "re-verified by an executable audit test."),
        "supersedes": (
            "the Round-4 wording of the W20 risk statement, which did not "
            "enumerate the SQL-level routes that R5-01 closes"),
    },
    "F11": {
        "disposition": "FIXED",
        "reason": (
            "The Round-4 manifest was written once at the start and once at "
            "the end, so an abrupt termination between artifacts could "
            "leave no verified artifact represented. R5-03 persists a "
            "per-artifact state progression and replaces the manifest "
            "atomically, and an isolated child process that terminates with "
            "os._exit() after the first verified artifact leaves a "
            "surviving manifest that represents it. The FIXED disposition "
            "stands."),
        "evidence": (
            "tests/test_g4_r5_corrections.py::TestR503ManifestDurability "
            "(including the abrupt-termination child process)"),
        "risk": (
            "The capacity preflight and the source-stability detection "
            "remain OPEN under F36; an abruptly terminated process leaves "
            "the preservation directory on disk for the operator to "
            "inspect."),
        "supersedes": "the Round-4 'no verified artifact is lost' wording",
    },
    "F28": {
        "disposition": "FIXED",
        "reason": (
            "The Round-4 failure helper emitted the JSON before the cleanup "
            "had run, so the payload could report a stale cleanup state and "
            "a cleanup failure could be swallowed while the command still "
            "exited 0. R5-02 refactors the command into ONE finalization "
            "path: the cleanup result is established before the payload is "
            "serialised, and the exit status agrees with the payload. The "
            "FIXED disposition stands."),
        "evidence": (
            "tests/test_g4_r5_corrections.py::TestR502VerificationLifecycle "
            "(cases A-J, including the exactly-one-JSON-object proof)"),
        "risk": (
            "The integrity verdict and the command verdict are reported "
            "separately: a cleanup failure does not corrupt the integrity "
            "verdict, and the overall result is still a failure."),
        "supersedes": (
            "the Round-4 wording, which did not distinguish the integrity "
            "verdict from the cleanup verdict"),
    },
    "W18": {
        "disposition": "FIXED",
        "reason": (
            "W18 shares the verification recovery-safety surface with "
            "F28. R5-02's single finalization path removes the "
            "'cleanup outcome unknown' case, so W18 cannot claim a clean "
            "disposal on unknown grounds any more. The FIXED disposition "
            "stands."),
        "evidence": (
            "tests/test_g4_r5_corrections.py::TestR502VerificationLifecycle"),
        "risk": "none beyond the F28 residual risks",
        "supersedes": None,
    },
    "F31": {
        "disposition": "PARTIAL",
        "reason": (
            "The Round-4 Scenario H asserted that the -shm still EXISTED. "
            "That is an existence assertion: a DIFFERENT file at the same "
            "pathname would have satisfied it. R5-04 corrects the invariant "
            "(the -wal carries PERSISTENT state, the -shm is transient "
            "coordination) and compares the filesystem IDENTITY of every "
            "artifact. The disposition stays PARTIAL because a different "
            "defect - the checkpoint inventory reporting pre-connection "
            "sidecar sizes - is untouched."),
        "evidence": (
            "tests/test_g4_interaction_scenarios.py::test_h_… (identity "
            "based); tests/test_g4_r5_corrections.py::TestR504SidecarIdentity"),
        "risk": (
            "The checkpoint inventory still reports PRE-connection sidecar "
            "sizes for its own figures (unchanged, and still open). The "
            "-shm BYTES are deliberately not asserted - they are a "
            "coordination structure, not persistent database content."),
        "supersedes": (
            "the Round-4 existence-only Scenario H assertion"),
    },
    "W14": {
        "disposition": "PARTIAL",
        "reason": (
            "R5-03 makes the preservation durable and crash-surviving, but "
            "the two F36 requirements - the preservation capacity preflight "
            "and the source-file stability detection - are still not "
            "implemented, so W14 remains PARTIAL."),
        "evidence": (
            "tests/test_g4_r5_corrections.py::TestR503ManifestDurability; "
            "tests/test_g4_r4_corrections.py::TestR403IncompletePreservation"),
        "risk": (
            "OPEN under F36: no capacity preflight and no detection of a "
            "source file changing during the copy. The preservation "
            "durability is process-crash durability, not power-loss "
            "durability on Windows."),
        "supersedes": None,
    },
    "W21": {
        "disposition": "FIXED",
        "reason": (
            "The Round-5 suite asserts the invariants it claims: the URI "
            "policy is exercised against the measured runtime semantics, "
            "the ATTACH/VACUUM INTO denial is proven by the absence of the "
            "destination file, the cleanup failure is proven by an injected "
            "failure, and the crosswalk generator is proven by --check. "
            "The FIXED disposition stands."),
        "evidence": (
            "tests/test_g4_r5_corrections.py (the complete Round-5 suite) "
            "plus docs/reports/independent-g4-fts/remediation5/"
            "C_REGRESSION_EVIDENCE.md"),
        "risk": "none",
        "supersedes": None,
    },
    "W24": {
        "disposition": "FIXED",
        "reason": (
            "The Round-4 Markdown register reported incorrect identifier "
            "counts for the first two sets; the Round-5 generator computes "
            "every aggregate from the machine-readable crosswalk and "
            "rejects a mismatch. The FIXED disposition stands."),
        "evidence": (
            "docs/reports/independent-g4-fts/remediation5/build_crosswalk.py "
            "--check; remediation5/A_FINDINGS_REGISTER.md; "
            "remediation5/E_DOCUMENTATION_RECONCILIATION.md"),
        "risk": "none",
        "supersedes": (
            "the Round-4 Markdown identifier counts, which were incorrect"),
    },
    "F36": {
        "disposition": "NOT FIXED",
        "reason": (
            "Neither the preservation capacity preflight nor the "
            "source-file stability detection has an implementation and "
            "executable evidence. R5-03 does not close them. The NOT FIXED "
            "disposition stands."),
        "evidence": (
            "tests/test_g4_r5_corrections.py::TestR503ManifestDurability "
            "(explicitly asserts that the two F36 requirements remain "
            "open)"),
        "risk": (
            "OPEN: no capacity preflight and no detection of a source file "
            "changing during the copy; the deployment contract (quiescence) "
            "remains the only protection."),
        "supersedes": None,
    },
}

#: The Round-5 work packages.  They are reported SEPARATELY and are NOT
#: part of the historical 98-identifier denominator.
ROUND5_FINDINGS = [
    {
        "id": "R5-01",
        "finding": "SQLite URI semantics and complete database-access protection",
        "current_disposition": "FIXED",
        "evidence": (
            "tests/test_g4_r5_corrections.py::TestR501UriPolicy, "
            "::TestR503QueryPolicy, ::TestR504SqlAccessRoutes, "
            "::TestR505FilesystemAliases; "
            "docs/reports/independent-g4-fts/remediation5/"
            "B_DATABASE_ACCESS_ROUTE_INVENTORY.md"),
        "residual_risk": (
            "Python-level defence in depth, not an OS sandbox; not atomic "
            "against a hostile same-user process; the "
            "`sqlite3.Connection` constructor cannot be intercepted at the "
            "Python level (the type is immutable) and is therefore audited "
            "rather than blocked - the application has zero call sites."),
        "supersedes": None,
    },
    {
        "id": "R5-02",
        "finding": "Disposable verification-copy lifecycle and truthful JSON",
        "current_disposition": "FIXED",
        "evidence": (
            "tests/test_g4_r5_corrections.py::TestR502VerificationLifecycle"),
        "residual_risk": (
            "The forensic preservation directory is intentionally retained; "
            "the operator is responsible for it."),
        "supersedes": None,
    },
    {
        "id": "R5-03",
        "finding": "Crash-surviving per-artifact preservation manifests",
        "current_disposition": "FIXED",
        "evidence": (
            "tests/test_g4_r5_corrections.py::TestR503ManifestDurability"),
        "residual_risk": (
            "Process-crash durability only; no power-loss claim on Windows, "
            "no storage-controller or hardware claim, no transactionally "
            "consistent source snapshot."),
        "supersedes": None,
    },
    {
        "id": "R5-04",
        "finding": "Correct sidecar lifecycle and file-identity evidence",
        "current_disposition": "FIXED",
        "evidence": (
            "tests/test_g4_interaction_scenarios.py::test_h_…; "
            "tests/test_g4_r5_corrections.py::TestR504SidecarIdentity"),
        "residual_risk": (
            "The -shm byte content is deliberately not asserted; on a "
            "filesystem that cannot provide a reliable identity the "
            "identity claim is reported as NOT VERIFIED."),
        "supersedes": None,
    },
    {
        "id": "R5-05",
        "finding": "Baseline reconstruction, crosswalk reconciliation and "
                   "evidence reproducibility",
        "current_disposition": "FIXED",
        "evidence": (
            "docs/reports/independent-g4-fts/remediation5/tools/"
            "g4_baseline.py; build_crosswalk.py --check; "
            "remediation5/C_REGRESSION_EVIDENCE.md"),
        "residual_risk": (
            "The Round-4 archive remains the only historical overlay; the "
            "Round-4 Markdown register still carries its incorrect "
            "identifier counts and is preserved unchanged as history."),
        "supersedes": None,
    },
    {
        "id": "R5-06",
        "finding": "Protected test bootstrap (specification section 7)",
        "current_disposition": "FIXED",
        "evidence": (
            "tests/run_g4_protected_pytest.py; "
            "tests/_g4_bootstrap.py; "
            "tests/test_g4_r5_corrections.py::TestR506Bootstrap"),
        "residual_risk": (
            "A child interpreter that does not inherit the environment "
            "(for example one started with a cleaned environment) is not "
            "protected; the sitecustomize bootstrap fails closed in that "
            "case rather than running unprotected."),
        "supersedes": None,
    },
]

#: The generic Round-5 evidence for an identifier that was not reassessed.
DEFAULT_EVIDENCE = (
    "The Round-4 evidence was re-executed unchanged in the Round-5 "
    "regression campaign through the protected launcher; the disposition "
    "is unchanged. See remediation5/C_REGRESSION_EVIDENCE.md and "
    "remediation5/test_execution_manifest.json."
)

DEFAULT_RISK = ("unchanged from the Round-4 residual-risk statement; see "
                "remediation4/A_FINDINGS_REGISTER.md")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--round4", default=str(REMEDIATION4))
    parser.add_argument("--out", default=str(HERE.parent / "crosswalk.json"))
    args = parser.parse_args()

    round4_path = Path(args.round4)
    records = json.loads(round4_path.read_text(encoding="utf-8"))

    seen = set()
    historical = []
    for record in records:
        identifier = record["id"]
        if identifier in seen:
            raise SystemExit(f"duplicate identifier in the Round-4 "
                             f"crosswalk: {identifier}")
        seen.add(identifier)
        entry = {
            "id": identifier,
            "finding": record.get("finding"),
            "historical": record.get("historical"),
            "round4_disposition": record["current"],
            "current_disposition": record["current"],
            "wp": record.get("wp"),
            "round4_evidence": record.get("evidence"),
            "round4_test": record.get("test"),
            "round4_risk": record.get("risk"),
            "round4_ref": record.get("ref"),
            "round5_evidence": DEFAULT_EVIDENCE,
            "round5_test": None,
            "residual_risk": DEFAULT_RISK,
            "supersedes": None,
            "round5_ref": f"remediation5 §A, {identifier}",
        }
        override = REASSESSED.get(identifier)
        if override:
            entry["current_disposition"] = override_reason_disposition(
                identifier, override)
            entry["round5_evidence"] = override["evidence"]
            entry["round5_test"] = override["evidence"]
            entry["residual_risk"] = override["risk"]
            entry["supersedes"] = override["supersedes"]
            entry["round5_reason"] = override["reason"]
        historical.append(entry)

    # the aggregate counts are COMPUTED, never hardcoded
    totals = Counter(entry["current_disposition"] for entry in historical)
    per_set = OrderedDict()
    for name, members in SET_MEMBERSHIP.items():
        counts = Counter(entry["current_disposition"]
                         for entry in historical
                         if entry["id"] in members)
        per_set[name] = {
            "identifiers": len(members),
            "dispositions": dict(sorted(counts.items())),
        }
    # normalise the Round-5 finding field names to the crosswalk schema
    for entry in ROUND5_FINDINGS:
        if "round5_evidence" not in entry and "evidence" in entry:
            entry["round5_evidence"] = entry.pop("evidence")
        if "round5_test" not in entry:
            entry["round5_test"] = entry.get("round5_evidence")

    round5_totals = Counter(entry["current_disposition"]
                             for entry in ROUND5_FINDINGS)

    payload = {
        "schema_version": 5,
        "description": (
            "The Round-5 crosswalk. The 98 historical identifiers keep "
            "their Round-4 disposition in `round4_disposition`; the current "
            "status is in `current_disposition`. The Round-5 findings are "
            "a SEPARATE collection and are NOT part of the historical "
            "denominator."),
        "round4_source": {
            "path": "docs/reports/independent-g4-fts/remediation4/"
                    "crosswalk.json",
            "sha256": sha256_file(round4_path),
        },
        "status_vocabulary": list(ROUND5_STATUSES),
        "set_membership": {name: list(members)
                           for name, members in SET_MEMBERSHIP.items()},
        "historical_findings": historical,
        "historical_totals": {
            "identifiers": len(historical),
            "dispositions": dict(sorted(totals.items())),
            "per_set": per_set,
        },
        "round5_findings": ROUND5_FINDINGS,
        "round5_totals": {
            "identifiers": len(ROUND5_FINDINGS),
            "dispositions": dict(sorted(round5_totals.items())),
        },
    }

    out = Path(args.out)
    out.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
                   encoding="utf-8")
    print(f"written {out}")
    print(f"historical: {len(historical)} identifiers "
          f"{dict(sorted(totals.items()))}")
    print(f"round 5   : {len(ROUND5_FINDINGS)} findings "
          f"{dict(sorted(round5_totals.items()))}")
    return 0


def override_reason_disposition(identifier, override):
    """The disposition after a Round-5 reassessment."""
    # The reassessment table states the disposition explicitly so that the
    # script never has to infer it.
    return override["disposition"]


if __name__ == "__main__":
    sys.exit(main())
