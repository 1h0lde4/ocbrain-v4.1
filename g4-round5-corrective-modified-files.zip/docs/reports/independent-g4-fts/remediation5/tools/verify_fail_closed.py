"""
verify_fail_closed.py — prove that the baseline reconstruction FAILS
CLOSED on a damaged Round-4 archive.

This is the reviewer's challenge H.5 item 13: "Corrupt one byte of the
Round-4 archive and confirm the reconstruction fails closed."

It exercises four cases:

  1. the intact archive          -> accepted (exit 0);
  2. ONE flipped byte             -> rejected (non-zero exit);
  3. a missing archive            -> rejected;
  4. a truncated archive          -> rejected.

    python verify_fail_closed.py --out <evidence.json>
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
TOOL = HERE / "reconstruct_baselines.py"


def run_case(tool, repo, archive, work, name):
    proc = subprocess.run(
        [sys.executable, "-X", "utf8", str(tool),
         "--work", str(work / f"w_{name}"),
         "--out", str(work / f"r_{name}.json"),
         "--repo", str(repo), "--archive", str(archive)],
        capture_output=True, text=True, timeout=3600)
    return {"case": name, "exit_code": proc.returncode,
            "accepted": proc.returncode == 0,
            "stderr": proc.stderr.strip()[:1000]}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", default=str(HERE.parents[4]))
    parser.add_argument("--archive", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    repo = Path(args.repo).resolve()
    archive = Path(args.archive).resolve()
    work = Path(tempfile.mkdtemp(prefix="g4_fail_closed_"))

    cases = []
    cases.append(run_case(TOOL, repo, archive, work, "intact"))

    corrupt = work / "corrupt.zip"
    data = bytearray(archive.read_bytes())
    data[len(data) // 2] ^= 0xFF
    corrupt.write_bytes(bytes(data))
    cases.append(run_case(TOOL, repo, corrupt, work, "one_byte_flipped"))
    cases[-1]["corrupted_sha256"] = hashlib.sha256(
        corrupt.read_bytes()).hexdigest()

    cases.append(run_case(TOOL, repo, work / "does_not_exist.zip", work,
                           "missing"))

    truncated = work / "truncated.zip"
    raw = archive.read_bytes()
    truncated.write_bytes(raw[: len(raw) // 2])
    cases.append(run_case(TOOL, repo, truncated, work, "truncated"))

    evidence = {
        "description": (
            "The baseline reconstruction fails closed on a damaged Round-4 "
            "archive.  The intact archive is accepted; a single flipped "
            "byte, a missing archive and a truncated archive are all "
            "rejected with a non-zero exit status."),
        "archive": str(archive),
        "archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
        "cases": cases,
        "result": ("PASS" if cases[0]["accepted"] and
                   not any(c["accepted"] for c in cases[1:]) else "FAIL"),
    }
    Path(args.out).write_text(json.dumps(evidence, indent=2,
                                         ensure_ascii=False),
                              encoding="utf-8")
    shutil.rmtree(work, ignore_errors=True)
    print(json.dumps({c["case"]: c["exit_code"] for c in cases}, indent=2))
    print("result:", evidence["result"])
    return 0 if evidence["result"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
