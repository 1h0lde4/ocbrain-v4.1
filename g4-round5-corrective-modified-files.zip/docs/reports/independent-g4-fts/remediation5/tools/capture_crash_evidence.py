"""
capture_crash_evidence.py — capture the abrupt-termination evidence.

It runs the R5-03 abrupt-termination scenario in an ISOLATED child
process and records what survived: the child's exact exit code, the
crash-injection marker, the surviving preservation directory and the
surviving ``manifest.json``.

The result is written as JSON so a reviewer can read the surviving
manifest without re-running the test.

    python capture_crash_evidence.py --out <file.json>
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

REPO = Path(r"C:\Users\Produ\Downloads\ocbrain-g4-indep\wt")

CHILD = r'''
import json, os, sys
sys.path.insert(0, {repo!r})
from core.memory import sqlite_migration as mig

def hook(manifest, record):
    with open({marker!r}, "w", encoding="utf-8") as fh:
        fh.write(json.dumps({{
            "destination_dir": os.path.dirname(record["destination"]),
            "manifest_path": os.path.join(
                os.path.dirname(record["destination"]), "manifest.json"),
            "verified_record": record["name"],
        }}))
        fh.flush()
        os.fsync(fh.fileno())
    os._exit(97)

mig.set_preservation_progress_hook(hook)
mig._preserve_recoverable_state(sys.argv[1], "round-5 crash evidence")
os._exit(98)
'''


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    work = Path(tempfile.mkdtemp(prefix="g4_crash_evidence_"))
    child = work / "crash_child.py"
    marker = work / "crash.marker"
    child.write_text(CHILD.format(repo=str(REPO), marker=str(marker)),
                     encoding="utf-8")

    # a synthetic database with synthetic sidecars
    import sqlite3
    db = work / "crash.db"
    conn = sqlite3.connect(str(db))
    conn.execute("CREATE TABLE knowledge_entries(entry_id TEXT PRIMARY KEY, "
                 "content TEXT)")
    conn.commit()
    conn.close()
    for suffix, payload in (("-wal", b"WALDATA"), ("-journal", b"JOURNAL")):
        (work / ("crash.db" + suffix)).write_bytes(payload)

    proc = subprocess.run([sys.executable, "-X", "utf8", str(child), str(db)],
                          capture_output=True, text=True, timeout=300,
                          cwd=str(REPO))

    evidence = {
        "child_exit_code": proc.returncode,
        "expected_exit_code": 97,
        "deliberate_termination": proc.returncode == 97,
        "crash_marker_present": marker.exists(),
        "child_stdout": proc.stdout[-2000:],
        "child_stderr": proc.stderr[-2000:],
    }
    if marker.exists():
        evidence["marker"] = json.loads(marker.read_text(encoding="utf-8"))
        manifest_path = Path(evidence["marker"]["manifest_path"])
        evidence["manifest_present"] = manifest_path.exists()
        if manifest_path.exists():
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            evidence["surviving_manifest"] = manifest
            verified = [f for f in manifest.get("files", [])
                        if f.get("verified")]
            evidence["verified_artifacts"] = [f["name"] for f in verified]
            evidence["pending_artifacts"] = [
                f["name"] for f in manifest.get("files", [])
                if not f.get("verified")]
            evidence["status"] = manifest.get("status")
            evidence["complete"] = manifest.get("complete")
    else:
        evidence["manifest_present"] = False

    Path(args.out).write_text(json.dumps(evidence, indent=2, ensure_ascii=False),
                              encoding="utf-8")
    print(json.dumps({k: v for k, v in evidence.items()
                      if k not in ("child_stdout", "child_stderr",
                                   "surviving_manifest")}, indent=2))
    return 0 if evidence.get("deliberate_termination") else 1


if __name__ == "__main__":
    sys.exit(main())
