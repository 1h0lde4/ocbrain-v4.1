"""
reconstruct_baselines.py — build and verify B0 / B4 / B5.

    B0 = the pristine export of the exact Git HEAD
    B4 = B0 + the verified Round-4 archive overlay
    B5 = B4 + the Round-5 overlay (the working tree at the end of Round 5)

The Round-4 source manifest INSIDE the archive is parsed as the EXPECTED
specification for B4, so the reconstruction is checked against the
historical artifact rather than against itself.

PRODUCTION DATA IS NEVER TOUCHED
--------------------------------
The source-tree scan excludes the runtime data directory (``.data``) — it
is production data, and a source-tree fingerprint must describe the
SOURCE.  The B0 and B4 trees are temporary exports that contain no
runtime data at all.

    python reconstruct_baselines.py --work <scratch> --out <result.json>
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from g4_baseline import (apply_overlay, build_manifest, fingerprint,   # noqa: E402
                         sha256_file)

REPO = Path(r"C:\Users\Produ\Downloads\ocbrain-g4-indep\wt")
ARCHIVE = Path(r"C:\Users\Produ\Downloads\ocbrain-g4-indep"
                r"\g4-round4-corrective-modified-files.zip")
EXPECTED_SHA = "1c75f7fc1033aad2f1b1c57969a05fed68f4a569418c9556f70900db7cf6ee0c"
HEAD = "739e58ce185a527d2d2f58c7622c5108f5b0e0db"
MANIFEST_REL = ("docs/reports/independent-g4-fts/remediation4"
                "/G_SOURCE_MANIFEST.md")


def parse_round4_manifest(text: str) -> dict:
    """Extract {path: {sha256, size}} from the Round-4 Markdown manifest."""
    expected = {}
    row = re.compile(
        r"^\|\s*`([^`]+)`\s*\|\s*(\d+)\s*\|\s*`?([0-9a-f]{64})`?\s*\|")
    for line in text.splitlines():
        match = row.match(line.strip())
        if match:
            path, size, digest = match.group(1), int(match.group(2)), \
                match.group(3)
            if path.endswith("/"):
                continue
            expected[path] = {"sha256": digest, "size": size}
    return expected


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--repo", default=str(REPO))
    parser.add_argument("--archive", default=str(ARCHIVE))
    args = parser.parse_args()

    repo = Path(args.repo)
    archive = Path(args.archive)
    work = Path(args.work)
    if work.exists():
        shutil.rmtree(work)
    work.mkdir(parents=True)

    result = {"head": HEAD, "archive": str(archive), "problems": []}

    got = sha256_file(archive)
    result["archive_sha256"] = got
    result["archive_sha256_ok"] = (got == EXPECTED_SHA)
    if got != EXPECTED_SHA:
        result["problems"].append("the Round-4 archive SHA-256 does not match")
        Path(args.out).write_text(json.dumps(result, indent=2), encoding="utf-8")
        return 1

    with zipfile.ZipFile(archive) as z:
        manifest_text = z.read(MANIFEST_REL).decode("utf-8")
    expected = parse_round4_manifest(manifest_text)
    result["expected_entries"] = len(expected)

    # ── B0 ───────────────────────────────────────────────────────────────
    b0 = work / "B0"
    b0zip = work / "b0.zip"
    out = subprocess.run(
        ["git", "-C", str(repo), "archive", "--format=zip", "-o", str(b0zip),
         HEAD], capture_output=True, text=True)
    if out.returncode != 0:
        result["problems"].append(f"git archive failed: {out.stderr}")
        Path(args.out).write_text(json.dumps(result, indent=2), encoding="utf-8")
        return 1
    with zipfile.ZipFile(b0zip) as z:
        z.extractall(b0)
    b0zip.unlink()
    b0_records = build_manifest(b0)
    b0_map = {r["path"]: r["sha256"] for r in b0_records}
    result["B0"] = {"files": len(b0_records),
                    "fingerprint": fingerprint(b0_records)}

    base_expected = {rel: {"sha256": rec["sha256"],
                           "base_sha256": b0_map.get(rel)}
                     for rel, rec in expected.items()}
    result["b4_entries_added_over_b0"] = len([r for r in expected
                                              if r not in b0_map])

    # ── B4 ───────────────────────────────────────────────────────────────
    b4 = work / "B4"
    applied = apply_overlay(b0, archive, b4, base_expected)
    b4_records = build_manifest(b4)
    result["B4"] = {"files": len(b4_records),
                    "fingerprint": fingerprint(b4_records),
                    "replaced": len(applied["replaced"]),
                    "added": len(applied["added"])}

    problems = []
    for rel, rec in expected.items():
        path = b4 / rel
        if not path.is_file():
            problems.append(f"B4 missing: {rel}")
            continue
        if sha256_file(path) != rec["sha256"]:
            problems.append(f"B4 hash mismatch: {rel}")
    result["B4"]["discrepancies"] = problems
    result["problems"].extend(problems)

    # ── B5 = the working tree (Round-5 overlay applied on top of B4) ────
    b5_records = build_manifest(repo)
    result["B5"] = {"files": len(b5_records),
                    "fingerprint": fingerprint(b5_records)}
    # The Round-5 delta: the Round-4 files that the Round-5 overlay
    # CHANGED.  This is the expected difference, not a discrepancy.
    delta = []
    for rel, rec in expected.items():
        path = repo / rel
        if not path.is_file():
            delta.append(f"working tree missing: {rel}")
        elif sha256_file(path) != rec["sha256"]:
            delta.append(rel)
    result["B5"]["round5_modified_round4_paths"] = delta
    result["B5"]["round5_missing_round4_paths"] = [
        d for d in delta if d.startswith("working tree missing")]
    missing = [d for d in result["B5"]["round5_missing_round4_paths"]]
    if missing:
        result["problems"].extend(missing)

    result["fingerprints_distinct"] = (
        result["B0"]["fingerprint"] != result["B4"]["fingerprint"]
        != result["B5"]["fingerprint"])
    result["production_data_excluded"] = \
        "the runtime data directory (.data) is excluded from every scan"

    Path(args.out).write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k != "problems"},
                     indent=2))
    if result["problems"]:
        print("PROBLEMS:")
        for problem in result["problems"][:40]:
            print("  -", problem)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
