"""
g4_report_plugin.py — a minimal pytest reporting plugin for the Round-5
campaign.

It records one JSON line per test report so that the campaign can
compare the states **per node id** instead of comparing aggregate counts.

The plugin is loaded EXPLICITLY with ``-p g4_report_plugin`` AFTER the
protection boundary is installed (the launcher loads it that way), so it
cannot be used to reach a database before the guard is in place.

The output path comes from the ``G4_REPORT_JSON`` environment variable.
"""
from __future__ import annotations

import json
import os

_OUTPUT = os.environ.get("G4_REPORT_JSON")


def pytest_runtest_logreport(report):
    if not _OUTPUT:
        return
    record = {
        "nodeid": report.nodeid,
        "when": report.when,
        "outcome": report.outcome,
        "duration": report.duration,
    }
    if report.failed:
        record["longrepr"] = str(report.longrepr)[:4000]
    elif report.skipped:
        record["longrepr"] = str(getattr(report, "longrepr", ""))[:1000]
        # ``wasxfail`` distinguishes an expected failure from a plain skip
        record["wasxfail"] = bool(getattr(report, "wasxfail", False))
    try:
        with open(_OUTPUT, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, ensure_ascii=False) + "\n")
    except OSError:
        pass


def pytest_sessionfinish(session, exitstatus):
    if not _OUTPUT:
        return
    summary = {
        "collected": len(session.items),
        "exitstatus": int(exitstatus),
    }
    try:
        with open(_OUTPUT + ".summary", "w", encoding="utf-8") as fh:
            json.dump(summary, fh)
    except OSError:
        pass
