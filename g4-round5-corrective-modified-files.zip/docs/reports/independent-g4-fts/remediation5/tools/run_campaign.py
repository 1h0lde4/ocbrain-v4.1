"""
run_campaign.py — the Round-5 regression campaign runner.

It runs the protected pytest launcher against a given SOURCE STATE (B0,
B4 or B5), records everything an independent reviewer needs to reproduce
and compare the run, and writes one JSON record per invocation.

    python run_campaign.py --state B5 --tree <dir> --out <dir> \
        [--label full] [-- <pytest arguments>]

The recorded record contains the exact command, the working directory, the
Python and SQLite identity, the pytest version, the platform, the
dependency inventory, the start/end timestamps, the exit code, the
collected/passed/failed/error/skipped/xfail/deselected counts, the test
node-id inventory (one line per test report), the stdout and stderr paths
with their SHA-256, and any deviation from the expected environment.

NO SECRET IS RECORDED: the environment is reduced to the variables that
can influence the result, and their values are sanitised where they
could carry a credential.
"""
from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
PLUGIN = HERE / "g4_report_plugin.py"

#: The environment variables that can influence the result.
RELEVANT_ENV = (
    "OCBRAIN_MEMORY_RUNTIME_ACK",
    "OCBRAIN_MEMORY_DIR",
    "OCBRAIN_PROTECTED_PATHS",
    "OCBRAIN_TEST_ALLOW_CONFIG_WRITE",
    "PYTEST_DISABLE_PLUGIN_AUTOLOAD",
    "PYTHONHASHSEED",
    "PYTHONIOENCODING",
    "PYTHONUTF8",
)

#: The harness files that are copied into a baseline tree so that the
#: campaign can run every state through the SAME protected launcher.  They
#: are a CAMPAIGN HARNESS, not part of the source state under test.
HARNESS_FILES = (
    "run_g4_protected_pytest.py",
    "_g4_bootstrap.py",
    "_g4_protection.py",
    "_g4_fsidentity.py",
)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def sqlite_identity() -> dict:
    import sqlite3
    info = {
        "sqlite_version": getattr(sqlite3, "sqlite_version", None),
        "sqlite_version_info": list(getattr(sqlite3, "sqlite_version_info",
                                            ())),
    }
    try:
        import importlib.util
        spec = importlib.util.find_spec("_sqlite3")
        base = os.path.dirname(spec.origin) if spec and spec.origin else \
            os.path.dirname(os.path.abspath(sqlite3.__file__))
        for name in ("sqlite3.dll", "libsqlite3-0.dll"):
            candidate = os.path.join(base, name)
            if os.path.exists(candidate):
                library = ctypes.CDLL(candidate)
                library.sqlite3_sourceid.restype = ctypes.c_char_p
                info["source_id"] = library.sqlite3_sourceid().decode()
                library.sqlite3_compileoption_get.restype = ctypes.c_char_p
                library.sqlite3_compileoption_get.argtypes = [ctypes.c_int]
                options = []
                index = 0
                while index < 300:
                    value = library.sqlite3_compileoption_get(index)
                    if not value:
                        break
                    options.append(value.decode())
                    index += 1
                info["compile_options"] = options
                break
    except Exception as exc:                           # pragma: no cover
        info["error"] = repr(exc)
    return info


def dependency_inventory() -> dict:
    import importlib.metadata as metadata
    packages = {}
    for distribution in metadata.distributions():
        name = distribution.metadata.get("Name")
        if not name:
            continue
        packages[name] = distribution.version
    return dict(sorted(packages.items()))


def sanitized_environment() -> dict:
    env = {}
    for name in RELEVANT_ENV:
        value = os.environ.get(name)
        if value is None:
            continue
        if name in ("OCBRAIN_PROTECTED_PATHS", "OCBRAIN_MEMORY_DIR"):
            value = "<set>"
        env[name] = value
    return env


def install_harness(tree: Path, source: Path) -> list:
    """Copy the campaign harness into a baseline tree."""
    installed = []
    target = tree / "tests"
    target.mkdir(parents=True, exist_ok=True)
    for name in HARNESS_FILES:
        origin = source / "tests" / name
        if not origin.exists():
            continue
        shutil.copy2(origin, target / name)
        installed.append(f"tests/{name}")
    return installed


def classify(reports):
    """
    The outcome of one test node.

    A test that FAILS during setup or teardown is an **ERROR**, not a
    failure: the test body never ran.  The distinction matters — it is the
    difference between "the assertion failed" and "the test could not be
    executed at all".
    """
    call_failed = any(r["when"] == "call" and r["outcome"] == "failed"
                      for r in reports)
    phase_failed = any(r["when"] in ("setup", "teardown")
                       and r["outcome"] == "failed" for r in reports)
    skipped = [r for r in reports if r["outcome"] == "skipped"]
    if call_failed:
        return "failed"
    if phase_failed:
        return "error"
    if skipped:
        for report in skipped:
            if report.get("wasxfail"):
                return "xfailed"
            longrepr = report.get("longrepr")
            if isinstance(longrepr, str) and "@pytest.mark.xfail" in longrepr:
                return "xfailed"
        return "skipped"
    return "passed"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", required=True,
                        help="the source-state id: B0, B4 or B5")
    parser.add_argument("--tree", required=True,
                        help="the root of the source state under test")
    parser.add_argument("--out", required=True,
                        help="the directory that receives the logs and the "
                             "record")
    parser.add_argument("--label", default="full")
    parser.add_argument("--harness-from", default=None,
                        help="a directory whose tests/ folder provides the "
                             "protected launcher; its root is also the "
                             "PRODUCTION root that stays protected")
    parser.add_argument("--protected-root", default=None,
                        help="the repository whose production paths are "
                             "protected (default: the harness root)")
    parser.add_argument("--reclassify", action="store_true",
                        help="re-derive the record from the existing report "
                             "file without running anything")
    parser.add_argument("pytest_args", nargs="*")
    args = parser.parse_args()

    tree = Path(args.tree).resolve()
    out_dir = Path(args.out).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    harness_installed = []
    if args.harness_from and not args.reclassify:
        harness_installed = install_harness(tree,
                                            Path(args.harness_from).resolve())

    report_path = out_dir / f"{args.state}_{args.label}.jsonl"
    record_path = out_dir / f"{args.state}_{args.label}.record.json"
    stdout_path = out_dir / f"{args.state}_{args.label}.stdout.log"
    stderr_path = out_dir / f"{args.state}_{args.label}.stderr.log"

    if args.reclassify:
        record = json.loads(record_path.read_text(encoding="utf-8"))
        reports = []
        if report_path.exists():
            for line in report_path.read_text(
                    encoding="utf-8", errors="replace").splitlines():
                if line.strip():
                    try:
                        reports.append(json.loads(line))
                    except json.JSONDecodeError:
                        pass
        nodes = {}
        for item in reports:
            node = item["nodeid"]
            nodes.setdefault(node, []).append(item)
        outcomes = {node: classify(items) for node, items in nodes.items()}
        counts = {"passed": 0, "failed": 0, "error": 0, "skipped": 0,
                  "xfailed": 0}
        for outcome in outcomes.values():
            counts[outcome] = counts.get(outcome, 0) + 1
        record["counts"] = counts
        record["collected"] = len(outcomes)
        record["node_ids"] = sorted(outcomes)
        record["node_outcomes"] = dict(sorted(outcomes.items()))
        record["reclassified"] = True
        record_path.write_text(json.dumps(record, indent=2,
                                          ensure_ascii=False),
                               encoding="utf-8")
        print(json.dumps({"source_state": record["source_state"],
                          "label": record["label"],
                          "collected": record["collected"],
                          "counts": counts}, indent=2))
        return 0

    launcher = tree / "tests" / "run_g4_protected_pytest.py"
    command = [sys.executable, "-X", "utf8", str(launcher),
               "-p", "no:cacheprovider", "-p", "g4_report_plugin",
               "-q"] + list(args.pytest_args)

    if report_path.exists():
        report_path.unlink()

    env = dict(os.environ)
    env["G4_REPORT_JSON"] = str(report_path)
    env["PYTHONPATH"] = os.pathsep.join(
        [str(HERE), str(tree / "tests"), env.get("PYTHONPATH", "")])
    env["PYTHONIOENCODING"] = "utf-8"
    # The PRODUCTION paths that are protected are the ones of the REAL
    # repository, not of the tree under test: a baseline state is run from
    # a temporary export, and that export is scratch space.
    env["OCBRAIN_PROTECTED_ROOT"] = str(
        Path(args.harness_from).resolve() if args.harness_from
        else Path(args.protected_root).resolve())

    stdout_path = out_dir / f"{args.state}_{args.label}.stdout.log"
    stderr_path = out_dir / f"{args.state}_{args.label}.stderr.log"

    started_at = time.time()
    with stdout_path.open("wb") as out, stderr_path.open("wb") as err:
        proc = subprocess.run(command, cwd=str(tree), env=env,
                              stdout=out, stderr=err)
    ended_at = time.time()

    reports = []
    if report_path.exists():
        for line in report_path.read_text(encoding="utf-8",
                                          errors="replace").splitlines():
            if line.strip():
                try:
                    reports.append(json.loads(line))
                except json.JSONDecodeError:
                    pass

    nodes = {}
    for record in reports:
        node = record["nodeid"]
        nodes.setdefault(node, {"outcome": "passed", "reports": []})
        nodes[node]["reports"].append(record)
    for node, entry in nodes.items():
        entry["outcome"] = classify(entry["reports"])

    counts = {"passed": 0, "failed": 0, "error": 0, "skipped": 0,
              "xfailed": 0}
    for entry in nodes.values():
        counts[entry["outcome"]] = counts.get(entry["outcome"], 0) + 1

    try:
        import pytest
        pytest_version = pytest.__version__
    except Exception:                                   # pragma: no cover
        pytest_version = "unknown"

    record = {
        "source_state": args.state,
        "label": args.label,
        "tree": str(tree),
        "command": command,
        "working_directory": str(tree),
        "python_executable": sys.executable,
        "python_version": sys.version,
        "sqlite": sqlite_identity(),
        "pytest_version": pytest_version,
        "platform": {
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "processor": platform.processor(),
        },
        "dependencies": dependency_inventory(),
        "environment": sanitized_environment(),
        "started_at": started_at,
        "ended_at": ended_at,
        "duration_s": ended_at - started_at,
        "exit_code": proc.returncode,
        "collected": len(nodes),
        "counts": counts,
        "node_ids": sorted(nodes),
        "node_outcomes": {node: entry["outcome"]
                          for node, entry in sorted(nodes.items())},
        "stdout_path": str(stdout_path),
        "stdout_sha256": sha256_file(stdout_path),
        "stderr_path": str(stderr_path),
        "stderr_sha256": sha256_file(stderr_path),
        "report_jsonl_path": str(report_path),
        "report_jsonl_sha256": (sha256_file(report_path)
                                if report_path.exists() else None),
        "campaign_harness_installed": harness_installed,
        "deviations": [],
    }
    if harness_installed:
        record["deviations"].append(
            "the protected launcher and its bootstrap were copied into the "
            "tree so that every source state runs through the SAME "
            "protection boundary; they are a campaign harness, not part of "
            "the source state under test")

    out_path = out_dir / f"{args.state}_{args.label}.record.json"
    out_path.write_text(json.dumps(record, indent=2, ensure_ascii=False),
                        encoding="utf-8")
    print(json.dumps({k: record[k] for k in
                      ("source_state", "label", "exit_code", "collected",
                       "counts", "duration_s")}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
