"""
build_source_manifest.py — the Round-5 changed-file manifest.

It compares the ROUND-4 BASELINE (the reconstructed B4 tree) with the
ROUND-5 working tree and produces ``G_SOURCE_MANIFEST.md``: every changed
path with its type, size, SHA-256, status (added / modified / deleted),
the related finding and the related test.

The comparison is a CONTENT comparison, not a git comparison: the B4 tree
is the verified Round-4 archive overlay on the pristine HEAD, so the
manifest describes exactly the Round-5 delta.

    python build_source_manifest.py --baseline <B4 tree> --tree <B5 tree> \
        --out <G_SOURCE_MANIFEST.md>
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import stat
import sys
from pathlib import Path

SKIP_DIRS = {".git", "__pycache__", ".pytest_cache", ".venv",
             ".venv312-build", "build", ".mypy_cache", ".ruff_cache",
             # R5-01 / §0.4: the RUNTIME DATA directory is PRODUCTION DATA.
             # The manifest describes the SOURCE delta; hashing the live
             # data would be a forbidden production inspection.
             ".data"}

#: The finding each changed path belongs to.
FINDING_MAP = {
    "tests/_g4_protection.py": ("R5-01", "TestR501UriPolicy; TestR502QueryPolicy; "
                                "TestR503FilesystemAliases"),
    "tests/_g4_fsidentity.py": ("R5-01 / R5-04", "TestR503FilesystemAliases; "
                                 "TestR508SidecarIdentity"),
    "core/memory/sqlite_guard.py": ("R5-01", "TestR504SqlAccessRoutes"),
    "core/memory/sqlite_contract.py": ("R5-01", "TestR501UriPolicy"),
    "core/memory/sqlite_migration.py": ("R5-03", "TestR507ManifestDurability"),
    "core/runtime/state.py": ("R5-01", "TestR504SqlAccessRoutes"),
    "core/context.py": ("R5-01", "TestR504SqlAccessRoutes"),
    "core/migrator.py": ("R5-01", "TestR504SqlAccessRoutes"),
    "core/events/event_stream.py": ("R5-01", "TestR504SqlAccessRoutes"),
    "core/memory/backends/sqlite_archive.py": ("R5-01",
                                               "TestR504SqlAccessRoutes"),
    "core/memory/backends/sqlite_storage.py": ("R5-01",
                                               "TestR504SqlAccessRoutes"),
    "core/memory/graph/graph_engine.py": ("R5-01", "TestR504SqlAccessRoutes"),
    "core/memory/sqlite_runtime.py": ("R5-01", "TestR504SqlAccessRoutes"),
    "interface/cli.py": ("R5-02", "TestR506VerificationLifecycle"),
    "tests/conftest.py": ("R5-06", "TestR505Bootstrap"),
    "tests/run_g4_protected_pytest.py": ("R5-06", "TestR505Bootstrap"),
    "tests/_g4_bootstrap.py": ("R5-06", "TestR505Bootstrap"),
    "tests/test_g4_interaction_scenarios.py": ("R5-04",
                                               "test_h_noop_migration_does_not_"
                                               "copy_the_whole_database"),
    "tests/test_g4_r5_corrections.py": ("R5-01..R5-05",
                                        "the complete Round-5 suite"),
    "docs/reports/independent-g4-fts/remediation5/": ("R5-05",
                                                       "TestR509Crosswalk"
                                                       "Reconciliation"),
    "docs/reports/G4_FTS_REV3_REMEDIATION_REPORT.md": ("R5-05", "§20"),
    "docs/reports/independent-g4-fts/HANDOFF.md": ("R5-05", "§11"),
    "KNOWN_ISSUES.md": ("R5-05", "the dated Round-5 entries"),
}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def scan(root: Path) -> dict:
    """path -> {type, mode, size, sha256}."""
    result = {}
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(d for d in dirnames if d not in SKIP_DIRS)
        for name in sorted(filenames):
            if name.endswith((".pyc", ".pyo")):
                continue
            if name == ".git":
                # repository metadata (a linked worktree has a .git FILE)
                continue
            path = Path(dirpath) / name
            relative = path.relative_to(root).as_posix()
            st = path.lstat()
            if stat.S_ISLNK(st.st_mode):
                result[relative] = {"type": "symlink", "mode": "0777",
                                    "size": st.st_size, "sha256": None,
                                    "link_target": os.readlink(path)}
            else:
                result[relative] = {
                    "type": "file",
                    "mode": f"{stat.S_IMODE(st.st_mode):04o}",
                    "size": st.st_size,
                    "sha256": sha256_file(path),
                    "link_target": None,
                }
    return result


def finding_for(path: str):
    for prefix, value in FINDING_MAP.items():
        if path == prefix or path.startswith(prefix):
            return value
    return ("—", "—")


def _is_binary(path: Path) -> bool:
    """A file with NUL bytes is not a text file — it has no meaningful
    unified diff and must not be rendered as one."""
    try:
        with path.open("rb") as fh:
            return b"\x00" in fh.read(4096)
    except OSError:
        return True


def write_patch(baseline: Path, tree: Path, entries: list, out: Path) -> int:
    """
    Write a unified diff of the Round-5 delta.

    The patch is the REPRODUCIBLE OVERLAY: applying it to the B4 baseline
    reproduces the B5 tree.  It is generated from the reconstructed
    baseline (not from git), because the baseline is the authoritative
    Round-4 state.

    BINARY files (a NUL byte in the first 4 KiB) are listed as
    "replaced" without a textual diff: a unified diff of a binary file
    would be meaningless and enormous.  Their content hash is in
    ``G_SOURCE_MANIFEST.md``.
    """
    import difflib
    lines = []
    written = 0
    for entry in entries:
        relative = entry["path"]
        before = baseline / relative
        after = tree / relative
        if (after.is_file() and _is_binary(after)) or \
                (before.is_file() and _is_binary(before)):
            lines.append(f"--- a/{relative}")
            lines.append(f"+++ b/{relative}")
            lines.append(f"# BINARY FILE — replaced; the content hash is in "
                         f"G_SOURCE_MANIFEST.md")
            lines.append(f"# sha256: {entry['sha256']}")
            written += 1
            continue
        if entry["status"] == "deleted":
            lines.append(f"--- a/{relative}")
            lines.append(f"+++ /dev/null")
            old = before.read_text(encoding="utf-8", errors="replace")
            for line in old.splitlines(keepends=True):
                lines.append("-" + line if line.endswith("\n") else "-" + line + "\n")
            written += 1
            continue
        if entry["status"] == "added":
            lines.append(f"--- /dev/null")
            lines.append(f"+++ b/{relative}")
            new = after.read_text(encoding="utf-8", errors="replace")
            for line in new.splitlines(keepends=True):
                lines.append("+" + line if line.endswith("\n") else "+" + line + "\n")
            written += 1
            continue
        old = before.read_text(encoding="utf-8", errors="replace")
        new = after.read_text(encoding="utf-8", errors="replace")
        diff = difflib.unified_diff(old.splitlines(keepends=True),
                                    new.splitlines(keepends=True),
                                    fromfile=f"a/{relative}",
                                    tofile=f"b/{relative}")
        lines.extend(line if line.endswith("\n") else line + "\n"
                     for line in diff)
        written += 1
    out.write_text("".join(lines), encoding="utf-8", newline="")
    return written


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", required=True)
    parser.add_argument("--tree", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--json", default=None)
    parser.add_argument("--patch", default=None,
                        help="write the unified diff of the Round-5 delta "
                             "here (the reproducible overlay)")
    args = parser.parse_args()

    baseline = scan(Path(args.baseline))
    current = scan(Path(args.tree))

    entries = []
    for path in sorted(set(baseline) | set(current)):
        before = baseline.get(path)
        after = current.get(path)
        if before is None and after is not None:
            status = "added"
        elif before is not None and after is None:
            status = "deleted"
        elif before.get("sha256") != after.get("sha256"):
            status = "modified"
        else:
            continue
        record = after or before
        finding, test = finding_for(path)
        entries.append({
            "path": path,
            "type": record["type"],
            "mode": record["mode"],
            "size": record["size"],
            "sha256": record["sha256"],
            "status": status,
            "finding": finding,
            "test": test,
            "base_sha256": (before or {}).get("sha256"),
        })

    counts = {}
    for entry in entries:
        counts[entry["status"]] = counts.get(entry["status"], 0) + 1

    lines = []
    lines.append("# G — Source Manifest (Round 5)")
    lines.append("")
    lines.append("<!-- GENERATED FILE — DO NOT EDIT BY HAND. -->")
    lines.append("")
    lines.append("The manifest describes the **Round-5 delta**: the")
    lines.append("difference between the reconstructed Round-4 baseline")
    lines.append("(`B4`) and the Round-5 working tree (`B5`).  The")
    lines.append("comparison is a CONTENT comparison, so a file that only")
    lines.append("changed its mode is reported as modified.")
    lines.append("")
    lines.append(f"- Baseline: `{args.baseline}`")
    lines.append(f"- Tree: `{args.tree}`")
    lines.append(f"- Changed paths: **{len(entries)}** "
                 f"({counts.get('added', 0)} added, "
                 f"{counts.get('modified', 0)} modified, "
                 f"{counts.get('deleted', 0)} deleted)")
    lines.append("")
    lines.append("| Path | Status | Type | Mode | Size | SHA-256 | Finding | Test |")
    lines.append("|---|---|---|---|---:|---|---|---|")
    for entry in entries:
        lines.append("| `{path}` | {status} | {type} | {mode} | {size} | "
                     "`{sha}` | {finding} | {test} |".format(
                         path=entry["path"], status=entry["status"],
                         type=entry["type"], mode=entry["mode"],
                         size=entry["size"],
                         sha=entry["sha256"] or "-",
                         finding=entry["finding"], test=entry["test"]))
    lines.append("")
    Path(args.out).write_text("\n".join(lines) + "\n", encoding="utf-8",
                               newline="\n")
    if args.json:
        Path(args.json).write_text(json.dumps(entries, indent=2),
                                   encoding="utf-8")
    if args.patch:
        count = write_patch(Path(args.baseline), Path(args.tree), entries,
                            Path(args.patch))
        print(f"written {args.patch} ({count} path(s) in the overlay)")
    print(f"written {args.out} ({len(entries)} changed paths)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
