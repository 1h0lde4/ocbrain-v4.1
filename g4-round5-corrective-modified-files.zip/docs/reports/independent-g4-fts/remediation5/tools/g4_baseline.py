"""
g4_baseline.py — deterministic source-baseline reconstruction for Round 5.

Three source states are constructed in SEPARATE temporary directories; the
original working tree is never modified:

    B0   pristine export of the exact Git HEAD
    B4   B0 + the verified Round-4 archive overlay
    B5   B4 + the Round-5 overlay (the files changed in Round 5)

Each state gets a machine-readable manifest (path, type, mode, size,
SHA-256, symlink target) and a deterministic source-tree fingerprint
computed from the sorted records.

Usage:
    python g4_baseline.py export-b0  --dest <dir> [--head <sha>]
    python g4_baseline.py build-b4  --b0 <dir> --dest <dir> --archive <zip>
    python g4_baseline.py fingerprint --tree <dir>
    python g4_baseline.py manifest   --tree <dir> --out <file.json>
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

SKIP_DIRS = {".git", "__pycache__", ".pytest_cache", ".venv", ".venv312-build",
             "build", ".mypy_cache", ".ruff_cache",
             # R5-01 / §0.4: the RUNTIME DATA directory is PRODUCTION DATA.
             # It is never hashed, stat-ed or fingerprinted: a source-tree
             # fingerprint must describe the SOURCE, not the live data.
             ".data"}
MANIFEST_NAME = "manifest.json"


# ── helpers ──────────────────────────────────────────────────────────────────

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def iter_tree(root: Path):
    """Yield (relpath, absolute path) for every tracked-able file.

    The ``.git`` ENTRY is skipped whether it is a directory (a clone) or a
    FILE (a linked worktree): it is repository metadata, never source.
    """
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(d for d in dirnames if d not in SKIP_DIRS)
        for name in sorted(filenames):
            if name.endswith((".pyc", ".pyo")):
                continue
            if name == ".git":
                continue
            p = Path(dirpath) / name
            yield p.relative_to(root).as_posix(), p


def build_manifest(root: Path) -> list:
    """One record per path: type, mode, size, sha256, symlink target."""
    records = []
    for rel, path in iter_tree(root):
        st = path.lstat()
        mode = stat.S_IMODE(st.st_mode)
        if stat.S_ISLNK(st.st_mode):
            records.append({"path": rel, "type": "symlink",
                            "mode": f"{mode:04o}",
                            "size": st.st_size,
                            "sha256": None,
                            "link_target": os.readlink(path)})
        else:
            records.append({"path": rel, "type": "file", "mode": f"{mode:04o}",
                            "size": st.st_size, "sha256": sha256_file(path),
                            "link_target": None})
    records.sort(key=lambda r: r["path"])
    return records


def fingerprint(records: list) -> str:
    """Deterministic tree fingerprint over the sorted records."""
    h = hashlib.sha256()
    for r in records:
        h.update(f"{r['path']}\t{r['type']}\t{r['mode']}\t"
                 f"{r['sha256'] or ''}\t{r['link_target'] or ''}\n"
                 .encode("utf-8"))
    return h.hexdigest()


# ── B0 ───────────────────────────────────────────────────────────────────────

def export_b0(dest: Path, head: str, repo: Path) -> dict:
    """Exact pristine export of `head` (no working-tree files)."""
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True)
    zip_path = dest.parent / f"{dest.name}.zip"
    out = subprocess.run(
        ["git", "-C", str(repo), "archive", "--format=zip", "-o", str(zip_path),
         head], capture_output=True, text=True)
    if out.returncode != 0:
        raise SystemExit(f"git archive failed: {out.stderr}")
    with zipfile.ZipFile(zip_path) as z:
        z.extractall(dest)
    zip_path.unlink()
    # the export must not contain the repository's own .git or caches
    records = build_manifest(dest)
    return {"state": "B0", "head": head, "fingerprint": fingerprint(records),
            "files": len(records)}


# ── B4 ───────────────────────────────────────────────────────────────────────

def apply_overlay(base: Path, archive: Path, dest: Path,
                  expected: dict | None = None) -> dict:
    """
    Apply a verified archive overlay onto a base tree.

    For every archive entry the BASE content is captured first and compared
    with the expected base hash (when one is supplied) — an ordinary
    extraction does not establish that a replacement was based on the
    expected original file. Deletions are applied explicitly; unexpected
    paths are rejected; the result is validated against the expected
    manifest.
    """
    if dest.exists():
        shutil.rmtree(dest)
    shutil.copytree(base, dest, symlinks=True)
    applied = {"replaced": [], "added": [], "deleted": [], "skipped": []}
    with zipfile.ZipFile(archive) as z:
        names = [n for n in z.namelist() if not n.endswith("/")]
        if len(names) != len(set(names)):
            raise SystemExit("archive contains duplicate entry paths")
        for name in names:
            if name.startswith("/") or ".." in Path(name).parts:
                raise SystemExit(f"unsafe archive path: {name}")
            target = dest / name
            base_file = base / name
            base_hash = (sha256_file(base_file)
                         if base_file.is_file() else None)
            if expected and name in expected:
                want_base = expected[name].get("base_sha256")
                if want_base and base_hash and want_base != base_hash:
                    raise SystemExit(
                        f"base hash mismatch for {name}: expected "
                        f"{want_base}, found {base_hash}")
            data = z.read(name)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            if base_hash is None:
                applied["added"].append(name)
            else:
                applied["replaced"].append(name)
    return applied


def validate_against_manifest(tree: Path, expected: dict) -> list:
    """Return the discrepancies between a tree and an expected manifest."""
    problems = []
    for rel, rec in expected.items():
        p = tree / rel
        if not p.is_file():
            problems.append(f"missing: {rel}")
            continue
        got = sha256_file(p)
        if rec.get("sha256") and got != rec["sha256"]:
            problems.append(f"hash mismatch: {rel}")
    return problems


# ── CLI ──────────────────────────────────────────────────────────────────────

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("export-b0")
    p.add_argument("--dest", required=True)
    p.add_argument("--head", required=True)
    p.add_argument("--repo", required=True)

    p = sub.add_parser("build-b4")
    p.add_argument("--b0", required=True)
    p.add_argument("--dest", required=True)
    p.add_argument("--archive", required=True)
    p.add_argument("--expect", default=None,
                   help="JSON map path -> {sha256, base_sha256}")

    p = sub.add_parser("fingerprint")
    p.add_argument("--tree", required=True)

    p = sub.add_parser("manifest")
    p.add_argument("--tree", required=True)
    p.add_argument("--out", required=True)

    args = ap.parse_args()

    if args.cmd == "export-b0":
        info = export_b0(Path(args.dest), args.head, Path(args.repo))
        print(json.dumps(info, indent=2))
        return 0

    if args.cmd == "build-b4":
        expected = (json.loads(Path(args.expect).read_text(encoding="utf-8"))
                    if args.expect else None)
        applied = apply_overlay(Path(args.b0), Path(args.archive),
                               Path(args.dest), expected)
        records = build_manifest(Path(args.dest))
        info = {"state": "B4", "fingerprint": fingerprint(records),
                "files": len(records), **applied}
        if expected:
            problems = validate_against_manifest(Path(args.dest), expected)
            info["discrepancies"] = problems
            if problems:
                print(json.dumps(info, indent=2))
                return 1
        print(json.dumps(info, indent=2))
        return 0

    if args.cmd == "fingerprint":
        records = build_manifest(Path(args.tree))
        print(json.dumps({"files": len(records),
                          "fingerprint": fingerprint(records)}, indent=2))
        return 0

    if args.cmd == "manifest":
        records = build_manifest(Path(args.tree))
        Path(args.out).write_text(json.dumps(
            {"fingerprint": fingerprint(records), "files": records},
            indent=2), encoding="utf-8")
        print(f"manifest written: {args.out}")
        return 0

    return 2


if __name__ == "__main__":
    sys.exit(main())
