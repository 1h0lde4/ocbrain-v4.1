"""
build_round5_package.py — build and verify the Round-5 evidence package.

    python build_round5_package.py --repo <tree> --out <zip> \
        [--round4-archive <zip>] [--manifest <json>]

THE ALLOWLIST IS EXPLICIT
--------------------------
The package contains only the paths this script lists.  A path that is
not on the list is NEVER added, whatever it is.  In particular the
runtime data directory (``.data``) is excluded by construction, and the
production databases can therefore not enter the package.

    production databases and their sidecars   EXCLUDED
    the cognitive vault                       EXCLUDED
    user data and vault contents              EXCLUDED
    credentials and secrets                   EXCLUDED
    virtual environments and caches           EXCLUDED
    temporary test directories                EXCLUDED
    unrelated untracked files                 EXCLUDED
    unrelated repository changes              EXCLUDED

THE ROUND-4 ARCHIVE IS NESTED VERBATIM
---------------------------------------
The Round-4 archive is the immutable historical input.  Its SHA-256 is
verified before it is added and it is stored **unmodified**; the
verification after the build proves the nested copy is byte-identical.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

#: The Round-4 archive's expected identity.
ROUND4_SHA256 = ("1c75f7fc1033aad2f1b1c57969a05fed68f4a569418c9556f70900db7cf6ee0c")
ROUND4_ENTRIES = 76

#: Directories that are never packaged, whatever else is listed.
FORBIDDEN_PREFIXES = (".data/", ".git/", ".venv", "node_modules/",
                       "__pycache__/", ".pytest_cache/", "build/")

#: The documentation package — the whole directory is included.
REMEDIATION5_DIR = "docs/reports/independent-g4-fts/remediation5"

#: The implementation and test files changed by Round 5 (the explicit
#: allowlist).  A file that is not listed here is not packaged.
SOURCE_ALLOWLIST = (
    "core/memory/sqlite_guard.py",
    "core/memory/sqlite_contract.py",
    "core/memory/sqlite_migration.py",
    "core/memory/sqlite_runtime.py",
    "core/memory/backends/sqlite_storage.py",
    "core/memory/backends/sqlite_archive.py",
    "core/memory/graph/graph_engine.py",
    "core/runtime/state.py",
    "core/context.py",
    "core/migrator.py",
    "core/events/event_stream.py",
    "interface/cli.py",
    "tests/_g4_protection.py",
    "tests/_g4_fsidentity.py",
    "tests/_g4_bootstrap.py",
    "tests/run_g4_protected_pytest.py",
    "tests/conftest.py",
    "tests/test_g4_r5_corrections.py",
    "tests/test_g4_interaction_scenarios.py",
    "docs/reports/G4_FTS_REV3_REMEDIATION_REPORT.md",
    "docs/reports/independent-g4-fts/HANDOFF.md",
    "docs/reports/independent-g4-fts/EVIDENCE_NOTE.md",
    "KNOWN_ISSUES.md",
)

#: The nested, immutable Round-4 input artifact.
ROUND4_NESTED_NAME = "g4-round4-corrective-modified-files.zip"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def is_forbidden(relative: str) -> bool:
    normalized = relative.replace("\\", "/")
    return any(normalized.startswith(prefix)
               for prefix in FORBIDDEN_PREFIXES)


def collect(repo: Path):
    """The explicit allowlist of files to package."""
    files = []
    for relative in SOURCE_ALLOWLIST:
        path = repo / relative
        if path.is_file():
            files.append((relative, path))
    package = repo / REMEDIATION5_DIR
    if package.is_dir():
        for dirpath, dirnames, filenames in os.walk(package):
            dirnames[:] = sorted(d for d in dirnames
                                 if d != "__pycache__")
            for name in sorted(filenames):
                path = Path(dirpath) / name
                relative = path.relative_to(repo).as_posix()
                if relative.endswith(".pyc"):
                    continue
                files.append((relative, path))
    known = repo / "KNOWN_ISSUES.md"
    if known.is_file() and not any(r == "KNOWN_ISSUES.md" for r, _ in files):
        files.append(("KNOWN_ISSUES.md", known))
    return files


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--round4-archive", required=True)
    parser.add_argument("--manifest", default=None)
    args = parser.parse_args()

    repo = Path(args.repo).resolve()
    out = Path(args.out).resolve()
    round4 = Path(args.round4_archive).resolve()

    # ── the nested Round-4 archive is verified BEFORE it is added ───────
    round4_sha = sha256_file(round4)
    if round4_sha != ROUND4_SHA256:
        sys.stderr.write(
            f"REFUSED: the Round-4 archive SHA-256 is {round4_sha}, "
            f"expected {ROUND4_SHA256}\n")
        return 2
    with zipfile.ZipFile(round4) as z:
        round4_entries = len([n for n in z.namelist()
                               if not n.endswith("/")])

    files = collect(repo)
    records = []
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for relative, path in files:
            if is_forbidden(relative):
                sys.stderr.write(f"REFUSED: {relative} is on the forbidden "
                                 "list\n")
                return 2
            z.write(path, relative)
            records.append({"path": relative,
                            "size": path.stat().st_size,
                            "sha256": sha256_file(path)})
        z.write(round4, ROUND4_NESTED_NAME)
        records.append({"path": ROUND4_NESTED_NAME,
                        "size": round4.stat().st_size,
                        "sha256": round4_sha,
                        "role": "immutable nested Round-4 input artifact"})

    # ── verification ─────────────────────────────────────────────────────
    with zipfile.ZipFile(out) as z:
        names = z.namelist()
        problems = []
        if len(names) != len(set(names)):
            problems.append("the archive contains duplicate entry paths")
        for name in names:
            if name.startswith("/") or ".." in Path(name).parts:
                problems.append(f"unsafe entry path: {name}")
            if "\\" in name:
                problems.append(f"entry path is not forward-slash: {name}")
            if is_forbidden(name):
                problems.append(f"forbidden entry: {name}")
        # every listed file is byte-identical
        for record in records:
            with z.open(record["path"]) as fh:
                digest = hashlib.sha256(fh.read()).hexdigest()
            if digest != record["sha256"]:
                problems.append(f"round-trip mismatch: {record['path']}")
        nested = z.read(ROUND4_NESTED_NAME)
        nested_sha = hashlib.sha256(nested).hexdigest()
        if nested_sha != ROUND4_SHA256:
            problems.append("the nested Round-4 archive is not byte-identical")

    # an independent extraction round-trip
    with tempfile.TemporaryDirectory(prefix="g4_package_check_") as tmp:
        with zipfile.ZipFile(out) as z:
            z.extractall(tmp)
        for record in records:
            extracted = Path(tmp) / record["path"]
            if not extracted.is_file():
                problems.append(f"not extracted: {record['path']}")
            elif sha256_file(extracted) != record["sha256"]:
                problems.append(f"extracted mismatch: {record['path']}")

    summary = {
        "package": str(out),
        "size": out.stat().st_size,
        "sha256": sha256_file(out),
        "entries": len(records),
        "nested_round4": {"name": ROUND4_NESTED_NAME,
                          "sha256": round4_sha,
                          "entries": round4_entries,
                          "byte_identical": nested_sha == ROUND4_SHA256},
        "files": records,
        "problems": problems,
    }
    if args.manifest:
        Path(args.manifest).write_text(json.dumps(summary, indent=2),
                                       encoding="utf-8")
    print(json.dumps({k: v for k, v in summary.items() if k != "files"},
                     indent=2))
    if problems:
        print("PROBLEMS:")
        for problem in problems:
            print("  -", problem)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
