#!/usr/bin/env python
"""
reproduce.py — the Round-5 reproduction script.

It runs, in order, everything an independent reviewer needs to reproduce
the Round-5 claims:

  1. the measured SQLite runtime facts;
  2. the measured SQLite URI semantics;
  3. the B0 / B4 / B5 baseline reconstruction and the three fingerprints;
  4. the crosswalk generator's ``--check`` mode;
  5. the protected test suites;
  6. the changed-file manifest and the Round-5 overlay patch;
  7. the crash-injection evidence;
  8. the package build and its verification.

    python reproduce.py --repo <tree> [--out <dir>]

The script changes nothing outside the output directory and the
reconstructed baseline trees.
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
REMEDIATION5 = HERE.parent
TOOLS = REMEDIATION5 / "tools"

ROUND4_ARCHIVE_NAME = "g4-round4-corrective-modified-files.zip"


def run(label, command, cwd=None):
    print(f"\n=== {label} ===")
    print("$ " + " ".join(str(c) for c in command))
    started = time.time()
    proc = subprocess.run([str(c) for c in command], cwd=cwd)
    print(f"--- exit {proc.returncode} in {time.time() - started:.1f}s")
    return proc.returncode


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", default=str(REMEDIATION5.parents[3]))
    parser.add_argument("--out", default=None)
    parser.add_argument("--skip-campaign", action="store_true",
                        help="skip the three full-suite campaigns")
    parser.add_argument("--round4-archive", default=None)
    args = parser.parse_args()

    repo = Path(args.repo).resolve()
    out = Path(args.out).resolve() if args.out else \
        Path(tempfile.mkdtemp(prefix="g4_reproduce_"))
    out.mkdir(parents=True, exist_ok=True)
    print(f"repository : {repo}")
    print(f"output     : {out}")

    failures = []

    code = run("1. the measured SQLite runtime",
               [sys.executable, "-X", "utf8",
                TOOLS / "sqlite_runtime_probe.py",
                out / "sqlite_runtime_probe.json"])
    if code:
        failures.append("the runtime probe")

    code = run("2. the measured SQLite URI semantics",
               [sys.executable, "-X", "utf8",
                TOOLS / "sqlite_uri_semantics_probe.py",
                out / "sqlite_uri_semantics.json"])
    if code:
        failures.append("the URI semantics probe")

    code = run("3. the B0 / B4 / B5 reconstruction",
               [sys.executable, "-X", "utf8",
                TOOLS / "reconstruct_baselines.py",
                "--work", out / "baselines",
                "--out", out / "baseline_reconstruction.json",
                "--repo", repo])
    if code:
        failures.append("the baseline reconstruction")

    code = run("4. the crosswalk generator (--check)",
               [sys.executable, "-X", "utf8",
                REMEDIATION5 / "build_crosswalk.py", "--check"],
               cwd=REMEDIATION5)
    if code:
        failures.append("the crosswalk --check")

    launcher = repo / "tests" / "run_g4_protected_pytest.py"
    for label, target in (
            ("5a. the Round-5 suite", "tests/test_g4_r5_corrections.py"),
            ("5b. the Round-4 suite", "tests/test_g4_r4_corrections.py"),
            ("5c. the interaction scenarios",
             "tests/test_g4_interaction_scenarios.py")):
        code = run(label,
                   [sys.executable, "-X", "utf8", launcher, target,
                    "-p", "no:cacheprovider", "-q"], cwd=repo)
        if code:
            failures.append(label)

    code = run("6. the changed-file manifest and the overlay patch",
               [sys.executable, "-X", "utf8",
                TOOLS / "build_source_manifest.py",
                "--baseline", out / "baselines" / "B4",
                "--tree", repo,
                "--out", out / "G_SOURCE_MANIFEST.md",
                "--json", out / "source_manifest.json",
                "--patch", out / "round5_overlay.patch"])
    if code:
        failures.append("the source manifest")

    code = run("7. the crash-injection evidence",
               [sys.executable, "-X", "utf8",
                TOOLS / "capture_crash_evidence.py",
                "--out", out / "crash_injection_evidence.json"])
    if code:
        failures.append("the crash-injection evidence")

    archive = args.round4_archive
    if archive is None:
        candidates = sorted(repo.glob(ROUND4_ARCHIVE_NAME)) + \
            sorted(repo.parent.glob(ROUND4_ARCHIVE_NAME))
        archive = str(candidates[0]) if candidates else None
    if archive:
        code = run("8. the package build and verification",
                   [sys.executable, "-X", "utf8",
                    TOOLS / "build_round5_package.py",
                    "--repo", repo,
                    "--out", out / "g4-round5-corrective-modified-files.zip",
                    "--round4-archive", archive,
                    "--manifest", out / "package_manifest.json"])
        if code:
            failures.append("the package build")
    else:
        print("\n=== 8. the package build === SKIPPED: the Round-4 archive "
              "was not found")

    print("\n=== SUMMARY ===")
    if failures:
        print("FAILED steps: " + ", ".join(failures))
        return 1
    print("every reproduction step completed")
    print(f"the evidence is in {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
