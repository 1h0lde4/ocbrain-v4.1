"""R5-01 §2.1 — establish the ACTUAL SQLite runtime behaviour (measured)."""
from __future__ import annotations

import ctypes
import json
import os
import sqlite3
import sys
import tempfile

out = {
    "python_version": sys.version,
    "python_version_info": list(sys.version_info[:3]),
    "sqlite3_module_version": getattr(sqlite3, "version", "REMOVED_IN_3_14"),
    "sqlite3_version": getattr(sqlite3, "sqlite_version", None),
    "sqlite_libversion": sqlite3.sqlite_version,
    "platform": sys.platform,
}

# ── locate the SQLite shared library that CPython actually loaded ────────────
def find_sqlite_dll():
    import importlib.util
    spec = importlib.util.find_spec("_sqlite3")
    if spec and spec.origin and os.path.exists(spec.origin):
        base = os.path.dirname(spec.origin)
        for name in ("sqlite3.dll", "libsqlite3-0.dll", "_sqlite3.pyd"):
            cand = os.path.join(base, name)
            if os.path.exists(cand):
                return cand
    import sqlite3 as s3
    base = os.path.dirname(s3.__file__)
    for name in ("sqlite3.dll", "libsqlite3-0.dll"):
        cand = os.path.join(base, name)
        if os.path.exists(cand):
            return cand
    return None


dll_path = find_sqlite_dll()
out["sqlite_dll_candidate"] = dll_path

dll = None
if dll_path:
    try:
        dll = ctypes.CDLL(dll_path)
    except OSError as exc:
        out["sqlite_dll_error"] = str(exc)

if dll is not None:
    dll.sqlite3_libversion.restype = ctypes.c_char_p
    out["sqlite3_libversion_ctypes"] = dll.sqlite3_libversion().decode()
    try:
        dll.sqlite3_sourceid.restype = ctypes.c_char_p
        out["sqlite3_sourceid"] = dll.sqlite3_sourceid().decode()
    except Exception as exc:
        out["sqlite3_sourceid_error"] = str(exc)
    try:
        dll.sqlite3_compileoption_get.restype = ctypes.c_char_p
        dll.sqlite3_compileoption_get.argtypes = [ctypes.c_int]
        opts = []
        i = 0
        while i < 300:
            v = dll.sqlite3_compileoption_get(i)
            if not v:
                break
            opts.append(v.decode())
            i += 1
        out["compile_options"] = opts
        out["SQLITE_USE_URI_compile_option"] = any(
            o.startswith("SQLITE_USE_URI") for o in opts)
        out["SQLITE_ALLOW_URI_AUTHORITY_compile_option"] = any(
            o.startswith("SQLITE_ALLOW_URI_AUTHORITY") for o in opts)
    except Exception as exc:
        out["compile_options_error"] = str(exc)
    out["has_sqlite3_config"] = hasattr(dll, "sqlite3_config")
    out["has_sqlite3_db_config"] = hasattr(dll, "sqlite3_db_config")
    # SQLITE_OPEN_URI = 0x00000040 ; SQLITE_OPEN_READONLY = 0x1
    try:
        dll.sqlite3_config.argtypes = [ctypes.c_int, ctypes.c_int]
        # SQLITE_CONFIG_URI = 3 ; call with get-semantics is not available, so
        # only record that the entry point exists.
        out["sqlite3_config_present"] = True
    except Exception:
        pass

# ── URI interpretation probes (in-memory / temp only) ───────────────────────
tmp = tempfile.mkdtemp(prefix="g4_r5_uri_probe_")
probe = {}


def uri_of(p):
    return "file:" + p.replace(os.sep, "/")


# (a) uri=True honours the query
q_target = os.path.join(tmp, "q_probe.db")
try:
    conn = sqlite3.connect(uri_of(q_target) + "?mode=rwc", uri=True)
    conn.execute("CREATE TABLE t(x)")
    conn.commit()
    conn.close()
    probe["uri_true_creates_target"] = os.path.exists(q_target)
    probe["uri_true_created_literal_name"] = os.path.exists(
        uri_of(q_target) + "?mode=rwc")
except Exception as exc:
    probe["uri_true_creates_target"] = "ERROR: %r" % (exc,)

# (b) uri=False treats the same string as an ORDINARY filename
lit_target = os.path.join(tmp, "lit_probe.db")
lit_name = "file:" + lit_target.replace(os.sep, "/") + "?mode=rwc"
cwd_before = set(os.listdir("."))
try:
    conn = sqlite3.connect(lit_name, uri=False)
    conn.execute("CREATE TABLE t(x)")
    conn.commit()
    conn.close()
    probe["uri_false_creates_target"] = os.path.exists(lit_target)
except Exception as exc:
    probe["uri_false_creates_target"] = "ERROR: %r" % (exc,)
probe["uri_false_new_cwd_entries"] = sorted(
    set(os.listdir(".")) - cwd_before)

# (c) ATTACH with a URI — URI processing applies to ATTACH when enabled for
#     the ORIGINAL connection.
attach_target = os.path.join(tmp, "attached.db")
try:
    conn = sqlite3.connect(":memory:")
    conn.execute("ATTACH DATABASE ? AS a", (uri_of(attach_target),))
    conn.execute("CREATE TABLE a.t(x)")
    conn.commit()
    conn.close()
    probe["attach_uri_creates_target"] = os.path.exists(attach_target)
    probe["attach_uri_created_literal_name"] = os.path.exists(
        uri_of(attach_target))
except Exception as exc:
    probe["attach_uri_creates_target"] = "ERROR: %r" % (exc,)

out["uri_probe"] = probe

# ── authorizer probe ─────────────────────────────────────────────────────────
auth = {}
SQLITE_ATTACH = 24
try:
    conn = sqlite3.connect(":memory:")
    seen = []

    def authorizer(action, arg1, arg2, dbname, trigger):
        seen.append((action, arg1, arg2, dbname))
        return sqlite3.SQLITE_OK

    conn.set_authorizer(authorizer)
    try:
        conn.execute("ATTACH DATABASE ':memory:' AS a")
    except Exception as exc:
        auth["attach_error"] = repr(exc)
    auth["attach_events"] = [list(e) for e in seen]
    seen.clear()
    vac_target = os.path.join(tmp, "vac.db")
    try:
        conn.execute("VACUUM INTO ?", (vac_target,))
    except Exception as exc:
        auth["vacuum_error"] = repr(exc)
    auth["vacuum_created_file"] = os.path.exists(vac_target)
    auth["vacuum_events"] = [list(e) for e in seen]
    auth["vacuum_reports_SQLITE_ATTACH"] = any(
        e[0] == SQLITE_ATTACH for e in seen)
    conn.close()
except Exception as exc:
    auth["setup_error"] = repr(exc)

# ATTACH with an expression -> arg1 is NULL
try:
    conn = sqlite3.connect(":memory:")
    seen = []

    def authorizer2(action, arg1, arg2, dbname, trigger):
        seen.append((action, arg1, arg2, dbname))
        return sqlite3.SQLITE_OK

    conn.set_authorizer(authorizer2)
    try:
        conn.execute("ATTACH DATABASE (SELECT 'x') AS a")
    except Exception:
        pass
    out["attach_expression_events"] = [list(e) for e in seen]
    conn.close()
except Exception as exc:
    out["attach_expression_error"] = repr(exc)

out["authorizer_probe"] = auth

# ── extension / dbconfig probe ───────────────────────────────────────────────
ext = {}
try:
    conn = sqlite3.connect(":memory:")
    ext["has_enable_load_extension"] = hasattr(conn, "enable_load_extension")
    conn.close()
except Exception as exc:
    ext["error"] = repr(exc)
out["extension_probe"] = ext

cfg = {}
try:
    conn = sqlite3.connect(":memory:")
    for name in ("enable_load_extension", "getlimit", "setlimit"):
        cfg[name] = hasattr(conn, name)
    try:
        cfg["SQLITE_LIMIT_ATTACHED"] = conn.getlimit(
            sqlite3.SQLITE_LIMIT_ATTACHED)
    except Exception as exc:
        cfg["limit_error"] = repr(exc)
    conn.close()
except Exception as exc:
    cfg["error"] = repr(exc)
out["dbconfig_probe"] = cfg

# ── python interface probe ───────────────────────────────────────────────────
py = {}
p = os.path.join(tmp, "pathlike.db")
try:
    from pathlib import Path
    conn = sqlite3.connect(Path(p))
    conn.execute("CREATE TABLE t(x)")
    conn.commit()
    conn.close()
    py["pathlib_accepted"] = os.path.exists(p)
except Exception as exc:
    py["pathlib_accepted"] = "ERROR: %r" % (exc,)
out["python_interface_probe"] = py

dest = sys.argv[1] if len(sys.argv) > 1 else "r5_probe.json"
with open(dest, "w", encoding="utf-8") as fh:
    json.dump(out, fh, indent=2, default=str)
print("written", dest)
