"""Empirical SQLite URI semantics probe (R5-01 §2.2). Measures what SQLite
actually opens for each URI form on THIS runtime. No production file."""
from __future__ import annotations

import json
import os
import shutil
import sqlite3
import sys
import tempfile

CASES = []


def case(name, uri, candidates):
    CASES.append((name, uri, candidates))


tmp = tempfile.mkdtemp(prefix="g4_uri_sem_")
base = os.path.join(tmp, "base")
os.makedirs(base, exist_ok=True)

# The relative-path cases create a file in the CURRENT WORKING DIRECTORY.
# The probe therefore runs in its own temporary directory and never leaves
# an artefact in the repository.
_original_cwd = os.getcwd()
os.chdir(tmp)


def w(p):
    """A candidate path -> what SQLite would create."""
    return p


# build a set of distinct candidate paths
def p(n):
    return os.path.join(base, n)


case("no_slash_drive", "file:" + p("a1.db").replace("\\", "/"),
     [p("a1.db"), os.path.join(tmp, "file:" + p("a1.db").replace("\\", "/"))])
case("slash_drive", "file:/" + p("a2.db").replace("\\", "/"), [p("a2.db")])
case("triple_slash", "file:///" + p("a3.db").replace("\\", "/"), [p("a3.db")])
case("localhost_authority", "file://localhost/" + p("a4.db").replace("\\", "/"),
     [p("a4.db"), os.path.join(base, "localhost", "a4.db")])
case("authority_looks_like_drive", "file://" + p("a5.db").replace("\\", "/"),
     [p("a5.db"), os.path.join("C:", "a5.db")])
case("foreign_authority", "file://evilserver/share/a6.db",
     [os.path.join(tmp, "share", "a6.db"),
      "//evilserver/share/a6.db"])
case("query_mode", "file:" + p("a7.db").replace("\\", "/") + "?mode=rwc",
     [p("a7.db")])
case("fragment_only", "file:" + p("a8.db").replace("\\", "/") + "#frag",
     [p("a8.db"), p("a8.db") + "#frag"])
case("query_then_fragment",
     "file:" + p("a9.db").replace("\\", "/") + "?mode=rwc#frag", [p("a9.db")])
case("fragment_before_question",
     "file:" + p("a10.db").replace("\\", "/") + "#frag?mode=ro", [p("a10.db")])
case("percent_hash_in_name",
     "file:" + p("a11#x.db").replace("\\", "/").replace("#", "%23"),
     [p("a11#x.db")])
case("unknown_query_param",
     "file:" + p("a12.db").replace("\\", "/") + "?mode=rwc&bogus=1",
     [p("a12.db")])
case("vfs_query_param",
     "file:" + p("a13.db").replace("\\", "/") + "?mode=rwc&vfs=nosuchvfs",
     [p("a13.db")])
case("modeof_query_param",
     "file:" + p("a14.db").replace("\\", "/") + "?mode=rwc&modeof=" +
     p("a14src.db").replace("\\", "/"), [p("a14.db")])
case("localhost_plus_query",
     "file://localhost/" + p("a15.db").replace("\\", "/") + "?mode=rwc",
     [p("a15.db")])
case("localhost_plus_fragment",
     "file://localhost/" + p("a16.db").replace("\\", "/") + "#frag",
     [p("a16.db")])
case("encoded_slash", "file:///" + p("a17.db").replace("\\", "/").replace(
    "/", "%2F", 1), [p("a17.db")])
case("no_query_no_fragment_no_scheme_prefix",
     p("a18.db"), [p("a18.db")])
case("relative", "file:rel19.db", [os.path.join(os.getcwd(), "rel19.db")])
case("drive_relative", "file:/C:rel20.db", [])
case("percent_encoded_space",
     "file:" + p("a 21.db").replace("\\", "/").replace(" ", "%20"),
     [p("a 21.db")])

results = {}
for name, uri, candidates in CASES:
    entry = {"uri": uri, "candidates": candidates}
    before = set()
    for root, _d, files in os.walk(tmp):
        for f in files:
            before.add(os.path.join(root, f))
    try:
        conn = sqlite3.connect(uri, uri=True)
        conn.execute("CREATE TABLE t(x)")
        conn.commit()
        conn.close()
        entry["opened"] = True
    except Exception as exc:
        entry["opened"] = False
        entry["error"] = "%s: %s" % (type(exc).__name__, exc)
    after = set()
    for root, _d, files in os.walk(tmp):
        for f in files:
            after.add(os.path.join(root, f))
    created = sorted(after - before)
    entry["created_files"] = [os.path.relpath(c, tmp) for c in created]
    entry["created_absolute"] = created
    # which candidate matched
    matched = []
    for c in candidates:
        for cr in created:
            if os.path.normcase(os.path.abspath(c)) == os.path.normcase(
                    os.path.abspath(cr)):
                matched.append(c)
    entry["matched_candidate"] = matched
    results[name] = entry

dest = sys.argv[1] if len(sys.argv) > 1 else "r5_uri_semantics.json"
os.chdir(_original_cwd)
with open(dest, "w", encoding="utf-8") as fh:
    json.dump({"tmp": tmp, "cwd": _original_cwd, "cases": results}, fh, indent=2)
shutil.rmtree(tmp, ignore_errors=True)
print("written", dest)
