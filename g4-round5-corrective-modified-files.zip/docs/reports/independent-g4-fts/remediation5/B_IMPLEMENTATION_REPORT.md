# B — Implementation Report (Round 5)

**Date:** 2026-11-12
**Baseline:** `independent/g4-fts-rev3-20261105` @ `739e58ce185a527d2d2f58c7622c5108f5b0e0db`
**Round-4 input archive:** `g4-round4-corrective-modified-files.zip`
(SHA-256 `1c75f7fc1033aad2f1b1c57969a05fed68f4a569418c9556f70900db7cf6ee0c`,
76 entries, 425 105 bytes) — **unchanged**, included verbatim in the
Round-5 package as a nested immutable input.

---

## B.1 The five work packages and the bootstrap

| ID | Work package | Primary files | Disposition |
|---|---|---|---|
| R5-01 | SQLite URI semantics and complete database-access protection | `tests/_g4_protection.py` (rewritten), `tests/_g4_fsidentity.py` (new), `core/memory/sqlite_guard.py` (new), `core/memory/sqlite_contract.py`, `core/runtime/state.py`, and the connection sites in `core/` and `interface/` | FIXED |
| R5-02 | Disposable verification-copy lifecycle and truthful JSON | `interface/cli.py` (`memory_verify`) | FIXED |
| R5-03 | Crash-surviving per-artifact preservation manifests | `core/memory/sqlite_migration.py` | FIXED |
| R5-04 | Correct sidecar lifecycle and file-identity evidence | `tests/test_g4_interaction_scenarios.py` (Scenario H), `tests/_g4_fsidentity.py` | FIXED |
| R5-05 | Baseline reconstruction, crosswalk reconciliation, evidence reproducibility | `docs/reports/independent-g4-fts/remediation5/**` | FIXED |
| R5-06 | Protected test bootstrap (specification §7) | `tests/run_g4_protected_pytest.py` (new), `tests/_g4_bootstrap.py` (new), `tests/conftest.py` | FIXED |

## B.2 R5-01 — what changed and why

### The URI parser (`tests/_g4_protection.py`)

The Round-4 parser stripped `file:`, cut the query at the first `?` and
never looked at the fragment.  It therefore computed a **different path**
than SQLite opened for `file:/C:/…#frag`, and it could not tell a
malformed URI from a valid one.

The new parser treats the URI structure **component-wise** — scheme,
authority, path, query, fragment — and implements the semantics
**measured** on the shipped runtime (see `B_DATABASE_ACCESS_ROUTE_INVENTORY.md`
§B.1 and `logs/sqlite_uri_semantics.json`):

* the **authority** is compared against the local set (`""`, `localhost`);
  every other authority is **rejected**, which is what SQLite itself does
  on this build (`invalid uri authority: …`);
* the **path** is percent-decoded exactly once at the byte level and then
  decoded as UTF-8; malformed escapes and encoded NULs are rejected;
* the **query** is subject to a **strict allowlist** — `mode` with the
  values `ro`, `rw`, `rwc` only.  Unknown parameters, duplicates,
  percent-encoded parameter names or values, parameters without a value
  and empty parameters are all rejected.  `vfs`, `modeof`, `nolock`,
  `immutable` and `psow` are rejected: `vfs` selects a VFS, `modeof`
  names another file, and the rest change the locking and
  change-detection assumptions;
* the **fragment** is stripped before the path comparison, and a literal
  `#` in a file name (`%23`) is never confused with the fragment
  delimiter.

The **lenient** resolver `_uri_to_path()` is kept (it must not raise for
the Round-4 suite) and is now fragment-aware and authority-aware.

A malformed or ambiguous `file:` target is **denied at the connection
boundary** — the boundary must never reason about a different path than
SQLite opens, and it never retries a rejected URI as an ordinary file
name.

### The companion-sidecar namespace

`protected_paths_for()` and `install()` now register the SQLite companion
files (`-wal`, `-shm`, `-journal`) of every protected **file** target.
A direct `sqlite3.connect()` of a protected sidecar is denied, while
SQLite's own internal VFS opens of those files (which the Python wrapper
does not intercept, and does not claim to) are unaffected.

### The authorizer policy

`SQLITE_ATTACH` (action code 24) is denied **unconditionally**, and the
decision is made on the **action code**, never on the filename text —
because an expression-based attachment reports the action with a **NULL**
filename argument on this runtime.

The policy is installed by the connection **class** (`GuardedConnection`),
which overrides `set_authorizer()`.  A later registration by application
code therefore **composes** with the policy instead of replacing it, and
`set_authorizer(None)` cannot remove it.  `sqlite3.Connection` is an
immutable extension type, so the policy cannot be attached to the type
itself; the `factory` argument of `sqlite3.connect` is the mechanism.

### The reviewed application factory (`core/memory/sqlite_guard.py`)

Every application-managed SQLite connection is now created through
`open_database()`.  The factory builds the target with the canonical URI
constructor, installs the authorizer policy, disables loadable extensions
and lowers `SQLITE_LIMIT_ATTACHED` to 0 — and **records** what was
actually applied (a configuration that could not be set is never assumed).

`core/runtime/state.py` no longer replaces the global `sqlite3.connect`.

### Native filesystem identity (`tests/_g4_fsidentity.py`)

On Windows the identity comes from
`GetFileInformationByHandleEx(FileIdInfo)` — the **measured** native
`sizeof(FILE_ID_INFO)` is **24** bytes (not 20: `FILE_ID_128` is
8-byte aligned inside the structure, so the 128-bit file id starts at
offset 8; a 20-byte buffer fails with `ERROR_BAD_LENGTH`).  The record
carries the volume serial number and the 128-bit file id.  On POSIX the
identity comes from `fstat` on a held descriptor.  The mechanism that was
actually used is always reported, because a fallback is a weaker
guarantee.

## B.3 R5-02 — the verification lifecycle

The Round-4 `memory_verify` emitted its JSON from a failure helper
**before** the cleanup had run, initialised `verification_target_removed`
to `False` (so a workspace that never existed was reported as "not
removed"), and used `shutil.rmtree(..., ignore_errors=True)` — which
**swallowed** a cleanup failure while the command still exited 0.

The command is now a single ordered lifecycle with **one** authoritative
serialisation point.  The payload carries `contract_passed`,
`contract_assessed`, `contract_verdict` (`PASS` / `FAIL` /
`INCOMPLETE`), `cleanup_ok`, `ok`, `verification_target`,
`verification_target_removed` (`true` / `false` / `null`),
`recovery_evidence_preserved`, `error`, `cleanup_error`,
`cleanup_errors`, `verification_workspace` and `exit_code`.

A cleanup failure **never** corrupts the integrity verdict: the contract
can report `PASS` while `cleanup_ok` is `false`, `ok` is `false` and the
exit code is 1.

## B.4 R5-03 — the preservation manifest

The manifest is now replaced **atomically** (temporary file in the same
directory → `flush` → `fsync` → same-directory `os.replace` → directory
`fsync` on POSIX), and every artifact advances through a **persisted**
state progression:

```
pending → copying → copied → verified
```

with a monotonic `revision` and a per-record `last_update_sequence`.
The copied artifact is `fsync`-ed before the record may be marked
verified.

The durability claim is stated precisely: **process-crash durability**;
on POSIX also power-loss durability *if* the filesystem honours the
directory `fsync`; on Windows there is **no** directory-sync equivalent,
so no power-loss claim is made.  Storage-controller cache durability,
hardware reliability, a transactionally consistent source snapshot and
source immutability during the copy are explicitly **not** claimed.

A dedicated test seam (`set_preservation_progress_hook`) lets an isolated
child process terminate with `os._exit()` after the first verified
artifact; the surviving manifest then shows the first artifact as
verified and the remaining ones as pending.

## B.5 R5-04 — the corrected Scenario H invariant

The Round-4 Scenario H demanded that the `-shm` still **exist** — an
existence assertion that a *different* file at the same pathname would
have satisfied.  The corrected invariant is:

> The **-wal** carries persistent database state and must be retained with
> its database; the **-shm** is SQLite's WAL-index coordination structure
> and is removed by SQLite's own last-connection cleanup.

The test now compares the **filesystem identity** of the main database,
the WAL and the SHM (and the expected absence of a rollback journal),
while the byte hash of the SHM is deliberately **not** asserted.  The
setup keeps an **anchor connection** open with a committed WAL state and
a read transaction, so SQLite's last-connection cleanup cannot fire in
the middle of the measurement.

## B.6 R5-05 — the crosswalk and the generator

The Round-4 crosswalk is **immutable history**.  The Round-5 crosswalk
keeps the 98 historical identifiers complete and adds
`round4_disposition`, `current_disposition`, `round5_evidence`,
`residual_risk` and `supersedes`.  The Round-5 findings are a **separate**
collection and are **not** part of the historical denominator.

`build_crosswalk.py` reads the machine-readable crosswalk as its source of
truth, validates the identifiers (missing, duplicate, unexpected), the
status vocabulary and the set membership, computes **every** aggregate
from the records, renders the register deterministically and provides a
`--check` mode that writes **nothing** and returns a non-zero exit code
when the generated output differs from the committed Markdown.

## B.7 R5-06 — the protected test bootstrap

`tests/run_g4_protected_pytest.py` imports only the standard library and
the protection bootstrap, installs the boundary, **verifies** that it is
active, and only then imports pytest.  Third-party plugin autoload is
disabled before pytest is imported; the plugin the suite genuinely needs
(`asyncio` = `pytest-asyncio`) is loaded **explicitly**, after the guard.

`tests/_g4_bootstrap.py` is shared by the launcher and `conftest.py`, so
the two entry points cannot drift.  Child interpreters inherit the
boundary through a generated `sitecustomize.py`; a child whose bootstrap
fails **fails closed** (`os._exit(70)`).

## B.8 The Round-5 production-data boundary change

The Round-4 detection harness **stat-ed** the production memory directory
before and after every test.  Under the Round-5 rule ("do not open, read,
hash, **stat**, timestamp, copy, checkpoint, migrate, verify, repair or
back up production database files or sidecars") that inspection is
itself forbidden, so it was **replaced** by an equivalent harness over a
**synthetic** protected root with the production layout.

The protection boundary itself decides **by path** and never opens,
reads, hashes, stats or timestamps a protected path.  It resolves
symlink aliases through the **link** (`os.readlink`), never through the
target, and it does not use `os.path.realpath` (which on Windows resolves
the final component through `GetFinalPathNameByHandle`, i.e. it **opens**
the file).

The Round-4 evidence (which did take production fingerprints) remains the
historical record; it is **not** presented as a Round-5 verification.

## B.10 The Round-3 / Round-4 contracts are preserved

The Round-5 campaign's **node-level** comparison found four genuine
regressions against the Round-3 G4 suite — the Round-5 changes had
broken two contracts that the earlier rounds had established.  Both were
fixed by making the Round-5 implementation **additive** rather than
replacing:

1. **The preservation manifest record shape.**  The Round-3 contract is
   `{source, destination, bytes, sha256, verified, status}`.  The Round-5
   record adds `name`, `source_size`, `destination_size`,
   `source_sha256`, `destination_sha256`, `copy_status`,
   `verification_status`, `failure_stage` and `last_update_sequence` — but
   it **keeps** `bytes` and `sha256` (the destination size and hash).
   The Round-5 fields never replace the earlier ones.
2. **The text-mode rendering must tolerate an aborted flow.**  The Round-4
   command exited at the failure point, so the summary block never ran with
   an incomplete result.  The Round-5 command always reaches the summary,
   so `total_cost_s` and `wall_cost_s` may be `None`; the rendering now
   formats them safely instead of raising `TypeError` — which had also
   suppressed the error message the Round-3 suite asserts on.

Both regressions were found by the **node-level** comparison, not by the
aggregate counts — which is exactly the reason the specification requires
that comparison.

## B.9 The line-ending alignment


The repository's working tree uses CRLF (git's `core.autocrlf`).  A patch
that reads a file with universal newlines and writes it back with
``newline=""`` silently converts it to LF, which turns a two-line change
into a **whole-file diff** and destroys the reviewability of the change
set.

Every Round-5-modified file was therefore **compared with its Round-4
(B4) version** and its original line ending restored; the new files were
aligned with the repository convention.  The result is a reviewable diff:
the Round-5 delta in the application code is a handful of lines per file,
not a whole-file rewrite.
