# E — Documentation Reconciliation (Round 5)

**Date:** 2026-11-12

This document records every place where the Round-4 documentation and the
Round-5 **measured** evidence disagree, and states which one is correct.
The Round-4 documents are **preserved unchanged** as historical evidence;
the corrections live in the Round-5 derived register
(`A_FINDINGS_REGISTER.md`, generated) and here.

---

## E.1 The Round-4 identifier counts were wrong

The Round-4 Markdown register reported incorrect identifier counts for the
first two sets.  The **machine-readable** `remediation4/crosswalk.json`
contains 98 unique identifiers and the correct category totals are:

| Set | Identifiers | FIXED | PARTIAL | NOT FIXED |
|---|---:|---:|---:|---:|
| F01–F38 | 38 | 34 | 3 | 1 |
| F39–F56 | 18 | 14 | 4 | 0 |
| R39–R56 | 18 | 15 | 3 | 0 |
| W01–W24 | 24 | 20 | 4 | 0 |
| **ALL** | **98** | **83** | **14** | **1** |

These totals are **recomputed** from the records by
`build_crosswalk.py`; they are not hardcoded into the generator.  The
`--check` mode fails when the generated register differs from the
committed Markdown.

**Correction applied:** the Round-5 register reports the computed totals.
**Round-4 documents preserved unchanged.**

## E.2 The Round-4 test inventory was wrong

The Round-4 prose claimed **six** test classes, **24** test functions and
**25** collected cases.  The measured collection under the protected
launcher is:

| Measurement | Round-4 prose | Measured (Round 5) |
|---|---:|---:|
| test classes | 6 | **5** |
| test functions | 24 | **22** |
| collected cases | 25 | **24** |

The measured values are produced by:

```
python tests/run_g4_protected_pytest.py tests/test_g4_r4_corrections.py \
    --collect-only -q -p no:cacheprovider
```

and are asserted by
`TestR509CrosswalkReconciliation::test_the_round4_collection_counts_are_the_measured_ones`.

The five classes are `TestR401UriProtection`, `TestR402JournalModeRepairPreservation`,
`TestR403IncompletePreservation`, `TestR404JsonContract` and
`TestR405DisposableCopy`.

The same measurement was taken for the other G4 suites (see
`C_REGRESSION_EVIDENCE.md`).

## E.3 The Round-4 archive did not contain the generator it claimed

Round 4 claimed a `build_crosswalk.py` generator, but the actual generator
was **not** in the 76-entry Round-4 archive.  Round 5 **includes** the
generator source
(`docs/reports/independent-g4-fts/remediation5/build_crosswalk.py`) and
**proves that it works**: the `--check` mode is executed by the Round-5
suite and by the reproduction script, and it returns a non-zero exit code
when the generated output differs from the committed Markdown.

## E.4 The Round-4 Scenario H invariant was imprecise

The Round-4 Scenario H asserted that the `-shm` still **existed** after a
no-op migration.  That is an **existence** assertion: a different file at
the same pathname would have satisfied it.  The corrected invariant
distinguishes the **persistent** WAL state from the **transient** SHM
coordination structure and compares the **filesystem identity** of every
artifact.  See `B_IMPLEMENTATION_REPORT.md` §B.5.

## E.5 The Round-4 verification reporting was stale

The Round-4 `memory_verify` emitted its JSON **before** the cleanup had
run, so the payload could report a stale `verification_target_removed`
value, and a cleanup failure could be swallowed while the command still
exited 0.  The Round-5 lifecycle has **one** finalisation point and the
exit status always agrees with the payload.  See `B_IMPLEMENTATION_REPORT.md`
§B.3.

## E.6 The Round-4 detection harness inspected production data

The Round-4 harness stat-ed the production memory directory before and
after every test.  Under the Round-5 rule that is itself a forbidden
inspection, so the harness now runs against a **synthetic** protected root
and the production directory is not scanned at all.  The Round-4 evidence
remains the historical record.

## E.7 The historical path-inventory discrepancy is resolved

The Round-4 evidence described **28** pre-edit paths in one place and
**18 modified + 12 untracked = 30** in another.  Both numbers are
correct — they describe **two different moments**:

* **28** = the state **before** Round 4 (18 modified + 10 untracked);
* **30** = the state **after** Round 4, because Round 4 itself added two
  paths: `tests/test_g4_r4_corrections.py` and
  `docs/reports/independent-g4-fts/remediation4/`.

There is no contradiction and no missing file.

## E.8 The Round-5 documentation set

| File | Content |
|---|---|
| `README.md` | the package overview and the reproduction commands |
| `A_FINDINGS_REGISTER.md` | **generated** from `crosswalk.json` by `build_crosswalk.py` |
| `B_IMPLEMENTATION_REPORT.md` | what changed in each work package and why |
| `B_DATABASE_ACCESS_ROUTE_INVENTORY.md` | the repository-wide database-access route audit |
| `C_REGRESSION_EVIDENCE.md` | the B0 / B4 / B5 campaign and the per-node comparison |
| `D_DATABASE_SAFETY_EVIDENCE.md` | the production-safety proof without touching production |
| `E_DOCUMENTATION_RECONCILIATION.md` | this document |
| `F_RESIDUAL_RISK_REGISTER.md` | every open risk, individually |
| `G_SOURCE_MANIFEST.md` | the changed-file manifest with hashes |
| `H_FRESH_REVIEW_HANDOFF.md` | the review order, the commands and the claims to challenge |
| `crosswalk.json` | the machine-readable source of truth |
| `build_crosswalk.py` | the generator (`--check` proves it) |
| `test_execution_manifest.json` | every test invocation with its environment and logs |
| `tools/` | the baseline reconstruction and the runtime probes |
| `logs/` | the probe outputs and the test logs |

## E.9 The main report

The main G4 remediation report gains a **dated superseding section §20**.
The historical sections §1–§18 are **not** rewritten in place.
`HANDOFF.md` gains a dated §11 and `KNOWN_ISSUES.md` gains the dated
Round-5 entries; the historical entries are preserved.
