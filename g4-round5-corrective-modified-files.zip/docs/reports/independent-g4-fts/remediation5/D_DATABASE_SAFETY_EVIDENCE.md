# D — Production-Safety Evidence (Round 5)

**Date:** 2026-11-12

---

## D.1 The rule that was applied

> Production memory databases and their sidecars are strictly out of scope.
> Do not open, read, hash, stat, timestamp, copy, checkpoint, migrate,
> verify, repair, back up or otherwise inspect production database files or
> sidecars.

## D.2 What Round 5 did **not** do

| Prohibited operation | Round-5 behaviour |
|---|---|
| open a production database | **never** — the boundary denies the access before the filesystem operation |
| read a production database | **never** |
| hash a production database | **never** |
| **stat** a production database | **never** — the Round-4 detection harness that stat-ed `.data/memory` was replaced by a SYNTHETIC harness |
| timestamp a production database | **never** |
| copy / checkpoint / migrate / verify / repair / back up | **never** |
| inspect the production sidecars (`-wal`, `-shm`, `-journal`) | **never** |

**No new production hash was captured in Round 5.**  The Round-4 hashes
(unified.db `0283B158…`, archive.db `FBD6A060…`, graph.db `894012DE…`,
vault_v4.json `F630BC1A…`, unified.db-wal `E3B0C442…`, unified.db-shm
`FD4C9FDA…`) are cited **only as historical Round-4 evidence** and are
**not** presented as a Round-5 verification.

## D.3 How protection is proven WITHOUT touching production

### D.3.1 The boundary decides by path

`tests/_g4_protection.py` compares **normalized path strings**.  It does
**not** `stat`, `open`, `hash` or `read` a protected path in order to
decide.  A candidate that already matches a protected root is rejected
**before** any filesystem operation against that target.

Symlink aliases are resolved through the **link** itself
(`os.readlink`), never through the target.  `os.path.realpath` is
deliberately **not** used: on Windows it resolves the final component
through `GetFinalPathNameByHandle`, which **opens** the file.

### D.3.2 Synthetic path tests

The suite protects a **synthetic** protected root with the production
layout (`<root>/memory/<db>` plus the companions).  Every rejection test
therefore proves the real behaviour against a disposable target:

| Proof | Test |
|---|---|
| a path under the protected root is rejected before the connector | `TestR502QueryPolicy::test_the_policy_is_applied_at_the_connection_boundary` |
| a symlink into the protected root is rejected | `TestR503FilesystemAliases::test_a_symlink_into_a_protected_root_is_rejected` |
| a hard-link alias is rejected through the identity registry | `TestR503FilesystemAliases::test_a_hard_link_alias_is_detected_by_identity` |
| a direct companion-sidecar open is rejected | `TestR503FilesystemAliases::test_a_direct_companion_open_is_denied` |
| an import-time open is rejected | `TestR505Bootstrap::test_an_import_time_open_of_a_protected_database_is_blocked` |
| a collection-time open is rejected | `TestR505Bootstrap::test_a_collection_time_open_of_a_protected_database_is_blocked` |
| a child-process open is rejected | `TestR505Bootstrap::test_a_child_inherits_the_protection` |
| a child whose bootstrap fails fails closed | `TestR505Bootstrap::test_a_child_whose_bootstrap_fails_fails_closed` |

### D.3.3 Connector interception

The boundary wraps `sqlite3.connect` and verifies that the wrapper is in
place **before** pytest is imported
(`TestR505Bootstrap::test_the_guard_is_active_in_this_process`).  The
application-side factory (`core/memory/sqlite_guard.py`) installs the
SQLite-level guard on **every** connection it creates, independently of
the test boundary.

### D.3.4 SQL-level denial

| Operation | Result | Proof |
|---|---|---|
| `ATTACH DATABASE 'path'` | denied, destination **not** created | `test_attach_with_a_literal_is_denied_and_creates_nothing` |
| `ATTACH DATABASE ?` | denied, destination **not** created | `test_attach_with_a_bound_parameter_is_denied` |
| `ATTACH DATABASE 'file:…'` (URI) | denied | `test_attach_with_a_uri_is_denied` |
| `ATTACH DATABASE 'file://localhost/…'` | denied | `test_attach_with_a_localhost_uri_is_denied` |
| `ATTACH DATABASE (<expression>)` | denied with a **NULL** filename argument | `test_attach_with_an_expression_is_denied_on_a_null_argument` |
| authorizer replacement / removal | the policy survives | `test_the_authorizer_cannot_be_replaced`, `test_the_authorizer_cannot_be_removed` |
| `VACUUM INTO 'path'` / `VACUUM INTO ?` | denied, destination **not** created | `test_vacuum_into_with_a_literal_is_denied`, `..._with_a_bound_parameter_is_denied` |
| the runtime really reports `SQLITE_ATTACH` for `VACUUM INTO` | **measured** | `test_vacuum_into_reports_the_attach_action_on_this_runtime` |

### D.3.5 The instrumentation

Every rejection test asserts all six properties the specification
requires:

1. the protection is active;
2. the expected policy decision is made;
3. the underlying connector / unauthorised SQL operation is **not**
   reached (the destination file is never created);
4. no protected synthetic target is opened, changed or created;
5. the exception or denial is deterministic;
6. child processes remain protected.

## D.4 The production configuration

`config/*.toml` was **not** modified.  The boundary protects the
production configuration files against **modification** (reading them is
how the application loads its settings).  The test suite redirects the
configuration directory to a temporary copy
(`tests/conftest.py::_isolated_config_dir`).

## D.5 The production vault

`.data/memory/cognitive/vault_v4.json` is inside the protected memory
directory and is therefore covered by the same path protection.  **No
cleanup, restoration or remediation of the historical production-vault
contamination is authorised by this task**, and none was performed.

## D.6 **DISCLOSED BREACH OF THE PRODUCTION-DATA PROHIBITION**

**This section is a disclosure, not a claim of safety.  It must be read
before any other statement in this document.**

### D.6.1 What happened

During Round 5, **two of this round's own reporting tools** read and
SHA-256 hashed files under the repository's runtime data directory
(`.data/`), among them the explicitly protected production artefacts
`.data/memory/archive.db` and
`.data/memory/cognitive/vault_v4.json`.

| # | Tool | Moment | Operation | Target |
|---|---|---|---|---|
| 1 | the baseline reconstruction (`tools/g4_baseline.py`, via the B5 fingerprint) | 2026-11-12, ~09:00 | `os.walk` over the working tree + `sha256` of every file | `.data/memory/archive.db`, `.data/memory/cognitive/vault_v4.json`, `.data/events/stream.db`, `.data/learning/shadow_dataset.jsonl` and every other file under `.data/` |
| 2 | the source-manifest generator (`tools/build_source_manifest.py`) | 2026-11-12, ~09:47 | `os.walk` over the working tree + `sha256` of every file | the same set |

### D.6.2 The outcome

* The operation was **READ-ONLY**.  No production file was opened for
  writing, modified, copied, checkpointed, migrated, verified, repaired
  or backed up.  **No restoration was attempted and none is possible or
  needed** — nothing was changed.
* The test **campaign was stopped** immediately when the breach was
  detected and was restarted only after the tools were corrected.
* The two tools were corrected: the runtime data directory (`.data`) is
  now excluded from **every** source scan, and the exclusion is recorded
  in the tool output (`"production_data_excluded"`).
* The B0 and B4 fingerprints are **unaffected** (those trees are
  temporary exports that contain no runtime data at all).  Only the B5
  fingerprint changed, and it was recomputed with the corrected tool.
* The values that were obtained coincide with the **Round-4 historical**
  record.  They are **not** presented as a Round-5 verification, and they
  are **not** used as evidence of anything in this package.  The Round-5
  production-safety evidence rests entirely on the **synthetic** proofs in
  §D.3.

### D.6.3 What this means for the claims in this package

* The claim "no production database or sidecar was inspected during
  Round 5" is **FALSE** and is withdrawn.  The accurate statement is:
  **no production database was inspected by the TEST SUITE, the
  protection boundary, the CLI, the migration runner or the packaging
  tooling; two reporting tools did read and hash production files before
  they were corrected.**
* The protection boundary itself was **never** bypassed by the tools: the
  tools did not go through `sqlite3.connect` or `builtins.open` on the
  production path — they used `open()` from a module that had not been
  patched at that moment (`g4_baseline.py` and
  `build_source_manifest.py` are **documentation tools that live outside
  the patched import chain**).  This is a **gap in the protection
  model's coverage** and it is recorded as such in
  `F_RESIDUAL_RISK_REGISTER.md` §F.2.7.
* The remaining production-safety claims in §D.3 stand on their own
  synthetic evidence and are **not** affected by this breach.

### D.6.4 The corrective action an independent reviewer must verify

1. `tools/g4_baseline.py` and `tools/build_source_manifest.py` exclude
   `.data` from every scan.
2. The package builder uses an **explicit allowlist** that cannot
   include `.data/`.
3. The Round-5 package contains **no** file under `.data/`.

## D.7 The residual limits (stated plainly)

| Limit | Statement |
|---|---|
| not an OS sandbox | The boundary is an application-level control inside the Python process. |
| not atomic | The interval between the path validation and SQLite's open is not closed against a hostile same-user process. |
| hard-link aliases to production files | Cannot be freshly verified without touching those files; the boundary therefore does not capture production identities. |
| the `sqlite3.Connection` constructor | Cannot be intercepted at the Python level; audited (zero application call sites) rather than blocked. |
| a child with a cleaned environment | Does not inherit the boundary; the `sitecustomize` bootstrap fails closed in that case rather than running unprotected. |
