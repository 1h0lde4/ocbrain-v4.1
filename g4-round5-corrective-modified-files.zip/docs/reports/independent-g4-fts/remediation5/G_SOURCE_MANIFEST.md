# G — Source Manifest (Round 5)

<!-- GENERATED FILE — DO NOT EDIT BY HAND. -->

The manifest describes the **Round-5 delta**: the
difference between the reconstructed Round-4 baseline
(`B4`) and the Round-5 working tree (`B5`).  The
comparison is a CONTENT comparison, so a file that only
changed its mode is reported as modified.

- Baseline: `C:\Users\Produ\AppData\Local\Temp\g4_bases\B4`
- Tree: `C:\Users\Produ\Downloads\ocbrain-g4-indep\wt`
- Changed paths: **81** (54 added, 27 modified, 0 deleted)

| Path | Status | Type | Mode | Size | SHA-256 | Finding | Test |
|---|---|---|---|---:|---|---|---|
| `.gitignore` | modified | file | 0666 | 3007 | `f743674c9cda4b881a13a850b7b3e411bba0411cc996acd33cea0375566c9447` | — | — |
| `KNOWN_ISSUES.md` | modified | file | 0666 | 255312 | `32f8a8fba97d2955a7ca45601516a8f29d995b5c854c8e38d49218d0de1b111c` | R5-05 | the dated Round-5 entries |
| `core/context.py` | modified | file | 0666 | 15592 | `20eaa878ce23181a14d6acd4dbff9b4912f3c8eaac12a4cc008d349fa5920a58` | R5-01 | TestR504SqlAccessRoutes |
| `core/events/event_stream.py` | modified | file | 0666 | 20893 | `5358ed885dd74c76fb52c6b1a755b21d2c5da02a2e1415a032adf1e19e22f91b` | R5-01 | TestR504SqlAccessRoutes |
| `core/memory/backends/sqlite_archive.py` | modified | file | 0666 | 11578 | `9d20c9892fb2963bae236fe7b537ae08782c0fe3c88096f4f55940cb8fa6765f` | R5-01 | TestR504SqlAccessRoutes |
| `core/memory/backends/sqlite_storage.py` | modified | file | 0666 | 30450 | `86174f2efd05265941a942431eb2bbe0d6d89778837341729253c8b414b03e63` | R5-01 | TestR504SqlAccessRoutes |
| `core/memory/graph/graph_engine.py` | modified | file | 0666 | 15835 | `cccf04471006ed26bcc31854f982c9fd5efcdc901ae93adabc6044547cb1c7c2` | R5-01 | TestR504SqlAccessRoutes |
| `core/memory/sqlite_guard.py` | added | file | 0666 | 11283 | `edd2bf0f787356c54d683a1e2125bf1ba71c87bb7d6b73fef7dd5783761e8ed4` | R5-01 | TestR504SqlAccessRoutes |
| `core/memory/sqlite_migration.py` | modified | file | 0666 | 126679 | `8d420878b5c93add40a34e3b7e6bb7a191fef1cb7c8544a22219c8dd2ee0258b` | R5-03 | TestR507ManifestDurability |
| `core/memory/sqlite_runtime.py` | modified | file | 0666 | 22745 | `b3bc5d45313d3a1d58e23aa22b1086619dcd6ee22f24db7f7489192fa09de12c` | R5-01 | TestR504SqlAccessRoutes |
| `core/migrator.py` | modified | file | 0666 | 3436 | `3cd5337fccca094268b680aece56d50db0ec61881abe66c6bb4bfb31323a28c2` | R5-01 | TestR504SqlAccessRoutes |
| `core/runtime/state.py` | modified | file | 0666 | 9788 | `a86e2618b12a322ebd8df6c559a5b58d11d61c787f8aa759ed99df8edac23a67` | R5-01 | TestR504SqlAccessRoutes |
| `data/context.sqlite` | modified | file | 0666 | 32768 | `474c0caee27989fd44df27c635cba232fa4c74d6d8b1fe2aa8a222dc29cb68b6` | — | — |
| `data/context.sqlite-shm` | added | file | 0666 | 32768 | `fd4c9fda9cd3f9ae7c962b0ddf37232294d55580e1aa165aa06129b8549389eb` | — | — |
| `data/context.sqlite-wal` | added | file | 0666 | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` | — | — |
| `docs/reports/G4_FTS_REV3_REMEDIATION_REPORT.md` | modified | file | 0666 | 95899 | `a2ff1def5c1414122c719f6f259d8f2832cdb5af89825b5f528d0ef61bd6f1ae` | R5-05 | §20 |
| `docs/reports/independent-g4-fts/HANDOFF.md` | modified | file | 0666 | 31691 | `8a8d77aa57509eac3ed2415d765e59087bfb3ec3ad89f8a4fba4e56c2e0fc430` | R5-05 | §11 |
| `docs/reports/independent-g4-fts/remediation5/A_FINDINGS_REGISTER.md` | added | file | 0666 | 43628 | `c9ed6731bf0fb695319cd4472fe1c56a008fa51c0287c3f3d345718d8ab6e0c3` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/B_DATABASE_ACCESS_ROUTE_INVENTORY.md` | added | file | 0666 | 9115 | `50066cd26f3e85d4aaca3c7e717438ffd7ce32cd8be035e31f12d71c07898cf3` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/B_IMPLEMENTATION_REPORT.md` | added | file | 0666 | 13101 | `46ffbf94782e438cc07221d1c5f3953495ff75e6eb35c7aff74b2e9aac2ecc5c` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/C_REGRESSION_EVIDENCE.md` | added | file | 0666 | 6129 | `df7d1bc82911c67da5bdbb0d6fe61cce76e0727a233deb798804ada42adc513f` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/D_DATABASE_SAFETY_EVIDENCE.md` | added | file | 0666 | 10082 | `65112c15d607344cfd56845cc26bcff02d70110f17e9532b36511878c1bc266e` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/E_DOCUMENTATION_RECONCILIATION.md` | added | file | 0666 | 5966 | `536c4a1c2bf5bcbe28dfc59f3e9de1d06f5e5fe422ad51da76ea088c79b364dc` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/F_RESIDUAL_RISK_REGISTER.md` | added | file | 0666 | 8412 | `20a00663efa940b856032a5b005058ae6378a8f5d727637c4eae7e49da73399b` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/G_SOURCE_MANIFEST.md` | added | file | 0666 | 16583 | `a69e06f22fd36448a7399f6cb78fdad80caba27552e7807f985d793a48210769` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/H_FRESH_REVIEW_HANDOFF.md` | added | file | 0666 | 9567 | `1ccac1b1858dae654c4cffff497887b5176530daad1179522f227f97318714ec` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/README.md` | added | file | 0666 | 6247 | `f4a4a55f15a365c53882704fd4260624493de5d174934b71e57a3b820a5fe17a` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/ROUND5_FINAL_REPORT.md` | added | file | 0666 | 20513 | `cfc909ef04fa8e6f3c30d27bd7f2a483c2ba77ab849fd1978bad7cffdc8640cd` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/build_crosswalk.py` | added | file | 0666 | 14421 | `fcd18e9be02ff208aad712661ebd82949d77261d25be00bf573ef71fa6c44f60` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/crosswalk.json` | added | file | 0666 | 105207 | `2bfc88619fe3453e5dcdcadf97ad8c04d4204a27b39ec308d553c06f1e67968b` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/logs/B0_full.jsonl` | added | file | 0666 | 1502608 | `eee7ccdb04a5e3563b31435d0567e7d87ab994d6f2259cf85c85d6118f0ae90a` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/logs/B0_full.jsonl.summary` | added | file | 0666 | 36 | `7eacf7894d634ec815e1cfe350e93dc0e0e6ecca67572192a8f39908be93fe75` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/logs/B0_full.record.json` | added | file | 0666 | 540509 | `1a1b15745b006f8a024304c1a7585e9cdad4b9cd45d80f81b82ddfd27ceaf99c` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/logs/B0_full.stderr.log` | added | file | 0666 | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/logs/B0_full.stdout.log` | added | file | 0666 | 509566 | `4f60bbe1afb083d74161e84fe0109ef5582404e55d1bc496915e30f4e14220ea` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/logs/B4_full.jsonl` | added | file | 0666 | 1497120 | `4372a7e1096d89827f146e4e1068a4d96a5aebd3b6e2d9e437d54b3b3dccd678` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/logs/B4_full.jsonl.summary` | added | file | 0666 | 36 | `f942dd507f8e27dfd5bdb827bdab4ad91cea9d7a817de498ca1874703b33d18d` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/logs/B4_full.record.json` | added | file | 0666 | 581523 | `ec5f70ec49af8ce53335e3b3e1c14bf4988182321b4757404744080f22b57da8` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/logs/B4_full.stderr.log` | added | file | 0666 | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/logs/B4_full.stdout.log` | added | file | 0666 | 113405 | `1ac687e15e338ea1c1cd6d2eb458aac202fa5d733b6bb23685845877553dc936` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/logs/B5_full.jsonl` | added | file | 0666 | 1575448 | `662b1f0ecc5bbb0f05fa2c20ee5b0f3d53fea3dbfae1172f23bd09f1f24a0731` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/logs/B5_full.jsonl.summary` | added | file | 0666 | 36 | `260de85fa7a622922522c9c8bd06233e731e1175c1e1088424387396b177f000` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/logs/B5_full.record.json` | added | file | 0666 | 612828 | `6bc28d2f9a67601c16cae2f1bd18af9dbc007c63ed2fcf181a3d774d17b0baff` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/logs/B5_full.stderr.log` | added | file | 0666 | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/logs/B5_full.stdout.log` | added | file | 0666 | 115819 | `3c3b57e82745ef3fc1d011ad900170052b44c678e6495e287cf34efc7fa937a9` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/logs/baseline_reconstruction.json` | added | file | 0666 | 1202 | `b69ca62807534509b2b8ffc12bb3c6ba82c7749e4c9a829c110594ab82cc41d0` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/logs/crash_injection_evidence.json` | added | file | 0666 | 3800 | `e1e3712fc290509bfc46baec0c60ad8010ce26fa2c608bf065370081f12e26c4` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/logs/fail_closed_verification.json` | added | file | 0666 | 2090 | `bef986c0be0e94b417b82ebff07a50252c9ca04129eb299db7ffa3fdda7c1281` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/logs/sqlite_runtime_probe.json` | added | file | 0666 | 5831 | `29956b0ec987eec1e1d352fdb136694a1fa209651970f95aaa5afbeaf5218e65` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/logs/sqlite_uri_semantics.json` | added | file | 0666 | 11986 | `0c1a75995959de6d6f33638abeefc8d680ae0737965a8c189551c5d801aaf043` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/package_manifest.json` | added | file | 0666 | 14871 | `a58cea997b6be7cb02c30e376d444a22c7c4c2b9f4cb152b925db1d0b7b44cf7` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/round5_overlay.patch` | added | file | 0666 | 18793560 | `c95dbd842d9e9d9507eb0e2c24881e26b824239c930e2808b79c6ca16f422a52` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/source_manifest.json` | added | file | 0666 | 29498 | `1c21f6ee8201bdf8b1fcc266c59ff1d347c2e143d43061e652583b4e5c01f1af` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/test_execution_manifest.json` | added | file | 0666 | 2404581 | `baf02105838610e0ee54aa9dff227d49a95ac52051d8bec66f1bd6c52168d9b4` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/tools/build_regression_evidence.py` | added | file | 0666 | 14381 | `fe94586228e54c5bda6c8a4278596edce139a1353463564b24a9146b61b484e9` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/tools/build_round5_crosswalk.py` | added | file | 0666 | 20732 | `b836831d05b0bd98841ed00f807a9886c28f40271b7dacd45ca0ed1131f147b4` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/tools/build_round5_package.py` | added | file | 0666 | 8922 | `93e4da79710c474fc3786609563537ee44a4bacacba0df9b9d1f4985d676d901` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/tools/build_source_manifest.py` | added | file | 0666 | 11780 | `3646dc29330e031c66c83eee3694c16a87f34e0cddad26038f59d4fcc66d6b5b` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/tools/capture_crash_evidence.py` | added | file | 0666 | 3996 | `19e87e42e709785356bbf6a809d6340cebd943775c1fb609fd063b91fbb6a358` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/tools/g4_baseline.py` | added | file | 0666 | 10179 | `586c893b136dc46eed83e85d789c00f46c9cf27f8a5c3eb7830805bd9e6b4890` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/tools/g4_report_plugin.py` | added | file | 0666 | 1725 | `773c93b5ffbcb1a2ba39685c724ddf767fb23c52c92935dbdaf6e0b2703f0a6a` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/tools/reconstruct_baselines.py` | added | file | 0666 | 7112 | `42f73cd89cbab1cd22778446fbe366b4378f79eb3e3147af79e53ccecb3c6576` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/tools/reproduce.py` | added | file | 0666 | 5589 | `5bb7504b1d1547e6b870f0de090d990eb91dfaf8aac4cfb3b4fff4cfea52e6d6` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/tools/run_campaign.py` | added | file | 0666 | 13987 | `a61379fb8591cec5552aae266c5318d815fd84a820cf93bd71fda6a5fecc0f68` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/tools/sqlite_runtime_probe.py` | added | file | 0666 | 8398 | `17b3a36de6545e7e97e19cac8e2f44e8b6ea819f383c32dc6fff04873eae720f` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/tools/sqlite_uri_semantics_probe.py` | added | file | 0666 | 4697 | `28ebd07534acff480fabdeaca7e1875ece289408956a64df4e4b0195d4a30296` | R5-05 | TestR509CrosswalkReconciliation |
| `docs/reports/independent-g4-fts/remediation5/tools/verify_fail_closed.py` | added | file | 0666 | 3405 | `a810afafb94466d1f509c17af7044d9847ed4fefdd015a8eb55019e39ff5c6e9` | R5-05 | TestR509CrosswalkReconciliation |
| `interface/cli.py` | modified | file | 0666 | 58113 | `fa5d10bd77bad5027080b68569b6dcd5eef2ceb2bf38378d6f3d1f65c96cf98a` | R5-02 | TestR506VerificationLifecycle |
| `modules/empty_test/knowledge.db/chroma.sqlite3` | modified | file | 0666 | 188416 | `c5e36d61b784c054854b31b5ed9d880cf70475ff84e94f846856a38be667d0e0` | — | — |
| `modules/mock/knowledge.db/cc9bd3b2-1aac-4807-9d2f-98423290d69e/data_level0.bin` | modified | file | 0666 | 854760 | `ab0430be2dd7152db2b806df1fcaf4155eb42118a277eb2cce0e9965ae073983` | — | — |
| `modules/mock/knowledge.db/cc9bd3b2-1aac-4807-9d2f-98423290d69e/header.bin` | modified | file | 0666 | 100 | `0e2d9dd6fd349efec22ed02048d350385a56ea7be69205d04f190f7cbd444733` | — | — |
| `modules/mock/knowledge.db/cc9bd3b2-1aac-4807-9d2f-98423290d69e/index_metadata.pickle` | modified | file | 0666 | 45934 | `ef39fb37e3c58b39fff4d3b9318cb42c7c4fd16fdb75f5c7396cc088489ae5d3` | — | — |
| `modules/mock/knowledge.db/cc9bd3b2-1aac-4807-9d2f-98423290d69e/length.bin` | modified | file | 0666 | 2040 | `45b204cd6fb48d14769fd79f17d9b78af22f47f3b832ee435640483c54f92531` | — | — |
| `modules/mock/knowledge.db/cc9bd3b2-1aac-4807-9d2f-98423290d69e/link_lists.bin` | modified | file | 0666 | 4488 | `2675b448d1074f3930bae0ff1ed486fa2ec863e9b99101e82e04742b323b997f` | — | — |
| `modules/mock/knowledge.db/chroma.sqlite3` | modified | file | 0666 | 2539520 | `0881706ece10a0d44e64c1e0b7b1353edf0960230d99aa8dfa8be7ab5a1ddcb8` | — | — |
| `modules/system_ctrl/knowledge.db/chroma.sqlite3` | modified | file | 0666 | 188416 | `68006aa592a5cab73f134810e360d05cfb6e1b5a6f4793dafb0ba9da04f0fb22` | — | — |
| `modules/test_rce001_name_tmp/knowledge.db/chroma.sqlite3` | modified | file | 0666 | 188416 | `05c8d4cc3e23ce695c6dee4dbb60cd1597256911ca31739a59761d73af32bd80` | — | — |
| `modules/test_rce001_tmp/knowledge.db/chroma.sqlite3` | modified | file | 0666 | 188416 | `2849c2384b519f94c83ec1188effba5d471eb31ea18fce14331a4972062201e0` | — | — |
| `tests/conftest.py` | modified | file | 0666 | 9432 | `ab9c8224a52659e6b4b1bdc6939e949dbe458331b445e33a845fc0d245067181` | R5-06 | TestR505Bootstrap |
| `tests/test_g4_interaction_scenarios.py` | modified | file | 0666 | 24297 | `d3214b068563798e59af08e6c15142495d483c2e2b7af27066c9c457541e6311` | R5-04 | test_h_noop_migration_does_not_copy_the_whole_database |
| `tests/test_g4_r5_corrections.py` | added | file | 0666 | 87331 | `6c00f6c3e1553353bd8aab3f28d8c9dd84f22ef3fbfffbf33c9ce1e6e4938dd3` | R5-01..R5-05 | the complete Round-5 suite |

