# G4 FTS Rev 3 — Round 5 Corrective Package

**Date:** 2026-11-12
**Branch:** `independent/g4-fts-rev3-20261105` (unchanged)
**HEAD:** `739e58ce185a527d2d2f58c7622c5108f5b0e0db` (unchanged)
**Governance disposition:** **G4 OPEN / NOT ACCEPTED / NO PASS**

This package contains the Round-5 corrective implementation, its
regression evidence, its production-safety evidence and the tooling an
independent reviewer needs to reproduce every claim.

---

## 1. What Round 5 did

| ID | Work package | Disposition |
|---|---|---|
| R5-01 | SQLite URI semantics and complete database-access protection | FIXED |
| R5-02 | Disposable verification-copy lifecycle and truthful JSON | FIXED |
| R5-03 | Crash-surviving per-artifact preservation manifests | FIXED |
| R5-04 | Correct sidecar lifecycle and file-identity evidence | FIXED |
| R5-05 | Baseline reconstruction, crosswalk reconciliation, evidence reproducibility | FIXED |
| R5-06 | Protected test bootstrap (specification §7) | FIXED |

**Nothing else was touched.**  No architecture was redesigned, no
unrelated debt was closed, SQLite was not upgraded, and no acceptance
decision was made.

## 2. The three source states

| ID | Source state | Purpose |
|---|---|---|
| B0 | the pristine export of the exact Git HEAD | the historical repository baseline |
| B4 | B0 + the verified Round-4 archive overlay | the actual Round-4 implementation baseline |
| B5 | B4 + the Round-5 overlay | the implementation under review |

The three states are constructed in **separate temporary directories**;
the working tree is never used as a baseline.  Each state has a
machine-readable manifest and a deterministic source-tree fingerprint.

The Round-4 archive is the **immutable historical input** and is included
**verbatim** in the Round-5 package:

| Property | Value |
|---|---|
| file | `g4-round4-corrective-modified-files.zip` |
| SHA-256 | `1c75f7fc1033aad2f1b1c57969a05fed68f4a569418c9556f70900db7cf6ee0c` |
| size | 425 105 bytes |
| entries | 76 |

## 3. How to reproduce

### 3.1 The protected test suite

Every test command runs through the **protected launcher**, which installs
the production-access boundary **before** pytest is imported:

```
cd <repository>
python tests/run_g4_protected_pytest.py tests/test_g4_r5_corrections.py \
    -p no:cacheprovider -q
python tests/run_g4_protected_pytest.py tests/test_g4_r4_corrections.py \
    -p no:cacheprovider -q
python tests/run_g4_protected_pytest.py tests/test_g4_interaction_scenarios.py \
    -p no:cacheprovider -q
python tests/run_g4_protected_pytest.py --collect-only -q -p no:cacheprovider
```

### 3.2 The crosswalk

```
cd docs/reports/independent-g4-fts/remediation5
python build_crosswalk.py --check        # writes NOTHING; non-zero on a difference
python build_crosswalk.py                # regenerates A_FINDINGS_REGISTER.md
```

### 3.3 The baselines

```
python docs/reports/independent-g4-fts/remediation5/tools/g4_baseline.py \
    export-b0 --dest <dir> --head 739e58ce185a527d2d2f58c7622c5108f5b0e0db \
    --repo <repository>
python docs/reports/independent-g4-fts/remediation5/tools/g4_baseline.py \
    build-b4 --b0 <dir> --dest <dir> \
    --archive g4-round4-corrective-modified-files.zip
python docs/reports/independent-g4-fts/remediation5/tools/g4_baseline.py \
    fingerprint --tree <dir>
```

### 3.4 The runtime probes

```
python docs/reports/independent-g4-fts/remediation5/tools/sqlite_runtime_probe.py \
    <out.json>
python docs/reports/independent-g4-fts/remediation5/tools/sqlite_uri_semantics_probe.py \
    <out.json>
```

### 3.5 The one-shot reproduction

```
python docs/reports/independent-g4-fts/remediation5/tools/reproduce.py \
    --repo <repository> --out <evidence dir>
```

It runs the probes, the baseline reconstruction, the crosswalk `--check`,
the three protected suites, the changed-file manifest and the overlay
patch, the crash-injection evidence and the package build — and reports
which step failed, if any.

## 4. The contents

| File | Content |
|---|---|
| `A_FINDINGS_REGISTER.md` | the findings register — **generated** from `crosswalk.json` |
| `B_IMPLEMENTATION_REPORT.md` | what changed in each work package and why |
| `B_DATABASE_ACCESS_ROUTE_INVENTORY.md` | the repository-wide database-access route audit |
| `C_REGRESSION_EVIDENCE.md` | the B0 / B4 / B5 campaign and the per-node comparison |
| `D_DATABASE_SAFETY_EVIDENCE.md` | the production-safety proof without touching production |
| `E_DOCUMENTATION_RECONCILIATION.md` | every documentation disagreement and its correction |
| `F_RESIDUAL_RISK_REGISTER.md` | every open risk, individually |
| `G_SOURCE_MANIFEST.md` | the changed-file manifest with hashes |
| `H_FRESH_REVIEW_HANDOFF.md` | the review order, the commands and the claims to challenge |
| `crosswalk.json` | the machine-readable source of truth (98 historical + 6 Round-5) |
| `build_crosswalk.py` | the generator (`--check` proves it) |
| `test_execution_manifest.json` | every test invocation, its environment and its logs |
| `tools/` | the baseline reconstruction, the crosswalk builder, the campaign runner, the runtime probes and the reproduction script |
| `logs/` | the probe outputs, the campaign logs and the crash-injection evidence |

### 4.1 The nested Round-4 archive

The package contains the Round-4 archive **verbatim** as
`g4-round4-corrective-modified-files.zip` (76 entries, 425 105 bytes,
SHA-256 `1c75f7fc1033aad2f1b1c57969a05fed68f4a569418c9556f70900db7cf6ee0c`).

It is the **immutable historical input** and the **immutable Round-4
documentation**: extract it to read the Round-4 deliverables A–H and the
Round-4 `crosswalk.json` exactly as they were delivered.  The Round-5
package does **not** duplicate those files, and it does **not** modify
them.

## 5. The governance boundary

| Area | Status |
|---|---|
| G4 | **OPEN / NOT ACCEPTED** |
| G4 acceptance | **NOT AUTHORIZED** |
| DEBT-045 | **OPEN** |
| F36 | **OPEN / NOT FIXED** |
| SQLite runtime certification | **NOT READY** |
| Deployment certification | **NOT READY** |
| Freeze | **NOT AUTHORIZED** |
| Production deployment | **NOT AUTHORIZED** |

A passing Round-5 suite is **not** a SQLite runtime certification and
**not** a G4 acceptance.
