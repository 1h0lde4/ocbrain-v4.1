# F — Residual Risk Register (Round 5)

**Date:** 2026-11-12

Every risk below is **open**.  None of them is closed by this round.  Each
entry states what the risk is, why it is still open, what evidence exists,
and what would close it.  Distinct risks are listed **individually** — they
are not combined into a single vague statement.

---

## F.1 Risks carried forward (unchanged)

| # | Risk | Status | Evidence / note |
|---|---|---|---|
| 1 | **SQLite WAL-reset runtime incompatibility.** The bundled runtime is SQLite **3.50.4**, which is inside the affected range (3.7.0 – 3.51.2). | **OPEN** | Measured on 2026-11-12: SQLite 3.50.4, source id `2025-07-30 19:33:53 4d8adfb30e03f9cf27f800a2c1ba3c48fb4ca1b08b0f5ed59a4d5ecbf45e20a3`. The runtime gate acknowledges the runtime explicitly; the memory service never reports full readiness. Round 5 did **not** upgrade SQLite. |
| 2 | **F36 — preservation capacity preflight.** The preservation does not check that the destination has enough space before it starts. | **OPEN** | No implementation exists. Asserted open by `TestR507ManifestDurability::test_the_f36_requirements_remain_open`. |
| 3 | **F36 — preservation source-stability detection.** A source file that changes **during** the copy is not detected. | **OPEN** | No implementation exists. The copied set is not proven to be one transactionally consistent point in time. |
| 4 | **Dedicated initialization lock.** Two simultaneous first starts are serialised only by SQLite's own locking; the loser is not told it lost. | **OPEN** | Round 4's `test_l_…` covers the partially-initialised database, not the lock. |
| 5 | **Database-path identity unification across aliases.** Relative and absolute spellings of the same database are not unified into one identity. | **OPEN** | The Round-5 native identity helper (`tests/_g4_fsidentity.py`) provides the mechanism, but the application does not yet use one canonical path identity everywhere. |
| 6 | **The advisory lock is not process fencing.** A lock file is a convention, not a fence: a process that ignores it can still write. | **OPEN** | Unchanged. |
| 7 | **The backup scope excludes application-owned user tables.** The verified digest covers the content table plus the schema/trigger/index identity, not the application-owned user tables. | **OPEN** | Unchanged (`W12` remains PARTIAL). |
| 8 | **Physical erasure semantics with `secure_delete` OFF.** A deleted row's bytes may remain in the free pages. | **OPEN** | Unchanged. |
| 9 | **DEBT-045 — hidden-rowid persistence.** The FTS content-row identity is the `rowid` column; a stable integer identity is an open architectural decision. | **OPEN** | Governance unchanged. |
| 10 | **Configuration flush semantics.** The configuration flush behaviour is not part of this round's scope. | **OPEN** | Unchanged. |
| 11 | **Stale checkpoint-inventory sidecar figures.** The checkpoint inventory still reports the **pre-connection** sidecar sizes for its own figures. | **OPEN** | Unchanged — `F31` therefore remains PARTIAL even though R5-04 corrected the Scenario H evidence. |
| 12 | **The Python protection is not an OS sandbox.** It is an application-level control inside the Python process; native code or a child interpreter that does not inherit the environment can bypass it. | **OPEN** | Stated in the module docstring, in `B_DATABASE_ACCESS_ROUTE_INVENTORY.md` §B.6 and in `D_DATABASE_SAFETY_EVIDENCE.md` §D.6. |
| 13 | **TOCTOU against hostile concurrent same-user filesystem changes.** The boundary performs a path validation followed by a later SQLite open; the interval is not closed. | **OPEN** | Stated explicitly; no atomic claim is made anywhere in the Round-5 documentation. |
| 14 | **Hard-link aliases to production files cannot be freshly verified without touching those files.** | **OPEN** | The boundary therefore does **not** capture production identities automatically; identity tracking is opt-in and is used with synthetic paths only. |
| 15 | **Historical production-vault pollution.** | **OPEN** | No cleanup, restoration or remediation is authorised by this task, and none was performed. |
| 16 | **The pre-existing test failures and errors** (unless the measured baseline proves a change). | **OPEN** | See `C_REGRESSION_EVIDENCE.md`: the B0/B4/B5 node-level comparison. |
| 17 | **Any SQLite API or extension path that cannot be proven to pass through the application protection boundary.** | **OPEN** | The route inventory is exhaustive for this repository, but the `sqlite3.Connection` constructor (F.2.1 below) and any future native extension remain outside the boundary. |

## F.2 New risks introduced or exposed by Round 5

| # | Risk | Status | Evidence / note |
|---|---|---|---|
| F.2.1 | **The `sqlite3.Connection` constructor cannot be intercepted.** `sqlite3.Connection` is an immutable extension type, so its constructor cannot be wrapped at the Python level. A caller that uses it bypasses the guarded `sqlite3.connect` entirely (and therefore also bypasses the authorizer policy). | **OPEN — audited, not blocked** | The application has **zero** call sites (executable audit test). The limitation is demonstrated honestly by `TestR504SqlAccessRoutes::test_the_direct_connection_constructor_is_not_interceptable`, which shows an unguarded connection accepting an `ATTACH`. |
| F.2.2 | **The strict URI policy is stricter than SQLite.** SQLite accepts unknown query parameters (it forwards them to the VFS) and accepts a `LOCALHOST` authority. The boundary rejects both. | **OPEN — accepted trade-off** | The specification explicitly permits rejecting more than SQLite does, as long as a rejected form is never silently mapped to an unintended path. The application only ever needs `mode=ro`/`rw`/`rwc`. |
| F.2.3 | **The preservation durability on Windows is process-crash only.** Windows has no directory-`fsync` equivalent, so the atomic manifest replacement is complete and atomic, but a **power loss** can lose the rename. | **OPEN** | Stated in the manifest's own `durability` block and in `B_IMPLEMENTATION_REPORT.md` §B.4. No power-loss claim is made anywhere. |
| F.2.4 | **The SHM byte content is deliberately not asserted.** The `-shm` is a coordination structure; a byte-level invariant for it would be wrong. | **OPEN — by design** | The identity of the SHM **is** asserted while the anchor connection requires it to persist. The legitimate last-connection cleanup is covered by a separate test. |
| F.2.5 | **The production detection harness no longer covers the production directory.** It was replaced by a synthetic harness because stat-ing production files is itself a forbidden inspection. | **OPEN — accepted trade-off** | The **prevention** boundary covers the production directory by path, and it never touches the file. The Round-4 evidence remains the historical record. |
| F.2.6 | **A child interpreter with a cleaned environment does not inherit the boundary.** The generated `sitecustomize.py` fails closed (exit 70) in that case, so the child does not run unprotected — but it also does not run. | **OPEN** | `TestR505Bootstrap::test_a_child_whose_bootstrap_fails_fails_closed`. |
| F.2.7 | **The protection boundary does not cover the round's own documentation tooling.** Two Round-5 reporting tools read and hashed production files under `.data/` before they were corrected (the full disclosure is in `D_DATABASE_SAFETY_EVIDENCE.md` §D.6). The tools lived outside the patched import chain and were therefore not intercepted. | **OPEN — disclosed breach** | The tools now exclude `.data` from every scan, the package builder uses an explicit allowlist that cannot include `.data/`, and the campaign was stopped and restarted. The residual risk is that **any** tool that reads the repository directly (outside the patched import chain) can bypass the boundary; a future reviewer must treat the tool allowlist as part of the boundary. |

## F.3 Risks that are explicitly **not** claimed to be closed

* Power-loss durability of the preservation manifest.
* Storage-controller cache durability, hardware reliability.
* A transactionally consistent source snapshot for the preserved artifact
  set.
* Source immutability during the copy.
* Atomic, race-free database protection.
* An operating-system sandbox.
* SQLite runtime certification.
* G4 acceptance, freeze or deployment readiness.
