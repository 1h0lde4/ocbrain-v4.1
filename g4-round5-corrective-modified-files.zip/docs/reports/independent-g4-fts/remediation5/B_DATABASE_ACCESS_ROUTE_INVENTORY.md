# B — Database-Access Route Inventory (Round 5)

**Scope:** every route through which OCBrain can open, attach to, copy to
or otherwise reach a SQLite database file.

**Method:** a repository-wide source and import audit over `core/`,
`interface/`, `modules/`, `learning/` and `install/`, plus the executable
audit test
`tests/test_g4_r5_corrections.py::TestR504SqlAccessRoutes::test_the_application_route_inventory_has_no_unprotected_connect`.

**Date:** 2026-11-12

---

## B.1 Measured runtime facts

These are **measured**, not assumed.  The probe is
`docs/reports/independent-g4-fts/remediation5/tools/sqlite_runtime_probe.py`
and its output is stored in `logs/sqlite_runtime_probe.json`.

| Property | Measured value |
|---|---|
| Python | 3.14.3 (MSC v.1944 64 bit AMD64) |
| Python `sqlite3` module version attribute | removed in 3.14 (`sqlite3.version` no longer exists) |
| SQLite runtime version | **3.50.4** |
| SQLite source id | `2025-07-30 19:33:53 4d8adfb30e03f9cf27f800a2c1ba3c48fb4ca1b08b0f5ed59a4d5ecbf45e20a3` |
| Compiler | `msvc-1944` |
| `SQLITE_USE_URI` compile option | **absent** |
| `SQLITE_ALLOW_URI_AUTHORITY` compile option | **absent** |
| `MAX_ATTACHED` | 10 |
| `THREADSAFE` | 1 |
| URI processing | **per connection** (`uri=True`); `uri=False` treats a `file:` string as an ordinary file name |
| `SQLITE_ATTACH` authorizer action code | **24** |
| `VACUUM INTO` authorizer action | **reports `SQLITE_ATTACH` (24)** on this runtime |
| `ATTACH DATABASE (<expression>)` | reports action 24 with a **NULL** filename argument |
| Foreign URI authority | SQLite itself rejects it: `invalid uri authority: <x>` |
| `SQLITE_DBCONFIG_ENABLE_ATTACH_CREATE` / `..._ATTACH_WRITE` | **not exposed** by CPython's `sqlite3` |
| `SQLITE_DBCONFIG_ENABLE_LOAD_EXTENSION` | exposed and settable (`Connection.setconfig`) |
| `SQLITE_LIMIT_ATTACHED` | exposed (`Connection.setlimit`) |

## B.2 Connection-creation routes

| # | Route | Status after R5-01 | Evidence |
|---|---|---|---|
| 1 | `sqlite3.connect(...)` in application code | **NONE remain.** Every application-managed connection is created by `core.memory.sqlite_guard.open_database()`. The only remaining `sqlite3.connect(` call in the application tree is the one inside the factory itself. | executable audit test |
| 2 | `from sqlite3 import connect` (captured alias) | **No occurrence** in the application tree. | audit test |
| 3 | `sqlite3.connect = ...` (global monkeypatch) | **Removed.** `core/runtime/state.py` used to replace the global `sqlite3.connect` with a wrapper that captured the unguarded connector **at import time** — a module imported before the boundary captured the unguarded connector, and a module imported after the boundary replaced the guarded one. The module now uses the reviewed factory. | `core/runtime/state.py`, audit test |
| 4 | `sqlite3.Connection(...)` (direct C constructor) | **ZERO application call sites.** The route still EXISTS and **cannot be intercepted at the Python level** (`sqlite3.Connection` is an immutable extension type). It is therefore **audited, not blocked**, and it is reported as a residual risk. The test `test_the_direct_connection_constructor_is_not_interceptable` demonstrates the limitation honestly rather than hiding it. | executable test |
| 5 | `sqlite3.dbapi2` | no application occurrence | audit test |
| 6 | `apsw` / other SQLite bindings | no application occurrence | audit test |
| 7 | direct SQLite C API (`ctypes` / `cffi`) | no application occurrence | audit test |
| 8 | native extension opening a SQLite file | no such extension in this repository | repository audit |
| 9 | Online Backup API (`src.backup(dst)`) | both ends must be connections; the destination is a connection created through the guarded factory, so the destination path passes the protection check. Audited at `core/memory/sqlite_migration.py` (`create_online_backup`). | `test_the_backup_api_destination_is_a_guarded_connection` |
| 10 | connection factory in a worker / child process | the application has no child-process database opener; the **test** child processes inherit the boundary through the generated `sitecustomize.py`, and a child whose bootstrap fails fails closed. | `TestR505Bootstrap` |
| 11 | a path that opens a database **before** the protection boundary is installed | in the **test** process the boundary is installed by the launcher **before pytest is imported**, so no plugin, conftest or test module can open a database first. In the **application** there is no import-time database open: every connection is created through the factory, which installs the SQLite-level guard on the connection itself. | `test_an_import_time_open_of_a_protected_database_is_blocked`, `test_a_collection_time_open_of_a_protected_database_is_blocked` |

## B.3 SQL-capable file-access routes

| Route | Policy | Evidence |
|---|---|---|
| `ATTACH DATABASE` | **DENIED unconditionally** by the SQLite authorizer (action code 24). The denial does not inspect the filename text, so an expression-based attachment (which reports a NULL filename) is denied too. | `test_attach_with_a_literal_is_denied_and_creates_nothing` and 5 further cases |
| `VACUUM INTO` | Denied by the same unconditional `SQLITE_ATTACH` denial — **measured**, not assumed: this runtime reports action 24 for `VACUUM INTO`. The test `test_vacuum_into_reports_the_attach_action_on_this_runtime` fails loudly if a future runtime stops doing so. | `test_vacuum_into_with_a_literal_is_denied`, `..._with_a_bound_parameter_is_denied` |
| Loadable extensions | `SQLITE_DBCONFIG_ENABLE_LOAD_EXTENSION` is set to **false** and `enable_load_extension(False)` is called. The `load_extension()` SQL function is therefore unavailable. | `test_loadable_extensions_are_disabled` |
| Application-defined SQL functions | **none** in the application (`create_function` audit) | audit test |
| Application-defined virtual tables | **none** in the application (`create_module` audit) | audit test |
| `sqlite3.Connection.backup` | audited; both ends must be guarded connections | backup test |
| `executescript` | used in the application, but only for schema DDL on the connection's own database; it cannot name an external file | audit test |

## B.4 The defence-in-depth layers

| Layer | Mechanism | Scope |
|---|---|---|
| L1 | `core.memory.sqlite_guard.open_database()` — the single reviewed factory. Builds the open target with the canonical URI constructor, installs the authorizer policy, disables extensions, lowers `SQLITE_LIMIT_ATTACHED` to 0. | every application-managed connection |
| L2 | The SQLite authorizer — a statement-level control that runs during statement preparation, i.e. **before** the destination file is opened or created. | every connection created by L1 |
| L3 | `core.memory.sqlite_contract.sqlite_file_uri()` — the canonical URI constructor. Percent-encodes the path, normalises the separators and appends the requested open mode. | every URI-based open |
| L4 | The test-side boundary `tests/_g4_protection.py` — path protection, the strict URI policy, the companion-sidecar namespace and the same authorizer policy. Installed **before pytest is imported**. | the test process and every child interpreter |

## B.5 The companion-sidecar namespace

A protected database implies its companion files:

| Companion | Meaning | Policy |
|---|---|---|
| `<db>-wal` | the write-ahead log — **persistent** database state | a direct open as an independent database is DENIED |
| `<db>-shm` | the WAL-index shared-memory **coordination** structure — transient | a direct open as an independent database is DENIED |
| `<db>-journal` | the rollback journal | a direct open as an independent database is DENIED |

The boundary distinguishes the two cases:

1. SQLite's **internal** VFS opens of the companion files while opening an
   APPROVED database are invisible to the Python-level wrapper and are
   therefore unaffected — the wrapper intercepts `sqlite3.connect`, not the
   VFS.
2. An **application or caller** that opens a protected companion as an
   independent database is denied by the Python-level wrapper.

This distinction is stated explicitly: **the Python connector wrapper does
NOT intercept SQLite's internal VFS opens.**  It intercepts the
application-level entry points.

## B.6 What is explicitly NOT claimed

* The boundary is **not** an operating-system sandbox.
* It is **not atomic**: the interval between the path validation and
  SQLite's open is not closed against a hostile same-user process.
* The `sqlite3.Connection` constructor route **cannot** be intercepted at
  the Python level and is **audited, not blocked**.
* `SQLITE_DBCONFIG_ENABLE_ATTACH_CREATE` and
  `SQLITE_DBCONFIG_ENABLE_ATTACH_WRITE` are **not exposed** by CPython;
  even if they were, SQLite documents that they would not prohibit all
  attachment.  The **unconditional authorizer denial** is the primary
  control.
* A hard-link alias to a production file cannot be verified without
  touching that file; the boundary therefore does not capture production
  identities automatically.
