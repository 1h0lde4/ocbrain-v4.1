#!/usr/bin/env python
"""
build_crosswalk.py — the Round-5 crosswalk generator (R5-05 §6.5).

The machine-readable crosswalk (``crosswalk.json``) is the SINGLE SOURCE
OF TRUTH.  This generator reads it, VALIDATES it, computes every
aggregate from the records, and renders the Markdown findings register
deterministically.

It deliberately contains NO hardcoded status counts: every number in the
generated Markdown is computed from the records, so a crosswalk error
cannot be concealed by a constant.  The expected identifier SETS are a
structural property of the identifier namespaces, not a status count.

    python build_crosswalk.py            # write A_FINDINGS_REGISTER.md
    python build_crosswalk.py --check    # verify it; write NOTHING

``--check`` performs NO file modification and returns a non-zero exit code
when the generated output differs from the committed Markdown.

REPRODUCTION
------------
    cd docs/reports/independent-g4-fts/remediation5
    python build_crosswalk.py --check
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import Counter, OrderedDict
from pathlib import Path

HERE = Path(__file__).resolve().parent
CROSSWALK = HERE / "crosswalk.json"
REGISTER = HERE / "A_FINDINGS_REGISTER.md"

#: The generator version.  Bump it when the rendering changes.
GENERATOR_VERSION = "5.1"

#: The status vocabulary allowed for a historical or Round-5 disposition.
ALLOWED_STATUSES = frozenset({
    "FIXED", "PARTIAL", "NOT FIXED", "NOT VERIFIED", "NOT APPLICABLE",
})

#: The expected identifier SETS.  Membership is structural; no status
#: count is encoded here.
EXPECTED_SETS = OrderedDict((
    ("F01-F38", ["F%02d" % n for n in range(1, 39)]),
    ("F39-F56", ["F%02d" % n for n in range(39, 57)]),
    ("R39-R56", ["R%02d" % n for n in range(39, 57)]),
    ("W01-W24", ["W%02d" % n for n in range(1, 25)]),
))


class CrosswalkError(RuntimeError):
    """The crosswalk failed validation."""


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _expected_identifiers():
    ordered = []
    for members in EXPECTED_SETS.values():
        ordered.extend(members)
    return ordered


def validate(crosswalk: dict) -> list:
    """
    Validate the crosswalk and return the historical records.

    Rejects missing identifiers, duplicates, unexpected identifiers,
    invalid status values and a wrong set membership.
    """
    historical = crosswalk.get("historical_findings")
    if not isinstance(historical, list):
        raise CrosswalkError("crosswalk.json has no 'historical_findings' list")

    seen = Counter()
    for record in historical:
        identifier = record.get("id")
        if not identifier:
            raise CrosswalkError("a historical record has no 'id'")
        seen[identifier] += 1
    duplicates = sorted(k for k, v in seen.items() if v > 1)
    if duplicates:
        raise CrosswalkError(f"duplicate identifiers in the crosswalk: "
                             f"{duplicates}")

    expected = _expected_identifiers()
    present = set(seen)
    missing = [i for i in expected if i not in present]
    unexpected = sorted(present - set(expected))
    if missing:
        raise CrosswalkError(f"missing historical identifiers: {missing}")
    if unexpected:
        raise CrosswalkError(f"unexpected historical identifiers: "
                             f"{unexpected}")

    for record in historical:
        for field in ("round4_disposition", "current_disposition"):
            value = record.get(field)
            if value not in ALLOWED_STATUSES:
                raise CrosswalkError(
                    f"{record['id']}: {field}={value!r} is not in the allowed "
                    f"vocabulary {sorted(ALLOWED_STATUSES)}")
        for field in ("round5_evidence", "residual_risk", "supersedes"):
            if field not in record:
                raise CrosswalkError(
                    f"{record['id']}: the required field {field!r} is missing")

    for name, members in EXPECTED_SETS.items():
        member_set = set(members)
        for record in historical:
            identifier = record["id"]
            in_this_set = identifier in member_set
            belongs_elsewhere = any(identifier in set(m)
                                    for m in EXPECTED_SETS.values()
                                    if m != members)
            if in_this_set and belongs_elsewhere:
                raise CrosswalkError(
                    f"{identifier} belongs to more than one set")
        stored = crosswalk.get("set_membership", {}).get(name)
        if stored is not None and list(stored) != list(members):
            raise CrosswalkError(
                f"the stored membership of the set {name} does not match the "
                "expected membership")

    for record in crosswalk.get("round5_findings", []):
        value = record.get("current_disposition")
        if value not in ALLOWED_STATUSES:
            raise CrosswalkError(
                f"{record.get('id')}: current_disposition={value!r} is not in "
                f"the allowed vocabulary {sorted(ALLOWED_STATUSES)}")
        for field in ("round5_evidence", "residual_risk", "supersedes"):
            if field not in record:
                raise CrosswalkError(
                    f"{record.get('id')}: the required field {field!r} is "
                    "missing")
    return historical


def compute_totals(historical: list, round5: list) -> dict:
    """Every aggregate count is COMPUTED from the records."""
    per_set = OrderedDict()
    for name, members in EXPECTED_SETS.items():
        counts = Counter(record["current_disposition"]
                         for record in historical
                         if record["id"] in set(members))
        per_set[name] = {"identifiers": len(members),
                         "counts": dict(sorted(counts.items()))}
    overall = Counter(record["current_disposition"] for record in historical)
    round5_counts = Counter(record["current_disposition"]
                            for record in round5)
    return {
        "per_set": per_set,
        "historical_identifiers": len(historical),
        "historical_counts": dict(sorted(overall.items())),
        "round5_identifiers": len(round5),
        "round5_counts": dict(sorted(round5_counts.items())),
    }


def _escape(text) -> str:
    return str(text if text is not None else "").replace("|", "\\|").replace(
        "\n", " ")


def render(crosswalk: dict, historical: list, totals: dict) -> str:
    """Render the Markdown register deterministically."""
    lines = []
    lines.append("# A — Findings Register (Round 5)")
    lines.append("")
    lines.append("<!-- GENERATED FILE — DO NOT EDIT BY HAND. -->")
    lines.append("<!-- Source of truth: crosswalk.json -->")
    lines.append("<!-- Generator: build_crosswalk.py -->")
    lines.append("")
    lines.append("This register is GENERATED from the machine-readable")
    lines.append("`crosswalk.json` by `build_crosswalk.py`. Every count")
    lines.append("below is computed from the records; the generator")
    lines.append("contains no hardcoded status counts.")
    lines.append("")
    lines.append(f"- Generator version: `{GENERATOR_VERSION}`")
    lines.append(f"- Crosswalk SHA-256: `{sha256_file(CROSSWALK)}`")
    lines.append(f"- Historical identifiers: **{totals['historical_identifiers']}**")
    lines.append("")
    lines.append("## A.1 Disposition vocabulary")
    lines.append("")
    lines.append("| Disposition | Meaning |")
    lines.append("|---|---|")
    lines.append("| FIXED | Implementation and required executable evidence "
                 "support closure |")
    lines.append("| PARTIAL | Some subclaims are resolved, but a material "
                 "requirement remains |")
    lines.append("| NOT FIXED | Defect remains or the correction is "
                 "ineffective |")
    lines.append("| NOT VERIFIED | Required evidence was not obtained |")
    lines.append("| NOT APPLICABLE | Explicitly justified and supported |")
    lines.append("")
    lines.append("## A.2 Historical identifiers — aggregate")
    lines.append("")
    lines.append("| Set | Identifiers | " + " | ".join(
        sorted(ALLOWED_STATUSES)) + " |")
    lines.append("|---|---:|" + "---:|" * len(ALLOWED_STATUSES))
    for name, entry in totals["per_set"].items():
        counts = entry["counts"]
        row = [name, str(entry["identifiers"])]
        row.extend(str(counts.get(status, 0))
                   for status in sorted(ALLOWED_STATUSES))
        lines.append("| " + " | ".join(row) + " |")
    row = ["**ALL**", f"**{totals['historical_identifiers']}**"]
    row.extend(f"**{totals['historical_counts'].get(status, 0)}**"
               for status in sorted(ALLOWED_STATUSES))
    lines.append("| " + " | ".join(row) + " |")
    lines.append("")
    lines.append("The Round-5 findings are reported separately in §A.4 and")
    lines.append("are NOT part of the historical denominator above.")
    lines.append("")
    lines.append("## A.3 Historical identifiers — detail")
    lines.append("")
    lines.append("`round4_disposition` is the EXACT Round-4 disposition and is")
    lines.append("never overwritten; `current_disposition` is the status")
    lines.append("supported by the Round-5 evidence.")
    lines.append("")
    for name, members in EXPECTED_SETS.items():
        member_set = set(members)
        lines.append(f"### {name}")
        lines.append("")
        lines.append("| ID | Finding | Round-4 | Current | Round-5 evidence | "
                     "Residual risk | Supersedes |")
        lines.append("|---|---|---|---|---|---|---|")
        for record in historical:
            if record["id"] not in member_set:
                continue
            lines.append("| {id} | {finding} | {r4} | {cur} | {ev} | {risk} | "
                         "{sup} |".format(
                             id=_escape(record["id"]),
                             finding=_escape(record.get("finding")),
                             r4=_escape(record.get("round4_disposition")),
                             cur=_escape(record.get("current_disposition")),
                             ev=_escape(record.get("round5_evidence")),
                             risk=_escape(record.get("residual_risk")),
                             sup=_escape(record.get("supersedes")) or "—"))
        lines.append("")
    lines.append("## A.4 Round-5 findings (separate denominator)")
    lines.append("")
    lines.append("| ID | Finding | Disposition | Evidence | Residual risk | "
                 "Supersedes |")
    lines.append("|---|---|---|---|---|---|")
    for record in crosswalk.get("round5_findings", []):
        lines.append("| {id} | {finding} | {cur} | {ev} | {risk} | {sup} |"
                     .format(
                         id=_escape(record.get("id")),
                         finding=_escape(record.get("finding")),
                         cur=_escape(record.get("current_disposition")),
                         ev=_escape(record.get("round5_evidence")),
                         risk=_escape(record.get("residual_risk")),
                         sup=_escape(record.get("supersedes")) or "—"))
    lines.append("")
    lines.append("| Round-5 set | Identifiers | " + " | ".join(
        sorted(ALLOWED_STATUSES)) + " |")
    lines.append("|---|---:|" + "---:|" * len(ALLOWED_STATUSES))
    row = ["**ALL**", f"**{totals['round5_identifiers']}**"]
    row.extend(f"**{totals['round5_counts'].get(status, 0)}**"
               for status in sorted(ALLOWED_STATUSES))
    lines.append("| " + " | ".join(row) + " |")
    lines.append("")
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true",
                        help="verify the generated Markdown; write NOTHING")
    parser.add_argument("--crosswalk", default=str(CROSSWALK))
    parser.add_argument("--register", default=str(REGISTER))
    args = parser.parse_args()

    crosswalk_path = Path(args.crosswalk)
    register_path = Path(args.register)

    try:
        crosswalk = json.loads(crosswalk_path.read_text(encoding="utf-8"))
        historical = validate(crosswalk)
    except (CrosswalkError, json.JSONDecodeError) as exc:
        sys.stderr.write(f"CROSSWALK INVALID: {exc}\n")
        return 2

    round5 = crosswalk.get("round5_findings", [])
    totals = compute_totals(historical, round5)

    # The stored aggregates (if any) must agree with the computed ones.
    stored = crosswalk.get("historical_totals")
    if isinstance(stored, dict):
        stored_counts = stored.get("dispositions")
        if stored_counts is not None and \
                dict(sorted(stored_counts.items())) != totals["historical_counts"]:
            sys.stderr.write(
                "CROSSWALK INVALID: the stored aggregate counts disagree "
                "with the counts computed from the records\n")
            return 2

    rendered = render(crosswalk, historical, totals)

    if args.check:
        if not register_path.exists():
            sys.stderr.write(f"MISSING: {register_path} does not exist\n")
            return 1
        expected = register_path.read_text(encoding="utf-8")
        if expected != rendered:
            sys.stderr.write(
                f"DIFFERENT: the generated register does not match "
                f"{register_path}\n")
            return 1
        print(f"OK: {register_path} matches the generated output "
              f"({totals['historical_identifiers']} historical identifiers, "
              f"{totals['round5_identifiers']} round-5 findings)")
        return 0

    register_path.write_text(rendered, encoding="utf-8", newline="\n")
    print(f"written {register_path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
