# H — Fresh Independent-Review Handoff (Round 5)

**Date:** 2026-11-12
**Package:** `g4-round5-corrective-modified-files.zip`
**Governance state at handoff:** G4 **OPEN / NOT ACCEPTED**; DEBT-045
**OPEN**; F36 **OPEN / NOT FIXED**; SQLite runtime certification **NOT
READY**; deployment **NOT READY**; freeze **NOT AUTHORIZED**.

This document is written for a reviewer who has **not** seen the previous
rounds.  It states what to review, in what order, with which commands, and
— most importantly — **which claims must be challenged**.

---

## H.1 The recommended review order

1. **Read the governance boundary first.** `README.md` §5 and the main
   report §20.  A passing Round-5 suite is **not** a G4 acceptance and
   **not** a SQLite runtime certification.
2. **Check the historical integrity of the input.** The nested
   `g4-round4-corrective-modified-files.zip` must have SHA-256
   `1c75f7fc1033aad2f1b1c57969a05fed68f4a569418c9556f70900db7cf6ee0c`,
   76 entries, 425 105 bytes.  The Round-4 documentation inside the
   package is **immutable history**.
3. **Read the disclosed breach first** (`D_DATABASE_SAFETY_EVIDENCE.md`
   §D.6).  It changes what the production-safety claims mean, and a
   reviewer must not read the safety evidence without it.
4. **Verify the baseline reconstruction** (`tools/reconstruct_baselines.py`).
   The three fingerprints must be distinct and B4 must have **0**
   discrepancies against the Round-4 manifest parsed from inside the
   archive.
5. **Re-run the protected suites** (§H.3).
6. **Audit the database-access routes** (`B_DATABASE_ACCESS_ROUTE_INVENTORY.md`)
   and then attack them (§H.5).
7. **Read the crosswalk and run the generator** (§H.4).
8. **Read the residual risk register** and check that nothing was quietly
   closed.

## H.2 The baseline reconstruction procedure

```
python docs/reports/independent-g4-fts/remediation5/tools/reconstruct_baselines.py \
    --work <scratch> --out <result.json>
```

Expected:

| State | Files | Fingerprint |
|---|---:|---|
| B0 | 580 | `499d6aedca08764acf7926420501e8e623c651fa012c1d9a2035bb3ded2a4207` |
| B4 | 638 | `8185f1bb73d71ea2b6e7ffd810ffc912043df6e95fda99080aeb9506a0be8e59` |
| B5 | (see `logs/baseline_reconstruction.json`) | (see `logs/baseline_reconstruction.json`) |

The B5 fingerprint is recomputed at the end of the round, after every
deliverable is written; it is recorded in
`logs/baseline_reconstruction.json` and in `G_SOURCE_MANIFEST.md`.

**The runtime data directory (`.data/`) is excluded from every scan** — it
is production data, and a source-tree fingerprint must describe the
source.

## H.3 The exact test commands

Every command goes through the **protected launcher**: it installs the
production-access boundary **before** pytest is imported.

```
cd <repository>

python tests/run_g4_protected_pytest.py tests/test_g4_r5_corrections.py \
    -p no:cacheprovider -q
python tests/run_g4_protected_pytest.py tests/test_g4_r4_corrections.py \
    -p no:cacheprovider -q
python tests/run_g4_protected_pytest.py tests/test_g4_interaction_scenarios.py \
    -p no:cacheprovider -q
python tests/run_g4_protected_pytest.py tests/test_g4_f01_f38_remediation.py \
    -p no:cacheprovider -q
python tests/run_g4_protected_pytest.py tests/test_g4_revg4_remediation.py \
    -p no:cacheprovider -q
python tests/run_g4_protected_pytest.py --collect-only -q -p no:cacheprovider
```

The full repository suite:

```
python tests/run_g4_protected_pytest.py -p no:cacheprovider -q
```

The reproduction of the whole campaign (all three source states):

```
python docs/reports/independent-g4-fts/remediation5/tools/run_campaign.py \
    --state B0 --tree <B0 tree> --out <out> --label full \
    --harness-from <repository>
```

## H.4 The crosswalk

```
cd docs/reports/independent-g4-fts/remediation5
python build_crosswalk.py --check      # writes NOTHING; non-zero on a difference
```

The generator must reject a missing, a duplicate and an unexpected
identifier, an invalid status and a wrong set membership.  It contains **no
hardcoded status counts**.

## H.5 The claims the reviewer MUST challenge

| # | Claim | How to attack it |
|---|---|---|
| 1 | "The protection boundary rejects a protected path **before** any filesystem operation." | Instrument `os.open` / `builtins.open` and prove the call never happens for a protected path. The rejection must happen in the path check, not after the open. |
| 2 | "The URI decision matches the path SQLite actually opens." | Take any URI form, run the **measured** SQLite probe (`tools/sqlite_uri_semantics_probe.py`) and compare it with `parse_sqlite_uri()`. Any disagreement is a defect. |
| 3 | "The strict query policy cannot be bypassed." | Try percent-encoded names, duplicate keys, `vfs=`, `modeof=`, `nolock=`, `immutable=`, `psow=`, a parameter with an `=` in the value, an empty parameter, a truncated escape. |
| 4 | "ATTACH and VACUUM INTO are denied." | Try a literal, a bound parameter, a URI, a `localhost` URI, an **expression** (the filename argument is NULL), a relative path, and a schema change that re-prepares statements. Prove the destination is **not** created. |
| 5 | "The authorizer cannot be removed." | Call `set_authorizer(callback)` and `set_authorizer(None)` on a guarded connection and re-attempt the ATTACH. |
| 6 | "The manifest survives an abrupt termination." | Run the crash test with a **different** artifact order and a different exit code; read the surviving `manifest.json` and check that the verified artifact is represented and the others are pending. |
| 7 | "The manifest replacement is atomic." | Kill the process during the replacement; the file must always be a **complete** JSON manifest, never a truncated one. |
| 8 | "The verification command reports the cleanup truthfully." | Inject a cleanup failure, a partial cleanup failure and a close failure; check `cleanup_ok`, `verification_target_removed`, `cleanup_error`, `cleanup_errors`, `ok` and the exit code against each other. |
| 9 | "Exactly one JSON object is emitted." | Parse stdout with a raw JSON decoder and assert that nothing but whitespace follows the object. |
| 10 | "The SHM identity proves the file was not replaced." | Replace the SHM with an identical-content file and confirm the identity check detects it. |
| 11 | "The file identity is native." | Verify that the mechanism really is `GetFileInformationByHandleEx(FileIdInfo)` (not `st_ino`), and that the native structure size is 24 bytes. |
| 12 | "No production data was touched." | **Read §D.6 first.** Then check the tools: do they exclude `.data`? Does the package contain anything under `.data`? |
| 13 | "The baseline reconstruction is faithful." | Corrupt one byte of the Round-4 archive and confirm the reconstruction fails closed. |
| 14 | "The crosswalk totals are right." | Recompute them from `crosswalk.json` with an independent script. |
| 15 | "No application connection bypasses the factory." | Grep for `sqlite3.connect(`, `sqlite3.Connection(`, `from sqlite3 import connect`, `apsw`, `ctypes` SQLite and `enable_load_extension(True)`. |
| 16 | "The Round-4 documentation was preserved." | Compare the Round-4 documents in the nested archive with the Round-4 documents in the repository — they must be byte-identical. |

## H.6 The known limitations the reviewer must keep in view

* The protection is a Python-level, application-level control — **not** an
  OS sandbox — and it is **not** race-free.
* The `sqlite3.Connection` constructor cannot be intercepted; it is
  audited, not blocked.
* The preservation durability is **process-crash** durability; on Windows
  there is no power-loss claim.
* The preservation does **not** prove a transactionally consistent source
  snapshot (F36).
* The SHM byte content is deliberately not asserted.
* The bundled SQLite **3.50.4** is inside the WAL-reset affected range.
* Two Round-5 reporting tools read and hashed production files before
  they were corrected (§D.6).
* The pre-existing test failures and errors are unchanged unless the
  measured baseline proves otherwise (see `C_REGRESSION_EVIDENCE.md`).

## H.7 The evidence locations

| Evidence | Path |
|---|---|
| the findings register (generated) | `A_FINDINGS_REGISTER.md` |
| the machine-readable crosswalk | `crosswalk.json` |
| the crosswalk generator | `build_crosswalk.py` |
| the per-invocation test records | `test_execution_manifest.json` |
| the regression evidence | `C_REGRESSION_EVIDENCE.md` |
| the production-safety evidence (incl. the disclosed breach) | `D_DATABASE_SAFETY_EVIDENCE.md` |
| the route inventory | `B_DATABASE_ACCESS_ROUTE_INVENTORY.md` |
| the residual risks | `F_RESIDUAL_RISK_REGISTER.md` |
| the changed-file manifest | `G_SOURCE_MANIFEST.md` |
| the **reproducible Round-5 overlay** (a unified diff against B4) | `round5_overlay.patch` |
| the baseline reconstruction | `logs/baseline_reconstruction.json` |
| the measured SQLite runtime | `logs/sqlite_runtime_probe.json` |
| the measured URI semantics | `logs/sqlite_uri_semantics.json` |
| the crash-injection evidence (the surviving manifest) | `logs/crash_injection_evidence.json` |
| the fail-closed verification (a damaged archive is rejected) | `logs/fail_closed_verification.json` |
| the campaign logs and per-node records | `logs/` |
| the package identity | `package_manifest.json` |

## H.8 The next step

The next step after this delivery is a **fresh independent review of the
immutable Round-5 archive**.  This package makes no acceptance decision
and authorises none.
