# C — Regression Evidence (Round 5)

<!-- GENERATED FILE — DO NOT EDIT BY HAND. -->

## C.1 The campaign

| Source state | Command | Collected | Passed | Failed | Errors | Skipped | xfailed | Exit code | Duration (s) |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| B0 | `-X utf8 C:\Users\Produ\AppData\Local\Temp\g4_bases\B0\tests\run_g4_protected_pytest.py -p no:cacheprovider -p g4_report_plugin -q` | 2322 | 2197 | 45 | 51 | 28 | 1 | 1 | 1158.8 |
| B4 | `-X utf8 C:\Users\Produ\AppData\Local\Temp\g4_bases\B4\tests\run_g4_protected_pytest.py -p no:cacheprovider -p g4_report_plugin -q` | 2485 | 2382 | 22 | 51 | 29 | 1 | 1 | 1527.8 |
| B5 | `-X utf8 C:\Users\Produ\AppData\Local\Temp\g4_bases\B5\tests\run_g4_protected_pytest.py -p no:cacheprovider -p g4_report_plugin -q` | 2613 | 2508 | 23 | 51 | 30 | 1 | 1 | 1581.4 |

Every invocation ran through the **protected launcher**, so
the production-access boundary was installed before pytest
was imported in every run.

### C.1.1 The previously reported numbers

The Round-4 evidence reported the following figures:

| Measurement | B0 reported | B4 reported |
|---|---:|---:|
| Passed | 2,186 | 2,349 |
| Failed | 21 | 21 |
| Errors | 51 | 51 |
| Skipped | 27 | 27 |
| **Deselected** | **36** | **36** |
| Xfailed | 1 | 1 |

These are **previously reported values, not independently
verified acceptance expectations**.  The Round-5 campaign
**deselects nothing**: the 36 deselected tests of the
Round-4 measurement were collected and executed here, which
is why the totals are the same (2,322) but the split
differs.  The Round-5 comparison is therefore made
**between the three source states under the IDENTICAL
command**, and on the **common node ids** — never against
the historical aggregates, and never with a deselection
that could hide a failure.

## C.2 The environment (identical for every invocation)

- Python: `3.14.3 (tags/v3.14.3:323c59a, Feb  3 2026, 16:04:56) [MSC v.1944 64 bit (AMD64)]`
- SQLite: **3.50.4** (source id `2025-07-30 19:33:53 4d8adfb30e03f9cf27f800a2c1ba3c48fb4ca1b08b0f5ed59a4d5ecbf45e20a3`)
- pytest: `9.0.3`
- Platform: Windows 11 (AMD64)
- Working directory: `C:\Users\Produ\AppData\Local\Temp\g4_bases\B0`

The full dependency inventory is recorded per invocation
in `test_execution_manifest.json`.

## C.3 The node-level comparison

The comparison is made on the **COMMON TEST NODE IDS** — a
later round naturally adds test cases, so the aggregate
counts alone cannot isolate a regression.

### B0_vs_B4

- common node ids: **2319**
- only in B0: 3
- only in B4: 166

| Classification | Count |
|---|---:|
| pass_in_both | 2192 |
| fail_in_both | 20 |
| error_in_both | 51 |
| new_failure | 2 |
| resolved_failure | 25 |
| new_error | 0 |
| resolved_error | 0 |
| skipped_status_changed | 29 |
| outcome_changed | 0 |

**Regressions** (new failures / new errors / outcome changes):

- new failure: `tests/test_b2c_cancellation.py::test_cancelling_one_request_does_not_affect_a_concurrent_request`
- new failure: `tests/test_orchestrator_memory_migration.py::TestSession4StayedInScope::test_web_learning_pipeline_still_uses_memory_vault`

### B4_vs_B5

- common node ids: **2485**
- only in B4: 0
- only in B5: 128

| Classification | Count |
|---|---:|
| pass_in_both | 2380 |
| fail_in_both | 21 |
| error_in_both | 51 |
| new_failure | 2 |
| resolved_failure | 1 |
| new_error | 0 |
| resolved_error | 0 |
| skipped_status_changed | 30 |
| outcome_changed | 0 |

**Regressions** (new failures / new errors / outcome changes):

- new failure: `tests/test_g4_f01_f38_remediation.py::TestF24ProductionBoundary::test_the_boundary_is_installed_in_this_process`
- new failure: `tests/test_production_robustness.py::test_batched_state`

## C.4 The per-node inventories

The complete node-id inventory of every invocation is in
`test_execution_manifest.json` under `invocations[*].node_ids`.

## C.4.1 The recorded environment incidents

Two invocations of the campaign ended with the Windows exit
code `3221225477` (`0xC0000005`, access violation) instead
of a pytest exit status.  **A crash is not a test result**
and is never counted as one.  Both invocations were re-run,
and the records in `test_execution_manifest.json` are the
re-runs.

| Source state | Attempt | Exit code | Collected | Faulting frame |
|---|---:|---:|---:|---|
| B4 | 1 | `3221225477` | 1894 | `torch/storage.py __getitem__ / transformers/core_model_loading.py _materialize_copy` |
| B5 | 2 | `3221225477` | 2030 | `torch/storage.py __getitem__ / transformers/core_model_loading.py _materialize_copy` |

The cause is the same in both: a **native model-loading
fault in torch/transformers** on a machine with 8 GB of RAM
and about 1 GB free.  It is an **environment resource
failure** in a test that loads a model — **no G4 module
appears in either traceback**, and the failure is unrelated
to the Round-5 work.

**The node-level comparison is unaffected by a partial
invocation**: it is computed over the node ids that are
present in BOTH records, so a state that stopped early
simply contributes fewer common node ids — and every node
id it DID reach is compared.

## C.5 The logs

- **B0** stdout: `C:\Users\Produ\AppData\Local\Temp\g4_campaign\B0_full.stdout.log` (SHA-256 `4f60bbe1afb083d74161e84fe0109ef5582404e55d1bc496915e30f4e14220ea`)
- **B0** stderr: `C:\Users\Produ\AppData\Local\Temp\g4_campaign\B0_full.stderr.log` (SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`)
- **B4** stdout: `C:\Users\Produ\AppData\Local\Temp\g4_campaign\B4_full.stdout.log` (SHA-256 `1ac687e15e338ea1c1cd6d2eb458aac202fa5d733b6bb23685845877553dc936`)
- **B4** stderr: `C:\Users\Produ\AppData\Local\Temp\g4_campaign\B4_full.stderr.log` (SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`)
- **B5** stdout: `C:\Users\Produ\AppData\Local\Temp\g4_campaign\B5_full.stdout.log` (SHA-256 `3c3b57e82745ef3fc1d011ad900170052b44c678e6495e287cf34efc7fa937a9`)
- **B5** stderr: `C:\Users\Produ\AppData\Local\Temp\g4_campaign\B5_full.stderr.log` (SHA-256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`)

