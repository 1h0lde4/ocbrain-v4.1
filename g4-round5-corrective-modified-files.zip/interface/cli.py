"""
interface/cli.py — Terminal interface. Headless, pipe-friendly, scriptable.
Usage:
  ocbrain "your query"
  ocbrain --status
  ocbrain --train coding
  ocbrain --new-module
  ocbrain --update
  ocbrain --rollback
  echo "query" | ocbrain
"""
import sys

import click
import httpx
from rich.console import Console
from rich.table import Table

from core.memory.sqlite_guard import open_database

console = Console()
BASE    = "http://localhost:7437"


class SubcommandFirstGroup(click.Group):
    """
    click.Group variant whose registered subcommands take priority over the
    group's free-form [QUERY] positional argument.

    Stock click parsing consumes the first non-option token of
    `ocbrain status` into the group's QUERY argument, leaving
    ctx._protected_args empty — every subcommand becomes unreachable (and an
    unknown option such as memory-doctor's --db aborts at the group level).
    With this class the first positional token is checked against the
    registered command table; when it names a command, parsing continues with
    the group's positional arguments hidden, so the token falls through to
    the subcommand path exactly as if no [QUERY] argument existed. A free
    text query (`ocbrain "why is it slow"`) contains no registered command
    name and is parsed as before.
    """

    def parse_args(self, ctx, args):
        if (args and not args[0].startswith("-")
                and args[0] in self.commands):
            # REV-G4-08 (sub-finding, found while building the corrective
            # regression suite): the group's OWN parameter list must be
            # restored COMPLETELY after the subcommand-first parse. The
            # previous code restored only the Argument params, permanently
            # dropping every Option (e.g. --module) from the group: the
            # SECOND in-process invocation of any subcommand then failed
            # with "cli() missing 1 required positional argument: 'module'".
            # A supervisor, a script or a test harness that calls the CLI
            # more than once in one process hit this every time.
            original_params = list(self.params)
            positional_params = [p for p in original_params
                                 if isinstance(p, click.Argument)]
            if positional_params:
                self.params = [p for p in original_params
                               if not isinstance(p, click.Argument)]
                try:
                    result = super().parse_args(ctx, args)
                    # The group callback still runs (invoke_without_command
                    # groups invoke it before the subcommand); it expects the
                    # positional to exist. With the subcommand claiming the
                    # free-form token, the query path is simply unused.
                    ctx.params.setdefault("query", None)
                    return result
                finally:
                    self.params = original_params
        return super().parse_args(ctx, args)


def _get(path: str) -> dict:
    resp = httpx.get(f"{BASE}{path}", timeout=30)
    resp.raise_for_status()
    return resp.json()


def _post(path: str, data: dict = None) -> dict:
    resp = httpx.post(f"{BASE}{path}", json=data or {}, headers={"X-OCBrain-Local": "1"}, timeout=120)
    resp.raise_for_status()
    return resp.json()


@click.group(invoke_without_command=True, cls=SubcommandFirstGroup)
@click.pass_context
@click.argument("query", required=False)
@click.option("--module", "-m", default=None, help="Force a specific module")
def cli(ctx, query, module):
    """OCBrain — local AI assistant."""
    if ctx.invoked_subcommand:
        return

    # Support pipe: echo "query" | ocbrain
    if not query and not sys.stdin.isatty():
        query = sys.stdin.read().strip()

    if query:
        try:
            result = _post("/query", {"query": query, "module": module})
            console.print(result.get("answer", "No answer returned."))
        except httpx.ConnectError:
            console.print("[red]OCBrain is not running. Start it with: ocbrain-start[/red]")
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")


@cli.command()
def status():
    """Show module health and maturity status."""
    try:
        data = _get("/status")
        table = Table(title="OCBrain Module Status")
        table.add_column("Module",  style="cyan")
        table.add_column("Stage",   style="magenta")
        table.add_column("Score",   style="green")
        table.add_column("Queries", style="yellow")
        table.add_column("KB Chunks")
        for name, info in data.get("modules", {}).items():
            table.add_row(
                name,
                info.get("stage", "?"),
                f"{info.get('maturity_score', 0):.2f}",
                str(info.get("query_count", 0)),
                str(info.get("kb_chunks", 0)),
            )
        console.print(table)
    except Exception as e:
        console.print(f"[red]{e}[/red]")


@cli.command()
@click.argument("module_name")
def train(module_name):
    """Manually trigger a training run for a module."""
    console.print(f"[yellow]Triggering training for '{module_name}'...[/yellow]")
    try:
        result = _post(f"/train/{module_name}")
        console.print(result.get("result", "Done."))
    except Exception as e:
        console.print(f"[red]{e}[/red]")


@cli.command(name="new-module")
def new_module():
    """Interactive wizard to create a new expert module."""
    console.print("[bold cyan]New Expert Module Creator[/bold cyan]")
    name     = click.prompt("Module name (e.g. finance)")
    desc     = click.prompt("Description")
    model    = click.prompt("Bootstrap model", default="mistral")
    kw_str   = click.prompt("Keywords (comma-separated)")
    src_str  = click.prompt("Source URLs (comma-separated, or press Enter to skip)", default="")
    keywords = [k.strip() for k in kw_str.split(",") if k.strip()]
    sources  = [s.strip() for s in src_str.split(",") if s.strip()]
    try:
        _post("/modules/new", {
            "name": name, "desc": desc, "model": model,
            "keywords": keywords, "sources": sources,
        })
        console.print(f"[green]Module '{name}' created successfully.[/green]")
    except Exception as e:
        console.print(f"[red]{e}[/red]")


@cli.command()
def update():
    """Check for and install available updates."""
    try:
        info = _get("/updates")

        if info.get("check_failed"):
            console.print(f"[yellow]Could not check for updates: {info.get('check_error')}[/yellow]")
            return

        current = info.get("current", "?")
        if info.get("available"):
            latest = info.get("version", "?")
            console.print(f"[green]Update available: v{current} → v{latest}[/green]")
            if info.get("changelog"):
                console.print(f"[dim]{info['changelog']}[/dim]")
            if click.confirm("Install now?"):
                console.print("[yellow]Installing... this runs git pull + pip install.[/yellow]")
                result = _post("/update/install")
                console.print(f"[green]{result.get('message', 'Done.')}[/green]")
                if result.get("status") == "installing":
                    console.print("[yellow]Restart OCBrain when update completes:[/yellow]")
                    console.print("  Ctrl+C → python main.py")
        else:
            console.print(f"[green]OCBrain v{current} is up to date.[/green]")

    except httpx.ConnectError:
        console.print("[red]OCBrain is not running. Start it with: source .venv/bin/activate && python main.py[/red]")
    except Exception as e:
        console.print(f"[red]{e}[/red]")


# ── Rev 3 (G4-FTS remediation): local memory maintenance commands ────────────
#
# These commands run LOCALLY on the machine holding the database files and
# deliberately do NOT go through the daemon HTTP API: migration and full
# verification must happen while every OCBrain process is STOPPED and drained
# (deployment contract, Amendment 2 §C). A live process would hold WAL state
# and could revive a WAL after the maintenance runner's final checkpoint.
#
# Default database path follows the configured memory database:
#   settings.toml → [memory] database   (fallback: .data/memory/unified.db)


def _memory_db_path(db: str | None) -> str:
    if db:
        return db
    try:
        from core.config import config
        return str(config.get("memory.database") or ".data/memory/unified.db")
    except Exception:
        return ".data/memory/unified.db"


def _open_inspection_connection(db_path: str):
    """
    STRICTLY read-only inspection connection (REV-G4-01) — used by
    `memory-doctor` and every other diagnostic that must observe without
    any possibility of mutation.

    Contract:
      * a missing database is refused before any connection attempt
        (never created);
      * the open uses the mode=ro URI — SQLite cannot checkpoint, recover,
        convert a journal mode, alter schema/content, or create the
        database/-wal/-shm artifacts through it;
      * if the read-only open FAILS (e.g. a WAL state that cannot be
        inspected without recovery, or an unreadable -shm), the error is
        re-raised fail-closed: there is NO write-capable fallback. The
        caller reports the inspection as unavailable rather than risk
        mutating the very state it is diagnosing.
    """
    import os
    import sqlite3
    from core.memory.sqlite_contract import sqlite_file_uri
    if not os.path.exists(db_path):
        raise sqlite3.OperationalError(
            f"database file does not exist: {db_path} — refusing to create "
            "it from a read-only diagnostic (no file, header or sidecar was "
            "written)")
    try:
        return open_database(db_path, mode="ro", timeout=20.0)
    except sqlite3.Error as exc:
        raise sqlite3.OperationalError(
            f"read-only inspection open failed for {db_path}: {exc} — "
            "failing closed: no write-capable fallback is used for "
            "inspection (a writable open could checkpoint, recover or "
            "modify the database being diagnosed)") from exc


def _open_verify_connection(db_path: str):
    """
    Open the FULL-VERIFICATION connection (REV-G4-01: deliberately SEPARATE
    from the doctor's inspection connection).

    The FTS5 `integrity-check(rank=1)` command is a read operation on the
    database image but is implemented as an INSERT on the FTS virtual table,
    so SQLite treats it as a WRITE and refuses it on read-only connections
    ("attempt to write a readonly database"). `memory-verify` therefore
    needs a read-write connection; every executed statement is non-mutating
    by contract, and the command records logical/physical before-after
    evidence to support that claim.

    This writability is NOT justified for `memory-doctor` (which never runs
    the rank=1 check): the doctor uses `_open_inspection_connection` above.
    A missing database is refused before any connection attempt (never
    created).
    """
    import os
    import sqlite3
    if not os.path.exists(db_path):
        raise sqlite3.OperationalError(
            f"database file does not exist: {db_path} — refusing to create "
            "it from a read-only diagnostic (no file, header or sidecar was "
            "written)")
    return open_database(db_path, timeout=20.0)


def _print_migration_report(report) -> None:
    """Render a MaintenanceReport (from core.memory.sqlite_migration)."""
    console.print(f"  database: [cyan]{report.db_path}[/cyan]")
    est = report.space_estimate or {}
    console.print(
        f"  space estimate (estimate, not a guarantee): "
        f"~{est.get('estimate_extra_bytes', '?')} bytes extra; "
        f"free: {est.get('free_bytes', '?')} bytes")
    table = Table(title="Migration steps")
    table.add_column("Step", style="cyan")
    table.add_column("Status", style="green")
    table.add_column("Detail")
    for step in report.steps:
        table.add_row(step.get("step", "?"), step.get("status", "?"),
                      step.get("detail", ""))
    console.print(table)

    ver = report.verification or {}
    if ver.get("passed") is not None:
        console.print(
            f"  verification: passed={ver.get('passed')} "
            f"total_cost_s={ver.get('total_cost_s')}")
        for finding in ver.get("findings", []):
            status = finding.get("status", "?")
            style = "[green]" if status in ("pass", "not_applicable") else "[red]"
            console.print(
                f"    {style}[{status}][/] {finding.get('scope')} / "
                f"{finding.get('name')}: {finding.get('detail')}")
    if report.ledger_row:
        console.print(f"  ledger row recorded: {report.ledger_row}")
    if report.checkpoint:
        console.print(f"  post-commit checkpoint: {report.checkpoint}")
    console.print(
        f"  WAL bytes before/after: "
        f"{report.wal_bytes_before} -> {report.wal_bytes_after}")
    if report.failure:
        console.print(f"  [red]failure:[/] {report.failure}")
    if report.remediation:
        console.print(f"  [yellow]remediation:[/] {report.remediation}")
    if report.preserved_files:
        console.print(
            f"  [red]corrupt database preserved (not rebuilt); copies:[/red] "
            f"{report.preserved_files}")


_MIGRATION_DEPLOYMENT_CONTRACT = (
    "Deployment contract (Amendment 2 §C): migration runs ONLY with all\n"
    " OCBrain processes stopped and drained on this machine. Live mutations\n"
    " during migration invalidate its locks; the final WAL checkpoint would\n"
    " be silently undone by a concurrently opened connection.")


@cli.command(name="memory-migrate")
@click.option("--db", "db", default=None,
              help="Database file to migrate (default: configured "
                   "[memory] database, e.g. .data/memory/unified.db)")
@click.option("--skip-checkpoint", is_flag=True, default=False,
              help="Do not run the post-commit WAL checkpoint")
def memory_migrate(db, skip_checkpoint):
    """Run the deferred memory migration while the app is STOPPED.

    Migrates one SQLite memory database to the Rev 3 canonical contract
    (canonical triggers, FTS external-content rebuild, indexes, ledger row,
    verification). Concurrent invocations are serialized by SQLite and an
    advisory lock file; a second runner re-reads state after locking and
    reports 'already_applied' when the first one has finished.
    """
    console.print("[bold yellow]" + _MIGRATION_DEPLOYMENT_CONTRACT +
                  "[/bold yellow]")
    db_path = _memory_db_path(db)
    console.print(f"[cyan]Migrating {db_path} …[/cyan]")
    try:
        from core.memory.sqlite_migration import run_maintenance_migration
        report = run_maintenance_migration(
            db_path, run_final_checkpoint=not skip_checkpoint)
    except Exception as e:
        console.print(f"[red]migration abort: {e}[/red]")
        raise SystemExit(1)

    console.print(f"[bold]outcome:[/bold] {report.outcome}")
    _print_migration_report(report)
    if report.outcome == "migrated":
        console.print("[green]Migration committed and verified. "
                      "Start OCBrain normally.[/green]")
    elif report.outcome == "migrated_post_commit_fault":
        # Independent Rev 3 fix (checklist C): a fault AFTER the commit is
        # reported as committed-for-real, not as a rolled-back failure.
        console.print(
            "[yellow]Migration COMMITTED and durable; a fault interrupted "
            "only the post-commit epilogue (checkpoint / WAL measurement). "
            "Nothing rolled back. Re-run memory-migrate — it reports "
            "already_applied with no side effects — or re-run with "
            "--skip-checkpoint to redo the epilogue without it.[/yellow]")
    elif report.outcome == "already_applied":
        console.print("[yellow]No work: migration already applied "
                      "(re-read after lock).[/yellow]")
    elif report.outcome == "preserved_corrupt":
        console.print("[red]Database corruption detected — the database was "
                      "NOT modified or rebuilt. Invoke memory recovery "
                      "procedures.[/red]")
        raise SystemExit(1)
    else:
        raise SystemExit(1)

    # Independent Rev 3 fix (checklist E): a successful migration states the
    # runtime-certification caveat — the migration fixes the FTS trigger
    # CONTRACT, not the SQLite runtime; full readiness still requires an
    # approved runtime verdict (computed WITH the configured vendor
    # provenance, matching the backend constructor).
    if report.outcome in ("migrated", "migrated_post_commit_fault",
                          "already_applied"):
        from core.memory.sqlite_runtime import (
            classify_wal_safety,
            collect_runtime_inventory,
            load_configured_vendor_provenance,
        )
        verdict = classify_wal_safety(
            collect_runtime_inventory(),
            approved_vendor_builds=load_configured_vendor_provenance())
        if verdict.wal_safe:
            console.print(
                f"[green]Runtime verdict on THIS machine: "
                f"{verdict.decision} (wal_safe=True).[/green]")
        else:
            console.print(
                f"[yellow]Runtime-certification caveat (SQLite runtime on "
                f"THIS machine): {verdict.decision} (wal_safe=False). "
                "The migration re-established the FTS delete-command "
                "CONTRACT but cannot change the runtime; full memory "
                "readiness still requires an approved runtime "
                "(fix line >= 3.51.3, a documented backport, or a vendor "
                "build admitted on provenance). Details: memory-doctor."
                "[/yellow]")


@cli.command(name="memory-doctor")
@click.option("--db", "db", default=None,
              help="Database file to inspect (default: configured "
                   "[memory] database)")
@click.option("--json", "as_json", is_flag=True, default=False,
              help="Emit the full inventory as JSON")
def memory_doctor(db, as_json):
    """Read-only diagnosis: SQLite runtime gate + checkpoint inventory +
    migration state. Writes nothing to the database: every inspection
    connection is strictly read-only (mode=ro, no write-capable fallback —
    REV-G4-01), the checkpoint inventory collects filesystem facts without
    opening a writable connection, and a WAL state that cannot safely be
    inspected read-only is reported as UNAVAILABLE, never as a pass."""
    import json as _json
    import sqlite3
    from core.memory.sqlite_migration import (
        collect_checkpoint_inventory,
        inspect_migration_state,
    )
    from core.memory.sqlite_integrity import validate_readiness
    from core.memory.sqlite_runtime import (
        classify_wal_safety,
        collect_runtime_inventory,
        load_configured_vendor_provenance,
        resolve_gate_mode,
    )
    from core.memory.sqlite_contract import MemoryReadinessError

    db_path = _memory_db_path(db)
    inventory: dict = {"database": db_path}

    # 1. Runtime compatibility inventory + verdict (Amendment 1).
    # Independent Rev 3 fix (checklist E): the CLI verdict is computed WITH
    # the configured vendor provenance records (Amendment 1 §C), matching
    # what the backend constructor does — the pre-fix bare
    # classify_wal_safety() call could disagree with the backend's verdict
    # for deployments that registered an approved vendor build.
    runtime_inv = collect_runtime_inventory()
    decision = classify_wal_safety(
        runtime_inv, approved_vendor_builds=load_configured_vendor_provenance())
    inventory["runtime"] = runtime_inv
    inventory["runtime_decision"] = {
        "decision": decision.decision,
        "wal_safe": decision.wal_safe,
        "affected_by_wal_reset_bug": decision.affected_by_wal_reset_bug,
        "full_wal_support": decision.full_wal_support,
        "reason": decision.reason,
        "remediation": decision.remediation,
        "vendor_evidence": decision.vendor_evidence,
    }
    inventory["gate_mode"] = resolve_gate_mode()

    if not as_json:
        console.print("[bold]SQLite runtime gate[/bold] "
                      f"(mode={inventory['gate_mode']})")
        console.print(f"  python: {runtime_inv['python_version']}")
        console.print(f"  sqlite3.sqlite_version: "
                      f"{runtime_inv['sqlite3_sqlite_version']}")
        console.print(f"  SELECT sqlite_version(): "
                      f"{runtime_inv['sqlite_version_sql']}")
        console.print(f"  sqlite_source_id: {runtime_inv['sqlite_source_id']}")
        console.print(f"  platform: {runtime_inv['os']}")
        console.print(f"  verdict: {decision.decision} "
                      f"(wal_safe={decision.wal_safe}, "
                      f"full_wal_support={decision.full_wal_support})")
        console.print(f"  reason: {decision.reason}")
        if decision.remediation:
            console.print(f"  remediation: {decision.remediation}")

    # 2. Checkpoint inventory (Amendment 10) — filesystem facts + a strictly
    #    read-only connection (REV-G4-01: no writable connection is opened;
    #    an uninspectable WAL state is reported as unavailable).
    inventory["checkpoint_inventory"] = collect_checkpoint_inventory(db_path)

    # 3. Migration state + readiness (strict read-only inspection only,
    #    never enforcement — REV-G4-01/08).
    inventory.setdefault("migration_state", None)
    inventory.setdefault("readiness", None)
    try:
        conn = _open_inspection_connection(db_path)
        try:
            state = inspect_migration_state(conn)
            inventory["migration_state"] = {
                "schema_state": state.state,
                "detail": state.finding,
                "remediation": state.remediation,
            }
            inventory["readiness"] = validate_readiness(conn)
        finally:
            conn.close()
    except sqlite3.Error as e:
        # REV-G4-08: an inspection that could not run is reported as
        # UNAVAILABLE — never as "unreadable data" or a pass.
        inventory["migration_state"] = {
            "schema_state": "unavailable",
            "detail": str(e),
            "remediation": ("the database state could not be inspected "
                            "read-only; nothing was modified to obtain a "
                            "result — investigate the WAL/journal state "
                            "with all processes stopped")}
        inventory["readiness"] = None
    except MemoryReadinessError as e:
        inventory["migration_state"] = {"schema_state": "refused",
                                        "detail": str(e)}
        inventory["readiness"] = None

    if not as_json:
        ci = inventory["checkpoint_inventory"]
        console.print("[bold]Checkpoint inventory[/bold]")
        console.print(f"  wal_bytes: {ci.get('wal_bytes')}")
        console.print(f"  automatic checkpointing: "
                      f"{ci.get('automatic_checkpointing')}")
        cf = ci.get("connection_facts") or {}
        if cf.get("unavailable"):
            console.print(
                f"  [yellow]connection facts: UNAVAILABLE — {cf.get('error')}"
                "[/yellow]")
        ms = inventory.get("migration_state", {}) or {}
        console.print(f"[bold]Migration state:[/] {ms}")
        rd = inventory.get("readiness")
        if rd:
            console.print("[bold]Readiness (inspection only; this command "
                          "does not gate the app):[/bold]")
            console.print(f"  passed={rd.get('passed')} "
                          f"cost_s={rd.get('total_cost_s')}")
            for finding in rd.get("checks", []):
                status = finding.get("status")
                style = "[green]" if status in ("pass", "not_applicable") \
                    else "[red]"
                console.print(
                    f"    {style}[{status}][/] {finding.get('name')}: "
                    f"{finding.get('detail')}")
        elif ms.get("schema_state") == "unavailable":
            console.print(
                "[yellow]Readiness: NOT EVALUATED — the inspection could "
                "not run (see above); this is not a pass.[/yellow]")
    else:
        # click.echo, NOT console.print: rich wrapping reflows long strings
        # and produces UNPARSEABLE JSON — the machine-readable channel must
        # be byte-exact (REV-G4-08).
        _json_output = _json.dumps(inventory, indent=2, default=str)
        click.echo(_json_output)


@cli.command(name="memory-verify")
@click.option("--db", "db", default=None,
              help="Database file to verify (default: configured "
                   "[memory] database)")
@click.option("--json", "as_json", is_flag=True, default=False,
              help="Emit the verification contract as machine-readable JSON "
                   "(the verdict and the exit code are identical to the "
                   "text output)")
def memory_verify(db, as_json=False):
    """Run the FULL memory integrity validation now (Amendment 3 — C).

    Explicitly runs every check that normal startup intentionally skips:
    whole-database integrity_check, foreign_key_check (when applicable),
    the FTS5 rank=1 integrity command and real MATCH retrieval probes — plus
    the schema/trigger/index/housekeeping contracts and the complete logical
    content digest.

    R4-04: `--json` ALWAYS emits exactly one JSON object on stdout, also on
    every early refusal and every failure path; the payload and the exit code
    agree; no diagnostic text pollutes stdout (diagnostics go to stderr in
    JSON mode).

    R4-05: when a writable open could consume recovery evidence, the raw
    artifact set is preserved FORENSICALLY (that snapshot is retained) and the
    writable verification runs against a MANAGED, disposable copy that is
    removed when the command finishes — the original is never verified
    write-capable in that case, and never modified.

    R5-02 — ONE finalization path.  The Round-4 implementation emitted the
    JSON from its failure helper BEFORE the cleanup had run, so the payload
    could report a stale `verification_target_removed` and a cleanup failure
    could be swallowed while the command still exited 0.  The lifecycle is
    now strictly ordered and there is exactly ONE place that serialises the
    payload:

        1. initialize the payload;
        2. determine the intended verification target;
        3. preserve recovery evidence where required;
        4. create the disposable verification workspace (if required);
        5. record the intended disposable target IMMEDIATELY;
        6. copy the required database artifacts;
        7. verify the copied artifact sizes and hashes;
        8. open and inspect ONLY the disposable target;
        9. close every connection and cursor;
       10. attempt the disposable-workspace cleanup;
       11. establish the ACTUAL cleanup result;
       12. finalise the complete payload;
       13. emit exactly one JSON object;
       14. return the exit status that agrees with the payload.

    The result semantics are explicit:

      * ``contract_passed``   — every required integrity-contract check
        executed AND passed;
      * ``contract_assessed`` — the integrity contract was actually assessed;
      * ``contract_verdict``  — ``PASS`` / ``FAIL`` / ``INCOMPLETE``;
      * ``cleanup_ok``        — every required temporary resource was removed;
      * ``ok``                — the COMPLETE command lifecycle succeeded;
      * ``verification_target_removed`` — ``true`` (a workspace was created and
        is confirmed removed), ``false`` (it remains wholly or partially) or
        ``null`` (no workspace was created);
      * ``cleanup_error``     — reported SEPARATELY from ``error``.

    A cleanup failure never corrupts the integrity verdict: the contract can
    report ``PASS`` while ``cleanup_ok`` is ``false``, ``ok`` is ``false`` and
    the exit code is 1.
    """
    import hashlib as _hashlib
    import json as _json
    import os
    import shutil as _shutil
    import sqlite3
    import sys as _sys
    import tempfile as _tempfile
    import time

    from core.memory.sqlite_contract import FTS_TABLE
    from core.memory.sqlite_integrity import (
        audit_housekeeping_contract,
        audit_index_contract,
        audit_trigger_contract,
        logical_content_digest,
        read_fts_configuration,
        read_secure_delete_policy,
        run_full_integrity_validation,
        verify_content_row_identity,
    )

    db_path = _memory_db_path(db)

    class _VerifyAbort(Exception):
        """Internal control-flow signal: a stage failed."""

        def __init__(self, stage, exc=None, message=None, **extra):
            super().__init__(message or (str(exc) if exc is not None
                                         else "verification failed"))
            self.stage = stage
            self.exc = exc
            self.message = message
            self.extra = extra

    def _abort(stage, exc=None, message=None, **extra):
        raise _VerifyAbort(stage, exc, message, **extra)

    # ── (1) the payload ──────────────────────────────────────────────────
    payload = {
        "database": db_path,
        "ok": False,
        "contract_passed": False,
        "contract_assessed": False,
        "contract_verdict": "INCOMPLETE",
        "cleanup_ok": True,
        "checks_ran": False,
        "error": None,
        "cleanup_error": None,
        "cleanup_errors": [],
        "contract": {},
        "validation": {"passed": False, "findings": [], "total_cost_s": 0.0},
        "content_row_identity": {"passed": False, "checks": []},
        "fts_configuration": {},
        "trigger_contract": {},
        "index_contract": {},
        "housekeeping_ledger": {},
        "verification_target": db_path,
        "verification_target_removed": None,
        "verification_workspace": None,
        "recovery_evidence_preserved": [],
        "preservation": None,
        "logical_before": None,
        "logical_after": None,
        "logical_unchanged": None,
        "total_cost_s": None,
        "wall_cost_s": None,
        "physical_state": "not evaluated",
        "verdict_scope": "the original database",
        "exit_code": 1,
    }

    def _diagnostic(text: str) -> None:
        """Diagnostics never pollute stdout in JSON mode."""
        if as_json:
            print(text, file=_sys.stderr)
        else:
            console.print(text)

    def _file_sha256(path: str) -> str:
        """SHA-256 of a file (used to verify a disposable copy against its
        source before it is opened)."""
        h = _hashlib.sha256()
        with open(path, "rb") as fh:
            for chunk in iter(lambda: fh.read(1 << 20), b""):
                h.update(chunk)
        return h.hexdigest()

    def _logical_facts(c):
        """The FULL logical digest: every stored value of the content table
        plus the hidden-rowid mapping, alongside the schema identity."""
        schema = c.execute(
            "SELECT name, sql FROM sqlite_schema WHERE sql IS NOT NULL "
            "ORDER BY name").fetchall()
        digest = logical_content_digest(c)
        return {
            "schema_sha256": _hashlib.sha256(
                repr(schema).encode("utf-8")).hexdigest(),
            "content_rows": digest["rows"],
            "content_sha256": digest["sha256"],
            "rowid_mapping_sha256": _hashlib.sha256(
                repr(digest["rowid_mapping"]).encode("utf-8")).hexdigest(),
        }

    def _probe_token(c):
        """A real token from the content table (so the MATCH probe is a
        POSITIVE test); None when the database holds no content."""
        try:
            row = c.execute(
                "SELECT content FROM knowledge_entries "
                "WHERE content IS NOT NULL AND content <> '' LIMIT 1"
            ).fetchone()
        except sqlite3.Error:
            return None
        if not row:
            return None
        for word in str(row[0]).split():
            token = "".join(ch for ch in word if ch.isalnum())
            if len(token) >= 4:
                return token.lower()
        return None

    def _remaining_entries(directory: str):
        """The entries that still exist under `directory`."""
        remaining = []
        for dirpath, dirnames, filenames in os.walk(directory):
            for name in list(dirnames) + list(filenames):
                remaining.append(os.path.join(dirpath, name))
        return sorted(remaining)

    def _record_cleanup_error(target, stage, exc=None, message=None,
                              remaining=None, workspace=None):
        """
        Record a cleanup failure.

        `cleanup_error` holds the FIRST cleanup failure (the primary one);
        `cleanup_errors` holds every cleanup failure.  A later failure must
        never overwrite an earlier one — a close failure and a workspace
        cleanup failure are two different facts.
        """
        entry = {
            "stage": stage,
            "type": (type(exc).__name__ if exc is not None else "Error"),
            "message": message or (str(exc) if exc is not None
                                   else "cleanup failed"),
            "remaining": remaining,
            "workspace": workspace,
        }
        target.setdefault("cleanup_errors", []).append(entry)
        if target.get("cleanup_error") is None:
            target["cleanup_error"] = entry
        return entry

    # ── (2)…(8) the verification flow ─────────────────────────────────────
    def _run() -> None:
        if not os.path.exists(db_path):
            _abort("path_check", message=(
                f"database does not exist: {db_path} — verification refuses "
                "to create database files (nothing was written). Point it at "
                "an existing memory database. A fresh database is created "
                "only by the application's own initialization path (start "
                "OCBrain once on this configured database path); "
                "`memory-migrate` NEVER creates or initializes a database "
                "(REV-G4-04)."))
        if not as_json:
            console.print(f"[cyan]Verifying {db_path} —[/cyan]")

        fs_before = {
            p: (os.path.getsize(p) if os.path.exists(p) else None)
            for p in (db_path, db_path + "-wal", db_path + "-shm",
                      db_path + "-journal")
        }

        # R4-18/F28: can a writable open consume recovery evidence?
        sidecars = {s: os.path.exists(db_path + s)
                    for s in ("-wal", "-shm", "-journal")}
        recovery_risk = bool(sidecars["-journal"] or
                             (sidecars["-wal"] and not sidecars["-shm"]))

        verify_target = db_path
        if recovery_risk:
            # (3) preserve the recovery evidence FORENSICALLY.  The
            # preservation directory is INDEPENDENT of the disposable
            # verification workspace and is never touched by the cleanup.
            from core.memory.sqlite_migration import (
                PreservationError, _preserve_recoverable_state)
            try:
                preserved = _preserve_recoverable_state(
                    db_path,
                    "memory-verify: recovery evidence preserved before a "
                    "writable open (the original's WAL / rollback-journal "
                    "state was preserved first)")
            except PreservationError as exc:
                payload["recovery_evidence_preserved"] = list(exc.verified)
                payload["preservation"] = {
                    "disposition": "incomplete",
                    "destination_dir": exc.destination_dir,
                    "manifest_path": exc.manifest_path,
                    "failed_file": exc.failed_file,
                    "error": exc.error,
                    "manifest_written": exc.manifest_written,
                }
                _abort("recovery_preservation", exc,
                       message=(f"the recovery evidence could not be "
                                f"preserved completely ({exc.stage}): "
                                f"{exc.error}; the partial set is at "
                                f"{exc.destination_dir}"))
            payload["recovery_evidence_preserved"] = list(preserved)
            payload["preservation"] = {
                "disposition": "complete",
                "destination_dir": os.path.dirname(preserved[0])
                if preserved else None,
                "manifest_path": os.path.join(
                    os.path.dirname(preserved[0]), "manifest.json")
                if preserved else None,
            }

            # (4) create the disposable verification workspace.
            try:
                copy_dir = _tempfile.mkdtemp(prefix="ocbrain-verify-copy-")
            except OSError as exc:
                _abort("workspace_create", exc,
                       message=(f"the disposable verification workspace "
                                f"could not be created: {exc}"))
            # (5) record the intended disposable target IMMEDIATELY — before
            # a single byte is copied — so a later failure still reports
            # the INTENDED target and never the original database.
            copy_path = os.path.join(copy_dir, "memory.db")
            payload["verification_workspace"] = copy_dir
            payload["verification_target"] = copy_path
            payload["verdict_scope"] = (
                "a DISPOSABLE COPY — the original's recovery evidence (WAL / "
                "rollback journal) was preserved first, so the writable "
                "verification could not consume it; the original file was "
                "not modified by this command. The copy is a temporary "
                "artifact and is REMOVED when the command finishes.")

            # (6) copy the required artifacts.
            for suffix in ("", "-wal", "-shm", "-journal"):
                src = db_path + suffix
                if not os.path.exists(src):
                    continue
                dst = copy_path + suffix
                try:
                    _shutil.copy2(src, dst)
                except OSError as exc:
                    _abort("disposable_copy", exc,
                           message=(f"the disposable verification copy "
                                    f"could not be created: {exc}"))
                # (7) verify the copied artifact against its source.
                try:
                    src_size = os.path.getsize(src)
                    dst_size = os.path.getsize(dst)
                    src_hash = _file_sha256(src)
                    dst_hash = _file_sha256(dst)
                    if src_size != dst_size or src_hash != dst_hash:
                        raise OSError(
                            f"the copied artifact {dst} does not match its "
                            f"source {src} (size {dst_size} != {src_size}, "
                            f"sha256 {dst_hash} != {src_hash})")
                except OSError as exc:
                    _abort("disposable_copy", exc,
                           message=(f"the disposable verification copy did "
                                    f"not match its source: {exc}"))
            verify_target = copy_path

        # (8) open and inspect ONLY the disposable target.
        try:
            conn = open_database(verify_target, mode="rw", timeout=20.0)
        except sqlite3.Error as exc:
            _abort("open", exc,
                   message=f"cannot open {db_path} for verification: {exc}")

        t0 = time.time()
        result = {"passed": False, "findings": [], "total_cost_s": 0.0}
        identity = {"passed": False, "checks": []}
        config, trig, secure = {}, {}, {}
        idx_audit, housekeeping = {}, {}
        logical_before = logical_after = None
        checks_ran = True
        try:
            logical_before = _logical_facts(conn)
            token = _probe_token(conn)
            result = run_full_integrity_validation(
                conn, retrieval_tokens=((token, True),) if token else ())
            identity = verify_content_row_identity(conn)
            config = read_fts_configuration(conn)
            trig = audit_trigger_contract(conn)
            secure = read_secure_delete_policy(conn)
            idx_audit = audit_index_contract(conn)
            housekeeping = audit_housekeeping_contract(conn)
            logical_after = _logical_facts(conn)
        except sqlite3.Error as exc:
            checks_ran = False
            _diagnostic(f"[red]verification battery could not complete: "
                        f"{type(exc).__name__}: {exc}[/red]")
        finally:
            # (9) close every connection and cursor.
            try:
                cursor = conn.cursor()
                cursor.close()
            except sqlite3.Error:
                pass
            try:
                conn.close()
            except sqlite3.Error as exc:
                _record_cleanup_error(payload, "connection_close", exc)

        wall_cost = time.time() - t0
        fs_after = {
            p: (os.path.getsize(p) if os.path.exists(p) else None)
            for p in (db_path, db_path + "-wal", db_path + "-shm",
                      db_path + "-journal")
        }
        logical_unchanged = (
            checks_ran and logical_before is not None
            and logical_after == logical_before)

        # W22: the explicit full-verification acceptance contract
        def _finding(scope, name=None):
            for f in result.get("findings", []):
                if f.get("scope") == scope and (name is None
                                                or f.get("name") == name):
                    return f
            return None

        def _req(name, ok, detail, na_justification=None):
            if ok:
                return {"status": "pass", "detail": detail}
            if na_justification:
                return {"status": "not_applicable",
                        "detail": na_justification}
            return {"status": "fail", "detail": detail}

        structural_f = _finding("sqlite_structural_integrity")
        fk_f = _finding("foreign_key_consistency")
        fts_f = _finding("fts_internal_external_content_integrity")
        retrieval_f = _finding("fts_retrieval_health")
        empty_db = bool(logical_before
                        and logical_before.get("content_rows") == 0)

        contract = {
            "structural_integrity": _req(
                "structural_integrity",
                bool(structural_f) and structural_f.get("status") == "pass",
                (structural_f or {}).get("detail", "the check did not run")),
            "foreign_keys": _req(
                "foreign_keys",
                bool(fk_f) and fk_f.get("status") in ("pass", "not_applicable"),
                (fk_f or {}).get("detail", "the check did not run"),
                na_justification=(
                    "the database declares no foreign-key relationships"
                    if fk_f and fk_f.get("status") == "not_applicable"
                    else None)),
            "fts_rank1": _req(
                "fts_rank1",
                bool(fts_f) and fts_f.get("status") == "pass",
                (fts_f or {}).get("detail", "the check did not run")),
            "retrieval_probes": _req(
                "retrieval_probes",
                bool(retrieval_f) and retrieval_f.get("status") == "pass",
                (retrieval_f or {}).get("detail", "the check did not run"),
                na_justification=(
                    "the content table is empty, so no positive MATCH probe "
                    "can be asserted (this is an explicit justification, not "
                    "a silent pass)"
                    if empty_db else None)),
            "fts_configuration": _req(
                "fts_configuration",
                config.get("classification") == "canonical",
                f"classification={config.get('classification')!r} "
                f"{config.get('reason', '')}"),
            "trigger_contract": _req(
                "trigger_contract",
                trig.get("classification") == "canonical",
                f"classification={trig.get('classification')!r} "
                f"{trig.get('reason', '')}"),
            "index_contract": _req(
                "index_contract",
                idx_audit.get("classification") == "canonical",
                f"classification={idx_audit.get('classification')!r}"),
            "housekeeping_ledger": _req(
                "housekeeping_ledger",
                housekeeping.get("classification") == "canonical",
                f"classification={housekeeping.get('classification')!r} "
                f"{housekeeping.get('reason', '')}"),
            "content_row_identity": _req(
                "content_row_identity",
                bool(identity.get("passed")),
                f"identity is the FTS {identity.get('content_rowid', 'rowid')} "
                "column; hidden rowid persistence remains an OPEN risk"),
            "logical_digest_invariance": _req(
                "logical_digest_invariance",
                bool(logical_unchanged),
                "the type-aware logical digest (every stored value plus the "
                "hidden-rowid mapping) is identical before and after the "
                "checks"),
            "all_inspections_completed": _req(
                "all_inspections_completed",
                bool(checks_ran),
                "every required inspection executed"),
        }
        contract_ok = all(c["status"] in ("pass", "not_applicable")
                           for c in contract.values())

        payload.update({
            "contract_passed": contract_ok,
            "contract_assessed": bool(checks_ran),
            "contract_verdict": ("PASS" if contract_ok
                                  else ("FAIL" if checks_ran else "INCOMPLETE")),
            "checks_ran": checks_ran,
            "contract": contract,
            "validation": result,
            "content_row_identity": identity,
            "fts_configuration": config,
            "trigger_contract": trig,
            "index_contract": idx_audit,
            "housekeeping_ledger": housekeeping,
            "logical_before": logical_before,
            "logical_after": logical_after,
            "logical_unchanged": logical_unchanged,
            "total_cost_s": result.get("total_cost_s"),
            "wall_cost_s": wall_cost,
            "physical_state": (
                "sidecar bytes may change during ANY open of a live WAL "
                "database (checkpoint lifecycle); logical content is the "
                "verified invariant" if fs_before != fs_after
                else "no physical sidecar changes"),
        })

    # ── the flow, the cleanup and the single finalization ─────────────────
    try:
        _run()
    except _VerifyAbort as abort:
        payload["error"] = {
            "stage": abort.stage,
            "type": (type(abort.exc).__name__ if abort.exc is not None
                     else "Error"),
            "message": abort.message or str(abort),
        }
    except SystemExit:                                   # pragma: no cover
        raise
    except Exception as exc:
        payload["error"] = {
            "stage": "inspection",
            "type": type(exc).__name__,
            "message": f"verification failed: {type(exc).__name__}: {exc}",
        }
    finally:
        # (10)/(11) attempt the cleanup and establish the ACTUAL result.
        workspace = payload.get("verification_workspace")
        if not workspace:
            # No disposable workspace was created: the state is UNKNOWN by
            # construction, not "removed".
            payload["verification_target_removed"] = None
            payload["cleanup_ok"] = True
        else:
            cleanup_error = None
            try:
                _shutil.rmtree(workspace)
            except Exception as exc:
                cleanup_error = f"{type(exc).__name__}: {exc}"
            remaining = []
            if os.path.exists(workspace):
                remaining = _remaining_entries(workspace)
                if cleanup_error is None:
                    cleanup_error = (
                        "the disposable verification workspace still exists "
                        "after the cleanup attempt")
            payload["verification_target_removed"] = not os.path.exists(
                workspace)
            payload["cleanup_ok"] = (cleanup_error is None and not remaining)
            if cleanup_error is not None:
                _record_cleanup_error(payload, "workspace_cleanup",
                                      message=cleanup_error,
                                      remaining=remaining, workspace=workspace)

    # (12) finalise the complete payload.
    contract_passed = bool(payload["contract_passed"])
    cleanup_ok = bool(payload["cleanup_ok"])
    ok = bool(contract_passed and cleanup_ok and payload["error"] is None)
    payload["ok"] = ok
    payload["exit_code"] = 0 if ok else 1

    # (13) emit exactly ONE JSON object — the single authoritative
    #     serialization point of this command.
    if as_json:
        click.echo(_json.dumps(payload, indent=2, default=str))
    else:
        result = payload["validation"]
        identity = payload["content_row_identity"]
        config = payload["fts_configuration"]
        trig = payload["trigger_contract"]
        secure = payload.get("fts_configuration", {})
        logical_before = payload["logical_before"]
        logical_after = payload["logical_after"]
        contract = payload["contract"]
        table = Table(title="Memory integrity findings")
        table.add_column("Check", style="cyan")
        table.add_column("Status", style="green")
        table.add_column("s", style="dim")
        table.add_column("Detail")
        for finding in result["findings"]:
            status = finding.get("status", "?")
            style = ("[green]" if status in ("pass", "not_applicable")
                     else "[red]")
            table.add_row(f"{finding.get('scope')}/{finding.get('name')}",
                          f"{style}{status}[/]",
                          f"{finding.get('duration_s', 0):.4f}",
                          finding.get("detail", ""))
        console.print(table)
        console.print(f"  validation passed: "
                      f"{'[green]YES[/]' if result['passed'] else '[red]NO[/]'}"
                      + ("" if payload["checks_ran"] else
                         "  [red](the battery could NOT complete — this is "
                         "NOT a verified result)[/]"))
        wall_cost = payload["wall_cost_s"]
        wall_text = (f"{wall_cost:.4f}s"
                     if isinstance(wall_cost, (int, float)) else "n/a")
        console.print(f"  checks total_cost_s: "
                      f"{result.get('total_cost_s')} "
                      f"(wall {wall_text} incl. open/close)")
        if payload["logical_unchanged"]:
            console.print(f"  logical invariance (writable rank=1 proven "
                          f"non-mutating): [green]UNCHANGED[/green] — "
                          f"content digest "
                          f"{logical_before['content_sha256'][:16]} and "
                          f"rowid mapping "
                          f"{logical_before['rowid_mapping_sha256'][:16]} "
                          f"identical before and after "
                          f"({logical_before['content_rows']} rows)")
        else:
            console.print(f"  logical invariance: [red]"
                          f"{'NOT ESTABLISHED (checks could not run)' if not payload['checks_ran'] else 'CHANGED'}[/red]")
        console.print(f"  physical state: {payload['physical_state']}")
        console.print(f"  content-row identity: "
                      f"{'[green]PASSED[/]' if identity.get('passed') else '[red]FAILED[/]'}"
                      f" — identity is the FTS "
                      f"{identity.get('content_rowid', 'rowid')} column "
                      f"(hidden rowid persistence remains an OPEN risk)")
        if not identity.get("passed"):
            for finding in identity.get("checks", []):
                console.print(f"    [red]{finding.status}[/] "
                              f"{finding.name}: {finding.detail}")
        console.print(f"  FTS configuration: {config.get('classification')} "
                      f"({config.get('reason', '')})")
        console.print(f"  trigger contract: {trig.get('classification')} "
                      f"({trig.get('reason', '')})")
        console.print(f"  FTS table: [cyan]{FTS_TABLE}[/cyan]; "
                      f"secure-delete policy: "
                      f"({secure.get('fts5_secure_delete')}) (FTS5) / "
                      f"({secure.get('core_pragma_secure_delete')}) "
                      f"(SQLite core PRAGMA)")
        console.print("[bold]Verification contract (all required)[/bold]")
        for name, entry in contract.items():
            style = ("[green]"
                     if entry["status"] in ("pass", "not_applicable")
                     else "[red]")
            console.print(f"  {style}{entry['status']}[/] {name}: "
                          f"{entry['detail']}")
        console.print(f"  verdict scope: {payload['verdict_scope']}")
        console.print(f"  contract verdict: {payload['contract_verdict']} "
                      f"(assessed={payload['contract_assessed']}, "
                      f"passed={contract_passed})")
        console.print(f"  cleanup ok: {cleanup_ok}; verification target "
                      f"removed: {payload['verification_target_removed']}")
        if payload.get("cleanup_error"):
            console.print(f"  [red]cleanup error: "
                          f"{payload['cleanup_error']['message']}[/red]")
        if payload.get("recovery_evidence_preserved"):
            console.print(f"  recovery evidence preserved before the "
                          f"writable open: "
                          f"{len(payload['recovery_evidence_preserved'])} "
                          f"artifact(s) under "
                          f"{os.path.dirname(payload['recovery_evidence_preserved'][0])}")
        if payload.get("error"):
            console.print(f"  [red]{payload['error']['stage']}: "
                          f"{payload['error']['message']}[/red]")
        if not contract_passed or not payload["checks_ran"]:
            failed = [n for n, e in contract.items()
                      if e["status"] not in ("pass", "not_applicable")]
            console.print("[red]Verification FAILED: "
                          + (", ".join(failed) if failed
                             else "the checks did not run") + "[/red]")
        elif not cleanup_ok:
            console.print("[red]Verification contract PASSED, but the "
                          "disposable workspace cleanup FAILED — the overall "
                          "result is a FAILURE.[/red]")
        else:
            console.print("[green]Verification complete: every required "
                          "contract result passed.[/green]")

    # (14) the exit status agrees with the payload.
    raise SystemExit(payload["exit_code"])


@cli.command()
def rollback():
    """Roll back to the previous version."""
    if click.confirm("Roll back to the commit before the last update?"):
        try:
            result = _post("/rollback")
            if result.get("status") == "ok":
                console.print(f"[green]{result.get('message')}[/green]")
                console.print("[yellow]Restart OCBrain:[/yellow]  Ctrl+C → python main.py")
            else:
                console.print(f"[red]Rollback failed: {result.get('message')}[/red]")
        except Exception as e:
            console.print(f"[red]{e}[/red]")


if __name__ == "__main__":
    cli()
