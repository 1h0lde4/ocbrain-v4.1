# Independent review brief — verification block, revision 3 (OCBrain G4 documentation workstream)

You are asked to act as an **independent, adversarial reviewer in a fresh context**. This package contains a ~40-line bash verification block, the patch that embeds it into a handoff document, and the files needed to test both. It deliberately contains **no test results and no conclusions of the author**. Inspect the implementation itself, line by line; do not rely on anyone's claims. Report only what you can reproduce.

Governing statuses (do not change or imply otherwise): G4 OPEN · High · freeze-blocking. G5–G8 HELD. Freeze readiness NOT DECLARED. No implementation authorized. Nothing in this package is to be applied, committed or pushed anywhere.

## What is in the package

| Path | What it is |
|---|---|
| `rev3/verify_block_rev3.sh` | **The block under review** (revision 3, 38 lines). |
| `rev3/P1d_rev3_handoff_section7_18_verification_block_PROPOSED.patch` | Patch that embeds the block and new prose into `handoff.md`. |
| `base/handoff.md` | The file the patch applies to (copy of `handoff.md` at the pushed tree; patch paths are `a/handoff.md`, `b/handoff.md`). |
| `rev2/verify_block.sh` | The earlier block (revision 2), for comparison only. |
| `optional_item_I/` | Only for item I; open it **after** finishing items A to H. |
| `SHA256SUMS.txt` | Check that what you received matches. |

## What the block is for

A future engineer runs it (`bash verify.sh`, from a clone of the repository) to decide whether a pushed git branch checkpoint is intact.

**Contract.** It must print a line starting `PASS` and exit 0 **only if**, at its final live observation of the remote, all of this holds:

1. `origin` is the canonical repository `https://github.com/1h0lde4/ocbrain-v4.1` (SSH forms and a trailing `.git` accepted; credentials in the URL ignored and never printed).
2. The remote branch `docs/g4-fts-errata-handoff-oct2026` tip is a linear chain: T (transfer commit) → H (handoff commit; its parent is exactly T; it is the commit that adds `handoff.md`) → zero or more commits, each a single-parent child of the previous one that changes `handoff.md` and no other path.
3. `handoff.md` in the tip's tree is a regular, non-symlink, non-executable file (mode 100644).
4. The live remote tip equals the verified tip at the final observation.

Otherwise it must print `FAIL` lines and `TRANSFER INCOMPLETE — REMOTE CHECKPOINT NOT VERIFIED` and exit 1.

**Cardinal invariant:** it must **never** print PASS when the contract is not met. A false FAIL is a lesser defect.

## What to verify (for each item: try to break it, and say what you did)

- **A. Six cases revision 2 is suspected to get wrong.** Confirm independently, against **both** blocks, which one gives a false PASS: (i) the remote branch moves right after the block's first `git ls-remote`; (ii) `git ls-remote` prints the correct ref and then exits non-zero; (iii) `handoff.md` is a symbolic link in a later commit; (iv) `origin` is a fork or mirror with identical history; (v) only the final `git ls-remote` call fails; (vi) `handoff.md` has mode 100755.
- **B. Canonical remote identity.** A fork with identical history must fail; mirrors and proxies must fail closed. Also try look-alike URL forms: userinfo tricks (`host@evil`), a path containing `@github.com`, upper-case host, trailing slash, explicit port, `http` instead of `https`, ssh with a password, a URL with a query string.
- **C. `git ls-remote` handling.** Every call's exit status must be checked; a failed call must never yield PASS. Also try zero, two, or a differently named ref line; a tail-matching ref (for example `refs/heads/zz/<branch>`); unusual whitespace.
- **D. `handoff.md` integrity.** Regular file only. Try symlink, directory, executable bit, gitlink/submodule entry, a similar name, a different case.
- **E. Credential protection.** No remote URL, embedded credential or token may appear in any PASS/FAIL or diagnostic output of the whole run, including messages printed by git itself. Use a dummy token string in `origin` URLs of several forms; run the whole block with proxies disabled against dead loopback ports (`127.0.0.1:1`; no traffic may leave the machine); search all stdout and stderr for the dummy token.
- **F. The unavoidable race** between the block's final observation and the moment someone reads PASS. Does the prose in the patch state the guarantee accurately (neither overstated nor understated)?
- **G. Patch integrity.** (1) The block embedded in the patch (the fenced `bash` block; lines beginning `+   ` with that prefix stripped) must be byte-identical to `rev3/verify_block_rev3.sh`. (2) The patch must apply cleanly to `base/handoff.md` (in your own scratch git repository). (3) It must introduce no unrelated changes. The **intended** changes are only: (a) the "Handoff commit:" line in the file's section 7; (b) the wording of three bullets inside the entry headed "Related documents and earlier revision" in section 16; (c) step 2 of section 18 replaced by prose plus the block. Flag anything else. (4) Compare every claim in the new step-2 prose with what the block actually does; list each claim that is inaccurate or overstated.
- **H. Shell and git pitfalls in the code itself.** Word splitting, globbing, `set --` side effects, `pipefail`, command-substitution failures, unset variables, `rev-list` ordering, `diff-tree` options (renames, copies, mode-only changes, empty commits), grafts and replace refs, shallow clones.
- **I. Lower priority; only after A to H.** See `optional_item_I/`. Look only at how `check_addendum4.py` handles the governing status line `G4 OPEN · High · freeze-blocking. G5–G8 HELD. Freeze readiness NOT DECLARED.` (an exact-substring test, a last-line test and a gate-table status-word test). Judge, by reading and by testing on your own mutated copies of the addendum text, whether it rejects incorrect statuses (for example "G4 CLOSED"), ambiguous statements and duplicate or conflicting status lines elsewhere in the text. Report what it does not catch.

## How to work

- Work in a new, empty directory. Do not run anything from inside the package directory; copy files out. Do not touch any real repository and do not use the network (dead-port loopback connections as in item E are fine).
- Build throw-away synthetic repositories: a bare repository as `origin` (a local path) plus a clone. To run the block, copy it and substitute **only** the `CANON=`, `T=` and `H=` lines (`CANON` must equal the synthetic origin path without the `.git` suffix; `T` and `H` are the synthetic commit hashes); leave every other line unchanged. A wrapper named `git`, placed first in `PATH` and calling the real git by absolute path, can simulate transport behaviour (a remote that moves between calls, a command that exits non-zero after printing).
- Use `GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null`, fixed author and committer variables, `GIT_TERMINAL_PROMPT=0`.
- Aim for about 25 distinct scenarios. Save a running report as you go, not only at the end.

## What to report

1. **First line:** `SUBSTANTIVE FINDINGS: yes` or `SUBSTANTIVE FINDINGS: no`. *Substantive* means: any reproduced false PASS of the revision 3 block; any reproduced output of a credential or URL; any claim in the patch prose that the block does not satisfy. A reproduced false FAIL alone is **not** substantive; list it as minor.
2. **For every issue:** short title; class (FALSE PASS / FALSE FAIL / SECRET OUTPUT / PROSE INACCURACY / PATCH INTEGRITY / OTHER); the exact commands or scripts you ran; the observed output; why it matters. List anything you could not reproduce separately as UNREPRODUCED SUSPICION.
3. **Items A to I:** one line each: "verified correct", "defect found (see issue N)" or "not tested", with how you tested it.
4. **What you did not test.**
5. State whether you are a human, or which model and version; whether you had any contact with the author's test results; and the date.

Do not propose a rewritten block or patch. **If you find a substantive weakness, stop and report it; do not iterate on a fix.**
