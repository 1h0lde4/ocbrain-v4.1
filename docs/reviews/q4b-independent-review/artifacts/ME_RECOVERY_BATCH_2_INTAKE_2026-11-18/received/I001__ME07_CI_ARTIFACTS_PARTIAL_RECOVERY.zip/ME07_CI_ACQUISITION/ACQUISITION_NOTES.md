# ME-07 controlled acquisition — partial recovery record

**Review disposition remains OPEN — NO PASS.** This package preserves the four original GitHub Actions artifact ZIPs and extracted copies. It does not claim complete ME-07 closure.

## Acquisition

- Date: 2026-11-18 (UTC)
- Repository: `1h0lde4/ocbrain-v4.1`
- Workflow: `CI`
- Event / branch: `push` / `main`
- Method: connected GitHub integration's `download_workflow_artifact` operation, followed by local byte-level verification.
- No workflow was re-run.
- The local filenames were assigned by the download operation; ZIP payload bytes were not rewritten.

## Run-to-commit mapping

| Run ID | Commit | Attempt | Artifact archives |
|---:|---|---:|---|
| 40781867485 | `4a4783c47ac37971a7d51ab3d7ab6fc904a37106` | 1 | `pytest-output`, `drift-report` |
| 39226693573 | `f13bfdefcdd197ed1f966de0b1f93037a4168af4` | 1 | `pytest-output`, `drift-report` |

The mapping and GitHub artifact digests match `ME07_OWNER_ACQUISITION_INSTRUCTIONS.md`. The two commit/run pairs are not swapped.

## Raw artifact ZIP verification

| Run | Artifact | Size (bytes) | SHA-256 | Result |
|---|---|---:|---|---|
| 40781867485 | `pytest-output.zip` | 1164 | `0a271629118a2b5005756bf81a75f4284cdb126869d694ef99b7b01e23bba52e` | MATCH |
| 40781867485 | `drift-report.zip` | 2318 | `6651320038614d52604eabdf505e88b36cb7b5f0a9826acd51cdc168c6cc4301` | MATCH |
| 39226693573 | `pytest-output.zip` | 893 | `7d63a9caa0f9e745d72f6d708d3b89c92db2af81c90cf466a30169cdd8566a06` | MATCH |
| 39226693573 | `drift-report.zip` | 2319 | `3a0049d338dc22628501dde6351fe51e95902e2fdcf781016ec8b3d9cf0aba30` | MATCH |

All four ZIPs passed `unzip -t`. Both extracted `pytest-exit-code.txt` files contain `0`. Both `drift-report.json` files parse as JSON. Per-archive SHA-256 lists are in each run's `raw/SHA256SUMS`; extracted member hashes are in each run's `extracted/SHA256SUMS`.

## Job log retrieval

The GitHub integration returned decoded logs for all four jobs. Job IDs and character counts are recorded in `API_METADATA.json`:

- Run 40781867485: jobs `123145287192` and `123145287528`.
- Run 39226693573: jobs `117974597952` and `117974598455`.

These decoded responses are **not** the original run-level `workflow-logs.zip` files and are not preserved as files in this package.

## Remaining gaps

1. Original run-level `workflow-logs.zip` for run 40781867485: NOT RECOVERED.
2. Original run-level `workflow-logs.zip` for run 39226693573: NOT RECOVERED.
3. `rendered/workflow-logs.txt` outputs: NOT PRESERVED.
4. Full `run-metadata.json` and `artifact-metadata.json` response bodies: NOT PRESERVED; selected artifact and job metadata are recorded in `API_METADATA.json`.

A direct attempt from this execution container to access `api.github.com` failed at DNS resolution. The GitHub integration could download artifact ZIPs and return decoded job logs, but it did not expose a raw run-level logs ZIP download operation.

## Important limitation

Successful job conclusions, zero exit-code artifacts, and the contents of these reports are preserved facts, not a review pass or authorization to close findings. ME-07 remains **PARTIALLY RECOVERED / OPEN — NO PASS**. The remaining log archive and rendered-log items must be acquired or explicitly dispositioned by the owner.
