import asyncio, sys, uuid, json
sys.path.insert(0, ".")
from core.workers.base import AbstractCognitiveWorker, WorkerResult
from core.runtime.worker_registry import WorkerRegistry
from core.runtime.execution_runtime import ExecutionRuntime
from core.workflow.runtime import WorkflowRuntime
from core.workflow.definition import WorkflowDefinition, WorkflowNode, RetryPolicy
from core.governance.governance_kernel import get_governance_kernel
from core.events.event_stream import get_event_stream

class Fails(AbstractCognitiveWorker):
    worker_type = "Fails"; runs = 0
    async def _run(self, context):
        type(self).runs += 1
        return WorkerResult(success=False, error="x")

async def main():
    reg = WorkerRegistry(); reg.register(Fails)
    s = get_event_stream()
    er = ExecutionRuntime(worker_registry=reg, governance=get_governance_kernel(), event_stream=s)
    wr = WorkflowRuntime(execution_runtime=er, event_stream=s)
    wid = "p6-" + uuid.uuid4().hex[:8]
    d = WorkflowDefinition(workflow_id=wid, nodes=[WorkflowNode(node_id="n", worker_type="Fails",
        retry_policy=RetryPolicy(max_retries=1, backoff_seconds=5.0, max_backoff_seconds=5.0))], entry_node="n")
    before = {t.get_name() for t in asyncio.all_tasks()}
    stats0 = wr.stats()
    t = asyncio.create_task(wr.execute(d, query="q"))
    await asyncio.sleep(0.5)          # inside the 5s retry backoff sleep
    t.cancel()
    res = {}
    try:
        r = await asyncio.wait_for(t, 3.0)
        res["outcome"] = {"returned": True, "success": r.success, "error": r.error}
    except BaseException as e:
        res["outcome"] = {"raised": type(e).__name__}
    await asyncio.sleep(0.3)
    res["fails_runs"] = Fails.runs
    leftover = [t_.get_name() + ":" + str(t_.get_coro()).split(" ")[2][:60] for t_ in asyncio.all_tasks() if t_ not in () and t_.get_name() not in before and not t_.done() and t_ is not asyncio.current_task()]
    res["tasks_still_running_after_cancel"] = leftover
    for et in ("workflow.completed", "workflow.failed"):
        res[f"events_{et}"] = len(await s.query(event_type=et, payload_workflow_id=wid, limit=50))
    res["stats_delta"] = {k: wr.stats()[k] - stats0[k] for k in stats0}
    print(json.dumps(res, indent=2, default=str))
asyncio.run(main())
