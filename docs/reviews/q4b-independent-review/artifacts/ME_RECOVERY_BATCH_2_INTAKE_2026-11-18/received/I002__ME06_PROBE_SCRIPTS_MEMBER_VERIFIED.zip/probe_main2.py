import asyncio, sys, uuid, json
sys.path.insert(0, ".")
from core.workers.base import AbstractCognitiveWorker, WorkerResult
from core.runtime.worker_registry import WorkerRegistry
from core.runtime.execution_runtime import ExecutionRuntime
from core.workflow.runtime import WorkflowRuntime
from core.workflow.definition import WorkflowDefinition, WorkflowNode, RetryPolicy
from core.governance.governance_kernel import get_governance_kernel
from core.events.event_stream import get_event_stream

class Flaky(AbstractCognitiveWorker):
    worker_type = "Flaky"; n = 0
    async def _run(self, context):
        type(self).n += 1
        return WorkerResult(success=type(self).n > 2, error="" if type(self).n > 2 else "transient")
class Sleeper(AbstractCognitiveWorker):
    worker_type = "Sleeper"; runs = 0
    async def _run(self, context):
        type(self).runs += 1
        await asyncio.sleep(30)
        return WorkerResult(success=True)

def make(*cs):
    reg = WorkerRegistry()
    for c in cs: reg.register(c)
    s = get_event_stream()
    er = ExecutionRuntime(worker_registry=reg, governance=get_governance_kernel(), event_stream=s)
    return WorkflowRuntime(execution_runtime=er, event_stream=s), s

async def ev(s, wid, t): return await s.query(event_type=t, payload_workflow_id=wid, limit=200)

async def main():
    out = {}
    wr, s = make(Flaky)
    wid = "p2-" + uuid.uuid4().hex[:8]
    d = WorkflowDefinition(workflow_id=wid, nodes=[WorkflowNode(node_id="f", worker_type="Flaky",
        retry_policy=RetryPolicy(max_retries=2, backoff_seconds=0.0))], entry_node="f")
    await wr.execute(d, query="q")
    comp = await ev(s, wid, "worker.completed")
    out["P3b_distinct_task_ids_in_worker_events"] = len({e.payload["task_id"] for e in comp})
    out["P3b_worker_event_count"] = len(comp)
    ec = await ev(s, wid, "execution.completed")
    out["P3b_execution.completed_payload_keys"] = sorted({k for e in ec for k in e.payload})
    out["P3b_execution.completed_has_workflow_id_or_attempt"] = [("workflow_id" in e.payload, "attempt_id" in e.payload) for e in ec]

    for retries in (0,):
        wr, s = make(Sleeper)
        Sleeper.runs = 0
        wid = "p5-" + uuid.uuid4().hex[:8]
        d = WorkflowDefinition(workflow_id=wid, nodes=[WorkflowNode(node_id="s", worker_type="Sleeper",
            retry_policy=RetryPolicy(max_retries=retries, backoff_seconds=0.0))], entry_node="s")
        t = asyncio.create_task(wr.execute(d, query="q"))
        await asyncio.sleep(0.3); t.cancel()
        try:
            r = await asyncio.wait_for(t, 3.0)
            out[f"P5b_cancel_max_retries_{retries}"] = {"returned": True, "workflow_success": r.success, "error": r.error,
                "sleeper_runs": Sleeper.runs, "node_results": {k: (v.success, v.error) for k, v in r.node_results.items()}}
        except BaseException as e:
            out[f"P5b_cancel_max_retries_{retries}"] = {"raised": type(e).__name__}
        out["P5b_worker.cancelled_events"] = len(await ev(s, wid, "worker.cancelled"))
        out["P5b_execution.failed_events"] = len(await ev(s, wid, "execution.failed"))
        out["P5b_workflow_level_events_for_wid"] = {t_: len(await ev(s, wid, t_)) for t_ in ("execution.completed","execution.failed","worker.failed")}
    print(json.dumps(out, indent=2, default=str))
asyncio.run(main())
