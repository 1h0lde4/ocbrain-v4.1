import asyncio, sys, json
sys.path.insert(0, ".")
from core.workers.base import AbstractCognitiveWorker, WorkerResult
from core.runtime.worker_registry import WorkerRegistry
from core.runtime.execution_runtime import ExecutionRuntime
from core.governance.governance_kernel import get_governance_kernel
from core.events.event_stream import get_event_stream

class ReturnsFalse(AbstractCognitiveWorker):
    worker_type = "ReturnsFalse"
    async def _run(self, context): return WorkerResult(success=False, error="returned-failure")
class RaisesInRun(AbstractCognitiveWorker):
    worker_type = "RaisesInRun"
    async def _run(self, context): raise RuntimeError("raised-in-run")
class Sleeper(AbstractCognitiveWorker):
    worker_type = "Sleeper"
    async def _run(self, context): await asyncio.sleep(30)

async def main():
    reg = WorkerRegistry()
    for c in (ReturnsFalse, RaisesInRun, Sleeper): reg.register(c)
    er = ExecutionRuntime(worker_registry=reg, governance=get_governance_kernel(), event_stream=get_event_stream())
    out = {}
    for name in ("ReturnsFalse", "RaisesInRun", "NoSuchWorker"):
        r = await er.invoke(name, query="q")
        out[name] = {"success": r.success, "execution_detail": None if r.execution_detail is None else str(r.execution_detail), "error": r.error[:40]}
    t = asyncio.create_task(er.invoke("Sleeper", query="q"))
    await asyncio.sleep(0.3); t.cancel()
    r = await asyncio.wait_for(t, 2.0)
    out["Sleeper_asyncio_cancelled"] = {"success": r.success, "execution_detail": None if r.execution_detail is None else str(r.execution_detail), "error": r.error[:40]}
    print(json.dumps(out, indent=2))
asyncio.run(main())
