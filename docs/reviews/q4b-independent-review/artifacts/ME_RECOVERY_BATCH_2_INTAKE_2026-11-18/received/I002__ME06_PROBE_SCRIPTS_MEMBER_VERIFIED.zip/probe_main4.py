import asyncio, sys, uuid, json, time
sys.path.insert(0, ".")
from core.workers.base import AbstractCognitiveWorker, WorkerResult
from core.runtime.worker_registry import WorkerRegistry
from core.runtime.execution_runtime import ExecutionRuntime
from core.runtime.execution_budget import ExecutionBudget
from core.runtime.cancellation import CancellationToken
from core.workflow.runtime import WorkflowRuntime
from core.workflow.definition import WorkflowDefinition, WorkflowNode, WorkflowEdge, RetryPolicy
from core.governance.governance_kernel import get_governance_kernel
from core.events.event_stream import get_event_stream

RAN = []
class SlowNoPoll(AbstractCognitiveWorker):
    """Never looks at the cancellation token."""
    worker_type = "SlowNoPoll"
    async def _run(self, context):
        RAN.append("SlowNoPoll"); await asyncio.sleep(3.0)
        return WorkerResult(success=True, output="done")
class After(AbstractCognitiveWorker):
    worker_type = "After"
    async def _run(self, context):
        RAN.append("After"); return WorkerResult(success=True, output="after")
class FailsOnce(AbstractCognitiveWorker):
    worker_type = "FailsOnce"
    async def _run(self, context):
        raise RuntimeError("boom")

def make(*cs, stream=None):
    reg = WorkerRegistry()
    for c in cs: reg.register(c)
    s = stream or get_event_stream()
    er = ExecutionRuntime(worker_registry=reg, governance=get_governance_kernel(), event_stream=s)
    return WorkflowRuntime(execution_runtime=er, event_stream=s), s

async def main():
    out = {}
    # --- watchdog hard deadline vs a worker that never polls the token ---
    wr, s = make(SlowNoPoll, After)
    wid = "p7-" + uuid.uuid4().hex[:8]
    d = WorkflowDefinition(workflow_id=wid,
        nodes=[WorkflowNode(node_id="a", worker_type="SlowNoPoll"), WorkflowNode(node_id="b", worker_type="After")],
        edges=[WorkflowEdge(from_node="a", to_node="b")], entry_node="a")
    snaps = []
    orig = wr._save_checkpoint
    async def spy(instance_id, workflow_id, node_states):
        snaps.append({k: v.status.value for k, v in node_states.items()})
        return await orig(instance_id, workflow_id, node_states)
    wr._save_checkpoint = spy
    tok = CancellationToken()
    budget = ExecutionBudget(startup_deadline_s=60, progress_deadline_s=60, hard_ceiling_s=1.0, absolute_ceiling_s=1.0, max_extension_s=0.0)
    t0 = time.monotonic()
    res = await wr.execute(d, query="q", cancellation_token=tok, metadata={"execution_budget": budget})
    out["P7_hard_deadline_1s_worker_3s_no_poll"] = {
        "elapsed_s": round(time.monotonic() - t0, 1), "workflow_success": res.success, "error": res.error,
        "token_cancelled": tok.is_cancelled, "token_reason": getattr(tok, "reason", None),
        "workers_run": list(RAN), "node_results": {k: (v.success, v.error) for k, v in res.node_results.items()},
        "last_checkpoint_states": snaps[-1] if snaps else None,
    }
    # --- terminal reporting failure: which emitters tolerate an event-store outage ---
    import traceback
    real = get_event_stream()
    def broken(match):
        class BrokenStream:
            def __getattr__(self, n): return getattr(real, n)
            async def append(self, *a, **k):
                et = k.get("event_type", "")
                if match(et, k.get("source", "")):
                    raise OSError("event store unavailable")
                return await real.append(*a, **k)
        return BrokenStream()
    variants = {
        "all_events_fail": lambda et, src: True,
        "worker_events_fail_only": lambda et, src: et.startswith("worker."),
        "progress_node_failed_fail_only": lambda et, src: et == "execution.node.failed",
        "workflow_terminal_fail_only": lambda et, src: et.startswith("workflow."),
    }
    p8 = {}
    for name, match in variants.items():
        wr2, _ = make(FailsOnce, stream=broken(match))
        wid2 = "p8-" + uuid.uuid4().hex[:8]
        d2 = WorkflowDefinition(workflow_id=wid2, nodes=[WorkflowNode(node_id="x", worker_type="FailsOnce")], entry_node="x")
        try:
            r2 = await wr2.execute(d2, query="q")
            p8[name] = {"execute_raised": False, "workflow_success": r2.success, "error": (r2.error or "")[:80]}
        except BaseException as e:
            tb = traceback.extract_tb(e.__traceback__)
            inner = [f"{f.filename.split('main-new/')[-1]}:{f.lineno}" for f in tb if 'main-new' in f.filename][-2:]
            p8[name] = {"execute_raised": type(e).__name__, "raised_at": inner}
    out["P8_event_store_outage_by_emitter"] = p8
    print(json.dumps(out, indent=2, default=str))
asyncio.run(main())
