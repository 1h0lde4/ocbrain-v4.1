# Q4-b audit probes (throw-away, read-only against a snapshot of OCBrain main)

Run from the root of an extracted snapshot of `main` (for example `git archive 4a4783c | tar -x -C DIR`),
never from the working repository. Python 3.12.3 with: pytest, pytest-asyncio, datasketch, tomli-w and the
other light modules the core imports. Each script prints one JSON object. They write event-store files into
the current directory, which is why they must run in a disposable copy.

| Script | Probes | Findings |
| --- | --- | --- |
| probe_main.py  | P1 failure counter per path; P2 error branch; P3 retries and attempt ids; P4 unknown worker; P5 asyncio cancel with one retry | F-02, F-03, F-04, F-06, F-08, F-10, F-11 |
| probe_main2.py | P3b attempt-to-event correlation; P5b asyncio cancel with no retry | F-04, F-08 |
| probe_main3.py | P6 asyncio cancel during retry backoff | F-09 |
| probe_main4.py | P7 watchdog hard deadline vs a worker that never polls the token; P8 event-store outage per emitter | F-15, F-16 |
| probe_main5.py | P9 whether worker failure and cancellation results populate WorkerResult.execution_detail | F-01 (amended) |

Not committed to any repository. Results quoted in the brief were produced on main f13bfde (P1-P6) and
re-run on main 4a4783c (P1-P8); P9 was run on 4a4783c only.
