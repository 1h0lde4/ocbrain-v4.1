"""Probe of failure-path behavior at main f13bfde. Runs inside the extracted snapshot copy only."""
import asyncio, sys, uuid, importlib.util, json
sys.path.insert(0, ".")
from core.workers.base import AbstractCognitiveWorker, WorkerResult
from core.runtime.worker_registry import WorkerRegistry
from core.runtime.execution_runtime import ExecutionRuntime
from core.workflow.runtime import WorkflowRuntime
from core.workflow.definition import WorkflowDefinition, WorkflowNode, RetryPolicy
from core.governance.governance_kernel import get_governance_kernel
from core.events.event_stream import get_event_stream

SEEN_ATTEMPT_IDS = []
SLEEP_RUNS = {"n": 0}


class ReturnsFalse(AbstractCognitiveWorker):
    worker_type = "ReturnsFalse"
    async def _run(self, context):
        return WorkerResult(success=False, error="returned-failure")


class RaisesInRun(AbstractCognitiveWorker):
    worker_type = "RaisesInRun"
    async def _run(self, context):
        raise RuntimeError("raised-in-run")


class ExecRaises(AbstractCognitiveWorker):
    """Overrides execute() itself so the exception reaches ExecutionRuntime's own handler."""
    worker_type = "ExecRaises"
    async def execute(self, context):
        raise RuntimeError("raised-from-execute")
    async def _run(self, context):
        return WorkerResult(success=True)


class Recovery(AbstractCognitiveWorker):
    worker_type = "Recovery"
    async def _run(self, context):
        return WorkerResult(success=True, output="recovered")


class Flaky(AbstractCognitiveWorker):
    worker_type = "Flaky"
    n = 0
    async def _run(self, context):
        SEEN_ATTEMPT_IDS.append((context.metadata or {}).get("attempt_id"))
        type(self).n += 1
        if type(self).n <= 2:
            return WorkerResult(success=False, error="transient")
        return WorkerResult(success=True, output="ok")


class Sleeper(AbstractCognitiveWorker):
    worker_type = "Sleeper"
    async def _run(self, context):
        SLEEP_RUNS["n"] += 1
        await asyncio.sleep(30)
        return WorkerResult(success=True)


def make(*classes):
    reg = WorkerRegistry()
    for c in classes:
        reg.register(c)
    stream = get_event_stream()
    er = ExecutionRuntime(worker_registry=reg, governance=get_governance_kernel(), event_stream=stream)
    return er, WorkflowRuntime(execution_runtime=er, event_stream=stream), stream


async def events(stream, wid, etype):
    return await stream.query(event_type=etype, payload_workflow_id=wid, limit=200)


async def main():
    out = {}

    # P1: failure-counter behavior per path (ExecutionRuntime.stats total_failures delta per invoke)
    er, wr, stream = make(ReturnsFalse, RaisesInRun, ExecRaises)
    deltas = {}
    for name in ("ReturnsFalse", "RaisesInRun", "ExecRaises", "NoSuchWorker"):
        before = er.stats()["total_failures"]
        r = await er.invoke(name, query="q")
        deltas[name] = {"success": r.success, "total_failures_delta": er.stats()["total_failures"] - before}
    out["P1_failure_counter_delta_per_invoke"] = deltas

    # P2: events + evaluator accounting for a returned-failure worker vs raising worker
    er, wr, stream = make(ReturnsFalse, RaisesInRun, Recovery)
    wid = "probe-" + uuid.uuid4().hex[:8]
    d = WorkflowDefinition(workflow_id=wid,
                           nodes=[WorkflowNode(node_id="a", worker_type="ReturnsFalse", error_branch="rec"),
                                  WorkflowNode(node_id="rec", worker_type="Recovery")],
                           entry_node="a")
    snaps = []
    orig = wr._save_checkpoint
    async def spy(instance_id, workflow_id, node_states):
        snaps.append({k: (v.status.value, v.attempts, v.attempt_id[:8]) for k, v in node_states.items()})
        return await orig(instance_id, workflow_id, node_states)
    wr._save_checkpoint = spy
    res = await wr.execute(d, query="q")
    comp = await events(stream, wid, "worker.completed")
    fail = await events(stream, wid, "worker.failed")
    out["P2_error_branch"] = {
        "workflow_success": res.success,
        "node_results": {k: v.success for k, v in res.node_results.items()},
        "checkpoint_node_states_last": snaps[-1] if snaps else None,
        "checkpoint_calls": len(snaps),
        "worker.completed_events": [{"success": e.payload.get("success")} for e in comp],
        "worker.failed_events": len(fail),
        "completed_payload_keys": sorted({k for e in comp for k in e.payload}),
    }
    spec = importlib.util.spec_from_file_location("tev", "tests/test_evaluator_worker.py")
    tev = importlib.util.module_from_spec(spec); spec.loader.exec_module(tev)
    from core.workers.evaluator import _build_evaluation_record
    rec = _build_evaluation_record(tev._make_plan(), [], comp, fail, {})
    out["P2_evaluator_tool_success_rate"] = rec.tool_success_rate

    # P3: retries -> attempt ids and evaluator accounting
    er, wr, stream = make(Flaky)
    wid2 = "probe-" + uuid.uuid4().hex[:8]
    d2 = WorkflowDefinition(workflow_id=wid2,
                            nodes=[WorkflowNode(node_id="f", worker_type="Flaky",
                                                retry_policy=RetryPolicy(max_retries=2, backoff_seconds=0.0))],
                            entry_node="f")
    snaps2 = []
    orig2 = wr._save_checkpoint
    async def spy2(instance_id, workflow_id, node_states):
        snaps2.append({k: (v.status.value, v.attempts, v.attempt_id) for k, v in node_states.items()})
        return await orig2(instance_id, workflow_id, node_states)
    wr._save_checkpoint = spy2
    Flaky.n = 0
    res2 = await wr.execute(d2, query="q")
    comp2 = await events(stream, wid2, "worker.completed")
    rec2 = _build_evaluation_record(tev._make_plan(), [], comp2, [], {})
    final = snaps2[-1]["f"] if snaps2 else None
    out["P3_retry"] = {
        "workflow_success": res2.success,
        "attempt_ids_seen_by_worker": [a[:8] if a else a for a in SEEN_ATTEMPT_IDS],
        "distinct_attempt_ids": len(set(SEEN_ATTEMPT_IDS)),
        "final_node_state": {"status": final[0], "attempts": final[1], "attempt_id": final[2][:8]} if final else None,
        "final_attempt_id_is_last_seen": bool(final) and final[2] == SEEN_ATTEMPT_IDS[-1],
        "worker.completed_success_flags": [e.payload.get("success") for e in comp2],
        "worker_event_payload_has_attempt_id": any("attempt_id" in e.payload for e in comp2),
        "evaluator_tool_success_rate": rec2.tool_success_rate,
    }

    # P4: unknown worker type -> events emitted?
    er, wr, stream = make(Recovery)
    wid3 = "probe-" + uuid.uuid4().hex[:8]
    r = await er.invoke("NoSuchWorker", query="q", workflow_id=wid3)
    out["P4_unknown_worker"] = {
        "success": r.success,
        "execution.completed_events": len(await events(stream, wid3, "execution.completed")),
        "worker.failed_events": len(await events(stream, wid3, "worker.failed")),
    }

    # P5: asyncio task cancellation while a worker is running, with one retry allowed
    er, wr, stream = make(Sleeper)
    wid4 = "probe-" + uuid.uuid4().hex[:8]
    d4 = WorkflowDefinition(workflow_id=wid4,
                            nodes=[WorkflowNode(node_id="s", worker_type="Sleeper",
                                                retry_policy=RetryPolicy(max_retries=1, backoff_seconds=0.0))],
                            entry_node="s")
    SLEEP_RUNS["n"] = 0
    task = asyncio.create_task(wr.execute(d4, query="q"))
    await asyncio.sleep(0.3)
    task.cancel()
    await asyncio.sleep(0.8)
    state = {"task_done": task.done(), "sleeper_run_count_after_cancel": SLEEP_RUNS["n"]}
    cancelled_evt = await events(stream, wid4, "worker.cancelled")
    state["worker.cancelled_events"] = len(cancelled_evt)
    if task.done():
        try:
            rr = task.result()
            state["outcome"] = {"returned": True, "success": rr.success, "error": rr.error}
        except asyncio.CancelledError:
            state["outcome"] = "CancelledError propagated to the caller"
    else:
        state["outcome"] = "task still running after cancel() (cancellation did not stop it)"
        task.cancel(); task.cancel()
        try:
            await asyncio.wait_for(task, 1.0)
        except BaseException as e:
            state["second_cancel_result"] = type(e).__name__
    out["P5_asyncio_cancel"] = state

    print(json.dumps(out, indent=2, default=str))

asyncio.run(main())
