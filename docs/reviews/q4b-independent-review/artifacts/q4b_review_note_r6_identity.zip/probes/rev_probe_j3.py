"""Reviewer probe J3 (read-only, snapshot): K4.2 production-flag path (repo runtime-integration stack). Payload-level view of orchestrator.* / workflow.* / execution.* events for a successful and a failing-adapter query (no whitelist: full key sets)."""
import asyncio, sys, json, importlib.util, tempfile, pathlib
sys.path.insert(0, ".")
spec = importlib.util.spec_from_file_location("tri", "tests/test_runtime_integration.py"); tri = importlib.util.module_from_spec(spec); spec.loader.exec_module(tri)
async def run(label, **kw):
    orch, stream, memory, wreg, adapter = tri._build_runtime_stack(pathlib.Path(tempfile.mkdtemp()), use_k42_frontend=True, **kw)
    ps = tri._mock_llm_calls()
    for p in ps: p.start()
    try: ans = await orch.handle("explain recursion simply", execution_id="EXEC-J3-" + label)
    finally:
        for p in ps: p.stop()
    evs = await stream.query(limit=100000)
    print(f"== {label}: answer={str(ans)[:40]!r} adapter_calls={adapter.call_count}")
    seen = set()
    for e in evs:
        p = e.payload if isinstance(e.payload, dict) else {}
        key = (e.event_type, bool(p.get("success", True)))
        if e.event_type in ("orchestrator.query_started", "orchestrator.query_completed", "workflow.started", "workflow.completed", "execution.completed", "execution.failed", "execution.node.failed", "worker.completed"):
            tag = (e.event_type, tuple(sorted(p.keys())), p.get("outcome"), p.get("success"))
            if tag in seen: continue
            seen.add(tag); print(f"   {e.event_type:28s} keys={sorted(p.keys())} outcome={p.get('outcome')} success={p.get('success')} error={str(p.get('error',''))[:40]!r}")
async def main():
    await run("ok"); await run("adapterfail", adapter_fails=True)
asyncio.run(main())
