"""Reviewer probe J4 (read-only): stage_tag and operation_id sharing, K4.2 path (the J1 whitelist omitted stage_tag)."""
import asyncio, sys, json, importlib.util, tempfile, pathlib
sys.path.insert(0, ".")
spec = importlib.util.spec_from_file_location("tri", "tests/test_runtime_integration.py"); tri = importlib.util.module_from_spec(spec); spec.loader.exec_module(tri)
async def main():
    orch, stream, memory, wreg, adapter = tri._build_runtime_stack(pathlib.Path(tempfile.mkdtemp()), use_k42_frontend=True)
    ps = tri._mock_llm_calls()
    for p in ps: p.start()
    try: await orch.handle("explain recursion simply", execution_id="EXEC-J4")
    finally:
        for p in ps: p.stop()
    for e in await stream.query(limit=100000):
        if e.event_type in ("cognitive.constraints_extracted", "cognitive.capabilities_discovered", "cognitive.plan_compiled"):
            p = e.payload; print(f"{e.event_type:34s} operation_id={str(p.get('operation_id'))[:8]} root_operation_id={str(p.get('root_operation_id'))[:8]} stage_tag={p.get('stage_tag')!r}")
asyncio.run(main())
