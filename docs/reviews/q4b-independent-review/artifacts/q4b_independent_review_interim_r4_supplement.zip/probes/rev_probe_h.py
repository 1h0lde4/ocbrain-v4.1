"""Reviewer probe H (read-only, snapshot): end-to-end identity lineage through Orchestrator.handle() with known injected ids; walks EVERY persisted event at any payload depth (no first-of-type shortcut). Embedding model STUBBED (diagnostic)."""
import asyncio, sys, json, importlib.util, os, tempfile
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/review/stubplug")
import hf_stub; hf_stub.pytest_configure(None)
spec = importlib.util.spec_from_file_location("k22", "tests/test_k2_2_runtime_migration.py"); k22 = importlib.util.module_from_spec(spec); spec.loader.exec_module(k22)
from unittest.mock import MagicMock
from core.model_router import RouteResult
from core.observability.tracer import set_trace_id
from core.events.event_stream import get_event_stream
IDK = ("trace_id", "operation_id", "root_operation_id", "execution_id", "workflow_id", "instance_id", "attempt_id", "task_id", "request_id", "plan_id", "goal_id")
def walk(o, path=""):
    if isinstance(o, dict):
        for k, v in o.items():
            if k in IDK and isinstance(v, (str, int)): yield path + k, str(v)
            yield from walk(v, path + k + ".")
    elif isinstance(o, list):
        for v in o: yield from walk(v, path)
async def main():
    async def route(*a, **k): return RouteResult(answer="stub answer", source="mock")
    router = MagicMock(); router.route = route
    orch, memory, ctx, router = k22._make_orchestrator_with_workflow_runtime(router=router)
    s0 = get_event_stream(); before = max([e.sequence for e in await s0.query(limit=100000)] or [0])
    set_trace_id("TRACE-KNOWN-1")
    ans = await orch.handle("What is the capital of France?", execution_id="EXEC-KNOWN-1")
    s = get_event_stream(); evs = await s.query(limit=100000)
    rows = []
    for e in [x for x in evs if x.sequence > before]:
        p = e.payload if isinstance(e.payload, dict) else {}
        found = sorted(set(walk(p)))
        raw = json.dumps(p, default=str)
        rows.append({"seq": e.sequence, "type": e.event_type, "source": e.source, "ids": found, "has_TRACE": "TRACE-KNOWN-1" in raw, "has_EXEC": "EXEC-KNOWN-1" in raw, "ckpt": bool(getattr(e, "checkpoint", ""))})
    json.dump({"answer": str(ans)[:80], "n_events": len(rows), "events": rows}, open("/home/claude/review/out_rev_h.json", "w"), indent=1, default=str)
    print("answer:", str(ans)[:80], "| events scanned:", len(rows))
    types = {}
    for r in rows: types.setdefault(r["type"], []).append(r)
    for t, rs in types.items():
        idnames = sorted({k.split(".")[-1] for r in rs for k, v in r["ids"]})
        print(f"  {t:32s} n={len(rs):<3} TRACE-KNOWN in {sum(r['has_TRACE'] for r in rs)}/{len(rs)}  EXEC-KNOWN in {sum(r['has_EXEC'] for r in rs)}/{len(rs)}  id fields: {idnames}")
    # value-level relationships
    vals = {}
    for r in rows:
        for k, v in r["ids"]: vals.setdefault(k.split(".")[-1], set()).add(v)
    for k in ("trace_id", "root_operation_id", "operation_id", "execution_id", "workflow_id", "instance_id", "attempt_id"):
        if k in vals: print(f"  distinct {k} values across all events: {len(vals[k])} {sorted(v[:12] for v in vals[k])[:4]}")
    await orch.close()
asyncio.run(main())
