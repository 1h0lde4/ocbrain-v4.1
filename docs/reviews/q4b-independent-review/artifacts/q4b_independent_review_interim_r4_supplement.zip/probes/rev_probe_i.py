"""Reviewer probe I (read-only, snapshot): execution-registry behaviour: duplicate execution_id, unknown-id growth, process-restart reconstruction. Package D."""
import asyncio, sys, os, json, tempfile, uuid, tracemalloc, subprocess
sys.path.insert(0, ".")
from core.events.event_stream import EventStream, SQLiteEventStore
from core.governance.governance_kernel import get_governance_kernel
from core.runtime.execution_runtime import ExecutionRuntime
from core.runtime.execution_graph import execution_registry
from core.runtime.worker_registry import WorkerRegistry
from core.workers.base import AbstractCognitiveWorker, WorkerResult
from core.workflow.definition import WorkflowDefinition, WorkflowEdge, WorkflowNode
from core.workflow.runtime import WorkflowRuntime
MODE = {"b": "ok"}
class W(AbstractCognitiveWorker):
    worker_type = "W"
    async def _run(self, context):
        node = (context.metadata or {}).get("node_id")
        await asyncio.sleep(0.3 if node == "b" else 0.02)
        if MODE.get(node) == "boom": raise RuntimeError("boom")
        return WorkerResult(success=True, output=node)
def mk(db):
    reg = WorkerRegistry(); reg.register(W); s = EventStream(SQLiteEventStore(db_path=db))
    return WorkflowRuntime(execution_runtime=ExecutionRuntime(worker_registry=reg, governance=get_governance_kernel(), event_stream=s), event_stream=s), s
D = WorkflowDefinition(workflow_id="w-reg", name="r", nodes=[WorkflowNode(node_id=n, worker_type="W") for n in ("a", "b")], edges=[WorkflowEdge(from_node="a", to_node="b")], entry_node="a")
def statuses(snap):
    out = []
    def w(o):
        if isinstance(o, dict):
            nid = o.get("node_id") or o.get("id")
            if nid is not None and o.get("status") is not None: out.append((str(nid)[:10], str(o["status"])))
            for v in o.values(): w(v)
        elif isinstance(o, list):
            for v in o: w(v)
    w(snap); return out
async def main():
    res = {}
    # D1 sequential duplicates
    rt, s = mk(os.path.join(tempfile.mkdtemp(), "i1.db")); eid = "DUP-1"
    MODE.clear(); r1 = await rt.execute(D, query="q", metadata={"execution_id": eid})
    g = execution_registry.get(eid); res["D1_after_first_run_ok"] = {"result": r1.success, "graph": statuses(await g.snapshot())}
    MODE.update({"a": "boom"}); r2 = await rt.execute(D, query="q", metadata={"execution_id": eid})
    g2 = execution_registry.get(eid)
    res["D1_after_second_run_fails_same_execution_id"] = {"result": r2.success, "same_graph_object": g is g2, "graph": statuses(await g2.snapshot()), "distinct_instance_ids": r1.instance_id != r2.instance_id}
    # D2 concurrent duplicates
    MODE.clear(); eid2 = "DUP-2"; rt2, s2 = mk(os.path.join(tempfile.mkdtemp(), "i2.db"))
    a, b = await asyncio.gather(rt2.execute(D, query="q", metadata={"execution_id": eid2}), rt2.execute(D, query="q", metadata={"execution_id": eid2}))
    res["D2_concurrent_same_execution_id"] = {"results": [a.success, b.success], "graphs_for_id": 1 if execution_registry.get(eid2) else 0, "graph": statuses(await execution_registry.get(eid2).snapshot())}
    # D3 unknown-id growth via the real API handler
    import httpx
    from interface import api
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=api.app), base_url="http://t", headers={"X-OCBrain-Local": "1"}) as c:
        n0 = len(execution_registry._graphs); q0 = len(execution_registry._queues); tracemalloc.start(); m0 = tracemalloc.get_traced_memory()[0]
        for i in range(2000):
            r = await c.get(f"/executions/unknown-{i}"); assert r.status_code == 200, r.status_code
        m1 = tracemalloc.get_traced_memory()[0]
        res["D3_unknown_id_GET_growth"] = {"requests": 2000, "graphs_added": len(execution_registry._graphs) - n0, "queues_added": len(execution_registry._queues) - q0, "net_traced_bytes_per_request": round((m1 - m0) / 2000)}
        for i in range(2000, 4000): await c.get(f"/executions/unknown-{i}")
        m2 = tracemalloc.get_traced_memory()[0]; res["D3_unknown_id_GET_growth"]["after_4000_graphs_total"] = len(execution_registry._graphs) - n0; res["D3_unknown_id_GET_growth"]["bytes_per_request_second_batch"] = round((m2 - m1) / 2000)
        res["D3_eviction_API_present"] = [m for m in dir(execution_registry) if any(k in m.lower() for k in ("evict", "remove", "delete", "expire", "prune", "clear", "discard"))]
    print(json.dumps(res, indent=1, default=str))
    # D4 process restart: run a workflow in this process on a persistent DB, then a fresh process asks the registry
    db = os.path.join(tempfile.mkdtemp(), "i4.db"); rt4, s4 = mk(db); MODE.clear()
    await rt4.execute(D, query="q", metadata={"execution_id": "RESTART-1"})
    child = r'''
import asyncio, sys, json, sqlite3
sys.path.insert(0, ".")
from core.runtime.execution_graph import execution_registry
from core.runtime.projection import project_graph
async def main():
    db = sys.argv[1]; con = sqlite3.connect(db); persisted = con.execute("SELECT COUNT(*) FROM events WHERE payload LIKE '%RESTART-1%'").fetchone()[0]; con.close()
    before = execution_registry.get("RESTART-1")
    g = before or execution_registry.create("RESTART-1", title="OCBrain execution")
    snap = project_graph(await g.snapshot())
    try:
        ev = await asyncio.wait_for(execution_registry.events("RESTART-1").__anext__(), 0.6); got = "event delivered"
    except asyncio.TimeoutError: got = "no event within 0.6s (no replay from persisted history)"
    print(json.dumps({"persisted_events_mentioning_id": persisted, "registry_had_graph_before_request": before is not None, "projected_snapshot_keys": sorted(snap.keys()) if isinstance(snap, dict) else str(type(snap)), "snapshot_nodes": json.dumps(snap, default=str)[:200], "events_endpoint_source": got}))
asyncio.run(main())
'''
    p = subprocess.run([sys.executable, "-c", child, db], capture_output=True, text=True, timeout=60)
    print("D4_process_restart:", p.stdout.strip()[:600], p.stderr.strip()[-200:] if p.returncode else "")
asyncio.run(main())
