"""Reviewer probe G (read-only observation; NO asyncio task cancellation, so it does not touch the #105 contract): hard-deadline (budget ceiling -> workflow token) topology matrix.
Same evidence surfaces for every case: WorkflowResult, node results, execution graph, checkpoint, event history, task state."""
import asyncio, sys, os, json, tempfile, sqlite3, uuid
sys.path.insert(0, ".")
from core.events.event_stream import EventStream, SQLiteEventStore
from core.governance.governance_kernel import get_governance_kernel
from core.runtime.execution_runtime import ExecutionRuntime
from core.runtime.execution_budget import ExecutionBudget
from core.runtime.cancellation import CancellationToken
from core.runtime.execution_graph import execution_registry
from core.runtime.worker_registry import WorkerRegistry
from core.workers.base import AbstractCognitiveWorker, WorkerResult
from core.workflow.definition import WorkflowDefinition, WorkflowEdge, WorkflowNode
from core.workflow.runtime import WorkflowRuntime
BEH = {}
class W(AbstractCognitiveWorker):
    worker_type = "W"
    async def _run(self, context):
        node = (context.metadata or {}).get("node_id"); b = BEH.get(node, "fast")
        if b == "nopoll": await asyncio.sleep(2.5)
        elif b == "poll":
            for _ in range(60):
                if context.cancellation_token.is_cancelled: return WorkerResult(success=False, error="stopped: token observed")
                await asyncio.sleep(0.1)
        return WorkerResult(success=True, output=f"done:{node}")
def walk_status(o, out):
    if isinstance(o, dict):
        nid = o.get("node_id") or o.get("id"); st = o.get("status")
        if nid is not None and st is not None: out.append((str(nid)[:10], str(st)))
        for v in o.values(): walk_status(v, out)
    elif isinstance(o, list):
        for v in o: walk_status(v, out)
async def case(name, nodes, behav):
    BEH.clear(); BEH.update(behav)
    db = os.path.join(tempfile.mkdtemp(), "g.db"); reg = WorkerRegistry(); reg.register(W); s = EventStream(SQLiteEventStore(db_path=db))
    rt = WorkflowRuntime(execution_runtime=ExecutionRuntime(worker_registry=reg, governance=get_governance_kernel(), event_stream=s), event_stream=s)
    d = WorkflowDefinition(workflow_id="w-g", name="g", nodes=[WorkflowNode(node_id=n, worker_type="W") for n in nodes],
                           edges=[WorkflowEdge(from_node=a, to_node=b) for a, b in zip(nodes, nodes[1:])], entry_node=nodes[0])
    bud = ExecutionBudget(startup_deadline_s=60, progress_deadline_s=60, hard_ceiling_s=1.0, absolute_ceiling_s=1.0, max_extension_s=0.0)
    tok = CancellationToken(); eid = "G-" + uuid.uuid4().hex[:6]; cur = asyncio.current_task(); before = set(asyncio.all_tasks())
    r = await rt.execute(d, query="q", cancellation_token=tok, metadata={"execution_budget": bud, "execution_id": eid})
    await asyncio.sleep(0.2)
    g = execution_registry.get(eid); gs = []
    if g is not None: walk_status(await g.snapshot(), gs)
    con = sqlite3.connect(db); cols = [c[1] for c in con.execute("PRAGMA table_info(events)")]; rows = [dict(zip(cols, x)) for x in con.execute("SELECT * FROM events ORDER BY sequence")]; con.close()
    seq = []
    for e in rows:
        p = json.loads(e["payload"]) if isinstance(e["payload"], str) else (e["payload"] or {})
        if e["event_type"] in ("execution.node.failed", "execution.node.completed", "execution.failed", "execution.completed", "workflow.completed"):
            tag = e["event_type"].replace("execution.", "x.").replace("workflow.", "wf.")
            seq.append(f"{tag}[{str(p.get('node_id', ''))[:8]}{'|ok=' + str(p.get('success')) if 'success' in p else ''}]")
    ck = [e for e in rows if (e["checkpoint"] or "").startswith("workflow:")]
    last = None
    if ck:
        p = json.loads(ck[-1]["payload"]) if isinstance(ck[-1]["payload"], str) else ck[-1]["payload"]
        last = {n: v["status"] for n, v in p["node_states"].items()}
    leaked = sorted({t.get_coro().__qualname__ for t in asyncio.all_tasks() if t not in before and t is not cur and not t.done()})
    for t in [t for t in asyncio.all_tasks() if t not in before and t is not cur and not t.done()]: t.cancel()
    return {"case": name, "workflow_result": {"success": r.success, "error": (r.error or "")[:30]}, "token_cancelled": tok.is_cancelled,
            "node_results": {k: (v.success, (v.error or "")[:26]) for k, v in r.node_results.items()}, "graph_statuses": gs, "last_checkpoint": last, "event_sequence": seq, "pending_tasks_after": leaked}
async def main():
    out = []
    out.append(await case("T1 single node, ignores token", ["a"], {"a": "nopoll"}))
    out.append(await case("T2 single node, polls token", ["a"], {"a": "poll"}))
    out.append(await case("T3 final node of a->b, ignores token", ["a", "b"], {"b": "nopoll"}))
    out.append(await case("T4 final node of a->b, polls token", ["a", "b"], {"b": "poll"}))
    out.append(await case("T5 non-final node a of a->b, ignores token", ["a", "b"], {"a": "nopoll"}))
    out.append(await case("T6 non-final node a of a->b, polls token", ["a", "b"], {"a": "poll"}))
    out.append(await case("T7 middle node b of a->b->c, ignores token", ["a", "b", "c"], {"b": "nopoll"}))
    json.dump(out, open("/home/claude/review/out_rev_g.json", "w"), indent=1)
    for o in out:
        print("==", o["case"]); [print(f"   {k}: {v}") for k, v in o.items() if k != "case"]
asyncio.run(main())
