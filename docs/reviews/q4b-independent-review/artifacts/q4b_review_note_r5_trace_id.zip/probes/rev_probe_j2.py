"""Reviewer probe J2 (read-only, snapshot): REAL uvicorn server, production flag use_k42_frontend=True, repo runtime-integration stack (LLM calls + capability adapter faked as in that test file).
(1) is the ambient trace_id fresh per HTTP request? (2) how does /query report an adapter failure? The driver never calls tracer functions in the server's main context."""
import asyncio, sys, json, importlib.util, tempfile, pathlib, collections
sys.path.insert(0, ".")
spec = importlib.util.spec_from_file_location("tri", "tests/test_runtime_integration.py"); tri = importlib.util.module_from_spec(spec); spec.loader.exec_module(tri)
import httpx, uvicorn
from interface import api
from core.observability.tracer import get_trace_id
SEEN = []   # (execution_id, trace id seen at handle() entry inside the request task)
def wrap(orch):
    orig = orch.handle
    async def handle(query, *a, **k):
        SEEN.append((k.get("execution_id"), get_trace_id())); return await orig(query, *a, **k)
    orch.handle = handle
async def serve(port):
    server = uvicorn.Server(uvicorn.Config(api.app, host="127.0.0.1", port=port, log_level="error")); t = asyncio.ensure_future(server.serve())
    for _ in range(100):
        if server.started: break
        await asyncio.sleep(0.05)
    return server, t
async def main():
    tmp = pathlib.Path(tempfile.mkdtemp()); H = {"X-OCBrain-Local": "1"}
    ps = tri._mock_llm_calls()
    for p in ps: p.start()
    try:
        orch, stream, memory, wreg, adapter = tri._build_runtime_stack(tmp, use_k42_frontend=True); wrap(orch); api.setup(orch, None)
        server, t = await serve(18765)
        async with httpx.AsyncClient(base_url="http://127.0.0.1:18765", headers=H, timeout=30) as c:
            r1 = await c.post("/query", json={"query": "explain recursion simply", "execution_id": "HTTP-1"})
            r2 = await c.post("/query", json={"query": "explain loops simply", "execution_id": "HTTP-2"})
            r3, r4 = await asyncio.gather(c.post("/query", json={"query": "explain trees simply", "execution_id": "HTTP-3"}), c.post("/query", json={"query": "explain graphs simply", "execution_id": "HTTP-4"}))
        evs = await stream.query(limit=100000)
        ev_trace = collections.Counter(); 
        for e in evs:
            p = e.payload if isinstance(e.payload, dict) else {}
            if e.event_type.startswith("cognitive.") and "trace_id" in p: ev_trace[p["trace_id"][:12]] += 1
        print("status codes:", [r.status_code for r in (r1, r2, r3, r4)])
        print("trace id seen at handle() entry per request:", [(e, (tid or '')[:12]) for e, tid in SEEN])
        print("distinct ambient trace ids at handle() entry:", len({tid for _, tid in SEEN}), "of", len(SEEN), "requests (sequential x2, concurrent x2, one keep-alive client connection)")
        print("trace ids found in cognitive.* events (count per id):", dict(ev_trace))
        server.should_exit = True; await t
        # J3: failure reporting through the real HTTP layer on the K4.2 path
        orch2, stream2, memory2, wreg2, adapter2 = tri._build_runtime_stack(tmp / "f", use_k42_frontend=True, adapter_fails=True) if (tmp / "f").mkdir() is None else (None,)*5
        api.setup(orch2, None); server, t = await serve(18766)
        async with httpx.AsyncClient(base_url="http://127.0.0.1:18766", headers=H, timeout=30) as c:
            r = await c.post("/query", json={"query": "explain recursion simply", "execution_id": "HTTP-FAIL"}); j = r.json()
        print("adapter failure via real /query:", {"status": r.status_code, "success": j.get("success"), "error": j.get("error"), "answer": str(j.get("answer"))[:110], "adapter_calls": adapter2.call_count})
        server.should_exit = True; await t
    finally:
        for p in ps: p.stop()
asyncio.run(main())
