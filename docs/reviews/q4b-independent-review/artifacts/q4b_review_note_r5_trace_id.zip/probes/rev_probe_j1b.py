"""Reviewer probe J1 (read-only, snapshot): REAL production-flag path (use_k42_frontend=True, as shipped in config/settings.toml) through Orchestrator.handle(),
using the repo's own runtime-integration stack (real EventStream/Governance/WorkflowRuntime/Orchestrator; only the LLM calls and the capability adapter are faked, as in that test file).
Scans EVERY persisted event at any payload depth for known injected ids."""
import asyncio, sys, json, importlib.util, tempfile, pathlib
sys.path.insert(0, ".")
spec = importlib.util.spec_from_file_location("tri", "tests/test_runtime_integration.py"); tri = importlib.util.module_from_spec(spec); spec.loader.exec_module(tri)
from core.observability.tracer import set_trace_id, get_trace_id
IDK = ("trace_id", "operation_id", "root_operation_id", "execution_id", "workflow_id", "instance_id", "attempt_id", "task_id", "request_id")
def walk(o, p=""):
    if isinstance(o, dict):
        for k, v in o.items():
            if k in IDK and isinstance(v, (str, int)): yield p + k, str(v)
            yield from walk(v, p + k + ".")
    elif isinstance(o, list):
        for v in o: yield from walk(v, p)
async def main():
    tmp = pathlib.Path(tempfile.mkdtemp())
    orch, stream, memory, wreg, adapter = tri._build_runtime_stack(tmp, use_k42_frontend=True)
    import gc
    from core.capabilities.adapter_runtime import AdapterRuntime
    for o in gc.get_objects():
        if isinstance(o, AdapterRuntime): o._event_stream = stream   # reviewer-side: mirror main.py:289, which passes event_stream
    print("orchestrator K4.2 flag:", getattr(orch, "_use_k42_frontend", getattr(orch, "use_k42_frontend", "?")))
    ps = tri._mock_llm_calls()
    for p in ps: p.start()
    try:
        set_trace_id("TRACE-KNOWN-1")
        ans = await orch.handle("explain recursion simply", execution_id="EXEC-KNOWN-1")
        ans2 = await orch.handle("explain recursion simply again", execution_id="EXEC-KNOWN-2")   # same task context, no set_trace_id
        evs = await stream.query(limit=100000)
    finally:
        for p in ps: p.stop()
    print("answers:", str(ans)[:60], "|", str(ans2)[:60], "| capability adapter calls:", adapter.call_count, "| events:", len(evs))
    types = {}
    for e in evs:
        p = e.payload if isinstance(e.payload, dict) else {}; raw = json.dumps(p, default=str)
        types.setdefault(e.event_type, []).append({"ids": sorted(set(walk(p))), "T1": "TRACE-KNOWN-1" in raw, "E1": "EXEC-KNOWN-1" in raw, "E2": "EXEC-KNOWN-2" in raw})
    for t, rs in types.items():
        names = sorted({k.split(".")[-1] for r in rs for k, v in r["ids"]})
        print(f"  {t:30s} n={len(rs):<3} TRACE-KNOWN-1:{sum(r['T1'] for r in rs):<2} EXEC-1:{sum(r['E1'] for r in rs):<2} EXEC-2:{sum(r['E2'] for r in rs):<2} ids={names}")
    tv = {}
    for t, rs in types.items():
        for r in rs:
            for k, v in r["ids"]:
                if k.split(".")[-1] == "trace_id": tv.setdefault(v, set()).add(t)
    print("distinct trace_id values over ALL events:", {k[:14]: sorted(v) for k, v in tv.items()})
    for k in ("root_operation_id", "operation_id", "workflow_id", "instance_id"):
        vals = {}
        for t, rs in types.items():
            for r in rs:
                for kk, v in r["ids"]:
                    if kk.split(".")[-1] == k: vals.setdefault(v[:14], set()).add(t)
        print(f"  {k}: {len(vals)} distinct -> {[(v, sorted(ts)) for v, ts in list(vals.items())[:4]]}")
    json.dump({t: rs for t, rs in types.items()}, open("/home/claude/review/out_rev_j1b_with_adapter_events.json", "w"), indent=1, default=str)
asyncio.run(main())
