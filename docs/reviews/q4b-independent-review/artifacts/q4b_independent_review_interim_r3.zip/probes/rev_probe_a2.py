"""Independent reviewer probe A (outside the repo). Sweeps a single event-store failure over every append call
of a one-node workflow, and checks the last-node hard-deadline case. Run from a disposable snapshot."""
import asyncio, sys, uuid, json, time, traceback
sys.path.insert(0, ".")
from core.workers.base import AbstractCognitiveWorker, WorkerResult
from core.runtime.worker_registry import WorkerRegistry
from core.runtime.execution_runtime import ExecutionRuntime
from core.runtime.execution_budget import ExecutionBudget
from core.runtime.cancellation import CancellationToken
from core.workflow.runtime import WorkflowRuntime
from core.workflow.definition import WorkflowDefinition, WorkflowNode
from core.governance.governance_kernel import get_governance_kernel
from core.events.event_stream import get_event_stream

class Ok(AbstractCognitiveWorker):
    worker_type = "Ok"
    async def _run(self, context): return WorkerResult(success=True, output="fine")
class Boom(AbstractCognitiveWorker):
    worker_type = "Boom"
    async def _run(self, context): raise RuntimeError("boom")
class SlowNoPoll(AbstractCognitiveWorker):
    worker_type = "SlowNoPoll"
    async def _run(self, context):
        await asyncio.sleep(2.5); return WorkerResult(success=True, output="done-late")

real = get_event_stream()
class Rec:
    def __init__(self, fail_index=None):
        self.calls = []; self.fail_index = fail_index
    def __getattr__(self, n): return getattr(real, n)
    async def append(self, *a, **k):
        i = len(self.calls) + 1
        p = k.get("payload") or {}
        self.calls.append((i, k.get("event_type"), k.get("source"), p.get("node_id"), p.get("status")))
        if self.fail_index == i:
            raise OSError("event store unavailable")
        return await real.append(*a, **k)

async def run(worker_cls, fail_index=None, budget=None):
    reg = WorkerRegistry(); reg.register(worker_cls)
    s = Rec(fail_index)
    er = ExecutionRuntime(worker_registry=reg, governance=get_governance_kernel(), event_stream=s)
    wr = WorkflowRuntime(execution_runtime=er, event_stream=s)
    snaps = []
    orig = wr._save_checkpoint
    async def spy(instance_id, workflow_id, node_states):
        snaps.append({k: v.status.value for k, v in node_states.items()})
        return await orig(instance_id, workflow_id, node_states)
    wr._save_checkpoint = spy
    before = set(asyncio.all_tasks())
    wid = "ra-" + uuid.uuid4().hex[:8]
    d = WorkflowDefinition(workflow_id=wid, nodes=[WorkflowNode(node_id="x", worker_type=worker_cls.worker_type)], entry_node="x")
    kw = {}
    tok = CancellationToken()
    if budget is not None:
        kw = {"cancellation_token": tok, "metadata": {"execution_budget": budget}}
    out = {}
    try:
        res = await wr.execute(d, query="q", **kw)
        out.update(raised=False, success=res.success, error=(res.error or "")[:70],
                   node_results={k: (v.success, (v.error or "")[:30]) for k, v in res.node_results.items()})
    except BaseException as e:
        tb = traceback.extract_tb(e.__traceback__)
        out.update(raised=type(e).__name__, raised_msg=str(e)[:60],
                   raised_at=[f"{f.filename.split('snap/')[-1]}:{f.lineno}" for f in tb if "snap/core" in f.filename][-2:])
    out["checkpoints"] = snaps
    out["token_cancelled"] = tok.is_cancelled if budget is not None else None
    await asyncio.sleep(0.2)
    cur = asyncio.current_task()
    new = [t for t in asyncio.all_tasks() if t is not cur and t not in before and not t.done()]
    out["leaked_tasks"] = sorted({t.get_coro().__qualname__ for t in new})
    for t in new: t.cancel()
    await asyncio.gather(*new, return_exceptions=True)
    return out, s.calls

async def main():
    res = {}
    bud = ExecutionBudget(startup_deadline_s=60, progress_deadline_s=60, hard_ceiling_s=1.0, absolute_ceiling_s=1.0, max_extension_s=0.0)
    for label, cls, idx in [("success_baseline", Ok, None), ("success_fail_i1_root_running", Ok, 1), ("success_fail_i3_node_running", Ok, 3),
                            ("success_fail_i7_node_completed", Ok, 7), ("success_fail_i8_root_status_completed", Ok, 8),
                            ("failing_baseline", Boom, None), ("failing_fail_i7_node_failed", Boom, 7), ("failing_fail_i8_root_status_failed", Boom, 8)]:
        r, _ = await run(cls, fail_index=idx); res[label] = r
    r, calls = await run(SlowNoPoll, budget=bud); res["last_node_deadline"] = r
    print(json.dumps(res, indent=1, default=str))
asyncio.run(main())
