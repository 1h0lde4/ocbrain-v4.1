"""Reviewer probe E (read-only against a snapshot): does DEBT-028's per-object resume() lock cover (a) execute-in-flight vs resume on the same object, (b) two WorkflowRuntime objects over one event store?"""
import asyncio, sys, os, json, tempfile, time, sqlite3
sys.path.insert(0, ".")
from core.events.event_stream import EventStream, SQLiteEventStore
from core.governance.governance_kernel import get_governance_kernel
from core.runtime.execution_runtime import ExecutionRuntime
from core.runtime.worker_registry import WorkerRegistry
from core.workers.base import AbstractCognitiveWorker, WorkerResult
from core.workflow.definition import WorkflowDefinition, WorkflowEdge, WorkflowNode
from core.workflow.runtime import WorkflowRuntime, WorkflowNodeState, NodeStatus
LOG = []
class W(AbstractCognitiveWorker):
    worker_type = "W"
    async def _run(self, context):
        node = (context.metadata or {}).get("node_id"); t0 = time.monotonic(); LOG.append((node, "start", round(t0, 2)))
        await asyncio.sleep(1.0 if node == "b" else 0.05)
        LOG.append((node, "end", round(time.monotonic(), 2))); return WorkerResult(success=True, output=node)
def mk(db):
    reg = WorkerRegistry(); reg.register(W); s = EventStream(SQLiteEventStore(db_path=db))
    return WorkflowRuntime(execution_runtime=ExecutionRuntime(worker_registry=reg, governance=get_governance_kernel(), event_stream=s), event_stream=s), s
D = WorkflowDefinition(workflow_id="w-lock", name="l", nodes=[WorkflowNode(node_id=n, worker_type="W") for n in ("a", "b")], edges=[WorkflowEdge(from_node="a", to_node="b")], entry_node="a")
def inst_from_db(db):
    con = sqlite3.connect(db); r = con.execute("SELECT DISTINCT checkpoint FROM events WHERE checkpoint LIKE 'workflow:%'").fetchall(); con.close()
    return r[0][0].split(":", 1)[1] if r else None
async def main():
    out = {}
    db = os.path.join(tempfile.mkdtemp(), "e.db"); rt, s = mk(db); LOG.clear()
    ex = asyncio.ensure_future(rt.execute(D, query="q"))
    inst = None
    for _ in range(100):
        await asyncio.sleep(0.05); inst = inst_from_db(db)
        if inst: break
    r2 = await rt.resume(D, inst, query="q")        # same object, execute() still running node b
    r1 = await ex
    out["a_execute_inflight_vs_resume_same_object"] = {"b_starts": sum(1 for l in LOG if l[0]=="b" and l[1]=="start"), "b_intervals": [l for l in LOG if l[0]=="b"], "execute_success": r1.success, "resume_success": r2.success}
    # (b) two runtime objects, one checkpoint with b pending
    db = os.path.join(tempfile.mkdtemp(), "e2.db"); rtA, sA = mk(db); rtB, sB = mk(db); LOG.clear()
    ns = {"a": WorkflowNodeState(node_id="a", status=NodeStatus.COMPLETED, result=WorkerResult(success=True, output="a")), "b": WorkflowNodeState(node_id="b", status=NodeStatus.PENDING)}
    await rtA._save_checkpoint("inst-x", "w-lock", ns)
    ra, rb = await asyncio.gather(rtA.resume(D, "inst-x", query="q"), rtB.resume(D, "inst-x", query="q"))
    out["b_two_runtime_objects_concurrent_resume"] = {"b_starts": sum(1 for l in LOG if l[0]=="b" and l[1]=="start"), "both_success": [ra.success, rb.success]}
    # (c) same object, two concurrent resumes (the case the PR's own tests cover), for contrast
    db = os.path.join(tempfile.mkdtemp(), "e3.db"); rtC, sC = mk(db); LOG.clear()
    await rtC._save_checkpoint("inst-y", "w-lock", ns)
    await asyncio.gather(rtC.resume(D, "inst-y", query="q"), rtC.resume(D, "inst-y", query="q"))
    out["c_same_object_two_concurrent_resumes"] = {"b_starts": sum(1 for l in LOG if l[0]=="b" and l[1]=="start")}
    print(json.dumps(out, indent=1))
asyncio.run(main())
