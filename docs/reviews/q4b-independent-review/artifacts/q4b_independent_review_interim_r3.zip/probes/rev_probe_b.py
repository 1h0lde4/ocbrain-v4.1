"""Reviewer probe B: does a cancelled workflow emit workflow-level terminal events? (checks probe_main2 P5b filter validity)"""
import asyncio, sys, uuid, json
sys.path.insert(0, ".")
from core.workers.base import AbstractCognitiveWorker, WorkerResult
from core.runtime.worker_registry import WorkerRegistry
from core.runtime.execution_runtime import ExecutionRuntime
from core.workflow.runtime import WorkflowRuntime
from core.workflow.definition import WorkflowDefinition, WorkflowNode, RetryPolicy
from core.governance.governance_kernel import get_governance_kernel
from core.events.event_stream import get_event_stream
real = get_event_stream()
class Rec:
    def __init__(self): self.calls = []
    def __getattr__(self, n): return getattr(real, n)
    async def append(self, *a, **k):
        p = k.get("payload") or {}
        self.calls.append((k.get("event_type"), k.get("source"), sorted(p.keys())[:8], p.get("status"), p.get("node_id") if (k.get("source") or "").startswith("Workflow") else None))
        return await real.append(*a, **k)
class Sleeper(AbstractCognitiveWorker):
    worker_type = "Sleeper"
    async def _run(self, context):
        await asyncio.sleep(30); return WorkerResult(success=True)
async def main():
    reg = WorkerRegistry(); reg.register(Sleeper); s = Rec()
    er = ExecutionRuntime(worker_registry=reg, governance=get_governance_kernel(), event_stream=s)
    wr = WorkflowRuntime(execution_runtime=er, event_stream=s)
    wid = "rb-" + uuid.uuid4().hex[:8]
    d = WorkflowDefinition(workflow_id=wid, nodes=[WorkflowNode(node_id="s", worker_type="Sleeper", retry_policy=RetryPolicy(max_retries=0))], entry_node="s")
    t = asyncio.ensure_future(wr.execute(d, query="q"))
    await asyncio.sleep(0.4); t.cancel()
    try:
        res = await t; out = {"returned": True, "success": res.success, "error": res.error}
    except BaseException as e: out = {"raised": type(e).__name__}
    await asyncio.sleep(0.1)
    out["all_events"] = [list(c) for c in s.calls]
    cur = asyncio.current_task()
    out["pending_tasks_after"] = sorted({x.get_coro().__qualname__ for x in asyncio.all_tasks() if x is not cur and not x.done()})
    print(json.dumps(out, indent=1, default=str))
asyncio.run(main())
