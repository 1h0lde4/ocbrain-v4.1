import subprocess, json, os, sys, tempfile, sqlite3
PY = "/home/claude/review/venv/bin/python"; CH = "rev_child_ckpt.py"
def run(db, log, mode, crash_at="-", fail="-", crash_ck="-", inst=None):
    a = [PY, CH, db, log, mode, crash_at, fail, crash_ck] + ([inst] if inst else [])
    p = subprocess.run(a, capture_output=True, text=True, timeout=60)
    last = [l for l in p.stdout.splitlines() if l.startswith("{")]
    return p.returncode, (json.loads(last[-1]) if last else None)
def db_view(db):
    con = sqlite3.connect(db); cols = [r[1] for r in con.execute("PRAGMA table_info(events)")]
    rows = [dict(zip(cols, r)) for r in con.execute("SELECT * FROM events ORDER BY sequence")]; con.close()
    ck = [r for r in rows if (r["checkpoint"] or "").startswith("workflow:")]
    last = None
    if ck:
        p = json.loads(ck[-1]["payload"]) if isinstance(ck[-1]["payload"], str) else ck[-1]["payload"]
        last = {n: s["status"] for n, s in p["node_states"].items()}
    node_completed_events = {}
    for r in rows:
        if r["event_type"] == "execution.node.completed":
            p = json.loads(r["payload"]) if isinstance(r["payload"], str) else r["payload"]; node_completed_events[p.get("node_id")] = node_completed_events.get(p.get("node_id"), 0) + 1
    return {"n_events": len(rows), "n_checkpoint_rows": len(ck), "last_checkpoint_states": last, "node.completed_events_in_log": node_completed_events,
            "events_mentioning_checkpoint_failure": [r["event_type"] for r in rows if "checkpoint" in (r["event_type"] or "").lower() and r["event_type"] != "system.checkpoint"]}
def counts(log):
    c = {}
    for l in open(log):
        d = json.loads(l)
        if d["node"] != "-": c.setdefault(d["node"], {"start": 0, "done": 0})[d["ev"]] += 1
    marks = [json.loads(l)["ev"] for l in open(log) if json.loads(l)["node"] == "-"]
    return c, marks
def scen(name, steps):
    d = tempfile.mkdtemp(); db = os.path.join(d, "e.db"); log = os.path.join(d, "l.jsonl"); open(log, "w").close(); out = {"scenario": name, "steps": []}; inst = None
    for st in steps:
        rc, res = run(db, log, st["mode"], st.get("crash_at", "-"), st.get("fail", "-"), st.get("crash_ck", "-"), inst if st["mode"] == "resume" else None)
        if res and res.get("instance_id") and st["mode"] == "run": inst = res["instance_id"]
        if inst is None:
            con = sqlite3.connect(db); r = con.execute("SELECT DISTINCT checkpoint FROM events WHERE checkpoint LIKE 'workflow:%'").fetchall(); con.close()
            inst = r[0][0].split(":", 1)[1] if r else None
        out["steps"].append({"args": {k: v for k, v in st.items()}, "exit": rc, "result": res})
    c, marks = counts(log); out["node_start_done_counts"] = c; out["checkpoint_marks"] = marks; out["db_after"] = db_view(db)
    return out
R = [
 scen("K1_checkpoint_call_1_fails_run_completes", [{"mode": "run", "fail": "1"}]),
 scen("K2_all_checkpoint_writes_fail_run_completes_then_resume", [{"mode": "run", "fail": "1,2,3"}, {"mode": "resume"}]),
 scen("K3_crash_exactly_before_checkpoint_2_write_then_resume", [{"mode": "run", "crash_ck": "2"}, {"mode": "resume"}]),
 scen("K4_checkpoint_2_fails_then_crash_in_c_then_resume", [{"mode": "run", "fail": "2", "crash_at": "c"}, {"mode": "resume"}]),
 scen("K5_repeated_recovery_crash_b_resume_crash_b_resume", [{"mode": "run", "crash_at": "b"}, {"mode": "resume", "crash_at": "b"}, {"mode": "resume"}]),
]
json.dump(R, open("/home/claude/review/out_rev_k.json", "w"), indent=1)
for s in R:
    print("=====", s["scenario"])
    for st in s["steps"]: print("  step", {k: v for k, v in st["args"].items()}, "exit", st["exit"], "->", {k: v for k, v in (st["result"] or {}).items() if k != "instance_id"})
    print("  starts/done:", s["node_start_done_counts"]); print("  checkpoint marks:", s["checkpoint_marks"]); print("  db:", s["db_after"])
