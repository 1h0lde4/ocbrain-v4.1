"""Reviewer probe D (SUPPLEMENTAL; embedding model STUBBED via hf_stub): Orchestrator.handle() and the /query HTTP layer under provider failure and cancellation."""
import asyncio, sys, json, importlib.util
sys.path.insert(0, "."); sys.path.insert(0, "/home/claude/review/stubplug")
import hf_stub; hf_stub.pytest_configure(None)
from unittest.mock import AsyncMock, MagicMock
spec = importlib.util.spec_from_file_location("k22", "tests/test_k2_2_runtime_migration.py"); k22 = importlib.util.module_from_spec(spec); spec.loader.exec_module(k22)
from core.model_router import RouteResult
import httpx
from interface import api

def orch_with(route):
    router = MagicMock(); router.route = route
    orch, memory, ctx, router = k22._make_orchestrator_with_workflow_runtime(router=router)
    return orch, memory

async def main():
    out = {}
    # 1. provider failure: handle() and HTTP success flag
    async def boom(*a, **k): raise RuntimeError("provider down")
    orch, memory = orch_with(boom)
    ans = await orch.handle("hello", execution_id="exec-fail-1")
    out["handle_on_provider_failure"] = {"returned": True, "answer_prefix": str(ans)[:70]}
    api.setup(orch, None)
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=api.app), base_url="http://t", headers={"X-OCBrain-Local": "1"}) as c:
        r = await c.post("/query", json={"query": "hello", "execution_id": "exec-fail-2"})
        j = r.json(); out["http_on_provider_failure"] = {"status": r.status_code, "success": j.get("success"), "error": j.get("error"), "answer_prefix": str(j.get("answer"))[:70], "meta_execution_id": (j.get("meta") or {}).get("execution_id")}
    await orch.close()
    # 2. handle() cancelled while the provider call is in flight
    async def slow(*a, **k): await asyncio.sleep(30); return RouteResult(answer="late", source="mock")
    orch, memory = orch_with(slow)
    t = asyncio.ensure_future(orch.handle("hello", execution_id="exec-cancel-1")); await asyncio.sleep(0.6); t.cancel()
    try: v = await t; out["handle_cancelled"] = {"returned": True, "answer_prefix": str(v)[:70]}
    except BaseException as e: out["handle_cancelled"] = {"raised": type(e).__name__}
    out["handle_cancelled"]["memory_write_awaited"] = memory.write.await_count
    await asyncio.sleep(0.2)
    cur = asyncio.current_task()
    out["handle_cancelled"]["pending_tasks_after"] = sorted({x.get_coro().__qualname__ for x in asyncio.all_tasks() if x is not cur and not x.done()})
    await orch.close()
    # 3. HTTP request task cancelled in flight (analogue of a client disconnect; NOT a real uvicorn disconnect)
    orch, memory = orch_with(slow); api.setup(orch, None)
    async def post():
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=api.app), base_url="http://t", headers={"X-OCBrain-Local": "1"}) as c:
            return await c.post("/query", json={"query": "hello", "execution_id": "exec-cancel-2"})
    t = asyncio.ensure_future(post()); await asyncio.sleep(0.6); t.cancel()
    try: r = await t; out["http_cancelled"] = {"returned": r.status_code, "body": r.text[:120]}
    except BaseException as e: out["http_cancelled"] = {"raised": type(e).__name__}
    await asyncio.sleep(0.2)
    out["http_cancelled"]["pending_tasks_after"] = sorted({x.get_coro().__qualname__ for x in asyncio.all_tasks() if x is not cur and not x.done()})
    out["http_cancelled"]["memory_write_awaited"] = memory.write.await_count
    # execution registry view of the cancelled executions
    try:
        from core.runtime.execution_graph import execution_registry
        for eid in ("exec-cancel-1", "exec-cancel-2"):
            g = execution_registry.get(eid)
            out.setdefault("registry", {})[eid] = None if g is None else {n: getattr(getattr(nd, "status", None), "value", str(getattr(nd, "status", None))) for n, nd in getattr(g, "nodes", {}).items()}
    except Exception as e: out["registry_error"] = f"{type(e).__name__}: {e}"[:120]
    for x in [x for x in asyncio.all_tasks() if x is not cur and not x.done()]: x.cancel()
    print(json.dumps(out, indent=1, default=str))
asyncio.run(main())
