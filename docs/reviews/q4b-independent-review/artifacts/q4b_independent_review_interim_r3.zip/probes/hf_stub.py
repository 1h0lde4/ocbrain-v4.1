"""DIAGNOSTIC ONLY (reviewer-side, outside the repo): replaces sentence_transformers.SentenceTransformer with a deterministic
hash-based stub so tests that need the unreachable huggingface.co model can show whether the model load is their only blocker.
A pass under this stub is NOT a pass of the real model path."""
import hashlib
import numpy as np
import sentence_transformers

class _Stub:
    def __init__(self, *a, **k): pass
    def get_sentence_embedding_dimension(self): return 384
    def _one(self, t):
        h = hashlib.sha256(str(t).encode()).digest()
        rng = np.random.default_rng(int.from_bytes(h[:8], "little"))
        v = rng.standard_normal(384).astype("float32"); return v / np.linalg.norm(v)
    def encode(self, sentences, *a, **k):
        if isinstance(sentences, str): return self._one(sentences)
        return np.stack([self._one(s) for s in sentences]) if len(sentences) else np.zeros((0, 384), "float32")

def pytest_configure(config):
    sentence_transformers.SentenceTransformer = _Stub
