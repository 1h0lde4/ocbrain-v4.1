"""Reviewer child process (outside the repo; run from a snapshot dir). Workflow a->b->c on a persistent SQLite event store with deterministic
checkpoint-persistence fault injection. argv: DB LOG MODE(run|resume) CRASH_AT(node|-) FAIL_CKPT(comma list of 1-based call numbers|-) CRASH_ON_CKPT(n|-) [INSTANCE]"""
import asyncio, json, os, sys
sys.path.insert(0, os.getcwd())
DB, LOG, MODE, CRASH_AT, FAIL, CRASH_CK = sys.argv[1:7]
INSTANCE = sys.argv[7] if len(sys.argv) > 7 else None
FAILSET = {int(x) for x in FAIL.split(",")} if FAIL != "-" else set()
from core.events.event_stream import EventStream, SQLiteEventStore
from core.governance.governance_kernel import get_governance_kernel
from core.runtime.execution_runtime import ExecutionRuntime
from core.runtime.worker_registry import WorkerRegistry
from core.workers.base import AbstractCognitiveWorker, WorkerResult
from core.workflow.definition import WorkflowDefinition, WorkflowEdge, WorkflowNode
from core.workflow.runtime import WorkflowRuntime
def log(node, ev):
    with open(LOG, "a") as f: f.write(json.dumps({"pid": os.getpid(), "node": node, "ev": ev}) + "\n")
class W(AbstractCognitiveWorker):
    worker_type = "W"
    async def _run(self, context):
        node = (context.metadata or {}).get("node_id"); log(node, "start")
        if CRASH_AT == node: os._exit(137)
        log(node, "done"); return WorkerResult(success=True, output=f"done:{node}")
D = WorkflowDefinition(workflow_id="w-ckpt", name="ck", nodes=[WorkflowNode(node_id=n, worker_type="W") for n in "abc"],
                       edges=[WorkflowEdge(from_node="a", to_node="b"), WorkflowEdge(from_node="b", to_node="c")], entry_node="a")
reg = WorkerRegistry(); reg.register(W)
stream = EventStream(SQLiteEventStore(db_path=DB))
calls = {"n": 0}
orig = stream.create_checkpoint
async def patched(*a, **k):
    calls["n"] += 1; n = calls["n"]
    if n in FAILSET: log("-", f"checkpoint_call_{n}_RAISED"); raise OSError("checkpoint store unavailable")
    if CRASH_CK != "-" and n == int(CRASH_CK): log("-", f"checkpoint_call_{n}_CRASH_BEFORE_WRITE"); os._exit(137)
    r = await orig(*a, **k); log("-", f"checkpoint_call_{n}_written"); return r
stream.create_checkpoint = patched
rt = WorkflowRuntime(execution_runtime=ExecutionRuntime(worker_registry=reg, governance=get_governance_kernel(), event_stream=stream), event_stream=stream)
async def main():
    r = await (rt.execute(D, query="q") if MODE == "run" else rt.resume(D, INSTANCE, query="q"))
    print(json.dumps({"success": r.success, "error": (r.error or "")[:80], "instance_id": r.instance_id, "nodes": {k: v.success for k, v in r.node_results.items()}}), flush=True)
asyncio.run(main())
