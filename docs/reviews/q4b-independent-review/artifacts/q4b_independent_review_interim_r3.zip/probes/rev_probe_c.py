"""Reviewer probe C: resume() after cancelled / deadlined runs; checkpoint content after cancellation (runtime gap groups 2 and 3)."""
import asyncio, sys, os, json, tempfile, uuid
sys.path.insert(0, ".")
from core.events.event_stream import EventStream, SQLiteEventStore
from core.governance.governance_kernel import get_governance_kernel
from core.runtime.execution_runtime import ExecutionRuntime
from core.runtime.execution_budget import ExecutionBudget
from core.runtime.cancellation import CancellationToken
from core.runtime.worker_registry import WorkerRegistry
from core.workers.base import AbstractCognitiveWorker, WorkerResult
from core.workflow.definition import WorkflowDefinition, WorkflowEdge, WorkflowNode, RetryPolicy
from core.workflow.runtime import WorkflowRuntime

RUNS = []          # every worker invocation: (phase, node)
PHASE = ["first"]
BEHAV = {}         # node -> coroutine factory name
class W(AbstractCognitiveWorker):
    worker_type = "W"
    async def _run(self, context):
        node = (context.metadata or {}).get("node_id")
        RUNS.append((PHASE[0], node))
        b = BEHAV.get(node, "ok")
        if b == "slow_nopoll": await asyncio.sleep(2.5)
        elif b == "sleep30": await asyncio.sleep(30)
        elif b == "fail_first" and sum(1 for r in RUNS if r[1] == node) == 1: raise RuntimeError("transient")
        return WorkerResult(success=True, output=f"done:{node}")

def build(db, retry_a=None):
    reg = WorkerRegistry(); reg.register(W)
    s = EventStream(SQLiteEventStore(db_path=db))
    wr = WorkflowRuntime(execution_runtime=ExecutionRuntime(worker_registry=reg, governance=get_governance_kernel(), event_stream=s), event_stream=s)
    na = WorkflowNode(node_id="a", worker_type="W", retry_policy=retry_a) if retry_a else WorkflowNode(node_id="a", worker_type="W")
    d = WorkflowDefinition(workflow_id="w-cancel-resume", name="cr", nodes=[na, WorkflowNode(node_id="b", worker_type="W")],
                           edges=[WorkflowEdge(from_node="a", to_node="b")], entry_node="a")
    return wr, s, d

async def ckpt(wr, s, inst):
    c = await s.get_checkpoint(wr._checkpoint_name(inst))
    if c is None: return None
    return {n: (v["status"], v.get("attempts")) for n, v in (c.payload or {}).get("node_states", {}).items()}

def summ(r):
    return {"success": r.success, "error": (r.error or "")[:60], "nodes": {k: (v.success, (v.error or "")[:25]) for k, v in r.node_results.items()}}

async def scenario(name, setup):
    RUNS.clear(); PHASE[0] = "first"; BEHAV.clear()
    db = os.path.join(tempfile.mkdtemp(), "ev.db")
    out = {"scenario": name}
    wr, s, d = setup["build"](db)
    BEHAV.update(setup["behav"])
    inst = None
    try:
        r = await setup["run"](wr, d)
        out["first_run"] = summ(r); inst = r.instance_id
    except BaseException as e:
        out["first_run"] = {"raised": type(e).__name__}
        # instance id unknown after a raise: recover from the event store checkpoint names
        import sqlite3
        con = sqlite3.connect(db); row = con.execute("SELECT DISTINCT checkpoint FROM events WHERE checkpoint LIKE 'workflow:%'").fetchall(); con.close()
        inst = row[0][0].split(":", 1)[1] if row else None
        out["checkpoint_names_found"] = len(row)
    await asyncio.sleep(0.1)
    out["checkpoint_after_first_run"] = await ckpt(wr, s, inst) if inst else "no instance id / no checkpoint"
    # fresh objects over the same SQLite file, then resume
    PHASE[0] = "resume"; BEHAV.clear()
    wr2, s2, d2 = setup["build"](db)
    if inst:
        r2 = await wr2.resume(d2, inst, query="q")
        out["resume"] = summ(r2)
        out["checkpoint_after_resume"] = await ckpt(wr2, s2, inst)
    else:
        r2 = await wr2.resume(d2, "does-not-exist", query="q"); out["resume_unknown_instance"] = summ(r2)
    out["worker_invocations"] = RUNS[:]
    cur = asyncio.current_task()
    for t in [t for t in asyncio.all_tasks() if t is not cur and not t.done()]: t.cancel()
    return out

async def main():
    res = []
    bud = ExecutionBudget(startup_deadline_s=60, progress_deadline_s=60, hard_ceiling_s=1.0, absolute_ceiling_s=1.0, max_extension_s=0.0)
    async def run_deadline(wr, d):
        return await wr.execute(d, query="q", cancellation_token=CancellationToken(), metadata={"execution_budget": bud})
    res.append(await scenario("S1_hard_deadline_non_polling_node_a_then_resume", {"build": build, "behav": {"a": "slow_nopoll"}, "run": run_deadline}))
    async def run_asyncio_cancel(wr, d):
        t = asyncio.ensure_future(wr.execute(d, query="q")); await asyncio.sleep(0.4); t.cancel(); return await t
    res.append(await scenario("S2_asyncio_cancel_swallowed_by_worker_then_resume", {"build": build, "behav": {"a": "sleep30"}, "run": run_asyncio_cancel}))
    def build_retry(db): return build(db, retry_a=RetryPolicy(max_retries=1, backoff_seconds=5.0, max_backoff_seconds=5.0))
    async def run_backoff_cancel(wr, d):
        t = asyncio.ensure_future(wr.execute(d, query="q")); await asyncio.sleep(0.6); t.cancel(); return await t
    res.append(await scenario("S3_asyncio_cancel_during_retry_backoff_then_resume", {"build": build_retry, "behav": {"a": "fail_first"}, "run": run_backoff_cancel}))
    print(json.dumps(res, indent=1, default=str))
asyncio.run(main())
