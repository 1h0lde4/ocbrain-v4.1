import asyncio, sys, json, os, tempfile, sqlite3
sys.path.insert(0, ".")
from core.events.event_stream import EventStream, SQLiteEventStore
from core.governance.governance_kernel import get_governance_kernel
from core.runtime.execution_runtime import ExecutionRuntime
from core.runtime.worker_registry import WorkerRegistry
from core.workers.base import AbstractCognitiveWorker, WorkerResult
from core.workflow.definition import WorkflowDefinition, WorkflowEdge, WorkflowNode
from core.workflow.runtime import WorkflowRuntime
class W(AbstractCognitiveWorker):
    worker_type = "W"
    async def _run(self, context):
        return WorkerResult(success=True, output="x", metadata={"seen_meta_keys": sorted((context.metadata or {}).keys())})
async def main():
    db = os.path.join(tempfile.mkdtemp(), "f.db"); reg = WorkerRegistry(); reg.register(W); s = EventStream(SQLiteEventStore(db_path=db))
    rt = WorkflowRuntime(execution_runtime=ExecutionRuntime(worker_registry=reg, governance=get_governance_kernel(), event_stream=s), event_stream=s)
    d = WorkflowDefinition(workflow_id="w-id", name="id", nodes=[WorkflowNode(node_id="a", worker_type="W")], entry_node="a", root_operation_id="ROOT-OP-1")
    r = await rt.execute(d, query="q", metadata={"execution_id": "CLIENT-EXEC-1"})
    print("WorkflowResult.instance_id:", r.instance_id[:8], "| node a metadata:", r.node_results["a"].metadata)
    con = sqlite3.connect(db); cols = [c[1] for c in con.execute("PRAGMA table_info(events)")]
    mapping = {}
    for row in con.execute("SELECT * FROM events ORDER BY sequence"):
        dd = dict(zip(cols, row)); p = json.loads(dd["payload"]) if isinstance(dd["payload"], str) else dd["payload"]
        ids = {k: (str(v)[:10]) for k, v in (p or {}).items() if k in ("instance_id", "execution_id", "workflow_id", "task_id", "attempt_id", "root_operation_id", "trace_id", "node_id")}
        mapping.setdefault(dd["event_type"], ids)
    for et, ids in mapping.items(): print(f"  {et:26s} {ids}")
    both = [et for et, ids in mapping.items() if "instance_id" in ids and "execution_id" in ids]
    print("event types carrying BOTH instance_id and execution_id:", both)
    print("any event carrying root_operation_id:", [et for et, ids in mapping.items() if "root_operation_id" in ids])
asyncio.run(main())
