#!/bin/sh
# usage: guarded_install.sh FIRST LAST  (1-based line range of stage2_pkgs.txt)
MIN_KB=1400000
sed -n "$1,$2p" stage2_pkgs.txt | while read pkg; do
  avail=$(df -k /home/claude | tail -1 | awk '{print $4}')
  if [ "$avail" -lt "$MIN_KB" ]; then echo "ABORT before $pkg: avail_kb=$avail < $MIN_KB"; exit 3; fi
  echo "== installing $pkg (avail_kb=$avail)"
  /home/claude/review/venv/bin/pip install --no-deps --no-cache-dir --quiet "$pkg" 2>&1 | tail -2
  echo "   done rc=$? avail_kb_after=$(df -k /home/claude | tail -1 | awk '{print $4}')"
done
