"""Reproduces the cross-baseline comparison. Run from the bundle root: python3 compare_baselines.py
Normalization applied to every JSON output before comparison: (1) the key 'raised_at' is dropped (it contains local paths);
(2) every string has full UUIDs and bare 8-hex-digit tokens replaced by '<id>'; (3) every float is rounded to 0 decimals.
Nothing else is altered. Inputs: baseline_outputs/<commit>/<probe>.json, produced by running the probe script against a `git archive <commit>` snapshot."""
import json, re, hashlib, itertools, os
U = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}|\b[0-9a-f]{8}\b")
def norm(x):
    if isinstance(x, dict): return {k: norm(v) for k, v in x.items() if k != "raised_at"}
    if isinstance(x, list): return [norm(v) for v in x]
    if isinstance(x, str): return U.sub("<id>", x)
    if isinstance(x, float): return round(x, 0)
    return x
PROBES = ["probe_main", "probe_main2", "probe_main3", "probe_main4", "probe_main5", "rev_probe_a2", "rev_probe_b", "rev_probe_c"]
BASES = ["16d663a", "ed3d141", "2491ae4"]
data = {}
for b in BASES:
    for p in PROBES:
        path = f"baseline_outputs/{b}/{p}.json"; raw = open(path, "rb").read()
        data[(b, p)] = (norm(json.loads(raw)), hashlib.sha256(raw).hexdigest())
print("raw output SHA-256 per baseline/probe:")
for p in PROBES: print(f"  {p:14s}", "  ".join(f"{b}:{data[(b, p)][1][:12]}" for b in BASES))
print("\nnormalized equality:")
allok = True
for a, b in itertools.combinations(BASES, 2):
    res = {p: data[(a, p)][0] == data[(b, p)][0] for p in PROBES}; allok &= all(res.values())
    print(f"  {a} vs {b}: {sum(res.values())}/{len(PROBES)} identical", "" if all(res.values()) else [p for p, v in res.items() if not v])
print("\nALL IDENTICAL:", allok)
