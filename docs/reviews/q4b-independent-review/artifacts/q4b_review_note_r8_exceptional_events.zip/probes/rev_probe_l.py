"""Reviewer probe L (read-only, snapshot): trigger the two exceptional-path events and print their REAL emitted payloads.
L1 cognitive.planner_impasse_terminal: reuses the repo's own fixture (tests/test_orchestrator_recovery.py; mocked planner/event stream, as that test does).
L2 orchestrator.response_incomplete: K4.2 runtime-integration stack with the WorkflowRuntime result REPLACED by a stub WorkflowResult carrying constraint_violations (the Orchestrator's own emission code runs; the runtime result is reviewer-supplied)."""
import asyncio, sys, json, importlib.util, tempfile, pathlib, dataclasses
from unittest.mock import patch, AsyncMock
sys.path.insert(0, ".")
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
async def main():
    rec = load("rec", "tests/test_orchestrator_recovery.py")
    orch, _, stream = rec._make_orchestrator(max_recovery_attempts=1)
    goal = rec._goal()
    with patch("core.cognitive.intent.interpret_request", new=AsyncMock(return_value=[goal])), patch("core.cognitive.planner.plan", new=AsyncMock(return_value=rec._impasse(op_id="op-final"))):
        await orch.handle("an impossible request")
    calls = [c for c in stream.append.call_args_list if c.kwargs.get("event_type") == "cognitive.planner_impasse_terminal"]
    print("L1 planner_impasse_terminal emitted:", len(calls), "| payload keys:", sorted(calls[0].kwargs["payload"].keys()) if calls else None)
    if calls: print("   payload (trimmed):", json.dumps({k: (str(v)[:48]) for k, v in calls[0].kwargs["payload"].items()}))
    tri = load("tri", "tests/test_runtime_integration.py")
    from core.workflow.runtime import WorkflowResult
    fields = {f.name: f for f in dataclasses.fields(WorkflowResult)}
    orch2, stream2, memory2, wreg2, adapter2 = tri._build_runtime_stack(pathlib.Path(tempfile.mkdtemp()), use_k42_frontend=True)
    real_execute = orch2._workflow_runtime.execute
    async def stub_execute(*a, **k):
        r = await real_execute(*a, **k)
        r.constraint_violations = ["reviewer-supplied violation: output too short"]
        return r
    orch2._workflow_runtime.execute = stub_execute
    ps = tri._mock_llm_calls()
    for p in ps: p.start()
    try: ans = await orch2.handle("explain recursion simply", execution_id="EXEC-L2")
    finally:
        for p in ps: p.stop()
    evs = [e for e in await stream2.query(limit=100000) if e.event_type in ("orchestrator.response_incomplete", "orchestrator.query_completed", "workflow.completed")]
    print("L2 answer:", str(ans)[:60])
    for e in evs: print(f"   {e.event_type:32s} {json.dumps({k: (str(v)[:40]) for k, v in e.payload.items()})}")
asyncio.run(main())
