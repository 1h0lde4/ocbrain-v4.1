"""Reviewer probe K (read-only, snapshot): K4.2 production-flag stack (repo runtime-integration fixture; LLM calls faked).
K1 interaction_id for identical vs different queries; K2 /query vs /brain/v2/query identity (both mounted by main.py wiring: interface/api.py setup() -> register_brain_api);
K3 the REAL ModelRouterAdapter (main.py:283 registers it for LLM_COMPLETION) over a fake ModelRouter, for provider exception / ExecutionOutcome failure / success."""
import asyncio, sys, json, importlib.util, tempfile, pathlib
from unittest.mock import MagicMock
sys.path.insert(0, ".")
spec = importlib.util.spec_from_file_location("tri", "tests/test_runtime_integration.py"); tri = importlib.util.module_from_spec(spec); spec.loader.exec_module(tri)
import httpx
from interface import api
from core.capabilities.capability import CapabilityType
from core.capabilities.adapters.model_router_adapter import ModelRouterAdapter
from core.model_router import RouteResult
from core.runtime.execution_outcome import ExecutionOutcome, FailureType
H = {"X-OCBrain-Local": "1"}
def pl(e): return e.payload if isinstance(e.payload, dict) else {}
async def new_events(stream, before): return [e for e in await stream.query(limit=100000) if e.sequence > before]
async def last_seq(stream): return max([e.sequence for e in await stream.query(limit=100000)] or [0])
async def main():
    out = {}
    ps = tri._mock_llm_calls()
    for p in ps: p.start()
    try:
        # K1
        orch, stream, memory, wreg, adapter = tri._build_runtime_stack(pathlib.Path(tempfile.mkdtemp()), use_k42_frontend=True)
        b = await last_seq(stream)
        await asyncio.gather(orch.handle("explain recursion simply", execution_id="EXEC-A"), orch.handle("explain recursion simply", execution_id="EXEC-B"), orch.handle("explain loops simply", execution_id="EXEC-C"))
        ids = [(pl(e).get("interaction_id") or "")[:24] for e in await new_events(stream, b) if e.event_type == "orchestrator.query_started"]
        out["K1_interaction_ids_for_[same,same,different]_queries_run_concurrently"] = {"values": ids, "distinct": len(set(ids))}
        # K2
        api.setup(orch, None)
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=api.app), base_url="http://t", headers=H) as c:
            for label, path, body in (("/query with client execution_id", "/query", {"query": "explain trees simply", "execution_id": "CLIENT-X"}), ("/brain/v2/query (no execution_id field)", "/brain/v2/query", {"query": "explain graphs simply"})):
                b = await last_seq(stream); r = await c.post(path, json=body); ev = await new_events(stream, b)
                exec_ids = sorted({pl(e).get("execution_id") for e in ev if pl(e).get("execution_id")}); inst = sorted({pl(e).get("instance_id") for e in ev if pl(e).get("instance_id")})
                out[f"K2 {label}"] = {"http": r.status_code, "execution_ids_in_events": exec_ids, "instance_ids_in_events": inst, "execution_id_equals_instance_id": exec_ids == inst and len(inst) == 1}
        await orch.close() if hasattr(orch, "close") else None
        # K3
        for label, behavior in (("router raises RuntimeError", "raise"), ("router returns ExecutionOutcome PROVIDER_FAILURE", "outcome_fail"), ("router returns normal answer", "ok")):
            orch, stream, memory, wreg, adapter = tri._build_runtime_stack(pathlib.Path(tempfile.mkdtemp()), use_k42_frontend=True)
            router = MagicMock()
            async def route(*a, _b=behavior, **k):
                if _b == "raise": raise RuntimeError("provider down")
                if _b == "outcome_fail": return RouteResult(answer="", source="mock", execution_detail=ExecutionOutcome(failure_type=FailureType.PROVIDER_FAILURE, detail="provider failed"))
                return RouteResult(answer="a real answer", source="mock", execution_detail=ExecutionOutcome(failure_type=FailureType.SUCCESS))
            router.route = route
            orch._capability_registry._adapters[CapabilityType.LLM_COMPLETION].clear()   # reviewer-side: the registry appends in priority order, so the fixture's fake would otherwise win
            orch._capability_registry.register_adapter(CapabilityType.LLM_COMPLETION, ModelRouterAdapter(router))
            real_adapters = [type(a).__name__ for a in orch._capability_registry.get_adapters(CapabilityType.LLM_COMPLETION)]
            b = await last_seq(stream); api.setup(orch, None)
            async with httpx.AsyncClient(transport=httpx.ASGITransport(app=api.app), base_url="http://t", headers=H) as c:
                r = await c.post("/query", json={"query": "explain recursion simply", "execution_id": "K3"}); j = r.json()
            ev = await new_events(stream, b)
            out[f"K3 real ModelRouterAdapter: {label}"] = {"adapters_registered": real_adapters, "fake_adapter_calls": adapter.call_count, "workflow.completed.success": [pl(e).get("success") for e in ev if e.event_type == "workflow.completed"],
                "worker.completed.success": [pl(e).get("success") for e in ev if e.event_type == "worker.completed"], "orchestrator.query_completed.outcome": [pl(e).get("outcome") for e in ev if e.event_type == "orchestrator.query_completed"],
                "http": {"status": r.status_code, "success": j.get("success"), "error": j.get("error"), "answer": str(j.get("answer"))[:40]}}
    finally:
        for p in ps: p.stop()
    print(json.dumps(out, indent=1))
asyncio.run(main())
