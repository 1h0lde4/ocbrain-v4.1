# Generic Python check (NOT through interface/voice.py): asyncio.create_task() called from a plain thread, as _handle_voice would be.
import asyncio, threading
async def work(): return 1
res = {}
def cb():
    coro = work()
    try: asyncio.create_task(coro); res["r"] = "created"
    except Exception as e: res["r"] = f"{type(e).__name__}: {e}"; coro.close()
async def main():
    t = threading.Thread(target=cb); t.start(); t.join()
asyncio.run(main()); print(res["r"])
