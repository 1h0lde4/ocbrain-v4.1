# Repeated live check — comparison

batch `20261012T121543Z` | mode **LIVE** | model requested `llama3` -> `llama3:latest` id `365c0bd3c000` 4.7 GB
commit `e305f2091802a02b01d607b9baf05fa08fdc6535` (DIRTY) | python 3.11.9 | 2026-10-12T12:15:43Z -> 2026-10-12T12:39:40Z
dirty files at batch start: `?? .ocbrain_install_state`; `?? .python-version`; `?? .python_selected`
isolation: every run executed in its own fresh process (worker pids 7728, 12096, 16424)
model id unchanged across the batch: **True**

> Observations for ONE model at default sampling over N runs. PASS = no contradiction found, not proof.

## Steps per plan (per request, per run)

| request | run 0 | run 1 | run 2 | run 3 | min–max (runs 1..N) |
|---|---|---|---|---|---|
| write a 1000 words story | 7 | 7 | 7 | 9 | 7–9 |
| write a story | 6 | 9 | 8 | 7 | 7–9 |
| write a poem | 7 | 8 | 8 | 6 | 6–8 |
| write me an essay | 7 | 13 | 7 | 12 | 7–13 |
| tell me a joke | 5 | 4 | 4 | 1 | 1–4 |
| write a long story please | 11 | 8 | 8 | 9 | 8–9 |
| Write a 500 word story. | 5 | 8 | 8 | 8 | 8–8 |
| compose a song | 7 | 5 | 7 | 8 | 5–8 |
| write a novel | 9 | 8 | 7 | 9 | 7–9 |
| write a 5000 word story | 7 | 10 | 7 | 7 | 7–10 |
| write a 10000 word essay | 12 | 7 | 8 | 10 | 7–10 |

## Per run

| run | valid | median | total | single-step | over cap | premise-word hits | story→character | essay→argument |
|---|---|---|---|---|---|---|---|---|
| 0 (supplied) | n/a | 7 | 83 | 0 | 9 | n/a | n/a | n/a |
| 1 | yes | 8 | 87 | 0 | 9 | 0 | 6/6 | 2/2 |
| 2 | yes | 7 | 79 | 0 | 10 | 0 | 6/6 | 2/2 |
| 3 | yes | 8 | 86 | 1 | 10 | 0 | 6/6 | 2/2 |

## Pre-registered criteria

valid runs: 3/3

- **FAIL** — C1 every plan multi-step (no single-step plan in any run)
- **PASS** — C2 per-run median steps in [5,9] and >= 7 plans over the 5-step cap
- **PASS** — C3 no concrete-premise word in any step (lexicon screen; human read still required)
- **PASS** — C4 form/process presupposition recurs: >= 5 story plans with a character step and >= 1 essay plan with an argument/research step, in every run

**Overall: FAIL**

## Category counts per run (plans containing each; descriptive)

| run | character_structure | plot_devices | worldbuilding | argument_research | human_workflow | tooling |
|---|---|---|---|---|---|---|
| 1 | 6 | 1 | 4 | 4 | 4 | 0 |
| 2 | 6 | 2 | 5 | 3 | 4 | 0 |
| 3 | 6 | 5 | 6 | 2 | 4 | 0 |
